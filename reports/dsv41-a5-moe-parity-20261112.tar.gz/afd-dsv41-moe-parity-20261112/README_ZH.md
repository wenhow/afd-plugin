# A5 单层 MoE TP1/TP4 对照

在已配置 CANN/ATB 的 shell 中，从本目录执行一次：

```bash
/usr/local/python3.11.10/bin/python -B tools/diagnostics/run_dsv41_a5_moe_parity.py \
  --model /home/models/DeepSeek-V4.1-Flash \
  --transformer-vendor /usr/local/Ascend/ascend-toolkit/latest/opp/vendors/custom_transformer \
  --output-root /mnt/workspace/tmp \
  --run
```

默认先单卡0执行TP1，再用0,1,2,3执行TP4；同一真实第0层权重及固定输入。
去掉--run只读取metadata/源码，无需再单独跑该前置步骤。回传打印的诊断.tar.gz，
失败也保留归档。该包不安装依赖、不包含模型权重、不修改上游源码。

A3已经通过真实包导入/TP1及TP4配置和默认metadata归档，数值计算仍待A5。
execution_success不等于模型等价；TP1/TP4误差只记录供分析，不预设容忍度。
实际num_hash_layers默认0，不强造Hash MoE。完整模型/AFD/Engram/性能不在此组件内。
source-manifest.json记录基线及逐文件SHA256；暂停的MTP和其他工作区改动不在包内。
