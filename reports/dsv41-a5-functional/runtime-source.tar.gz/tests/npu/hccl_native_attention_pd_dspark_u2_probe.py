# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Two real retained P prefixes and native two-request D verification.

Runtime dependencies are loaded only by the supervised NPU worker. This
successor retains the original native Scheduler, PD, sampling and proposal;
the target/FFN arithmetic remains controlled and serving remains guarded.
"""

from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import asdict

PROMPTS = ((11, 12, 13, 14, 15), (21, 22, 23, 24, 25))
REQUEST_COUNT = len(PROMPTS)
QUERY_ROWS = 3
DRAFT_ROWS = 2
MAX_OUTPUT_TOKENS = 4
POLL_SECONDS = 0.1


def check_native_draft_writes(
    bindings,
    pages,
    before,
    after,
    state,
    blocks_by_request,
    positions_by_request,
    accepted_context_counts,
    detail,
):
    """Check actual query/context slots and protect every other physical byte."""
    from hccl_native_attention_pd_dspark_decode_probe import row_location
    from vllm.v1.attention.backends.utils import PAD_SLOT_ID

    speculator = bindings.owner.speculator
    batch = state.input_batch
    request_ids = list(batch.req_ids)
    assert set(request_ids) == set(blocks_by_request)
    assert speculator.num_query_per_req == DRAFT_ROWS
    masks = [bytearray(len(raw)) for raw in before]
    context_positions, query_positions = [], []
    for request_id in request_ids:
        positions = positions_by_request[request_id]
        accepted = accepted_context_counts[request_id]
        assert 0 < accepted <= len(positions)
        context_positions.extend(positions[:accepted])
        context_positions.extend([0] * (len(positions) - accepted))
        frontier = positions[accepted - 1] + 1
        query_positions.extend(range(frontier, frontier + DRAFT_ROWS))
    assert speculator.context_positions[: batch.num_tokens].cpu().tolist() == (
        context_positions
    )
    assert (
        speculator.input_buffers.positions[: len(request_ids) * DRAFT_ROWS]
        .cpu()
        .tolist()
        == query_positions
    )
    groups = tuple(speculator.draft_kv_cache_group_ids)
    records = []
    for name in speculator.model.get_draft_kv_cache_layer_names():
        group_id = next(
            index
            for index, group in enumerate(bindings.kv_config.kv_cache_groups)
            if name in group.layer_names
        )
        cache = bindings.caches[name]
        block_size = cache.shape[1]
        expected_query, expected_context = [], []
        for ordinal, request_id in enumerate(request_ids):
            blocks = blocks_by_request[request_id][group_id]
            positions = positions_by_request[request_id]
            accepted = accepted_context_counts[request_id]
            for position in query_positions[
                ordinal * DRAFT_ROWS : (ordinal + 1) * DRAFT_ROWS
            ]:
                expected_query.append(
                    blocks[position // block_size] * block_size + position % block_size
                )
            for position in positions[:accepted]:
                expected_context.append(
                    blocks[position // block_size] * block_size + position % block_size
                )
            expected_context.extend([PAD_SLOT_ID] * (len(positions) - accepted))
        actual_query = (
            speculator.block_tables.slot_mappings[group_id][
                : len(request_ids) * DRAFT_ROWS
            ]
            .cpu()
            .tolist()
        )
        actual_context = (
            speculator._context_slot_mappings[groups.index(group_id)][
                : batch.num_tokens
            ]
            .cpu()
            .tolist()
        )
        assert actual_query == expected_query and actual_context == expected_context
        records.append(
            {
                "layer": name,
                "query_slots": actual_query,
                "context_slots": actual_context,
                "allowed_write_ranges": [],
            }
        )
        for slot in expected_query + expected_context:
            if slot == PAD_SLOT_ID:
                continue
            block, position = divmod(slot, block_size)
            assert block > 0
            pool, begin, size = row_location(cache, pages, block, position)
            masks[pool][begin : begin + size] = b"\1" * size
            records[-1]["allowed_write_ranges"].append([pool, begin, size])
    for old, new, mask in zip(before, after, masks, strict=True):
        assert len(old) == len(new) == len(mask)
        assert all(
            first == second
            for first, second, allowed in zip(old, new, mask, strict=True)
            if not allowed
        )
    detail["native_draft_write_mappings"] = records
    detail["all_bytes_outside_native_draft_write_rows_unchanged"] = True


def run_prefill_sources(args, bindings, report, deadline, *, prompts=PROMPTS):
    """Produce distinct native prefixes sequentially on one eager P owner."""
    import torch
    from hccl_native_attention_pd_aux_probe import batch_coordinates
    from hccl_native_attention_pd_dspark_decode_probe import target_reference
    from hccl_native_attention_pd_dspark_run_probe import (
        await_record,
        physical_pages,
        save_tensor,
        snapshot_pages,
        write_json,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    from afd_plugin.compat.npu.dspark_pd import source_request_from_payload
    from afd_plugin.compat.npu.kv_layout_connector import DSPARK_SOURCE_PARAM

    owner, config = bindings.owner, bindings.owner.vllm_config
    assert prompts and len(set(prompts)) == len(prompts)
    assert config.model_config.enforce_eager
    assert config.scheduler_config.max_num_seqs == 1
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        StructuredOutputManager(config),
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    idle_usage = scheduler.kv_cache_manager.usage
    layout, pages = physical_pages(bindings)
    report["layout"] = json.loads(layout.to_json())
    sources = report["sources"] = []
    retained = []
    for ordinal, prompt in enumerate(prompts):
        request_id = f"{args.run_id}-source-{ordinal}"
        request = Request(
            request_id,
            list(prompt),
            SamplingParams(
                temperature=0,
                max_tokens=3,
                extra_args={
                    "kv_transfer_params": {
                        "do_remote_prefill": False,
                        "do_remote_decode": True,
                    }
                },
            ),
            None,
        )
        scheduler.add_request(request)
        assert request.prompt_token_ids == list(prompt[:-1]) and request.max_tokens == 1
        step = scheduler.schedule()
        assert step.num_scheduled_tokens == {request_id: len(prompt) - 1}
        assert len(step.scheduled_new_reqs) == 1
        blocks = tuple(tuple(ids) for ids in step.scheduled_new_reqs[0].block_ids)
        assert len(blocks) == len(bindings.kv_config.kv_cache_groups)
        assert all(ids and all(block > 0 for block in ids) for ids in blocks)
        for previous in retained:
            assert all(
                not set(old).intersection(new)
                for old, new in zip(previous["blocks"], blocks, strict=True)
            )
        detail = {
            "request_id": request_id,
            "prompt": list(prompt),
            "blocks": blocks,
            "schedule": scheduler_record(step),
            "before_target": snapshot_pages(
                pages, args.output_dir, f"producer-{ordinal}-before-target"
            ),
        }
        sources.append(detail)
        before = [bytes(page.cpu().numpy()) for page in pages]
        expected, auxiliary, expected_pages, layers = target_reference(
            bindings,
            pages,
            before,
            blocks,
            prompt[:-1],
            tuple(range(len(prompt) - 1)),
            step.new_block_ids_to_zero,
        )
        assert owner.execute_model(step) is None
        state = owner.execute_model_state
        assert state is not None and state.aux_hidden_states is not None
        coordinates = batch_coordinates(state)
        assert coordinates["request_ids"] == [request_id]
        assert coordinates["input_ids"] == list(prompt[:-1])
        assert coordinates["positions"] == list(range(len(prompt) - 1))
        assert coordinates["num_computed_tokens"] == [0]
        detail["native_request_index"] = owner.req_states.req_id_to_index[request_id]
        assert detail["native_request_index"] == 0
        assert torch.equal(state.hidden_states.cpu(), expected)
        assert all(
            torch.equal(actual.cpu(), reference)
            for actual, reference in zip(
                state.aux_hidden_states, auxiliary, strict=True
            )
        )
        actual_pages = [bytes(page.cpu().numpy()) for page in pages]
        assert actual_pages == expected_pages
        detail["target_after"] = snapshot_pages(
            pages, args.output_dir, f"producer-{ordinal}-after-target"
        )
        detail["hidden"] = save_tensor(
            state.hidden_states, args.output_dir / f"producer-{ordinal}-hidden.bin"
        )
        detail["expected_hidden"] = save_tensor(
            expected, args.output_dir / f"producer-{ordinal}-expected-hidden.bin"
        )
        detail["auxiliary"] = [
            {
                "actual": save_tensor(
                    actual,
                    args.output_dir / f"producer-{ordinal}-aux-{layer}.bin",
                ),
                "expected": save_tensor(
                    reference,
                    args.output_dir / f"producer-{ordinal}-expected-aux-{layer}.bin",
                ),
            }
            for layer, (actual, reference) in enumerate(
                zip(state.aux_hidden_states, auxiliary, strict=True)
            )
        ]
        pointers = [
            value.data_ptr()
            for value in (state.hidden_states, *state.aux_hidden_states)
        ]
        returned = owner.sample_tokens(None)
        assert isinstance(returned, AsyncOutput)
        output = returned.get_output()
        assert output.req_ids == [request_id] and output.sampled_token_ids == [[7]]
        assert owner.execute_model_state is None
        assert owner._dspark_pd_pending_scheduler is None
        assert not owner.dspark_pd_consumer.terminal
        assert batch_coordinates(state) == coordinates
        assert [
            value.data_ptr()
            for value in (state.hidden_states, *state.aux_hidden_states)
        ] == pointers
        assert torch.equal(state.hidden_states.cpu(), expected)
        assert all(
            torch.equal(actual.cpu(), reference)
            for actual, reference in zip(
                state.aux_hidden_states, auxiliary, strict=True
            )
        )
        after = [bytes(page.cpu().numpy()) for page in pages]
        detail["hidden_after_sample"] = save_tensor(
            state.hidden_states,
            args.output_dir / f"producer-{ordinal}-hidden-after.bin",
        )
        detail["auxiliary_after_sample"] = [
            save_tensor(
                actual, args.output_dir / f"producer-{ordinal}-aux-after-{layer}.bin"
            )
            for layer, actual in enumerate(state.aux_hidden_states)
        ]
        detail["after_proposal"] = snapshot_pages(
            pages, args.output_dir, f"producer-{ordinal}-after-proposal"
        )
        check_native_draft_writes(
            bindings,
            pages,
            actual_pages,
            after,
            state,
            {request_id: blocks},
            {request_id: list(range(len(prompt) - 1))},
            {request_id: len(prompt) - 1},
            detail,
        )
        # Older prefixes remain retained while the second native source runs.
        # Compare the complete physical blocks referenced by every real group.
        for previous in retained:
            for index, descriptor in enumerate(bindings.kv_config.kv_cache_tensors):
                protected = {
                    block
                    for group_id, group in enumerate(bindings.kv_config.kv_cache_groups)
                    if set(group.layer_names).intersection(descriptor.layers)
                    for block in previous["blocks"][group_id]
                }
                stride = descriptor.block_stride
                for block in protected:
                    begin = block * stride
                    assert (
                        after[index][begin : begin + stride]
                        == previous["pages"][index][begin : begin + stride]
                    )
        envelopes = [
            item
            for batch in scheduler.update_from_output(step, output).values()
            for item in batch.outputs
        ]
        assert len(envelopes) == 1
        envelope = envelopes[0]
        assert envelope.request_id == request_id and envelope.finished
        assert envelope.new_token_ids == [7]
        params = envelope.kv_transfer_params
        assert DSPARK_SOURCE_PARAM in params
        assert params["remote_request_id"] == request_id
        assert tuple(tuple(ids) for ids in params["remote_block_ids"]) == blocks
        declaration = source_request_from_payload(params[DSPARK_SOURCE_PARAM])
        assert declaration.request_id == request_id
        assert declaration.allocation_block_ids == blocks
        assert declaration.transfer_block_ids == blocks
        assert declaration.original_prompt_tokens == len(prompt)
        assert declaration.computed_prefix_tokens == len(prompt) - 1
        assert request.status == RequestStatus.FINISHED_LENGTH_CAPPED
        assert scheduler.requests[request_id] is request
        detail.update(
            source_transfer_params=params,
            original_state_identity=id(state),
            batch_before_sample=coordinates,
            batch_after_sample=batch_coordinates(state),
            parent_tensor_addresses=pointers,
            independent_layer_oracles=layers,
            held_previous_sources_unchanged=True,
            source_declaration=asdict(declaration),
            held_cache_usage=scheduler.kv_cache_manager.usage,
        )
        send = scheduler.schedule()
        assert send.total_num_scheduled_tokens == 0
        assert send.finished_req_ids == {request_id}
        assert set(send.kv_connector_metadata.requests_to_send) == {request_id}
        returned = owner.execute_model(send)
        assert isinstance(returned, ModelRunnerOutput)
        scheduler.update_from_output(send, returned)
        assert all(item["request_id"] in scheduler.requests for item in sources)
        assert not owner.req_states.req_id_to_index
        retained.append({"blocks": blocks, "pages": after})
    assert len(sources) == len(prompts)
    assert len(
        {source["source_declaration"]["source_generation"] for source in sources}
    ) == len(prompts)
    report["native_sample_and_proposal_returned"] = True
    report["after_sample"] = snapshot_pages(
        pages, args.output_dir, f"producer-{len(prompts)}-prefixes"
    )
    write_json(
        args.output_dir / "producer-ready.json",
        {
            "run_id": args.run_id,
            "sources": sources,
            "source_pages": report["after_sample"],
            "source_layout": report["layout"],
            "draft_weights": report["draft_weights"],
            **report["handshake"],
        },
    )
    completed = set()
    report["poll_steps"] = []
    source_ids = {item["request_id"] for item in sources}
    while scheduler.requests:
        if time.monotonic() >= deadline:
            raise TimeoutError("P prefixes did not retire through typed DONE")
        poll = scheduler.schedule()
        assert poll.total_num_scheduled_tokens == 0
        returned = owner.execute_model(poll)
        assert isinstance(returned, ModelRunnerOutput)
        kv = returned.kv_connector_output
        sent = set(() if kv is None else kv.finished_sending or ())
        assert sent <= source_ids and not completed.intersection(sent)
        assert kv is None or not (kv.failed_recving or kv.invalid_block_ids)
        completed.update(sent)
        scheduler.update_from_output(poll, returned)
        report["poll_steps"].append(
            {"schedule": scheduler_record(poll), "finished_sending": sorted(sent)}
        )
        time.sleep(POLL_SECONDS)
    assert completed == source_ids
    assert scheduler.kv_cache_manager.usage == idle_usage
    assert not owner.req_states.req_id_to_index
    report["typed_done_observed"] = True
    report["typed_done_source_ids"] = sorted(completed)
    await_record(args.output_dir / "consumer-verified.json", args.run_id, deadline)
    owner.prepare_shutdown()
    report["stop_returned"] = True
    ensure_kv_transfer_shutdown()
    scheduler.shutdown()
    owner.shutdown()
    report["native_owner_shutdown_returned"] = True


def execute_decode_step(
    args,
    bindings,
    scheduler,
    report,
    step,
    requests,
    prompts,
    blocks,
    raw_pages,
    *,
    expected_by_request,
    weights,
):
    """Execute one real Q3 parent, native sample/proposal and independent oracles.

    Requests and expected accepted tokens are per active request. The caller
    owns scheduling, cancellation, admission, retirement and owner shutdown.
    """
    import torch
    from hccl_native_attention_pd_aux_probe import batch_coordinates
    from hccl_native_attention_pd_dspark_decode_probe import (
        module_weights,
        target_reference,
    )
    from hccl_native_attention_pd_dspark_run_probe import (
        physical_pages,
        save_tensor,
        snapshot_pages,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    owner = bindings.owner
    _, pages = physical_pages(bindings)
    ordinal = len(report["decode_steps"])
    request_count = len(requests)
    assert request_count in (1, 2)
    assert set(expected_by_request) == set(requests)
    assert step.num_scheduled_tokens == dict.fromkeys(requests, QUERY_ROWS)
    assert step.scheduled_spec_decode_tokens == {
        request_id: [-1, -1] for request_id in requests
    }
    scheduled_frontiers = {
        item.req_id: item.num_computed_tokens for item in step.scheduled_new_reqs
    } | dict(
        zip(
            step.scheduled_cached_reqs.req_ids,
            step.scheduled_cached_reqs.num_computed_tokens,
            strict=True,
        )
    )
    assert set(scheduled_frontiers) == set(requests)
    assert not set(step.new_block_ids_to_zero or ()).intersection(
        block for groups in blocks.values() for group in groups for block in group
    )
    current_blocks = {
        request_id: tuple(
            tuple(ids) for ids in scheduler.kv_cache_manager.get_block_ids(request_id)
        )
        for request_id in requests
    }
    detail = {
        "ordinal": ordinal,
        "schedule": scheduler_record(step),
        "scheduler_blocks_before_execute": current_blocks,
        "before_target": snapshot_pages(
            pages, args.output_dir, f"decode-{ordinal}-before-target"
        ),
    }
    report["decode_steps"].append(detail)
    assert owner.execute_model(step) is None
    state = owner.execute_model_state
    assert state is not None and state.aux_hidden_states is not None
    coords = batch_coordinates(state)
    order = coords["request_ids"]
    assert set(order) == set(requests) and len(order) == request_count
    assert coords["num_reqs"] == request_count
    valid_rows = request_count * QUERY_ROWS
    padded_rows = coords["num_tokens_after_padding"]
    assert coords["num_valid_tokens"] == valid_rows
    assert valid_rows <= padded_rows <= REQUEST_COUNT * QUERY_ROWS
    assert padded_rows % QUERY_ROWS == 0
    assert (
        coords["query_start_loc"]
        == coords["query_start_loc_np"]
        == [QUERY_ROWS * index for index in range(padded_rows // QUERY_ROWS + 1)]
    )
    assert coords["logits_indices"] == list(range(valid_rows))
    detail["valid_target_rows"] = valid_rows
    detail["padded_target_rows"] = padded_rows
    expected_input = {
        request_id: [prompts[request_id][-1], 0, 0]
        if not requests[request_id].output_token_ids
        else [7, 7, 7]
        for request_id in order
    }
    positions = {
        request_id: [
            scheduled_frontiers[request_id] + offset for offset in range(QUERY_ROWS)
        ]
        for request_id in order
    }
    assert coords["input_ids"][:valid_rows] == [
        token for request_id in order for token in expected_input[request_id]
    ]
    assert coords["positions"][:valid_rows] == [
        position for request_id in order for position in positions[request_id]
    ]
    assert coords["num_computed_tokens"] == [
        positions[request_id][0] for request_id in order
    ]
    detail["expected_inputs_by_request"] = expected_input
    detail["expected_positions_by_request"] = positions
    expected_pages = raw_pages
    expected_hidden, expected_aux, per_request_layers = [], [], []
    for request_ordinal, request_id in enumerate(order):
        hidden, auxiliary, expected_pages, layers = target_reference(
            bindings,
            pages,
            expected_pages,
            current_blocks[request_id],
            expected_input[request_id],
            positions[request_id],
            step.new_block_ids_to_zero if request_ordinal == 0 else (),
        )
        expected_hidden.append(hidden)
        expected_aux.append(auxiliary)
        per_request_layers.append(layers)
    value = torch.cat(expected_hidden)
    auxiliary = tuple(
        torch.cat([per_request[layer] for per_request in expected_aux])
        for layer in range(len(expected_aux[0]))
    )
    assert state.hidden_states.shape[0] == padded_rows
    assert torch.equal(state.hidden_states[:valid_rows].cpu(), value)
    assert all(
        actual.shape[0] == padded_rows
        and torch.equal(actual[:valid_rows].cpu(), expected)
        for actual, expected in zip(state.aux_hidden_states, auxiliary, strict=True)
    )
    assert [bytes(page.cpu().numpy()) for page in pages] == expected_pages
    detail["target_after"] = snapshot_pages(
        pages, args.output_dir, f"decode-{ordinal}-after-target"
    )
    detail["hidden"] = save_tensor(
        state.hidden_states, args.output_dir / f"decode-{ordinal}-hidden.bin"
    )
    detail["expected_hidden"] = save_tensor(
        value, args.output_dir / f"decode-{ordinal}-expected-hidden.bin"
    )
    detail["auxiliary"] = [
        {
            "actual": save_tensor(
                actual,
                args.output_dir / f"decode-{ordinal}-aux-{layer}.bin",
            ),
            "expected": save_tensor(
                expected,
                args.output_dir / f"decode-{ordinal}-expected-aux-{layer}.bin",
            ),
        }
        for layer, (actual, expected) in enumerate(
            zip(state.aux_hidden_states, auxiliary, strict=True)
        )
    ]
    detail["per_request_layer_oracles"] = dict(
        zip(order, per_request_layers, strict=True)
    )
    parent_tensors = (state.hidden_states, *state.aux_hidden_states)
    parent_contents = tuple(tensor.cpu().clone() for tensor in parent_tensors)
    pointers = [value.data_ptr() for value in parent_tensors]
    detail["batch_before_sample"] = coords
    detail["independent_layer_oracles"] = [
        {
            "layer": layer,
            **{
                name: [
                    row
                    for request_layers in per_request_layers
                    for row in request_layers[layer][name]
                ]
                for name in ("input_ids", "hidden", "router_fp32", "output")
            },
        }
        for layer in range(len(per_request_layers[0]))
    ]
    detail["parent_tensor_addresses_before_sample"] = pointers
    returned = owner.sample_tokens(None)
    assert isinstance(returned, AsyncOutput)
    output = returned.get_output()
    expected_tokens = [expected_by_request[request_id] for request_id in order]
    assert output.req_ids == order
    assert output.sampled_token_ids == expected_tokens
    assert returned.sampler_output.num_sampled.cpu().tolist() == [
        len(tokens) for tokens in expected_tokens
    ]
    assert returned.sampler_output.num_rejected.cpu().tolist() == [
        QUERY_ROWS - len(tokens) for tokens in expected_tokens
    ]
    assert (
        owner.execute_model_state is None and owner._dspark_pd_pending_scheduler is None
    )
    assert not owner.dspark_pd_consumer.terminal
    assert batch_coordinates(state) == coords
    assert [value.data_ptr() for value in parent_tensors] == pointers
    assert all(
        torch.equal(tensor.cpu(), frozen)
        for tensor, frozen in zip(parent_tensors, parent_contents, strict=True)
    )
    assert torch.equal(state.hidden_states[:valid_rows].cpu(), value)
    assert all(
        torch.equal(actual[:valid_rows].cpu(), expected)
        for actual, expected in zip(state.aux_hidden_states, auxiliary, strict=True)
    )
    raw_pages = [bytes(page.cpu().numpy()) for page in pages]
    detail["hidden_after_sample"] = save_tensor(
        state.hidden_states, args.output_dir / f"decode-{ordinal}-hidden-after.bin"
    )
    detail["auxiliary_after_sample"] = [
        save_tensor(actual, args.output_dir / f"decode-{ordinal}-aux-after-{layer}.bin")
        for layer, actual in enumerate(state.aux_hidden_states)
    ]
    detail["seq_lens_cpu"] = owner.input_buffers.seq_lens_cpu[:request_count].tolist()
    assert detail["seq_lens_cpu"] == [
        positions[request_id][0] + QUERY_ROWS for request_id in order
    ]
    detail["after_proposal"] = snapshot_pages(
        pages, args.output_dir, f"decode-{ordinal}-after-proposal"
    )
    check_native_draft_writes(
        bindings,
        pages,
        expected_pages,
        raw_pages,
        state,
        current_blocks,
        positions,
        {request_id: len(expected_by_request[request_id]) for request_id in order},
        detail,
    )
    assert (
        owner.speculator.input_buffers.input_ids[: request_count * DRAFT_ROWS]
        .cpu()
        .tolist()
        == [7, 0] * request_count
    )
    detail["request_states"] = {}
    for request_id in order:
        request_index = owner.req_states.req_id_to_index[request_id]
        computed_cpu = int(owner.req_states.num_computed_tokens_np[request_index])
        computed_gpu = int(
            owner.req_states.num_computed_tokens.gpu[request_index].item()
        )
        assert computed_cpu == positions[request_id][0]
        assert computed_gpu == positions[request_id][0] + len(
            expected_by_request[request_id]
        )
        assert owner.req_states.draft_tokens[request_index].cpu().tolist() == [7, 7]
        expected_history = (
            list(prompts[request_id])
            + list(requests[request_id].output_token_ids)
            + expected_by_request[request_id]
        )
        history = (
            owner.req_states.all_token_ids.gpu[request_index, : len(expected_history)]
            .cpu()
            .tolist()
        )
        assert history == expected_history
        detail["request_states"][request_id] = {
            "request_index": request_index,
            "computed_cpu": computed_cpu,
            "computed_gpu": computed_gpu,
            "native_history": history,
            "native_draft_ids": [7, 7],
        }
    detail["sampled_token_ids"] = output.sampled_token_ids
    detail["parent_tensor_addresses_after_sample"] = [
        value.data_ptr() for value in parent_tensors
    ]
    scheduler.update_from_output(step, output)
    assert all(
        request.num_computed_tokens
        == detail["request_states"][request_id]["computed_gpu"]
        for request_id, request in requests.items()
    )
    assert all(
        list(request.output_token_ids)
        == detail["request_states"][request_id]["native_history"][
            len(prompts[request_id]) :
        ]
        for request_id, request in requests.items()
    )
    drafts = owner.take_draft_token_ids()
    assert drafts is not None and drafts.req_ids == order
    assert drafts.draft_token_ids == [[-1, -1]] * request_count
    detail["public_draft_ids"] = asdict(drafts)
    scheduler.update_draft_token_ids(drafts)
    assert module_weights(owner) == weights
    return raw_pages, detail


def run_decode_requests(args, bindings, report, deadline):
    """Read both real prefixes, then execute and globally sample two Q3 parents."""
    from hccl_native_attention_pd_dspark_decode_probe import (
        module_weights,
    )
    from hccl_native_attention_pd_dspark_run_probe import (
        await_record,
        physical_pages,
        snapshot_pages,
        write_json,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.core.sched.interface import PauseState
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager

    from afd_plugin.compat.npu.kv_layout_connector import (
        DSPARK_SOURCE_PARAM,
        DsparkMooncakeConnectorMetadata,
    )

    assert args.target_logits_policy == "constant7"
    peer = await_record(args.output_dir / "producer-ready.json", args.run_id, deadline)
    assert report["draft_weights"] == peer["draft_weights"]
    assert len(peer["sources"]) == REQUEST_COUNT
    owner, config = bindings.owner, bindings.owner.vllm_config
    assert config.parallel_config.use_ubatching and owner.ubatch_runner is not None
    assert config.scheduler_config.max_num_seqs == REQUEST_COUNT
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        StructuredOutputManager(config),
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    idle_usage = scheduler.kv_cache_manager.usage
    requests, prompts = {}, {}
    for ordinal, (source, prompt) in enumerate(
        zip(peer["sources"], PROMPTS, strict=True)
    ):
        assert source["prompt"] == list(prompt)
        params = dict(source["source_transfer_params"])
        params["remote_block_ids"] = tuple(
            list(ids) for ids in params["remote_block_ids"]
        )
        assert DSPARK_SOURCE_PARAM in params
        assert params["remote_request_id"] == source["request_id"]
        assert params["remote_engine_id"] == peer["engine_id"]
        assert params["remote_host"] == peer["host"]
        assert params["remote_port"] == peer["port"]
        request_id = f"{args.run_id}-destination-{ordinal}"
        request = Request(
            request_id,
            list(prompt),
            SamplingParams(
                temperature=0,
                max_tokens=MAX_OUTPUT_TOKENS,
                extra_args={"kv_transfer_params": params},
            ),
            None,
        )
        scheduler.add_request(request)
        requests[request_id], prompts[request_id] = request, prompt
    step = scheduler.schedule()
    report["first_schedule"] = scheduler_record(step)
    assert not step.total_num_scheduled_tokens and not step.has_sync_kv_loads
    assert all(
        request.status == RequestStatus.WAITING_FOR_REMOTE_KVS
        for request in requests.values()
    )
    metadata = step.kv_connector_metadata
    assert isinstance(metadata, DsparkMooncakeConnectorMetadata)
    assert set(metadata.requests) == set(metadata.dspark_destinations) == set(requests)
    transfers = dict(metadata.requests)
    blocks = {
        request_id: tuple(tuple(ids) for ids in transfer.local_block_ids)
        for request_id, transfer in transfers.items()
    }
    report["destinations"] = {
        request_id: asdict(metadata.dspark_destinations[request_id])
        for request_id in requests
    }
    pairs = {
        request_id: tuple(
            tuple(zip(remote, local, strict=True))
            for remote, local in zip(
                transfer.remote_block_ids, transfer.local_block_ids, strict=True
            )
        )
        for request_id, transfer in transfers.items()
    }
    report["group_block_pairs_by_request"] = pairs
    scheduler.set_pause_state(PauseState.PAUSED_NEW)
    report["admission_pause_states"] = [scheduler.pause_state.name]
    completed, zero_ids = set(), set()
    report["zero_steps"] = []
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("two D remote prefixes did not complete")
        assert not step.total_num_scheduled_tokens and not step.has_sync_kv_loads
        returned = owner.execute_model(step)
        assert isinstance(returned, ModelRunnerOutput)
        zero_ids.update(step.new_block_ids_to_zero or ())
        kv = returned.kv_connector_output
        received = set(() if kv is None else kv.finished_recving or ())
        assert received <= set(requests) and not completed.intersection(received)
        assert kv is None or not (
            kv.finished_sending or kv.failed_recving or kv.invalid_block_ids
        )
        completed.update(received)
        report["zero_steps"].append(
            {"schedule": scheduler_record(step), "finished_recving": sorted(received)}
        )
        scheduler.update_from_output(step, returned)
        if completed == set(requests):
            scheduler.set_pause_state(PauseState.UNPAUSED)
            report["admission_pause_states"].append(scheduler.pause_state.name)
        step = scheduler.schedule()
        if step.total_num_scheduled_tokens:
            assert completed == set(requests)
            break
        time.sleep(POLL_SECONDS)
    layout, pages = physical_pages(bindings)
    report["layout"] = json.loads(layout.to_json())
    report["after_read"] = snapshot_pages(
        pages, args.output_dir, "consumer-two-after-read"
    )
    raw_pages = [bytes(page.cpu().numpy()) for page in pages]
    for index, descriptor in enumerate(bindings.kv_config.kv_cache_tensors):
        expected = bytearray(
            (args.output_dir / report["before"][index]["path"]).read_bytes()
        )
        stride = descriptor.block_stride
        for block in zero_ids:
            expected[block * stride : (block + 1) * stride] = bytes(stride)
        source_raw = (
            args.output_dir / peer["source_pages"][index]["path"]
        ).read_bytes()
        mapping = {}
        for request_pairs in pairs.values():
            for group_id, group in enumerate(bindings.kv_config.kv_cache_groups):
                if set(group.layer_names).intersection(descriptor.layers):
                    for remote, local in request_pairs[group_id]:
                        assert mapping.setdefault(local, remote) == remote
        for local, remote in mapping.items():
            expected[local * stride : (local + 1) * stride] = source_raw[
                remote * stride : (remote + 1) * stride
            ]
        assert raw_pages[index] == expected
    report["typed_read_and_whole_pool_oracle_passed"] = True
    weights = report["shared_weights_before"] = module_weights(owner)
    report["decode_steps"] = []
    for ordinal in range(2):
        raw_pages, _ = execute_decode_step(
            args,
            bindings,
            scheduler,
            report,
            step,
            requests,
            prompts,
            blocks,
            raw_pages,
            expected_by_request=dict.fromkeys(
                requests, [7] if ordinal == 0 else [7, 7, 7]
            ),
            weights=weights,
        )
        if ordinal == 0:
            step = scheduler.schedule()
    assert all(
        request.status == RequestStatus.FINISHED_LENGTH_CAPPED
        for request in requests.values()
    )
    retirement = scheduler.schedule()
    assert retirement.total_num_scheduled_tokens == 0
    assert retirement.finished_req_ids == set(requests)
    returned = owner.execute_model(retirement)
    assert isinstance(returned, ModelRunnerOutput)
    scheduler.update_from_output(retirement, returned)
    assert not scheduler.requests and not owner.req_states.req_id_to_index
    assert scheduler.kv_cache_manager.usage == idle_usage
    report["retirement_schedule"] = scheduler_record(retirement)
    receiver = owner.kv_connector.kv_connector.connector_worker.kv_recv_thread
    assert receiver.is_alive() and not receiver.retired
    owner.prepare_shutdown()
    ensure_kv_transfer_shutdown()
    assert receiver.retired and not receiver.is_alive()
    scheduler.shutdown()
    assert module_weights(owner) == weights
    report["shared_weights_after"] = module_weights(owner)
    owner.shutdown()
    report["receiver_retired"] = True
    report["native_owner_shutdown_returned"] = True
    report["native_decode_and_verification_accepted"] = True
    report["two_request_native_decode_accepted"] = True
    write_json(args.output_dir / "consumer-verified.json", {"run_id": args.run_id})


def verify_graph_decode_requests(attention, ffn, *, local_devices):
    """Join two actual requests with native dispatch, Graph protocol and F output."""
    from hccl_native_attention_pd_dspark_graph_probe import (
        verify_graph_host_records,
        verify_graph_pair_messages,
    )

    assert attention["two_request_native_decode_accepted"]
    assert attention["native_decode_and_verification_accepted"]
    assert not attention["full_model_accepted"] and not attention["u2_accepted"]
    detail = attention["target_graph_decode"]
    assert detail["accepted"] and detail["target_u2"]
    assert detail["target_requests"] == REQUEST_COUNT
    inventory = {
        entry["key_digest"]: entry for entry in detail["storage_before"]["entries"]
    }
    assert inventory
    assert len(inventory) == len(detail["storage_before"]["entries"])
    zero_count = len(attention["zero_steps"])
    assert len(detail["executions"]) == zero_count + 3
    parent_count = 1 + 2 * len(inventory) + len(detail["executions"])
    protocol = verify_graph_pair_messages(
        attention,
        ffn,
        parent_count,
        target_requests=REQUEST_COUNT,
        allow_u2=True,
    )
    parents = protocol["parents"]
    assert Counter(parent["phase"] for parent in parents) == {
        "warmup": len(inventory),
        "capture": len(inventory),
        "eager": zero_count + 3,
        "replay": 1,
    }
    for phase in ("warmup", "capture"):
        assert Counter(
            parent["key_digest"] for parent in parents if parent["phase"] == phase
        ) == dict.fromkeys(inventory, 1)
    by_id = {parent["transaction_id"]: parent for parent in parents}
    assert [entry["transaction_id"] for entry in detail["executions"]] == [
        parent["transaction_id"] for parent in parents[1 + 2 * len(inventory) :]
    ]
    for entry in detail["executions"]:
        parent = by_id[entry["transaction_id"]]
        assert all(
            parent[name] == entry[name]
            for name in ("phase", "mode", "reason", "key_digest")
        )
        assert sum(parent["valid_tokens"]) == entry["scheduled_tokens"]
    targets = [entry for entry in detail["executions"] if entry["scheduled_tokens"]]
    assert len(targets) == 2
    assert [entry["phase"] for entry in targets] == ["eager", "replay"]
    assert [entry["python_target_calls"] for entry in targets] == [2, 0]
    for entry in targets:
        parent = by_id[entry["transaction_id"]]
        assert parent["valid_tokens"] == parent["padded_tokens"] == [3, 3]
    replay = by_id[targets[1]["transaction_id"]]
    captured = inventory[replay["key_digest"]]
    assert captured["num_reqs"] == REQUEST_COUNT
    assert captured["num_tokens"] == REQUEST_COUNT * QUERY_ROWS
    assert captured["num_stages"] == REQUEST_COUNT
    assert parents.index(by_id[targets[0]["transaction_id"]]) > max(
        index for index, parent in enumerate(parents) if parent["phase"] == "capture"
    )
    service = ffn["native_ffn"]
    assert service["native_daemon_retired"] and service["stop_acknowledged"]
    transactions = service["transactions"]
    assert len(transactions) == len(parents)
    for actual, expected in zip(transactions, parents, strict=True):
        assert actual["transaction_id"] == expected["transaction_id"]
        assert actual["phase"] == expected["phase"]
        assert actual["mode"] == expected["mode"]
        assert actual["reason"] == expected["reason"]
        assert (actual["key"] or "") == expected["key_digest"]
        assert actual["valid_tokens_by_stage"] == expected["valid_tokens"]
        assert actual["padded_tokens_by_stage"] == expected["padded_tokens"]
    for role, records in (
        (
            "attention",
            attention["native_live_owner"]["target_graph"]["host_records"],
        ),
        ("ffn", service["host_records"]),
    ):
        verify_graph_host_records(
            records, parents, role=role,
            local_device=local_devices[role],
        )
    for target, step in zip(targets, attention["decode_steps"], strict=True):
        assert step["batch_before_sample"]["num_reqs"] == REQUEST_COUNT
        assert step["batch_before_sample"]["query_start_loc"] == [0, 3, 6]
        actual = transactions[parents.index(by_id[target["transaction_id"]])]
        assert actual["num_stages"] == REQUEST_COUNT
        assert [layer["layer"] for layer in actual["layer_observations"]] == [0, 1]
        assert [layer["layer"] for layer in step["independent_layer_oracles"]] == [0, 1]
        for layer, expected in zip(
            actual["layer_observations"], step["independent_layer_oracles"], strict=True
        ):
            assert layer["layer"] == expected["layer"]
            assert all(
                len(layer[name]) == len(expected[name]) == REQUEST_COUNT * QUERY_ROWS
                for name in ("input_ids", "hidden", "router_fp32", "output")
            )
            assert all(
                layer[name] == expected[name]
                for name in ("input_ids", "hidden", "router_fp32", "output")
            )
            stages = layer["stage_observations"]
            assert [stage["stage"] for stage in stages] == [0, 1]
            for ordinal, stage in enumerate(stages):
                assert stage["transaction_id"] == target["transaction_id"]
                assert stage["layer"] == layer["layer"]
                assert stage["rows"] == stage["valid_rows"] == QUERY_ROWS
                assert all(
                    len(stage[name]) == QUERY_ROWS
                    for name in ("input_ids", "hidden", "router_fp32", "output")
                )
                assert all(
                    stage[name]
                    == expected[name][ordinal * QUERY_ROWS : (ordinal + 1) * QUERY_ROWS]
                    for name in ("input_ids", "hidden", "router_fp32", "output")
                )
    return protocol | {
        "native_target_graph_component_accepted": True,
        "native_target_graph_u2_component_accepted": True,
        "actual_request_count": REQUEST_COUNT,
        "actual_query_rows_per_request": QUERY_ROWS,
        "full_model_accepted": False,
        "u2_accepted": False,
        "zero_parent_count": zero_count,
        "native_capture_inventory_count": len(inventory),
    }
