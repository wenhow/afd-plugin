# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Validate the explicit Graph compute axis on the native DSpark lifecycle.

Reported host identities protect retained owners. Actual device evidence is
still required, and these checks make no physical-overlap or performance claim.
"""

from __future__ import annotations

TARGET_LAYERS = (0, 1)
TARGET_STAGES = (0, 1)
PIPELINE_EVENT_COUNT = 20


def verify_pipeline_storage(
    value, *, bank, device, graph_all_axes=False, graph_exchange_order="stage_serial"
):
    """Require one complete retained U2 pipeline with nonaliasing host owners."""
    expected = {
        "pipeline",
        "bank",
        "compute_stream",
        "device",
        "events",
        "steps",
        "stages",
    }
    if graph_all_axes:
        expected.update(("policy", "exchange_order"))
        assert value["exchange_order"] == graph_exchange_order
        assert set(value["policy"]) == {
            "hybrid",
            "attention_three_stream",
            "ffn_recv_stream",
            "ffn_cross_layer",
        }
        assert all(enabled is True for enabled in value["policy"].values())
        if graph_exchange_order == "cross_layer_v1":
            from hccl_native_attention_pd_dspark_cross_layer_probe import TARGET_ACTIONS

            expected.add("schedule")
            schedule = value["schedule"]
            assert set(schedule) == {"identity", "actions", "compute_steps"}
            assert type(schedule["identity"]) is int and schedule["identity"] > 0
            assert schedule["actions"] == [list(action) for action in TARGET_ACTIONS]
            assert all(
                type(coordinate) is int
                for action in schedule["actions"]
                for coordinate in action[1:]
            )
            assert schedule["compute_steps"] == [
                [layer, stage] for layer in TARGET_LAYERS for stage in TARGET_STAGES
            ]
            assert all(
                type(coordinate) is int
                for step in schedule["compute_steps"]
                for coordinate in step
            )
    assert set(value) == expected
    assert value["bank"] == bank and value["device"] == device
    assert all(
        type(value[name]) is int and value[name] > 0
        for name in ("pipeline", "bank", "compute_stream")
    )
    assert value["steps"] == [
        [layer, stage] for layer in TARGET_LAYERS for stage in TARGET_STAGES
    ]
    assert value["stages"] == list(TARGET_STAGES)
    events = value["events"]
    assert len(events) == len(set(events)) == PIPELINE_EVENT_COUNT
    assert all(type(event) is int and event > 0 for event in events)


def verify_graph_compute_lifecycle(
    attention, ffn, *, local_devices, graph_all_axes=False,
    graph_exchange_order="stage_serial",
):
    """Join the existing lifecycle with explicit compute owners on both roles."""
    from hccl_native_attention_pd_dspark_graph_probe import verify_graph_host_records
    from hccl_native_attention_pd_dspark_lifecycle_probe import (
        verify_decode_cancel_replace,
    )

    assert attention["graph_compute_overlap_requested"] is True
    assert ffn["graph_compute_overlap_requested"] is True
    assert attention["native_live_owner"]["graph_compute_overlap_requested"] is True
    service = ffn["native_ffn"]
    assert service["graph_compute_overlap_requested"] is True
    assert type(graph_all_axes) is bool
    if graph_all_axes:
        assert attention["graph_all_axes_requested"] is True
        assert ffn["graph_all_axes_requested"] is True
        assert attention["native_live_owner"]["graph_all_axes_requested"] is True
        assert service["graph_all_axes_requested"] is True
    protocol = verify_decode_cancel_replace(
        attention,
        ffn,
        local_devices=local_devices,
        graph_compute_overlap=True,
        graph_all_axes=graph_all_axes,
        graph_exchange_order=graph_exchange_order,
    )
    entries = attention["target_graph_decode"]["storage_before"]["entries"]
    assert len(entries) == 2
    assert sorted(entry["num_stages"] for entry in entries) == [1, 2]
    captures = service["captured_entries"]
    assert len(captures) == len(entries)
    captured = {entry["key"]: entry for entry in captures}
    assert len(captured) == len(captures)
    assert set(captured) == {entry["key_digest"] for entry in entries}
    for entry in entries:
        pipeline = entry["pipeline_storage"]
        peer = captured[entry["key_digest"]]
        assert peer["num_ubatches"] == entry["num_stages"]
        assert peer["num_reqs"] == entry["num_reqs"] == 2
        assert peer["num_tokens"] == entry["num_tokens"] == 6
        assert peer["pipeline_allocated"] is (entry["num_stages"] == 2)
        if entry["num_stages"] == 1:
            assert pipeline is None and peer["pipeline_storage"] is None
        else:
            verify_pipeline_storage(
                pipeline,
                bank=entry["bank"],
                device=local_devices["attention"],
                graph_all_axes=graph_all_axes,
                graph_exchange_order=graph_exchange_order,
            )
            verify_pipeline_storage(
                peer["pipeline_storage"],
                bank=peer["bank_identity"],
                device=local_devices["ffn"],
                graph_all_axes=graph_all_axes,
                graph_exchange_order=graph_exchange_order,
            )
        for transaction in service["transactions"]:
            if transaction["phase"] == "replay" and transaction["key"] == peer["key"]:
                assert transaction["pipeline_storage"] == peer["pipeline_storage"]
                assert transaction["bank_identity"] == peer["bank_identity"]
                assert transaction["bank_addresses"] == peer["bank_addresses"]
                assert transaction["python_body_executed"] is False
    # The FFN handler deliberately separates parent and body streams. Validate
    # both real record schemas without inventing a device-completion boundary.
    verify_graph_host_records(
        [*service["host_records"], *service["body_records"]],
        protocol["parents"],
        role="ffn",
        local_device=local_devices["ffn"],
        graph_compute_overlap=True,
        graph_all_axes=graph_all_axes,
    )
    side_records = [
        record
        for record in service["body_records"]
        if record["actual.mode"] == "graph-streamed"
    ]
    assert side_records
    assert {record["phase"] for record in side_records} == {
        "graph_warmup",
        "graph_capture",
    }
    assert all(record["num_stages"] == 2 for record in side_records)
    return protocol | {
        "native_dspark_graph_compute_lifecycle_component_accepted": True,
        "native_dspark_graph_all_axes_lifecycle_component_accepted": graph_all_axes,
        "graph_compute_overlap_requested": True,
        "graph_all_axes_requested": graph_all_axes,
        "graph_exchange_order_requested": graph_exchange_order,
        "physical_overlap_accepted": False,
        "performance_accepted": False,
    }
