# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Four owned TP1 roles: live P/Ready/read and genuine D DSpark verification.

Default/help use only stdlib. --run starts P,D,F1,F2 on separate devices and
two independent AFD pairs. Target arithmetic/logits and F arithmetic
are controlled; the loaded native draft and rejection sampler are unchanged.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
import uuid
from contextlib import ExitStack, contextmanager
from dataclasses import asdict
from pathlib import Path

DEFAULT_TIMEOUT = 360
RETENTION_TIMEOUT = 720
GROUP_TIMEOUT = 60
POLL_SECONDS = 0.1
PROMPT = (11, 12, 13, 14, 15)
DECODE_BATCHES = ((15, 0, 0), (7, 7, 7))
DECODE_POSITIONS = ((4, 5, 6), (5, 6, 7))
MAX_OUTPUT_TOKENS = 4
REJECTION_CONTINUATION_BATCHES = DECODE_BATCHES + ((8, 7, 7),)
REJECTION_CONTINUATION_POSITIONS = DECODE_POSITIONS + ((7, 8, 9),)
REJECTION_CONTINUATION_MAX_OUTPUT_TOKENS = 5
SOURCE_PATTERN = 0x3F00
ROLES = ("kv_producer", "kv_consumer", "ffn_producer", "ffn_consumer")
POLICIES = ("constant7", "reject-second-verification-row")
LEGACY_PAIR_PROTOCOL_VERSION = 2
TARGET_HIDDEN_SIZE = 512
TARGET_VOCAB_SIZE = 128
MAX_PROTOCOL_INTEGER = (1 << 31) - 1
MAX_TRANSACTION_ID_BYTES = 256


@contextmanager
def observe_pair_controls(report):
    """Record actual completed codec calls, without changing the pair protocol."""
    from afd_plugin.connectors.npu.hccl_protocol import encode_hccl_control_message
    from afd_plugin.connectors.npu.hccl_transport import HcclEagerTransport

    records = report["pair_control_messages"] = []
    original_send = HcclEagerTransport._send_control
    original_recv = HcclEagerTransport._recv_control

    def record(direction, transport, message):
        encoded = encode_hccl_control_message(message)
        records.append(
            {
                "ordinal": len(records),
                "direction": direction,
                "role": transport.role.value,
                "peer_pair_rank": transport.peer_rank,
                "encoded_message": json.loads(encoded),
                "sha256": hashlib.sha256(encoded).hexdigest(),
            }
        )

    def send(transport, message):
        result = original_send(transport, message)
        record("send_returned", transport, message)
        return result

    def receive(transport):
        message = original_recv(transport)
        record("receive_returned", transport, message)
        return message

    try:
        HcclEagerTransport._send_control = send
        HcclEagerTransport._recv_control = receive
        yield
    finally:
        HcclEagerTransport._send_control = original_send
        HcclEagerTransport._recv_control = original_recv


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def module_weights(owner) -> dict:
    import torch

    target = owner.model.language_model
    draft = owner.speculator.model
    assert target.lm_head is draft.lm_head
    assert target.model.embed_tokens is draft.model.embed_tokens
    result = {}
    for name, module in (
        ("lm_head", target.lm_head),
        ("embed_tokens", target.model.embed_tokens),
    ):
        tensor = module.weight
        raw = tensor.detach().contiguous().cpu().view(torch.uint8).numpy().tobytes()
        result[name] = {
            "identity": id(module),
            "data_ptr": tensor.data_ptr(),
            "sha256": hashlib.sha256(raw).hexdigest(),
        }
    return result


def row_location(cache, pages, block: int, position: int) -> tuple[int, int, int]:
    """Map a native typed SWA row into its complete physical descriptor span."""
    assert cache.ndim == 4 and cache.shape[2] == 1
    assert 0 <= block < cache.shape[0] and 0 <= position < cache.shape[1]
    assert cache.stride(-1) == 1
    address = cache.data_ptr() + cache.element_size() * (
        block * cache.stride(0) + position * cache.stride(1)
    )
    size = cache.shape[-1] * cache.element_size()
    matches = [
        (index, address - page.data_ptr(), size)
        for index, page in enumerate(pages)
        if page.data_ptr() <= address
        and address + size <= page.data_ptr() + page.numel()
    ]
    assert len(matches) == 1
    return matches[0]


def target_reference(
    bindings, pages, raw_pages, blocks, token_ids, positions, zero_ids
):
    """Independent CPU recurrence and exact whole-pool target-write oracle."""
    import torch
    from dsv41_dspark_a5_runtime import (
        encode_reference_row,
        read_reference_row,
    )
    from hccl_native_attention_pd_dspark_probe import ROUTER_DELTA, ROUTER_SCALE

    expected = [bytearray(raw) for raw in raw_pages]
    for descriptor, raw in zip(
        bindings.kv_config.kv_cache_tensors, expected, strict=True
    ):
        for block in zero_ids or ():
            begin = block * descriptor.block_stride
            raw[begin : begin + descriptor.block_stride] = bytes(
                descriptor.block_stride
            )
    value = bindings.embedding_cpu[list(token_ids)].clone()
    aux, layers = [], []
    for index, decoder in enumerate(bindings.owner.model.language_model.model.layers):
        aux.append(value.clone())
        name = decoder.self_attn.cache_name
        group_id = next(
            group_id
            for group_id, group in enumerate(bindings.kv_config.kv_cache_groups)
            if name in group.layer_names
        )
        cache = decoder.self_attn.cache_layer.kv_cache[0]
        previous, locations = [], []
        for position in positions:
            block = blocks[group_id][position // cache.shape[1]]
            offset = position % cache.shape[1]
            pool, begin, size = row_location(cache, pages, block, max(offset - 1, 0))
            previous.append(
                read_reference_row(
                    cache, bytes(expected[pool][begin : begin + size])
                )
            )
            locations.append(row_location(cache, pages, block, offset))
        prior = torch.stack(previous)
        for row, (pool, begin, size) in zip(value, locations, strict=True):
            raw = encode_reference_row(cache, row)
            assert len(raw) == size
            expected[pool][begin : begin + size] = raw
        attention = (
            value.float() + prior.float() + torch.tensor(positions)[:, None]
        ).bfloat16()
        residual = (value.float() + attention.float()).bfloat16()
        router = residual.float() + ROUTER_DELTA
        moe = (
            residual.float()
            + (router - residual.float()) * ROUTER_SCALE
            + torch.tensor(token_ids)[:, None]
        ).bfloat16()
        value = (residual.float() + moe.float()).bfloat16()
        layers.append(
            {
                "layer": index,
                "previous": prior.float().tolist(),
                "hidden": residual.float().tolist(),
                "router_fp32": router.tolist(),
                "output": moe.float().tolist(),
                "input_ids": list(token_ids),
                "write_ranges": locations,
            }
        )
    return value, aux, [bytes(raw) for raw in expected], layers


def check_proposal_protection(
    bindings, pages, before, after, state, detail, blocks, positions, num_sampled
) -> None:
    """Check all bytes outside real native draft query/context row mappings."""
    from vllm.v1.attention.backends.utils import PAD_SLOT_ID

    owner = bindings.owner
    speculator = owner.speculator
    masks = [bytearray(len(raw)) for raw in before]
    groups = tuple(speculator.draft_kv_cache_group_ids)
    context_slots = speculator._context_slot_mappings
    expected_context_positions = list(positions[:num_sampled]) + [0] * (
        len(positions) - num_sampled
    )
    query_positions = tuple(
        range(positions[num_sampled - 1] + 1, positions[num_sampled - 1] + 3)
    )
    assert (
        speculator.context_positions[: len(positions)].cpu().tolist()
        == expected_context_positions
    )
    assert speculator.input_buffers.positions[:2].cpu().tolist() == list(
        query_positions
    )
    records = []
    for name in speculator.model.get_draft_kv_cache_layer_names():
        group_id = next(
            index
            for index, group in enumerate(bindings.kv_config.kv_cache_groups)
            if name in group.layer_names
        )
        group_index = groups.index(group_id)
        cache = bindings.caches[name]
        block_size = cache.shape[1]
        expected_query = [
            blocks[group_id][position // block_size] * block_size
            + position % block_size
            for position in query_positions
        ]
        expected_context = [
            blocks[group_id][position // block_size] * block_size
            + position % block_size
            for position in positions[:num_sampled]
        ] + [PAD_SLOT_ID] * (len(positions) - num_sampled)
        query = (
            speculator.block_tables.slot_mappings[group_id][
                : speculator.num_query_per_req
            ]
            .cpu()
            .tolist()
        )
        context = (
            context_slots[group_index][: state.input_batch.num_tokens].cpu().tolist()
        )
        assert query == expected_query and context == expected_context
        record = {"layer": name, "query_slots": query, "context_slots": context}
        records.append(record)
        for slot in expected_query + expected_context:
            if slot == PAD_SLOT_ID:
                continue
            block, position = divmod(slot, block_size)
            assert block > 0
            pool, begin, size = row_location(cache, pages, block, position)
            masks[pool][begin : begin + size] = b"\1" * size
    detail["native_draft_write_mappings"] = records
    for old, new, mask in zip(before, after, masks, strict=True):
        assert len(old) == len(new) == len(mask)
        assert all(
            first == second
            for first, second, allowed in zip(old, new, mask, strict=True)
            if not allowed
        )
    detail["all_bytes_outside_native_draft_write_rows_unchanged"] = True


def run_decode(args, bindings, report, deadline):
    import torch
    from hccl_native_attention_pd_aux_probe import batch_coordinates
    from hccl_native_attention_pd_dspark_run_probe import (
        await_record,
        physical_pages,
        save_tensor,
        snapshot_pages,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    from afd_plugin.compat.npu.kv_layout_connector import (
        DSPARK_SOURCE_PARAM,
        DsparkMooncakeConnectorMetadata,
    )

    peer = await_record(args.output_dir / "producer-ready.json", args.run_id, deadline)
    assert report["draft_weights"] == peer["draft_weights"]
    owner, config = bindings.owner, bindings.owner.vllm_config
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    structured = StructuredOutputManager(config)
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        structured,
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    params = dict(peer["source_transfer_params"])
    params["remote_block_ids"] = tuple(list(ids) for ids in params["remote_block_ids"])
    assert DSPARK_SOURCE_PARAM in params
    assert params["remote_engine_id"] == peer["engine_id"]
    assert params["remote_host"] == peer["host"]
    assert params["remote_port"] == peer["port"]
    request_id = args.run_id + "-destination"
    max_output_tokens = (
        REJECTION_CONTINUATION_MAX_OUTPUT_TOKENS
        if args.continue_after_rejection
        else MAX_OUTPUT_TOKENS
    )
    report["max_output_tokens"] = max_output_tokens
    request = Request(
        request_id,
        list(PROMPT),
        SamplingParams(
            temperature=0,
            max_tokens=max_output_tokens,
            extra_args={"kv_transfer_params": params},
        ),
        None,
    )
    idle_usage = scheduler.kv_cache_manager.usage
    scheduler.add_request(request)
    step = scheduler.schedule()
    report["first_schedule"] = scheduler_record(step)
    assert step.total_num_scheduled_tokens == 0 and not step.has_sync_kv_loads
    assert request.status == RequestStatus.WAITING_FOR_REMOTE_KVS
    metadata = step.kv_connector_metadata
    assert isinstance(metadata, DsparkMooncakeConnectorMetadata)
    transfer = metadata.requests[request_id]
    report["destination"] = asdict(metadata.dspark_destinations[request_id])
    pairs = tuple(
        tuple(zip(remote, local, strict=True))
        for remote, local in zip(
            transfer.remote_block_ids, transfer.local_block_ids, strict=True
        )
    )
    report["group_block_pairs"] = pairs
    completed = set()
    report["zero_steps"] = []
    pre_load_zero_ids = set()
    while step.total_num_scheduled_tokens == 0:
        if time.monotonic() >= deadline:
            raise TimeoutError("D remote prefix did not complete")
        returned = owner.execute_model(step)
        pre_load_zero_ids.update(step.new_block_ids_to_zero or ())
        assert isinstance(returned, ModelRunnerOutput)
        kv = returned.kv_connector_output
        received = set(() if kv is None else kv.finished_recving or ())
        assert received <= {request_id}
        assert kv is None or not (
            kv.finished_sending or kv.failed_recving or kv.invalid_block_ids
        )
        completed.update(received)
        report["zero_steps"].append(
            {"schedule": scheduler_record(step), "finished_recving": sorted(received)}
        )
        scheduler.update_from_output(step, returned)
        step = scheduler.schedule()
        if not step.total_num_scheduled_tokens:
            time.sleep(POLL_SECONDS)
    assert completed == {request_id}
    layout, pages = physical_pages(bindings)
    report["layout"] = json.loads(layout.to_json())
    report["after_read"] = snapshot_pages(pages, args.output_dir, "consumer-after-read")
    raw_pages = [bytes(page.cpu().numpy()) for page in pages]
    for index, descriptor in enumerate(bindings.kv_config.kv_cache_tensors):
        expected = bytearray(
            (args.output_dir / report["before"][index]["path"]).read_bytes()
        )
        for block in pre_load_zero_ids:
            begin = block * descriptor.block_stride
            expected[begin : begin + descriptor.block_stride] = bytes(
                descriptor.block_stride
            )
        source = (args.output_dir / peer["source_pages"][index]["path"]).read_bytes()
        mapping = {}
        for group_id, group in enumerate(bindings.kv_config.kv_cache_groups):
            if set(group.layer_names).intersection(descriptor.layers):
                for remote, local in pairs[group_id]:
                    assert mapping.setdefault(local, remote) == remote
        for local, remote in mapping.items():
            size = descriptor.block_stride
            expected[local * size : (local + 1) * size] = source[
                remote * size : (remote + 1) * size
            ]
        assert raw_pages[index] == expected
    report["typed_read_and_whole_pool_oracle_passed"] = True
    identities = {
        name: id(value)
        for name, value in (
            ("owner", owner),
            ("model", owner.model),
            ("model_state", owner.model_state),
            ("request_state", owner.req_states),
            ("input_buffers", owner.input_buffers),
            ("block_tables", owner.block_tables),
            ("speculator", owner.speculator),
            ("consumer", owner.dspark_pd_consumer),
            ("active_kv", owner.kv_connector),
        )
    }
    report["owner_identities"] = identities
    weights = report["shared_weights_before"] = module_weights(owner)
    report["decode_steps"] = []
    batches = (
        REJECTION_CONTINUATION_BATCHES
        if args.continue_after_rejection
        else DECODE_BATCHES
    )
    batch_positions = (
        REJECTION_CONTINUATION_POSITIONS
        if args.continue_after_rejection
        else DECODE_POSITIONS
    )
    expected_outputs = []
    for ordinal, (input_ids, positions) in enumerate(
        zip(batches, batch_positions, strict=True)
    ):
        detail = {"ordinal": ordinal, "schedule": scheduler_record(step)}
        report["decode_steps"].append(detail)
        assert step.num_scheduled_tokens == {request_id: len(input_ids)}
        assert step.scheduled_spec_decode_tokens == {request_id: [-1, -1]}
        detail["scheduler_optimistic_computed_before_execute"] = (
            request.num_computed_tokens
        )
        assert request.num_computed_tokens == positions[0] + len(input_ids)
        blocks = tuple(
            tuple(ids) for ids in scheduler.kv_cache_manager.get_block_ids(request_id)
        )
        if ordinal == 0:
            assert len(step.scheduled_new_reqs) == 1
            assert step.scheduled_new_reqs[0].num_computed_tokens == positions[0]
            assert (
                tuple(tuple(ids) for ids in step.scheduled_new_reqs[0].block_ids)
                == blocks
            )
        value, expected_aux, expected_pages, layer_records = target_reference(
            bindings,
            pages,
            raw_pages,
            blocks,
            input_ids,
            positions,
            step.new_block_ids_to_zero,
        )
        detail["independent_layer_oracles"] = layer_records
        assert owner.execute_model(step) is None
        state = owner.execute_model_state
        assert state is not None and state.aux_hidden_states is not None
        coords = batch_coordinates(state)
        detail["batch_before_sample"] = coords
        assert coords["input_ids"] == list(input_ids)
        assert coords["positions"] == list(positions)
        assert coords["num_valid_tokens"] == coords["num_tokens_after_padding"] == 3
        assert coords["num_computed_tokens"] == [positions[0]]
        assert torch.equal(state.hidden_states.cpu(), value)
        assert all(
            torch.equal(actual.cpu(), expected)
            for actual, expected in zip(
                state.aux_hidden_states, expected_aux, strict=True
            )
        )
        detail["output"] = save_tensor(
            state.hidden_states, args.output_dir / f"decode-{ordinal}-hidden.bin"
        )
        detail["expected_output"] = save_tensor(
            value, args.output_dir / f"decode-{ordinal}-expected.bin"
        )
        detail["target_after"] = snapshot_pages(
            pages, args.output_dir, f"decode-{ordinal}-target"
        )
        actual_pages = [bytes(page.cpu().numpy()) for page in pages]
        assert actual_pages == expected_pages
        req_index = owner.req_states.req_id_to_index[request_id]
        detail["request_index"] = req_index
        detail["draft_tokens_before_sample"] = (
            owner.req_states.draft_tokens[req_index].cpu().tolist()
        )
        assert detail["draft_tokens_before_sample"] == (
            [0, 0] if ordinal == 0 else [7, 7]
        )
        parent_tensors = (state.hidden_states, *state.aux_hidden_states)
        parent_addresses = [tensor.data_ptr() for tensor in parent_tensors]
        detail["parent_tensor_addresses_before_sample"] = parent_addresses
        returned = owner.sample_tokens(None)
        assert isinstance(returned, AsyncOutput)
        output = returned.get_output()
        expected_tokens = (
            [7]
            if ordinal == 0
            else ([7, 7, 7] if args.target_logits_policy == "constant7" else [7, 8])
        )
        assert output.req_ids == [request_id] and output.sampled_token_ids == [
            expected_tokens
        ]
        expected_outputs.extend(expected_tokens)
        detail["sampled_token_ids"] = output.sampled_token_ids
        detail["native_num_sampled"] = (
            returned.sampler_output.num_sampled.cpu().tolist()
        )
        detail["native_num_rejected"] = (
            returned.sampler_output.num_rejected.cpu().tolist()
        )
        assert detail["native_num_sampled"] == [len(expected_tokens)]
        assert detail["native_num_rejected"] == [3 - len(expected_tokens)]
        assert owner.execute_model_state is None
        assert owner._dspark_pd_pending_scheduler is None
        assert batch_coordinates(state) == coords
        assert [tensor.data_ptr() for tensor in parent_tensors] == parent_addresses
        assert torch.equal(state.hidden_states.cpu(), value)
        assert all(
            torch.equal(actual.cpu(), expected)
            for actual, expected in zip(
                state.aux_hidden_states, expected_aux, strict=True
            )
        )
        detail["parent_tensor_addresses_after_sample"] = [
            tensor.data_ptr()
            for tensor in (state.hidden_states, *state.aux_hidden_states)
        ]
        assert detail["parent_tensor_addresses_after_sample"] == parent_addresses
        assert not owner.dspark_pd_consumer.terminal
        detail["original_execute_state_identity"] = id(state)
        detail["native_numeric_drafts"] = (
            owner.req_states.draft_tokens[req_index].cpu().tolist()
        )
        assert detail["native_numeric_drafts"] == [7, 7]
        detail["native_proposal_input_ids"] = (
            owner.speculator.input_buffers.input_ids[:2].cpu().tolist()
        )
        assert detail["native_proposal_input_ids"] == [expected_tokens[-1], 0]
        detail["native_proposal_positions"] = (
            owner.speculator.input_buffers.positions[:2].cpu().tolist()
        )
        detail["computed_gpu"] = int(
            owner.req_states.num_computed_tokens.gpu[req_index].item()
        )
        detail["computed_cpu"] = int(owner.req_states.num_computed_tokens_np[req_index])
        detail["seq_lens_cpu"] = owner.input_buffers.seq_lens_cpu[:1].tolist()
        assert detail["seq_lens_cpu"] == [positions[0] + len(input_ids)]
        assert detail["computed_cpu"] == positions[0]
        assert detail["computed_gpu"] == positions[0] + len(expected_tokens)
        detail["native_history"] = (
            owner.req_states.all_token_ids.gpu[
                req_index,
                : len(PROMPT) + len(expected_outputs),
            ]
            .cpu()
            .tolist()
        )
        detail["after_proposal"] = snapshot_pages(
            pages, args.output_dir, f"decode-{ordinal}-proposal"
        )
        raw_pages = [bytes(page.cpu().numpy()) for page in pages]
        check_proposal_protection(
            bindings,
            pages,
            actual_pages,
            raw_pages,
            state,
            detail,
            blocks,
            positions,
            len(expected_tokens),
        )
        scheduler.update_from_output(step, output)
        detail["scheduler_computed_after_update"] = request.num_computed_tokens
        detail["scheduler_outputs"] = list(request.output_token_ids)
        assert request.num_computed_tokens == detail["computed_gpu"]
        assert list(request.output_token_ids) == expected_outputs
        assert detail["native_history"] == list(PROMPT) + list(request.output_token_ids)
        drafts = owner.take_draft_token_ids()
        assert drafts is not None
        assert drafts.req_ids == [request_id] and drafts.draft_token_ids == [[-1, -1]]
        detail["public_draft_ids"] = asdict(drafts)
        scheduler.update_draft_token_ids(drafts)
        assert module_weights(owner) == weights
        if ordinal + 1 < len(batches):
            assert request.status == RequestStatus.RUNNING
            step = scheduler.schedule()
    if args.target_logits_policy == "constant7" or args.continue_after_rejection:
        assert request.status == RequestStatus.FINISHED_LENGTH_CAPPED
    else:
        assert request.status == RequestStatus.RUNNING
        scheduler.finish_requests(request_id, RequestStatus.FINISHED_ABORTED)
        assert request.status == RequestStatus.FINISHED_ABORTED
    report["final_request_status"] = request.status.name
    retirement = scheduler.schedule()
    assert retirement.total_num_scheduled_tokens == 0
    assert retirement.finished_req_ids == {request_id}
    output = owner.execute_model(retirement)
    assert isinstance(output, ModelRunnerOutput)
    scheduler.update_from_output(retirement, output)
    report["retirement_schedule"] = scheduler_record(retirement)
    assert not owner.req_states.req_id_to_index and not scheduler.requests
    assert scheduler.kv_cache_manager.usage == idle_usage
    receiver = owner.kv_connector.kv_connector.connector_worker.kv_recv_thread
    assert receiver.is_alive() and not receiver.retired
    owner.prepare_shutdown()
    ensure_kv_transfer_shutdown()
    assert receiver.retired and not receiver.is_alive()
    scheduler.shutdown()
    assert module_weights(owner) == weights
    report["shared_weights_after"] = module_weights(owner)
    assert identities == {
        name: id(value)
        for name, value in (
            ("owner", owner),
            ("model", owner.model),
            ("model_state", owner.model_state),
            ("request_state", owner.req_states),
            ("input_buffers", owner.input_buffers),
            ("block_tables", owner.block_tables),
            ("speculator", owner.speculator),
            ("consumer", owner.dspark_pd_consumer),
            ("active_kv", owner.kv_connector),
        )
    }
    owner.shutdown()
    report["receiver_retired"] = True
    report["native_owner_shutdown_returned"] = True
    report["native_decode_and_verification_accepted"] = True
    report["native_post_rejection_continuation_accepted"] = (
        args.continue_after_rejection
    )
    write_json(args.output_dir / "consumer-verified.json", {"run_id": args.run_id})


def run_worker(args) -> None:
    report = {
        "run_id": args.run_id,
        "role": args.role,
        "success": False,
        "target_logits_policy": args.target_logits_policy,
        "continue_after_rejection_requested": args.continue_after_rejection,
        "full_model_accepted": False,
        "full_worker_accepted": False,
        "model_admission_accepted": False,
        "engram_accepted": False,
        "graph_accepted": False,
        "target_graph_requested": args.target_graph,
        "target_u2_requested": args.target_u2,
        "target_cancel_replace_requested": args.target_cancel_replace,
        "eager_stream_overlap_requested": args.eager_stream_overlap,
        "graph_compute_overlap_requested": args.graph_compute_overlap,
        "graph_all_axes_requested": args.graph_all_axes,
        "graph_exchange_order_requested": args.graph_exchange_order,
        "u2_accepted": False,
        "performance_accepted": False,
        "engine_core_process_constructed": False,
        "ready_frontier": {"status": "not_requested"},
        "ready_before_sample_observed": "not_observed",
    }
    runtime_imported = False
    try:
        from dsv41_dspark_speculator_probe import NATIVE_PLUGINS

        if args.target_cancel_replace:
            import hccl_native_attention_pd_dspark_lifecycle_probe as lifecycle_probe

        for name in tuple(os.environ):
            if name.startswith(("AFD_", "VLLM_", "MOONCAKE_", "ENGRAM_")):
                del os.environ[name]
        os.environ.update(
            VLLM_PLUGINS=NATIVE_PLUGINS,
            VLLM_USE_V2_MODEL_RUNNER="1",
            VLLM_WORKER_MULTIPROC_METHOD="spawn",
            VLLM_ASCEND_ENABLE_FLASHCOMM1="0",
            VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT=str(RETENTION_TIMEOUT),
        )
        import msgspec
        import torch
        import torch_npu  # noqa: F401
        from dsv41_dspark_projection_model_probe import native_projection_world
        from dsv41_dspark_speculator_probe import SEED
        from hccl_native_attention_pd_dspark_owner_probe import (
            build_native_live_prefix_owner,
        )
        from hccl_native_attention_pd_dspark_probe import create_live_prefix_config
        from hccl_native_attention_pd_dspark_run_probe import (
            physical_pages,
            run_ffn,
            run_prefill,
            save_tensor,
            snapshot_pages,
        )
        from vllm.config import set_current_vllm_config
        from vllm.platforms import current_platform

        current_platform.pre_register_and_update()
        from vllm.plugins import load_general_plugins
        from vllm_ascend.utils import (
            adapt_patch,
            register_ascend_customop,
        )
        from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

        load_general_plugins()
        adapt_patch()
        device = torch.device("npu", args.device)
        torch.npu.set_device(device)
        runtime_imported = True
        from dsv41_dspark_a5_runtime import native_a5_bootstrap

        report["native_a5_bootstrap"] = native_a5_bootstrap()
        report["custom_ops_enabled"] = False
        torch.manual_seed(SEED)
        role_directory = args.output_dir / args.role
        role_directory.mkdir()
        kv_role = (
            "kv_consumer"
            if args.role in ("kv_consumer", "ffn_consumer")
            else "kv_producer"
        )
        is_ffn = args.role.startswith("ffn_")
        requested_engine = args.run_id + "-" + args.role
        config = create_live_prefix_config(
            args.model,
            role_directory,
            role=kv_role,
            engine_id=requested_engine,
            host=args.host,
            handshake_port=args.handshake_port,
            afd_port=args.afd_port,
            afd_role="ffn" if is_ffn else "attention",
            target_graph=args.target_graph and kv_role == "kv_consumer",
            target_u2=args.target_u2 and kv_role == "kv_consumer",
            eager_stream_overlap=args.eager_stream_overlap and kv_role == "kv_consumer",
            graph_exchange_order=(
                args.graph_exchange_order
                if kv_role == "kv_consumer"
                else "stage_serial"
            ),
        )
        report["requested_engine_id"] = requested_engine
        report["actual_engine_id"] = config.kv_transfer_config.engine_id
        deadline = time.monotonic() + args.timeout
        with (
            set_current_vllm_config(config),
            torch.inference_mode(),
            torch_cuda_wrapper(),
            native_projection_world(config, device, role_directory, report),
            ExitStack() as pair_observations,
        ):
            if (
                args.target_graph or args.eager_stream_overlap
            ) and kv_role == "kv_consumer":
                from hccl_native_attention_pd_dspark_graph_probe import (
                    observe_graph_pair_controls,
                )

                pair_observations.enter_context(observe_graph_pair_controls(report))
                if args.eager_stream_overlap:
                    from hccl_native_attention_pd_dspark_eager_probe import (
                        observe_eager_pipeline_finishes,
                    )

                    pair_observations.enter_context(
                        observe_eager_pipeline_finishes(report)
                    )
                if args.graph_exchange_order == "cross_layer_v1":
                    from hccl_native_attention_pd_dspark_cross_layer_probe import (
                        observe_cross_layer_actions,
                    )

                    pair_observations.enter_context(observe_cross_layer_actions(report))
            else:
                pair_observations.enter_context(observe_pair_controls(report))
            register_ascend_customop(config)
            if is_ffn:
                if args.eager_stream_overlap and kv_role == "kv_consumer":
                    from hccl_native_attention_pd_dspark_eager_ffn_probe import (
                        run_native_dspark_eager_ffn,
                    )

                    run_native_dspark_eager_ffn(
                        config, device, report, deadline, eager_stream_overlap=True
                    )
                elif args.target_graph and kv_role == "kv_consumer":
                    from hccl_native_attention_pd_dspark_graph_ffn_probe import (
                        run_native_dspark_graph_ffn,
                    )

                    run_native_dspark_graph_ffn(
                        config,
                        device,
                        report,
                        deadline,
                        graph_compute_overlap=args.graph_compute_overlap,
                        graph_all_axes=args.graph_all_axes,
                        graph_exchange_order=args.graph_exchange_order,
                    )
                else:
                    batches = (
                        (PROMPT[:-1],)
                        if args.role == "ffn_producer"
                        else (
                            REJECTION_CONTINUATION_BATCHES
                            if args.continue_after_rejection
                            else DECODE_BATCHES
                        )
                    )
                    if args.target_u2:
                        if args.target_cancel_replace:
                            batches = tuple(
                                prompt[:-1] for prompt in lifecycle_probe.PROMPTS
                            )
                        else:
                            from hccl_native_attention_pd_dspark_u2_probe import PROMPTS

                            batches = tuple(prompt[:-1] for prompt in PROMPTS)
                    run_ffn(
                        config, device, report, deadline, expected_input_batches=batches
                    )
            else:
                bindings = build_native_live_prefix_owner(
                    config,
                    device,
                    report,
                    connect_ffn=True,
                    kv_role=kv_role,
                    target_logits_policy=(
                        None if kv_role == "kv_producer" else args.target_logits_policy
                    ),
                    target_graph=args.target_graph and kv_role == "kv_consumer",
                    target_u2=args.target_u2 and kv_role == "kv_consumer",
                    eager_stream_overlap=(
                        args.eager_stream_overlap and kv_role == "kv_consumer"
                    ),
                    graph_compute_overlap=(
                        args.graph_compute_overlap and kv_role == "kv_consumer"
                    ),
                    graph_all_axes=(args.graph_all_axes and kv_role == "kv_consumer"),
                    graph_exchange_order=(
                        args.graph_exchange_order
                        if kv_role == "kv_consumer"
                        else "stage_serial"
                    ),
                    retained_prefixes=(
                        3 if args.target_cancel_replace else 2 if args.target_u2 else 1
                    ),
                )
                layout, pages = physical_pages(bindings)
                report["layout"] = json.loads(layout.to_json())
                for index, page in enumerate(pages):
                    assert page.numel() % 2 == 0
                    page.view(torch.int16).fill_(SOURCE_PATTERN + index)
                torch.npu.synchronize(device)
                report["before"] = snapshot_pages(
                    pages, args.output_dir, args.role + "-before"
                )
                weights = []
                for index, (name, value) in enumerate(
                    bindings.owner.speculator.model.state_dict().items()
                ):
                    assert torch.isfinite(value).all().item()
                    entry = save_tensor(
                        value, args.output_dir / f"{args.role}-draft-weight-{index}.bin"
                    )
                    weights.append(
                        {key: entry[key] for key in ("sha256", "shape", "dtype")}
                        | {"name": name}
                    )
                report["draft_weights"] = weights
                report["draft_weight_files"] = [
                    f"{args.role}-draft-weight-{index}.bin"
                    for index in range(len(weights))
                ]
                handshake = (
                    bindings.owner.kv_connector.kv_connector.get_handshake_metadata()
                )
                assert handshake.engine_id == config.kv_transfer_config.engine_id
                path = args.output_dir / f"{args.role}-handshake.msgpack"
                path.write_bytes(msgspec.msgpack.encode(handshake))
                report["handshake"] = {
                    "engine_id": handshake.engine_id,
                    "host": handshake.local_ip,
                    "port": config.kv_transfer_config.kv_port,
                    "path": path.name,
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                }
                if kv_role == "kv_producer" and args.target_u2:
                    from hccl_native_attention_pd_dspark_u2_probe import (
                        run_prefill_sources,
                    )

                    if args.target_cancel_replace:
                        run_prefill_sources(
                            args,
                            bindings,
                            report,
                            deadline,
                            prompts=lifecycle_probe.PROMPTS,
                        )
                    else:
                        run_prefill_sources(args, bindings, report, deadline)
                elif kv_role == "kv_producer":
                    with ExitStack() as observations:
                        observer = None
                        if args.observe_ready_frontier:
                            from hccl_native_attention_pd_dspark_ready_probe import (
                                observe_ready_frontier,
                            )

                            observer = observations.enter_context(
                                observe_ready_frontier(
                                    bindings,
                                    run_id=args.run_id,
                                    host=handshake.local_ip,
                                    port=config.kv_transfer_config.kv_port,
                                    deadline=deadline,
                                    report=report,
                                )
                            )
                        run_prefill(
                            args, bindings, report, deadline, ready_observer=observer
                        )
                else:
                    if args.eager_stream_overlap:
                        from hccl_native_attention_pd_dspark_eager_probe import (
                            observe_eager_decode,
                        )

                        with observe_eager_decode(bindings, report):
                            lifecycle_probe.run_decode_cancel_replace(
                                args, bindings, report, deadline
                            )
                    elif args.target_graph:
                        from hccl_native_attention_pd_dspark_graph_probe import (
                            observe_graph_decode,
                        )

                        expected_target_batches = None
                        if args.target_cancel_replace:
                            expected_target_batches = lifecycle_probe.TARGET_BATCHES
                        with observe_graph_decode(
                            bindings,
                            report,
                            target_requests=2 if args.target_u2 else 1,
                            allow_u2=args.target_u2,
                            expected_target_batches=expected_target_batches,
                        ):
                            if args.target_cancel_replace:
                                lifecycle_probe.run_decode_cancel_replace(
                                    args, bindings, report, deadline
                                )
                            elif args.target_u2:
                                from hccl_native_attention_pd_dspark_u2_probe import (
                                    run_decode_requests,
                                )

                                run_decode_requests(args, bindings, report, deadline)
                            else:
                                run_decode(args, bindings, report, deadline)
                    else:
                        run_decode(args, bindings, report, deadline)
        report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        if runtime_imported:
            from dsv41_dspark_speculator_probe import loaded_runtime_libraries

            try:
                report["loaded_runtime_libraries"] = loaded_runtime_libraries()
            except OSError as error:
                report["loaded_runtime_libraries_error"] = {
                    "type": type(error).__name__,
                    "message": str(error),
                }
        write_json(args.output_dir / f"{args.role}.json", report)


def verify_pair_messages(attention, ffn, expected_counts):
    """Check canonical codec observations; these are not raw socket captures."""
    first = attention["pair_control_messages"]
    second = ffn["pair_control_messages"]
    sequence = [
        ("send_returned", "HELLO"),
        ("receive_returned", "HELLO"),
        *[
            (direction, kind)
            for _ in expected_counts
            for direction, kind in (
                ("send_returned", "FORWARD"),
                ("receive_returned", "ACCEPT"),
                ("receive_returned", "COMPLETE"),
            )
        ],
        ("send_returned", "STOP"),
        ("receive_returned", "STOP_ACK"),
    ]
    assert len(first) == len(second) == len(sequence)
    for records, role, peer_rank in ((first, "attention", 0), (second, "ffn", 1)):
        for ordinal, (entry, (direction, kind)) in enumerate(
            zip(records, sequence, strict=True)
        ):
            expected_direction = (
                direction
                if role == "attention"
                else (
                    "receive_returned"
                    if direction == "send_returned"
                    else "send_returned"
                )
            )
            assert type(entry["ordinal"]) is int and entry["ordinal"] == ordinal
            assert entry["direction"] == expected_direction
            assert entry["role"] == role
            assert type(entry["peer_pair_rank"]) is int
            assert entry["peer_pair_rank"] == peer_rank
            payload = entry["encoded_message"]
            assert payload["kind"] == kind
            assert type(payload["version"]) is int
            assert payload["version"] == LEGACY_PAIR_PROTOCOL_VERSION
            canonical = json.dumps(
                payload,
                ensure_ascii=False,
                allow_nan=False,
                separators=(",", ":"),
                sort_keys=True,
            ).encode()
            assert hashlib.sha256(canonical).hexdigest() == entry["sha256"]
            fields = {"kind", "version"}
            if kind == "HELLO":
                fields |= {"role", "capabilities"}
                sender = (
                    role
                    if expected_direction == "send_returned"
                    else ("ffn" if role == "attention" else "attention")
                )
                assert payload["role"] == sender
                capabilities = payload["capabilities"]
                assert set(capabilities) == {
                    "hidden_size",
                    "vocab_size",
                    "max_tokens",
                    "layer_indices",
                    "native_tp_size",
                    "pair_rank",
                }
                for name in (
                    "hidden_size",
                    "vocab_size",
                    "max_tokens",
                    "native_tp_size",
                ):
                    assert type(capabilities[name]) is int
                    assert 1 <= capabilities[name] <= MAX_PROTOCOL_INTEGER
                assert capabilities["hidden_size"] == TARGET_HIDDEN_SIZE
                assert capabilities["vocab_size"] == TARGET_VOCAB_SIZE
                assert capabilities["max_tokens"] >= max(expected_counts)
                assert capabilities["native_tp_size"] == 1
                assert type(capabilities["pair_rank"]) is int
                assert capabilities["pair_rank"] == 0
                assert capabilities["layer_indices"] == [0, 1]
                assert all(
                    type(layer) is int for layer in capabilities["layer_indices"]
                )
            elif kind == "FORWARD":
                fields.add("plan")
            elif kind in ("ACCEPT", "COMPLETE"):
                fields.add("transaction_id")
            assert set(payload) == fields
    assert all(
        one["sha256"] == two["sha256"] for one, two in zip(first, second, strict=True)
    )
    assert (
        first[0]["encoded_message"]["capabilities"]
        == first[1]["encoded_message"]["capabilities"]
    )
    transactions = []
    for ordinal, count in enumerate(expected_counts):
        forward, accept, complete = first[2 + ordinal * 3 : 5 + ordinal * 3]
        plan = forward["encoded_message"]["plan"]
        assert set(plan) == {
            "transaction_id",
            "layer_indices",
            "valid_tokens",
            "padded_tokens",
            "mode",
            "stage_idx",
        }
        transaction_id = plan["transaction_id"]
        assert isinstance(transaction_id, str) and transaction_id.strip()
        assert len(transaction_id.encode("utf-8")) <= MAX_TRANSACTION_ID_BYTES
        transactions.append(transaction_id)
        assert (
            accept["encoded_message"]["transaction_id"]
            == complete["encoded_message"]["transaction_id"]
            == transaction_id
        )
        assert all(
            type(plan[name]) is int
            for name in ("valid_tokens", "padded_tokens", "stage_idx")
        )
        assert plan["valid_tokens"] == plan["padded_tokens"] == count
        assert plan["mode"] == "target" and plan["stage_idx"] == 0
        assert plan["layer_indices"] == [0, 1]
        assert all(type(layer) is int for layer in plan["layer_indices"])
    assert len(set(transactions)) == len(transactions)
    return {"transaction_ids": transactions, "bidirectional_codec_records_match": True}


def supervise(args) -> dict:
    from hccl_eager_backend_probe import kill_owned, observe_owned
    from hccl_staged_probe import select_port_block

    ports = select_port_block(4)
    run_id = uuid.uuid4().hex
    started = time.monotonic()
    children, owned = {}, {}
    local_devices = {
        "attention": args.devices[ROLES.index("kv_consumer")],
        "ffn": args.devices[ROLES.index("ffn_consumer")],
    }
    report = {
        "success": False,
        "run_id": run_id,
        "local_devices": local_devices,
        "target_logits_policy": args.target_logits_policy,
        "continue_after_rejection_requested": args.continue_after_rejection,
        "target_graph_requested": args.target_graph,
        "target_u2_requested": args.target_u2,
        "target_cancel_replace_requested": args.target_cancel_replace,
        "graph_compute_overlap_requested": args.graph_compute_overlap,
        "graph_all_axes_requested": args.graph_all_axes,
        "graph_exchange_order_requested": args.graph_exchange_order,
        "timed_out": False,
        "forced_killed_pids": [],
        "native_tp_world_size_per_process": 1,
        "afd_pair_world_size": 2,
        "independent_afd_pair_count": 2,
        "eager_stream_overlap_requested": args.eager_stream_overlap,
    }
    try:
        with ExitStack() as stack:
            for index, role in enumerate(ROLES):
                consumer_pair = role in ("kv_consumer", "ffn_consumer")
                log = stack.enter_context((args.output_dir / f"{role}.log").open("wb"))
                command = [
                    sys.executable,
                    "-B",
                    str(Path(__file__).resolve()),
                    "--run",
                    "--worker",
                    "--role",
                    role,
                    "--run-id",
                    run_id,
                    "--device",
                    str(args.devices[index]),
                    "--model",
                    args.model,
                    "--output-dir",
                    str(args.output_dir),
                    "--timeout",
                    str(args.timeout),
                    "--host",
                    args.host,
                    "--handshake-port",
                    str(ports + int(consumer_pair)),
                    "--afd-port",
                    str(ports + 2 + int(consumer_pair)),
                    "--target-logits-policy",
                    args.target_logits_policy,
                ]
                if args.observe_ready_frontier:
                    command.append("--observe-ready-frontier")
                if args.continue_after_rejection:
                    command.append("--continue-after-rejection")
                if args.target_graph:
                    command.append("--target-graph")
                if args.target_u2:
                    command.append("--target-u2")
                if args.target_cancel_replace:
                    command.append("--target-cancel-replace")
                if args.eager_stream_overlap:
                    command.append("--eager-stream-overlap")
                if args.graph_compute_overlap:
                    command.append("--graph-compute-overlap")
                if args.graph_all_axes:
                    command.append("--graph-all-axes")
                command.extend(["--graph-exchange-order", args.graph_exchange_order])
                children[role] = subprocess.Popen(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    env=os.environ
                    | {"VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT": str(RETENTION_TIMEOUT)},
                )
            while any(child.poll() is None for child in children.values()):
                for child in children.values():
                    if child.poll() is None:
                        observe_owned(child.pid, owned)
                write_json(
                    args.output_dir / "ownership.json",
                    {
                        "supervisor_pid": os.getpid(),
                        "workers": {
                            role: child.pid for role, child in children.items()
                        },
                        "owned_pid_start_ticks": {
                            str(pid): ticks for pid, ticks in owned.items()
                        },
                    },
                )
                failures = {
                    role: child.returncode
                    for role, child in children.items()
                    if child.poll() is not None and child.returncode != 0
                }
                if failures:
                    raise RuntimeError(f"live native decode worker failed: {failures}")
                if time.monotonic() - started >= args.timeout:
                    report["timed_out"] = True
                    raise TimeoutError("live native decode exceeded total bound")
                time.sleep(POLL_SECONDS)
            report["returncodes"] = {
                role: child.returncode for role, child in children.items()
            }
            report["workers"] = {
                role: json.loads((args.output_dir / f"{role}.json").read_text())
                for role in children
            }
            assert all(code == 0 for code in report["returncodes"].values())
            assert all(worker["success"] for worker in report["workers"].values())
            producer, consumer = (
                report["workers"]["kv_producer"],
                report["workers"]["kv_consumer"],
            )
            assert producer["typed_done_observed"]
            assert consumer["native_decode_and_verification_accepted"]
            for role in ("ffn_producer", "ffn_consumer"):
                assert report["workers"][role]["native_ffn"]["native_daemon_retired"]
            if args.observe_ready_frontier:
                assert producer["ready_frontier"]["status"] == "passed"
            report["pair_protocols"] = {
                "producer": verify_pair_messages(
                    producer,
                    report["workers"]["ffn_producer"],
                    (len(PROMPT) - 1,)
                    * (3 if args.target_cancel_replace else 2 if args.target_u2 else 1),
                ),
            }
            if args.eager_stream_overlap:
                from hccl_native_attention_pd_dspark_eager_probe import (
                    verify_eager_lifecycle,
                )

                assert len(producer["sources"]) == 3
                assert set(producer["typed_done_source_ids"]) == {
                    source["request_id"] for source in producer["sources"]
                }
                report["pair_protocols"]["consumer"] = verify_eager_lifecycle(
                    consumer, report["workers"]["ffn_consumer"]
                )
                report["success"] = True
                return report
            if args.target_graph:
                if args.graph_exchange_order == "cross_layer_v1":
                    from hccl_native_attention_pd_dspark_cross_layer_probe import (
                        verify_cross_layer_lifecycle,
                    )

                    assert len(producer["sources"]) == 3
                    assert set(producer["typed_done_source_ids"]) == {
                        item["request_id"] for item in producer["sources"]
                    }
                    report["pair_protocols"]["consumer"] = verify_cross_layer_lifecycle(
                        consumer,
                        report["workers"]["ffn_consumer"],
                        local_devices=local_devices,
                    )
                elif args.graph_compute_overlap:
                    from hccl_native_attention_pd_dspark_overlap_probe import (
                        verify_graph_compute_lifecycle,
                    )

                    assert len(producer["sources"]) == 3
                    assert set(producer["typed_done_source_ids"]) == {
                        source["request_id"] for source in producer["sources"]
                    }
                    report["pair_protocols"]["consumer"] = (
                        verify_graph_compute_lifecycle(
                            consumer,
                            report["workers"]["ffn_consumer"],
                            local_devices=local_devices,
                            graph_all_axes=args.graph_all_axes,
                        )
                    )
                elif args.target_cancel_replace:
                    from hccl_native_attention_pd_dspark_lifecycle_probe import (
                        verify_decode_cancel_replace,
                    )

                    assert len(producer["sources"]) == 3
                    assert set(producer["typed_done_source_ids"]) == {
                        source["request_id"] for source in producer["sources"]
                    }
                    report["pair_protocols"]["consumer"] = verify_decode_cancel_replace(
                        consumer,
                        report["workers"]["ffn_consumer"],
                        local_devices=local_devices,
                    )
                elif args.target_u2:
                    from hccl_native_attention_pd_dspark_u2_probe import (
                        verify_graph_decode_requests,
                    )

                    assert len(producer["sources"]) == 2
                    assert set(producer["typed_done_source_ids"]) == {
                        source["request_id"] for source in producer["sources"]
                    }
                    report["pair_protocols"]["consumer"] = verify_graph_decode_requests(
                        consumer,
                        report["workers"]["ffn_consumer"],
                        local_devices=local_devices,
                    )
                else:
                    from hccl_native_attention_pd_dspark_graph_probe import (
                        verify_graph_decode,
                    )

                    report["pair_protocols"]["consumer"] = verify_graph_decode(
                        consumer,
                        report["workers"]["ffn_consumer"],
                        local_devices=local_devices,
                    )
                report["success"] = True
                return report
            batches = (
                REJECTION_CONTINUATION_BATCHES
                if args.continue_after_rejection
                else DECODE_BATCHES
            )
            report["pair_protocols"]["consumer"] = verify_pair_messages(
                consumer,
                report["workers"]["ffn_consumer"],
                tuple(len(batch) for batch in batches),
            )
            if args.continue_after_rejection:
                assert consumer["continue_after_rejection_requested"] is True
                assert consumer["native_post_rejection_continuation_accepted"] is True
                assert consumer["max_output_tokens"] == (
                    REJECTION_CONTINUATION_MAX_OUTPUT_TOKENS
                )
                assert consumer["final_request_status"] == "FINISHED_LENGTH_CAPPED"
                steps = consumer["decode_steps"]
                assert len(steps) == len(REJECTION_CONTINUATION_BATCHES)
                expected_outputs = []
                for detail, batch, positions, sampled in zip(
                    steps,
                    REJECTION_CONTINUATION_BATCHES,
                    REJECTION_CONTINUATION_POSITIONS,
                    ((7,), (7, 8), (7, 8)),
                    strict=True,
                ):
                    expected_outputs.extend(sampled)
                    assert detail["batch_before_sample"]["input_ids"] == list(batch)
                    assert detail["batch_before_sample"]["positions"] == list(positions)
                    assert detail["sampled_token_ids"] == [list(sampled)]
                    assert detail["native_num_sampled"] == [len(sampled)]
                    assert detail["native_num_rejected"] == [len(batch) - len(sampled)]
                    assert detail["computed_cpu"] == positions[0]
                    assert detail["seq_lens_cpu"] == [positions[0] + len(batch)]
                    assert detail["computed_gpu"] == positions[0] + len(sampled)
                    assert detail["scheduler_computed_after_update"] == (
                        positions[0] + len(sampled)
                    )
                    assert detail["scheduler_outputs"] == expected_outputs
                    assert detail["native_history"] == list(PROMPT) + expected_outputs
            f2 = report["workers"]["ffn_consumer"]["native_ffn"]["steps"]
            expected_layers = [
                layer
                for step in consumer["decode_steps"]
                for layer in step["independent_layer_oracles"]
            ]
            assert len(f2) == len(expected_layers)
            for actual, expected in zip(f2, expected_layers, strict=True):
                assert all(
                    actual[key] == expected[key]
                    for key in ("input_ids", "layer", "hidden", "router_fp32")
                )
            report["native_post_rejection_continuation_accepted"] = (
                args.continue_after_rejection
            )
            report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
    finally:
        for child in children.values():
            if child.poll() is None:
                observe_owned(child.pid, owned)
        report["forced_killed_pids"] = kill_owned(owned)
        if report["forced_killed_pids"]:
            report["success"] = False
        for child in children.values():
            if child.poll() is None:
                child.wait(timeout=GROUP_TIMEOUT)
        report["elapsed_seconds"] = time.monotonic() - started
        write_json(args.output_dir / "summary.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--devices", default="0,2,4,6")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--target-logits-policy", choices=POLICIES, default=POLICIES[0])
    parser.add_argument(
        "--continue-after-rejection",
        action="store_true",
        help="Run a third eager/U1 verification after rejection, with max_tokens=5",
    )
    parser.add_argument("--observe-ready-frontier", action="store_true")
    parser.add_argument("--target-graph", action="store_true")
    parser.add_argument("--target-u2", action="store_true")
    parser.add_argument("--target-cancel-replace", action="store_true")
    parser.add_argument("--eager-stream-overlap", action="store_true")
    parser.add_argument("--graph-compute-overlap", action="store_true")
    parser.add_argument("--graph-all-axes", action="store_true")
    parser.add_argument(
        "--graph-exchange-order",
        choices=("stage_serial", "cross_layer_v1"),
        default="stage_serial",
    )
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--role", choices=ROLES, help=argparse.SUPPRESS)
    parser.add_argument("--run-id", help=argparse.SUPPRESS)
    parser.add_argument("--device", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--handshake-port", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--afd-port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.continue_after_rejection and (
        args.target_logits_policy != "reject-second-verification-row"
        or args.target_graph
        or args.target_u2
        or args.target_cancel_replace
        or args.eager_stream_overlap
        or args.graph_compute_overlap
        or args.graph_all_axes
        or args.graph_exchange_order != "stage_serial"
    ):
        parser.error(
            "--continue-after-rejection requires eager U1 "
            "reject-second-verification-row decode with Graph axes off"
        )
    if args.eager_stream_overlap and (
        args.target_graph
        or not args.target_cancel_replace
        or not args.target_u2
        or args.graph_compute_overlap
        or args.graph_all_axes
        or args.graph_exchange_order != "stage_serial"
    ):
        parser.error(
            "--eager-stream-overlap requires eager U2 cancel/replace "
            "and stage_serial with Graph axes off"
        )
    if args.target_cancel_replace and not args.target_u2:
        parser.error("--target-cancel-replace requires --target-u2")
    if args.graph_exchange_order == "cross_layer_v1" and not args.graph_all_axes:
        parser.error("cross_layer_v1 requires --graph-all-axes")
    if args.graph_all_axes and not args.graph_compute_overlap:
        parser.error("--graph-all-axes requires --graph-compute-overlap")
    if args.graph_compute_overlap and not args.target_cancel_replace:
        parser.error("--graph-compute-overlap requires --target-cancel-replace")
    if args.target_u2 and (
        not (args.target_graph or args.eager_stream_overlap)
        or args.target_logits_policy != "constant7"
        or args.observe_ready_frontier
    ):
        parser.error(
            "--target-u2 requires Graph or explicit eager streams and constant7; "
            "Ready frontier negatives use the separate U1 case"
        )
    try:
        args.devices = tuple(int(value) for value in args.devices.split(","))
    except ValueError:
        parser.error("--devices requires four comma-separated integers")
    if (
        len(args.devices) != len(ROLES)
        or len(set(args.devices)) != len(ROLES)
        or min(args.devices) < 0
    ):
        parser.error("--devices requires four distinct nonnegative integers")
    if not 0 < args.timeout < RETENTION_TIMEOUT:
        parser.error("--timeout must be positive and below source retention timeout")
    if args.worker and (
        not args.run
        or not args.run_id
        or args.device is None
        or args.role is None
        or args.handshake_port is None
        or args.afd_port is None
    ):
        parser.error("hidden worker requires complete supervisor identity")
    if not args.run:
        print(
            json.dumps(
                {
                    "run": False,
                    "runtime_imported": False,
                    "devices": args.devices,
                    "target_logits_policy": args.target_logits_policy,
                    "continue_after_rejection_requested": (
                        args.continue_after_rejection
                    ),
                    "observe_ready_frontier_requested": args.observe_ready_frontier,
                    "target_graph_requested": args.target_graph,
                    "target_u2_requested": args.target_u2,
                    "target_cancel_replace_requested": args.target_cancel_replace,
                    "eager_stream_overlap_requested": args.eager_stream_overlap,
                    "graph_compute_overlap_requested": args.graph_compute_overlap,
                    "graph_all_axes_requested": args.graph_all_axes,
                    "graph_exchange_order_requested": args.graph_exchange_order,
                    "scope": (
                        "controlled target/FFN; real native draft/rejection/PD; "
                        "explicit --run required"
                    ),
                }
            )
        )
        return 0
    args.output_dir = args.output_dir.resolve()
    if args.worker:
        run_worker(args)
        return 0
    args.output_dir.mkdir(parents=True, exist_ok=False)
    return 0 if supervise(args)["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
