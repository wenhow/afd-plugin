# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native DSpark cancel, survivor completion and replacement on one D owner.

This supervised successor uses the original Scheduler, execute/sample/propose,
typed PD transfer and Graph owner. Runtime imports stay inside worker entries.
The target arithmetic is controlled; no serving or full-model claim is made.
"""

from __future__ import annotations

import json
import time
from collections import Counter
from dataclasses import asdict

PROMPTS = (
    (11, 12, 13, 14, 15),
    (21, 22, 23, 24, 25),
    (31, 32, 33, 34, 35),
)
INITIAL_REQUESTS = 2
SOURCE_COUNT = len(PROMPTS)
INITIAL_MAX_OUTPUT_TOKENS = 7
REPLACEMENT_MAX_OUTPUT_TOKENS = 4
QUERY_ROWS = 3
POLL_SECONDS = 0.1
TARGET_BATCHES = (
    (2, "eager", 2),
    (2, "replay", 0),
    (1, "replay", 0),
    (1, "eager", 1),
    (1, "replay", 0),
)
TARGET_REQUEST_COUNTS = tuple(item[0] for item in TARGET_BATCHES)
TARGET_PHASES = tuple(item[1] for item in TARGET_BATCHES)


def _owner_identity(bindings):
    from hccl_native_attention_pd_dspark_run_probe import physical_pages

    owner = bindings.owner
    worker = owner.kv_connector.kv_connector.connector_worker
    _, pages = physical_pages(bindings)
    return {
        "owner": id(owner),
        "model": id(owner.model),
        "head": id(owner.model.language_model.lm_head),
        "model_state": id(owner.model_state),
        "request_state": id(owner.req_states),
        "input_buffers": id(owner.input_buffers),
        "block_tables": id(owner.block_tables),
        "sampler": id(owner.sampler),
        "speculator": id(owner.speculator),
        "active_kv": id(owner.kv_connector),
        "receiver": id(worker.kv_recv_thread),
        "engine": id(worker.engine),
        "physical_pointers": [page.data_ptr() for page in pages],
    }


def _new_request(args, source, peer, prompt, ordinal, max_tokens):
    from vllm.sampling_params import SamplingParams
    from vllm.v1.request import Request

    from afd_plugin.compat.npu.kv_layout_connector import DSPARK_SOURCE_PARAM

    assert source["prompt"] == list(prompt)
    params = dict(source["source_transfer_params"])
    params["remote_block_ids"] = tuple(list(ids) for ids in params["remote_block_ids"])
    assert DSPARK_SOURCE_PARAM in params
    assert params["remote_request_id"] == source["request_id"]
    assert params["remote_engine_id"] == peer["engine_id"]
    assert params["remote_host"] == peer["host"]
    assert params["remote_port"] == peer["port"]
    return Request(
        f"{args.run_id}-destination-{ordinal}",
        list(prompt),
        SamplingParams(
            temperature=0,
            max_tokens=max_tokens,
            extra_args={"kv_transfer_params": params},
        ),
        None,
    )


def _read_prefixes(
    args,
    bindings,
    scheduler,
    report,
    peer,
    requests,
    step,
    before,
    deadline,
    *,
    label,
):
    """Submit actual async metadata and resume only after native receive output."""
    from hccl_native_attention_pd_dspark_run_probe import (
        physical_pages,
        snapshot_pages,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.v1.core.sched.interface import PauseState
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import RequestStatus

    from afd_plugin.compat.npu.kv_layout_connector import (
        DsparkMooncakeConnectorMetadata,
    )

    owner = bindings.owner
    assert not step.total_num_scheduled_tokens and not step.has_sync_kv_loads
    assert all(
        request.status == RequestStatus.WAITING_FOR_REMOTE_KVS
        for request in requests.values()
    )
    metadata = step.kv_connector_metadata
    assert isinstance(metadata, DsparkMooncakeConnectorMetadata)
    assert set(metadata.requests) == set(metadata.dspark_destinations) == set(requests)
    blocks = {
        request_id: tuple(tuple(ids) for ids in transfer.local_block_ids)
        for request_id, transfer in metadata.requests.items()
    }
    pairs = {
        request_id: tuple(
            tuple(zip(remote, local, strict=True))
            for remote, local in zip(
                transfer.remote_block_ids, transfer.local_block_ids, strict=True
            )
        )
        for request_id, transfer in metadata.requests.items()
    }
    report.setdefault("destinations", {}).update(
        {
            request_id: asdict(destination)
            for request_id, destination in metadata.dspark_destinations.items()
        }
    )
    report.setdefault("group_block_pairs_by_request", {}).update(pairs)
    scheduler.set_pause_state(PauseState.PAUSED_NEW)
    record = {
        "label": label,
        "initial_schedule": scheduler_record(step),
        "pause_states": [scheduler.pause_state.name],
        "finished_recving": [],
    }
    report["native_dspark_request_lifecycle"]["transfers"].append(record)
    completed, zero_ids = set(), set()
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("DSpark lifecycle remote prefix did not complete")
        assert not step.total_num_scheduled_tokens and not step.has_sync_kv_loads
        returned = owner.execute_model(step)
        assert isinstance(returned, ModelRunnerOutput)
        zero_ids.update(step.new_block_ids_to_zero or ())
        output = returned.kv_connector_output
        received = set(() if output is None else output.finished_recving or ())
        assert received <= set(requests) and not completed.intersection(received)
        assert output is None or not (
            output.finished_sending or output.failed_recving or output.invalid_block_ids
        )
        completed.update(received)
        report["zero_steps"].append(
            {
                "label": label,
                "schedule": scheduler_record(step),
                "finished_recving": sorted(received),
                "kv_connector_output_present": output is not None,
            }
        )
        scheduler.update_from_output(step, returned)
        if completed == set(requests):
            scheduler.set_pause_state(PauseState.UNPAUSED)
            record["pause_states"].append(scheduler.pause_state.name)
        step = scheduler.schedule()
        if step.total_num_scheduled_tokens:
            assert completed == set(requests)
            break
        time.sleep(POLL_SECONDS)
    _, pages = physical_pages(bindings)
    raw = [bytes(page.cpu().numpy()) for page in pages]
    for index, descriptor in enumerate(bindings.kv_config.kv_cache_tensors):
        expected = bytearray(before[index])
        stride = descriptor.block_stride
        for block in zero_ids:
            expected[block * stride : (block + 1) * stride] = bytes(stride)
        source = (args.output_dir / peer["source_pages"][index]["path"]).read_bytes()
        mapping = {}
        for request_pairs in pairs.values():
            for group_id, group in enumerate(bindings.kv_config.kv_cache_groups):
                if set(group.layer_names).intersection(descriptor.layers):
                    for remote, local in request_pairs[group_id]:
                        assert mapping.setdefault(local, remote) == remote
        for local, remote in mapping.items():
            expected[local * stride : (local + 1) * stride] = source[
                remote * stride : (remote + 1) * stride
            ]
        assert raw[index] == expected
    record["finished_recving"] = sorted(completed)
    record["new_block_ids_to_zero"] = sorted(zero_ids)
    record["after_read"] = snapshot_pages(pages, args.output_dir, label + "-after-read")
    record["whole_physical_pool_oracle_passed"] = True
    return step, blocks, raw


def _retire_requests(args, bindings, scheduler, report, raw_pages, expected, label):
    from hccl_native_attention_pd_dspark_run_probe import physical_pages
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.v1.outputs import ModelRunnerOutput

    step = scheduler.schedule()
    assert step.total_num_scheduled_tokens == 0 and step.finished_req_ids == expected
    returned = bindings.owner.execute_model(step)
    assert isinstance(returned, ModelRunnerOutput)
    output = returned.kv_connector_output
    assert output is None or not (
        output.finished_recving
        or output.finished_sending
        or output.failed_recving
        or output.invalid_block_ids
    )
    scheduler.update_from_output(step, returned)
    assert not scheduler.requests and not bindings.owner.req_states.req_id_to_index
    assert bindings.owner.execute_model_state is None
    _, pages = physical_pages(bindings)
    assert [bytes(page.cpu().numpy()) for page in pages] == raw_pages
    report["zero_steps"].append(
        {
            "label": label,
            "schedule": scheduler_record(step),
            "finished_recving": [],
            "kv_connector_output_present": returned.kv_connector_output is not None,
        }
    )
    return step


def run_decode_cancel_replace(args, bindings, report, deadline):
    """Cancel A, finish survivor B, then load and execute C with the same owner."""
    from hccl_native_attention_pd_dspark_decode_probe import module_weights
    from hccl_native_attention_pd_dspark_run_probe import (
        await_record,
        physical_pages,
        snapshot_pages,
        write_json,
    )
    from hccl_native_attention_pd_dspark_u2_probe import execute_decode_step
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.request import RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager

    assert args.target_u2
    if not args.target_graph:
        assert args.eager_stream_overlap
    assert args.target_logits_policy == "constant7"
    owner, config = bindings.owner, bindings.owner.vllm_config
    assert config.parallel_config.use_ubatching and owner.ubatch_runner is not None
    assert config.scheduler_config.max_num_seqs == INITIAL_REQUESTS
    peer = await_record(args.output_dir / "producer-ready.json", args.run_id, deadline)
    assert report["draft_weights"] == peer["draft_weights"]
    assert len(peer["sources"]) == SOURCE_COUNT
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        StructuredOutputManager(config),
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    idle_usage = scheduler.kv_cache_manager.usage
    identity = _owner_identity(bindings)
    lifecycle = report["native_dspark_request_lifecycle"] = {
        "accepted": False,
        "transfers": [],
        "initial_max_output_tokens": INITIAL_MAX_OUTPUT_TOKENS,
        "replacement_max_output_tokens": REPLACEMENT_MAX_OUTPUT_TOKENS,
        "owner_identity_before": identity,
        "concurrent_survivor_replacement_executed": False,
        "physical_block_reuse_guaranteed": False,
    }
    layout, pages = physical_pages(bindings)
    report["layout"] = json.loads(layout.to_json())
    report["zero_steps"], report["decode_steps"] = [], []
    weights = report["shared_weights_before"] = module_weights(owner)
    requests, prompts = {}, {}
    for ordinal in range(INITIAL_REQUESTS):
        request = _new_request(
            args,
            peer["sources"][ordinal],
            peer,
            PROMPTS[ordinal],
            ordinal,
            INITIAL_MAX_OUTPUT_TOKENS,
        )
        scheduler.add_request(request)
        requests[request.request_id] = request
        prompts[request.request_id] = PROMPTS[ordinal]
    original_ids = tuple(requests)
    before = [
        (args.output_dir / entry["path"]).read_bytes() for entry in report["before"]
    ]
    step, blocks, raw = _read_prefixes(
        args,
        bindings,
        scheduler,
        report,
        peer,
        requests,
        scheduler.schedule(),
        before,
        deadline,
        label="initial",
    )
    for ordinal, tokens in enumerate(([7], [7, 7, 7])):
        raw, detail = execute_decode_step(
            args,
            bindings,
            scheduler,
            report,
            step,
            requests,
            prompts,
            blocks,
            raw,
            expected_by_request=dict.fromkeys(requests, tokens),
            weights=weights,
        )
        # schedule() may allocate additional lookahead blocks. Preserve the
        # actual allocator's pre-execute result, separate from transfer IDs.
        blocks.update(detail["scheduler_blocks_before_execute"])
        assert all(
            request.status == RequestStatus.RUNNING for request in requests.values()
        )
        assert _owner_identity(bindings) == identity
        if ordinal == 0:
            step = scheduler.schedule()
    cancelled_id, survivor_id = original_ids
    cancelled, survivor = requests[cancelled_id], requests[survivor_id]
    original_slots = {
        request_id: detail["request_states"][request_id]["request_index"]
        for request_id in requests
    }
    cancelled_blocks = blocks[cancelled_id]
    usage_before_cancel = scheduler.kv_cache_manager.usage
    assert scheduler.finish_requests(cancelled_id, RequestStatus.FINISHED_ABORTED) == [
        cancelled
    ]
    assert cancelled.status == RequestStatus.FINISHED_ABORTED
    assert cancelled_id not in scheduler.requests
    assert all(
        not group for group in scheduler.kv_cache_manager.get_block_ids(cancelled_id)
    )
    assert scheduler.kv_cache_manager.usage < usage_before_cancel
    lifecycle["cancel"] = {
        "request_id": cancelled_id,
        "status": cancelled.status.name,
        "previous_blocks": cancelled_blocks,
        "native_request_index": original_slots[cancelled_id],
        "after_completed_target_steps": len(report["decode_steps"]),
        "kv_usage_before": usage_before_cancel,
        "kv_usage_after": scheduler.kv_cache_manager.usage,
    }
    step = scheduler.schedule()
    assert step.finished_req_ids == {cancelled_id}
    assert step.num_scheduled_tokens == {survivor_id: QUERY_ROWS}
    raw, survivor_detail = execute_decode_step(
        args,
        bindings,
        scheduler,
        report,
        step,
        {survivor_id: survivor},
        {survivor_id: prompts[survivor_id]},
        {survivor_id: blocks[survivor_id]},
        raw,
        expected_by_request={survivor_id: [7, 7, 7]},
        weights=weights,
    )
    blocks.update(survivor_detail["scheduler_blocks_before_execute"])
    assert cancelled_id not in owner.req_states.req_id_to_index
    assert survivor.status == RequestStatus.FINISHED_LENGTH_CAPPED
    assert list(survivor.output_token_ids) == [7] * INITIAL_MAX_OUTPUT_TOKENS
    lifecycle["cancel"]["native_runner_retired_by_survivor_execute"] = True
    lifecycle["survivor"] = {
        "request_id": survivor_id,
        "status": survivor.status.name,
        "native_request_index": survivor_detail["request_states"][survivor_id][
            "request_index"
        ],
        "output_token_ids": list(survivor.output_token_ids),
        "last_execution_blocks": blocks[survivor_id],
    }
    retirement = _retire_requests(
        args, bindings, scheduler, report, raw, {survivor_id}, "survivor-retirement"
    )
    lifecycle["initial_retirement_schedule"] = scheduler_record(retirement)
    assert scheduler.kv_cache_manager.usage == idle_usage
    assert _owner_identity(bindings) == identity
    replacement = _new_request(
        args,
        peer["sources"][INITIAL_REQUESTS],
        peer,
        PROMPTS[INITIAL_REQUESTS],
        INITIAL_REQUESTS,
        REPLACEMENT_MAX_OUTPUT_TOKENS,
    )
    scheduler.add_request(replacement)
    replacement_id = replacement.request_id
    replacement_requests = {replacement_id: replacement}
    replacement_prompts = {replacement_id: PROMPTS[INITIAL_REQUESTS]}
    step, replacement_blocks, raw = _read_prefixes(
        args,
        bindings,
        scheduler,
        report,
        peer,
        replacement_requests,
        scheduler.schedule(),
        raw,
        deadline,
        label="replacement",
    )
    for ordinal, tokens in enumerate(([7], [7, 7, 7])):
        raw, detail = execute_decode_step(
            args,
            bindings,
            scheduler,
            report,
            step,
            replacement_requests,
            replacement_prompts,
            replacement_blocks,
            raw,
            expected_by_request={replacement_id: tokens},
            weights=weights,
        )
        replacement_blocks.update(detail["scheduler_blocks_before_execute"])
        assert not set(original_ids).intersection(owner.req_states.req_id_to_index)
        assert _owner_identity(bindings) == identity
        if ordinal == 0:
            replacement_slot = detail["request_states"][replacement_id]["request_index"]
            assert replacement_slot in set(original_slots.values())
            old_blocks = {
                block
                for per_request in blocks.values()
                for group in per_request
                for block in group
            }
            new_blocks = {
                block for group in replacement_blocks[replacement_id] for block in group
            }
            lifecycle["replacement"] = {
                "request_id": replacement_id,
                "native_request_index": replacement_slot,
                "reused_prior_request_id": next(
                    request_id
                    for request_id, index in original_slots.items()
                    if index == replacement_slot
                ),
                "actual_reused_block_ids": sorted(old_blocks & new_blocks),
                "block_ids": replacement_blocks[replacement_id],
                "first_input_ids": detail["expected_inputs_by_request"][replacement_id],
            }
            assert lifecycle["replacement"]["first_input_ids"] == [
                PROMPTS[INITIAL_REQUESTS][-1],
                0,
                0,
            ]
            assert replacement.status == RequestStatus.RUNNING
            step = scheduler.schedule()
    assert replacement.status == RequestStatus.FINISHED_LENGTH_CAPPED
    assert list(replacement.output_token_ids) == [7] * REPLACEMENT_MAX_OUTPUT_TOKENS
    lifecycle["replacement"]["status"] = replacement.status.name
    lifecycle["replacement"]["output_token_ids"] = list(replacement.output_token_ids)
    retirement = _retire_requests(
        args,
        bindings,
        scheduler,
        report,
        raw,
        {replacement_id},
        "replacement-retirement",
    )
    report["retirement_schedule"] = scheduler_record(retirement)
    assert scheduler.kv_cache_manager.usage == idle_usage
    assert _owner_identity(bindings) == identity and module_weights(owner) == weights
    lifecycle["owner_identity_after"] = _owner_identity(bindings)
    lifecycle["whole_physical_pages_after"] = snapshot_pages(
        pages, args.output_dir, "lifecycle-after-final-retirement"
    )
    report["typed_read_and_whole_pool_oracle_passed"] = True
    receiver = owner.kv_connector.kv_connector.connector_worker.kv_recv_thread
    assert receiver.is_alive() and not receiver.retired
    owner.prepare_shutdown()
    ensure_kv_transfer_shutdown()
    assert receiver.retired and not receiver.is_alive()
    scheduler.shutdown()
    assert module_weights(owner) == weights
    report["shared_weights_after"] = module_weights(owner)
    owner.shutdown()
    report["receiver_retired"] = True
    report["native_owner_shutdown_returned"] = True
    report["native_decode_and_verification_accepted"] = True
    report["two_request_native_decode_accepted"] = True
    report["native_dspark_request_lifecycle_accepted"] = True
    lifecycle["accepted"] = True
    write_json(args.output_dir / "consumer-verified.json", {"run_id": args.run_id})


def verify_native_request_lifecycle(
    attention, *, target_transactions, padded_tokens_by_step
):
    """Check shared native requests and math after the caller validates wire joins.

    The caller supplies its independent padding declaration and five actual F
    transactions already joined to the accepted target parents. No Graph phase,
    stream policy or transport family is inferred here.
    """
    assert len(target_transactions) == len(TARGET_REQUEST_COUNTS)
    lifecycle = attention["native_dspark_request_lifecycle"]
    assert lifecycle["accepted"]
    assert attention["native_dspark_request_lifecycle_accepted"]
    assert attention["native_decode_and_verification_accepted"]
    assert attention["two_request_native_decode_accepted"]
    assert attention["full_model_accepted"] is False
    assert attention["u2_accepted"] is False
    assert attention["receiver_retired"] and attention["native_owner_shutdown_returned"]
    owner_identity = lifecycle["owner_identity_before"]
    scalar_keys = (
        "owner",
        "model",
        "head",
        "model_state",
        "request_state",
        "input_buffers",
        "block_tables",
        "sampler",
        "speculator",
        "active_kv",
        "receiver",
        "engine",
    )
    assert set(owner_identity) == {*scalar_keys, "physical_pointers"}
    assert all(
        type(owner_identity[name]) is int and owner_identity[name] > 0
        for name in scalar_keys
    )
    pointers = owner_identity["physical_pointers"]
    assert pointers and len(pointers) == len(set(pointers))
    assert all(type(pointer) is int and pointer > 0 for pointer in pointers)
    assert lifecycle["owner_identity_before"] == lifecycle["owner_identity_after"]
    cancel_id = lifecycle["cancel"]["request_id"]
    survivor_id = lifecycle["survivor"]["request_id"]
    replacement_id = lifecycle["replacement"]["request_id"]
    assert all(
        isinstance(request_id, str) and request_id
        for request_id in (cancel_id, survivor_id, replacement_id)
    )
    assert len({cancel_id, survivor_id, replacement_id}) == SOURCE_COUNT
    assert lifecycle["cancel"]["status"] == "FINISHED_ABORTED"
    assert lifecycle["cancel"]["after_completed_target_steps"] == 2
    assert lifecycle["cancel"]["native_runner_retired_by_survivor_execute"]
    assert lifecycle["survivor"]["status"] == "FINISHED_LENGTH_CAPPED"
    assert lifecycle["survivor"]["output_token_ids"] == [7] * INITIAL_MAX_OUTPUT_TOKENS
    assert lifecycle["replacement"]["status"] == "FINISHED_LENGTH_CAPPED"
    assert (
        lifecycle["replacement"]["output_token_ids"]
        == [7] * REPLACEMENT_MAX_OUTPUT_TOKENS
    )
    assert lifecycle["replacement"]["reused_prior_request_id"] in (
        cancel_id,
        survivor_id,
    )
    prior_slots = {
        cancel_id: lifecycle["cancel"]["native_request_index"],
        survivor_id: lifecycle["survivor"]["native_request_index"],
    }
    assert all(type(index) is int and index >= 0 for index in prior_slots.values())
    assert len(set(prior_slots.values())) == INITIAL_REQUESTS
    assert (
        lifecycle["replacement"]["native_request_index"]
        == prior_slots[lifecycle["replacement"]["reused_prior_request_id"]]
    )
    assert lifecycle["replacement"]["first_input_ids"] == [PROMPTS[-1][-1], 0, 0]
    assert [item["label"] for item in lifecycle["transfers"]] == [
        "initial",
        "replacement",
    ]
    assert all(
        transfer["whole_physical_pool_oracle_passed"]
        and transfer["pause_states"] == ["PAUSED_NEW", "UNPAUSED"]
        for transfer in lifecycle["transfers"]
    )
    for transfer, request_ids in zip(
        lifecycle["transfers"],
        ({cancel_id, survivor_id}, {replacement_id}),
        strict=True,
    ):
        assert len(transfer["finished_recving"]) == len(request_ids)
        assert set(transfer["finished_recving"]) == request_ids
    for retirement, request_id in (
        (lifecycle["initial_retirement_schedule"], survivor_id),
        (attention["retirement_schedule"], replacement_id),
    ):
        assert retirement["finished_req_ids"] == [request_id]
        assert retirement["total_num_scheduled_tokens"] == 0
        assert retirement["num_scheduled_tokens"] == {}
        assert not retirement["new_requests"] and not retirement["cached_request_ids"]
        assert any(item["schedule"] == retirement for item in attention["zero_steps"])
    expected_request_sets = (
        {cancel_id, survivor_id},
        {cancel_id, survivor_id},
        {survivor_id},
        {replacement_id},
        {replacement_id},
    )
    declared_prompts = dict(
        zip((cancel_id, survivor_id, replacement_id), PROMPTS, strict=True)
    )
    frontiers = (
        len(PROMPTS[0]) - 1,
        len(PROMPTS[0]),
        len(PROMPTS[0]) + QUERY_ROWS,
        len(PROMPTS[-1]) - 1,
        len(PROMPTS[-1]),
    )
    sampled_counts = (1, QUERY_ROWS, QUERY_ROWS, 1, QUERY_ROWS)
    output_counts = dict.fromkeys(declared_prompts, 0)
    for ordinal, (step, padded_by_stage, request_ids) in enumerate(
        zip(
            attention["decode_steps"],
            padded_tokens_by_step,
            expected_request_sets,
            strict=True,
        )
    ):
        request_count = TARGET_REQUEST_COUNTS[ordinal]
        valid_by_stage = [QUERY_ROWS] * request_count
        assert len(padded_by_stage) == request_count
        assert all(type(rows) is int and rows >= QUERY_ROWS for rows in padded_by_stage)
        batch = step["batch_before_sample"]
        assert set(batch["request_ids"]) == request_ids
        assert len(batch["request_ids"]) == request_count
        assert step["schedule"]["finished_req_ids"] == (
            [cancel_id] if ordinal == 2 else []
        )
        frontier = frontiers[ordinal]
        valid_rows = request_count * QUERY_ROWS
        input_by_request = {
            request_id: [declared_prompts[request_id][-1], 0, 0]
            if ordinal in (0, 3)
            else [7] * QUERY_ROWS
            for request_id in batch["request_ids"]
        }
        assert batch["input_ids"][:valid_rows] == [
            token
            for request_id in batch["request_ids"]
            for token in input_by_request[request_id]
        ]
        assert batch["positions"][:valid_rows] == (
            list(range(frontier, frontier + QUERY_ROWS)) * request_count
        )
        assert batch["num_computed_tokens"] == [frontier] * request_count
        assert batch["logits_indices"] == list(range(valid_rows))
        if ordinal == 3:
            assert (
                lifecycle["replacement"]["first_input_ids"]
                == (batch["input_ids"][:QUERY_ROWS])
            )
        assert set(step["request_states"]) == request_ids
        assert step["sampled_token_ids"] == (
            [[7] * sampled_counts[ordinal]] * request_count
        )
        for request_id, request_state in step["request_states"].items():
            expected_index = (
                lifecycle["replacement"]["native_request_index"]
                if request_id == replacement_id
                else prior_slots[request_id]
            )
            assert request_state["request_index"] == expected_index
            assert request_state["computed_cpu"] == frontier
            assert request_state["computed_gpu"] == frontier + sampled_counts[ordinal]
            output_counts[request_id] += sampled_counts[ordinal]
            assert request_state["native_history"] == (
                list(declared_prompts[request_id]) + [7] * output_counts[request_id]
            )
        assert batch["num_reqs"] == request_count
        assert batch["num_valid_tokens"] == request_count * QUERY_ROWS
        assert batch["num_tokens_after_padding"] == sum(padded_by_stage)
        assert (
            batch["query_start_loc"]
            == batch["query_start_loc_np"]
            == [
                QUERY_ROWS * index
                for index in range(sum(padded_by_stage) // QUERY_ROWS + 1)
            ]
        )
        transaction = target_transactions[ordinal]
        assert transaction["num_stages"] == len(padded_by_stage)
        assert [layer["layer"] for layer in transaction["layer_observations"]] == [0, 1]
        oracles = step["independent_layer_oracles"]
        assert [layer["layer"] for layer in oracles] == [0, 1]
        for layer, expected in zip(
            transaction["layer_observations"], oracles, strict=True
        ):
            assert layer["layer"] == expected["layer"]
            for name in ("input_ids", "hidden", "router_fp32", "output"):
                assert len(layer[name]) == sum(padded_by_stage)
                assert len(expected[name]) == request_count * QUERY_ROWS
                # Retain every padded F row as raw evidence; the independent
                # arithmetic oracle describes only actual request coordinates.
                valid_values = [
                    row
                    for stage in layer["stage_observations"]
                    for row in stage[name][: stage["valid_rows"]]
                ]
                assert valid_values == expected[name]
                assert layer[name] == [
                    row for stage in layer["stage_observations"] for row in stage[name]
                ]
            assert [stage["stage"] for stage in layer["stage_observations"]] == list(
                range(request_count)
            )
            for ordinal, stage in enumerate(layer["stage_observations"]):
                assert stage["transaction_id"] == transaction["transaction_id"]
                assert stage["layer"] == layer["layer"]
                assert stage["rows"] == padded_by_stage[ordinal]
                assert stage["valid_rows"] == valid_by_stage[ordinal]
                for name in ("input_ids", "hidden", "router_fp32", "output"):
                    assert len(stage[name]) == padded_by_stage[ordinal]
                    assert (
                        stage[name][: stage["valid_rows"]]
                        == expected[name][
                            ordinal * QUERY_ROWS : (ordinal + 1) * QUERY_ROWS
                        ]
                    )
    return {
        "native_dspark_request_lifecycle_component_accepted": True,
        "actual_request_count": INITIAL_REQUESTS,
        "actual_query_rows_per_request": QUERY_ROWS,
        "distinct_destination_requests": SOURCE_COUNT,
        "request_slot_reuse_observed": True,
        "physical_block_reuse_guaranteed": False,
        "full_model_accepted": False,
        "u2_accepted": False,
    }


def verify_decode_cancel_replace(
    attention,
    ffn,
    *,
    local_devices,
    graph_compute_overlap=False,
    graph_all_axes=False,
    graph_exchange_order="stage_serial",
):
    """Join actual lifecycle, strict codec parents and every target/F layer row."""
    from hccl_native_attention_pd_dspark_graph_probe import (
        verify_graph_host_records,
        verify_graph_pair_messages,
    )

    detail = attention["target_graph_decode"]
    assert detail["accepted"] and detail["target_u2"]
    inventory = {
        entry["key_digest"]: entry for entry in detail["storage_before"]["entries"]
    }
    assert inventory and len(inventory) == len(detail["storage_before"]["entries"])
    zero_count = len(attention["zero_steps"])
    assert len(detail["executions"]) == zero_count + len(TARGET_REQUEST_COUNTS)
    protocol = verify_graph_pair_messages(
        attention,
        ffn,
        1 + 2 * len(inventory) + len(detail["executions"]),
        target_requests=INITIAL_REQUESTS,
        allow_u2=True,
        graph_exchange_order=graph_exchange_order,
    )
    parents = protocol["parents"]
    assert Counter(parent["phase"] for parent in parents) == {
        "warmup": len(inventory),
        "capture": len(inventory),
        "eager": zero_count + 1 + TARGET_PHASES.count("eager"),
        "replay": TARGET_PHASES.count("replay"),
    }
    for phase in ("warmup", "capture"):
        assert Counter(
            parent["key_digest"] for parent in parents if parent["phase"] == phase
        ) == dict.fromkeys(inventory, 1)
    by_id = {parent["transaction_id"]: parent for parent in parents}
    executions = detail["executions"]
    assert [entry["transaction_id"] for entry in executions] == [
        parent["transaction_id"] for parent in parents[1 + 2 * len(inventory) :]
    ]
    for execution in executions:
        parent = by_id[execution["transaction_id"]]
        assert all(
            parent[name] == execution[name]
            for name in ("phase", "mode", "reason", "key_digest")
        )
        assert sum(parent["valid_tokens"]) == execution["scheduled_tokens"]
    targets = [entry for entry in executions if entry["scheduled_tokens"]]
    assert [entry["phase"] for entry in targets] == list(TARGET_PHASES)
    assert [entry["python_target_calls"] for entry in targets] == [
        item[2] for item in TARGET_BATCHES
    ]
    for execution, (request_count, phase, _) in zip(
        targets, TARGET_BATCHES, strict=True
    ):
        parent = by_id[execution["transaction_id"]]
        assert parent["valid_tokens"] == [QUERY_ROWS] * request_count
        assert parent["padded_tokens"] == (
            [INITIAL_REQUESTS * QUERY_ROWS]
            if phase == "replay" and request_count == 1
            else [QUERY_ROWS] * request_count
        )
        if phase == "replay":
            captured = inventory[parent["key_digest"]]
            assert captured["num_reqs"] == INITIAL_REQUESTS
            assert captured["num_tokens"] == INITIAL_REQUESTS * QUERY_ROWS
            assert captured["num_stages"] == request_count
        else:
            assert not parent["key_digest"]
    service = ffn["native_ffn"]
    assert service["native_daemon_retired"] and service["stop_acknowledged"]
    transactions = service["transactions"]
    assert len(transactions) == len(parents)
    for actual, expected in zip(transactions, parents, strict=True):
        assert actual["transaction_id"] == expected["transaction_id"]
        assert actual["phase"] == expected["phase"]
        assert actual["mode"] == expected["mode"]
        assert actual["reason"] == expected["reason"]
        assert (actual["key"] or "") == expected["key_digest"]
        assert actual["valid_tokens_by_stage"] == expected["valid_tokens"]
        assert actual["padded_tokens_by_stage"] == expected["padded_tokens"]
    for role, records in (
        (
            "attention",
            attention["native_live_owner"]["target_graph"]["host_records"],
        ),
        ("ffn", service["host_records"]),
    ):
        verify_graph_host_records(
            records,
            parents,
            role=role,
            local_device=local_devices[role],
            graph_compute_overlap=graph_compute_overlap,
            graph_all_axes=graph_all_axes,
        )
    common = verify_native_request_lifecycle(
        attention,
        target_transactions=[
            transactions[parents.index(by_id[target["transaction_id"]])]
            for target in targets
        ],
        padded_tokens_by_step=((3, 3), (3, 3), (6,), (3,), (6,)),
    )
    return (
        protocol
        | common
        | {
            "native_target_graph_component_accepted": True,
            "native_target_graph_u2_component_accepted": True,
        }
    )
