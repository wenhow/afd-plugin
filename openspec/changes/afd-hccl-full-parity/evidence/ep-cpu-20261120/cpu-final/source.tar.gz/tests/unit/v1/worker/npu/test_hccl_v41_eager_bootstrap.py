# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Loaded-model/KV handoff over CPU packet seams; no NPU execution proof."""

from dataclasses import replace

import pytest

pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

import torch  # noqa: E402

from tests.unit.fakes.hccl_v41_eager_bootstrap import (  # noqa: E402
    accept_bootstrap_parent,
    make_eager_bootstrap_case,
)
from tests.unit.fakes.npu_stream import HostStream  # noqa: E402


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("tp", [1, 2])
def test_matched_family_warms_dtype_packets_and_hands_off_the_same_session(
    monkeypatch, role, tp
):
    case = make_eager_bootstrap_case(monkeypatch, role=role, tp=tp)

    case.bootstrap.prepare(case.runtime.parent)
    session = case.bootstrap.session
    case.bootstrap.begin_kv_init()
    case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert session.initialized and session.settings is case.settings
    assert case.bound_sessions == [session]
    assert case.transport.eager_pipeline_warmed
    assert case.bootstrap.diagnostics is None
    sends, receives = (3, 1) if role == "attention" else (1, 3)
    for stage in range(2):
        packets = [
            packet
            for packet in case.backend.trace
            if len(packet) == 5 and packet[3] == stage
        ]
        assert sorted(packet[-1] for packet in packets if packet[0] == "warm_send") == (
            ["torch.bfloat16", "torch.float32", "torch.int32"]
            if sends == 3
            else ["torch.bfloat16"]
        )
        assert sorted(packet[-1] for packet in packets if packet[0] == "warm_recv") == (
            ["torch.bfloat16", "torch.float32", "torch.int32"]
            if receives == 3
            else ["torch.bfloat16"]
        )
    assert case.backend.trace[-1] == ("warm_barrier",)
    assert case.runtime.current == case.runtime.parent
    assert not case.transport.closed and not case.transport.terminal
    assert case.transport.transcript == []


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("stages,tp", [(1, 1), (1, 4), (2, 4)])
@pytest.mark.parametrize("diagnostics", [False, True])
def test_disabled_family_keeps_serial_geometry_and_independent_diagnostics(
    monkeypatch, role, stages, tp, diagnostics
):
    case = make_eager_bootstrap_case(
        monkeypatch,
        role=role,
        stages=stages,
        tp=tp,
        enabled=False,
        diagnostics=diagnostics,
    )

    case.bootstrap.prepare(case.runtime.parent)
    case.bootstrap.begin_kv_init()
    case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bootstrap.session is None and case.bound_sessions == []
    assert case.runtime.allocated == [] and case.backend.trace == []
    assert not case.transport.eager_pipeline_warmed
    assert (case.bootstrap.diagnostics is not None) == diagnostics
    if diagnostics:
        assert case.bootstrap.diagnostics.settings is case.settings
        accept_bootstrap_parent(case, stages=stages)
        progress = case.bootstrap.diagnostics.bind_parent()
        progress.record("compute_returned", 0, 0)
        progress.synchronize_compute(0, 0)
        assert case.recorder.records[-1]["actual.mode"] == "serial"
        sync_active = role == "ffn" and stages == 1
        assert case.recorder.records[-1]["actual.ffn_compute_sync"] == sync_active
        assert ("device_sync" in case.recorder.events) == sync_active


@pytest.mark.parametrize("role", ["attention", "ffn"])
def test_stream_session_and_diagnostics_keep_one_snapshot_through_kv(monkeypatch, role):
    case = make_eager_bootstrap_case(monkeypatch, role=role, diagnostics=True)
    case.bootstrap.prepare(case.runtime.parent)
    session, diagnostics = case.bootstrap.session, case.bootstrap.diagnostics
    monkeypatch.setenv("AFD_HCCL_EAGER_U2_STREAM_OVERLAP", "0")
    monkeypatch.setenv("AFD_HCCL_STAGE_DIAGNOSTICS", "0")

    case.bootstrap.begin_kv_init()
    case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bound_sessions == [session]
    assert session.settings is diagnostics.settings is case.settings
    assert diagnostics.settings.stage_diagnostics
    assert diagnostics.settings.eager_u2_stream_overlap
    assert case.transport.eager_pipeline_warmed and not case.transport.terminal


@pytest.mark.parametrize(
    "local_version,negotiated_version,enabled",
    [
        (0, 0, True),
        (1, 1, False),
        (1, 0, True),
        (0, 1, True),
    ],
)
def test_settings_mismatch_is_terminal_before_any_stream_or_warmup_packet(
    monkeypatch, local_version, negotiated_version, enabled
):
    case = make_eager_bootstrap_case(monkeypatch, enabled=enabled)
    case.transport.capabilities = replace(
        case.transport.capabilities, eager_pipeline_version=local_version
    )
    case.transport.negotiated_capabilities = replace(
        case.transport.negotiated_capabilities,
        eager_pipeline_version=negotiated_version,
    )

    with pytest.raises(ValueError, match="settings and HELLO family"):
        case.bootstrap.prepare(case.runtime.parent)

    assert case.runtime.allocated == [] and case.backend.trace == []
    assert case.bootstrap.session is None
    assert case.transport.terminal and not case.transport.closed
    assert case.transport.transcript == []


@pytest.mark.parametrize(
    "invalid", ["uninitialized", "closed", "plan", "rank", "graph"]
)
def test_preparation_rejects_foreign_or_busy_binding_before_allocation(
    monkeypatch, invalid
):
    case = make_eager_bootstrap_case(monkeypatch)
    if invalid == "uninitialized":
        case.transport.initialized = False
    elif invalid == "closed":
        case.transport.closed = True
    elif invalid == "plan":
        accept_bootstrap_parent(case)
    elif invalid == "rank":
        case.config.parallel_config.rank = 1
    else:
        caps = replace(
            case.transport.capabilities,
            graph_execution_version=1,
            eager_pipeline_version=0,
        )
        case.transport.capabilities = case.transport.negotiated_capabilities = caps

    with pytest.raises((RuntimeError, ValueError)):
        case.bootstrap.prepare(case.runtime.parent)

    assert case.runtime.allocated == [] and case.backend.trace == []
    assert case.bootstrap.session is None and case.transport.terminal


@pytest.mark.parametrize("foreign", ["device", "current", "capture"])
def test_parent_stream_must_be_the_actual_indexed_npu_stream(monkeypatch, foreign):
    case = make_eager_bootstrap_case(monkeypatch)
    parent = case.runtime.parent
    if foreign == "device":
        parent = HostStream("foreign", torch.device("npu", 1))
    elif foreign == "current":
        case.runtime.current = HostStream("foreign", parent.device)
    else:
        case.runtime.capturing = True

    with pytest.raises(ValueError, match="actual NPU parent stream"):
        case.bootstrap.prepare(parent)

    assert case.runtime.allocated == [] and case.backend.trace == []
    assert case.transport.terminal and not case.transport.closed


def test_failed_warmup_retains_the_published_session_and_live_groups(monkeypatch):
    case = make_eager_bootstrap_case(monkeypatch)
    case.backend.fail_warmup = True
    groups = tuple(case.transport.data_groups)

    with pytest.raises(RuntimeError, match="matched warmup failed"):
        case.bootstrap.prepare(case.runtime.parent)

    session = case.bootstrap.session
    assert session is not None and not session.initialized
    assert session.parent_stream is case.runtime.parent
    assert tuple(case.transport.data_groups) == groups
    assert case.transport.terminal and not case.transport.closed
    assert case.transport.transcript == []
    before_retry = list(case.backend.trace)
    with pytest.raises(RuntimeError, match="only once"):
        case.bootstrap.prepare(case.runtime.parent)
    assert case.bootstrap.session is session
    assert case.backend.trace == before_retry


@pytest.mark.parametrize("entry", ["prepare", "begin", "complete"])
@pytest.mark.parametrize("enabled", [False, True])
def test_successful_lifecycle_refuses_reuse_without_replacing_resources(
    monkeypatch, entry, enabled
):
    case = make_eager_bootstrap_case(monkeypatch, enabled=enabled)
    case.bootstrap.prepare(case.runtime.parent)
    session = case.bootstrap.session
    case.bootstrap.begin_kv_init()
    case.bootstrap.complete_kv_init(case.bound_sessions.append)

    with pytest.raises(
        RuntimeError, match="only once|first prepared load|first allocation"
    ):
        if entry == "prepare":
            case.bootstrap.prepare(case.runtime.parent)
        elif entry == "begin":
            case.bootstrap.begin_kv_init()
        else:
            case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bootstrap.session is session
    assert case.bound_sessions == ([session] if enabled else [])
    assert case.transport.terminal and not case.transport.closed
    assert case.transport.transcript == []


@pytest.mark.parametrize("entry", ["begin", "complete"])
def test_kv_cannot_begin_or_complete_before_preparation(monkeypatch, entry):
    case = make_eager_bootstrap_case(monkeypatch, enabled=False)

    with pytest.raises(RuntimeError, match="first prepared load|first allocation"):
        if entry == "begin":
            case.bootstrap.begin_kv_init()
        else:
            case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bound_sessions == [] and case.runtime.allocated == []
    assert case.transport.terminal and not case.transport.closed


def test_failed_final_binding_preserves_the_original_error_and_session(monkeypatch):
    case = make_eager_bootstrap_case(monkeypatch)
    case.bootstrap.prepare(case.runtime.parent)
    session = case.bootstrap.session
    case.bootstrap.begin_kv_init()
    failure = RuntimeError("native U2 binding failed")

    def bind_session(_session):
        raise failure

    with pytest.raises(RuntimeError, match="native U2 binding failed") as raised:
        case.bootstrap.complete_kv_init(bind_session)

    assert raised.value is failure
    assert case.bootstrap.session is session and session.initialized
    assert case.transport.terminal and not case.transport.closed
    assert case.transport.transcript == []


@pytest.mark.parametrize("entry", ["begin", "complete"])
def test_kv_handoff_rechecks_the_live_idle_transport(monkeypatch, entry):
    case = make_eager_bootstrap_case(monkeypatch)
    case.bootstrap.prepare(case.runtime.parent)
    if entry == "complete":
        case.bootstrap.begin_kv_init()
    accept_bootstrap_parent(case)

    with pytest.raises(RuntimeError, match="idle live transport"):
        if entry == "begin":
            case.bootstrap.begin_kv_init()
        else:
            case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bound_sessions == []
    assert case.bootstrap.session.initialized
    assert case.transport.terminal and not case.transport.closed


@pytest.mark.parametrize("entry", ["begin", "complete"])
def test_kv_handoff_rejects_a_changed_hello_family(monkeypatch, entry):
    case = make_eager_bootstrap_case(monkeypatch)
    case.bootstrap.prepare(case.runtime.parent)
    if entry == "complete":
        case.bootstrap.begin_kv_init()
    case.transport.negotiated_capabilities = replace(
        case.transport.negotiated_capabilities, eager_pipeline_version=0
    )

    with pytest.raises(ValueError, match="settings and HELLO family"):
        if entry == "begin":
            case.bootstrap.begin_kv_init()
        else:
            case.bootstrap.complete_kv_init(case.bound_sessions.append)

    assert case.bound_sessions == []
    assert case.bootstrap.session.initialized
    assert case.transport.terminal and not case.transport.closed
