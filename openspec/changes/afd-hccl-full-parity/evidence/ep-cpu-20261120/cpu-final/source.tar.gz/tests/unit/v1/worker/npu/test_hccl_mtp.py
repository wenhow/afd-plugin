# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Proposal/actual-call ownership, without native proposal kernels or HCCL."""

from concurrent.futures import ThreadPoolExecutor
from copy import copy

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

from afd_plugin.model_executor.models.npu import (  # noqa: E402
    deepseek_v4_mtp as adapter,
)
from afd_plugin.v1.worker.npu.hccl_mtp import MtpCompletedTarget  # noqa: E402
from tests.unit.fakes.mtp_runtime import make_mtp_session_case  # noqa: E402


@pytest.mark.parametrize("steps", [1, 2, 3])
@pytest.mark.parametrize("mode", ["target", "dummy", "profile"])
def test_native_proposal_binding_pairs_actual_prefill_then_request_rows_and_end(
    monkeypatch, steps, mode
):
    case = make_mtp_session_case(monkeypatch, adapter, steps=steps, mode=mode)
    output = case.owner.speculator.propose(**case.propose_kwargs)
    torch.testing.assert_close(output, torch.arange(2 * steps).view(2, steps))
    calls = [record[1] for record in case.exchange.records if record[0] == "forward"]
    assert [call.logical_step for call in calls] == list(range(steps))
    assert [call.segment for call in calls] == ["prefill"] + ["decode"] * (steps - 1)
    assert [call.padded_tokens for call in calls] == [6] + [2] * (steps - 1)
    assert [call.valid_tokens for call in calls] == (
        [5] + [2] * (steps - 1) if mode == "target" else [0] * steps
    )
    assert case.exchange.records[-2:] == [
        ("native_return",),
        ("end", "target-1", steps),
    ]
    assert not case.session.proposal_active
    assert not case.session.failed


def test_next_native_proposal_restarts_step_zero_for_its_actual_target(monkeypatch):
    case = make_mtp_session_case(monkeypatch, adapter, steps=2)
    case.owner.speculator.propose(**case.propose_kwargs)
    case.session.record_completed_target(
        MtpCompletedTarget("target-2", case.input_batch, "target")
    )
    case.owner.speculator.propose(**case.propose_kwargs)
    calls = [record[1] for record in case.exchange.records if record[0] == "forward"]
    assert [(call.target_transaction_id, call.logical_step) for call in calls] == [
        ("target-1", 0),
        ("target-1", 1),
        ("target-2", 0),
        ("target-2", 1),
    ]


@pytest.mark.parametrize("forwards", [1, 3])
def test_incomplete_or_excess_native_proposal_fails_without_proposal_end(
    monkeypatch, forwards
):
    case = make_mtp_session_case(monkeypatch, adapter, steps=2)
    case.owner.speculator.forward_limit = forwards
    with pytest.raises(RuntimeError, match="exactly N|exceeded"):
        case.owner.speculator.propose(**case.propose_kwargs)
    assert case.session.failed
    assert not any(record[0] == "end" for record in case.exchange.records)
    with pytest.raises(RuntimeError, match="closed or failed"):
        case.owner.speculator.propose(**case.propose_kwargs)


def test_native_head_feedback_failure_after_model_complete_does_not_close_proposal(
    monkeypatch,
):
    case = make_mtp_session_case(monkeypatch, adapter)
    case.owner.speculator.fail_after_models = True
    with pytest.raises(RuntimeError, match="feedback/head failed"):
        case.owner.speculator.propose(**case.propose_kwargs)
    assert [record[0] for record in case.exchange.records][-2:] == [
        "native_return",
        "failed",
    ]
    assert not any(record[0] == "end" for record in case.exchange.records)
    assert case.session.failed


def test_foreign_target_batch_is_rejected_before_any_forward_without_poisoning_owner(
    monkeypatch,
):
    case = make_mtp_session_case(monkeypatch, adapter)
    kwargs = dict(case.propose_kwargs, input_batch=copy(case.input_batch))
    with pytest.raises(RuntimeError, match="actual completed target batch"):
        case.owner.speculator.propose(**kwargs)
    assert case.exchange.records == []
    assert not case.session.failed


def test_proposal_binding_rejects_a_foreign_execution_thread_before_protocol(
    monkeypatch,
):
    case = make_mtp_session_case(monkeypatch, adapter)
    with ThreadPoolExecutor(max_workers=1) as pool:
        result = pool.submit(case.owner.speculator.propose, **case.propose_kwargs)
        with pytest.raises(RuntimeError, match="execution thread"):
            result.result()
    assert case.exchange.records == []
    assert not case.session.failed


def test_quiescent_stop_restores_native_instance_and_close_is_idempotent(monkeypatch):
    case = make_mtp_session_case(monkeypatch, adapter)
    with pytest.raises(RuntimeError, match="peer STOP"):
        case.session.close_after_stop()
    case.owner.speculator.propose(**case.propose_kwargs)
    case.exchange.acknowledged_stop = True
    case.session.close_after_stop()
    case.session.close_after_stop()
    case.owner.speculator.result_only = True
    output = case.owner.speculator.propose(**case.propose_kwargs)
    torch.testing.assert_close(output, torch.arange(4).view(2, 2))
    assert case.session.closed
