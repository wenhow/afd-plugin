# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
# ruff: noqa: E402
"""CPU metadata/alias seams only; the actual zeroing kernel is NPU evidence."""

from dataclasses import asdict, replace
from types import SimpleNamespace

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

from vllm.v1.worker.gpu.model_runner import GPUModelRunner
from vllm.v1.worker.utils import KVBlockZeroer
from vllm_ascend.worker.v2.model_runner import NPUModelRunner

from afd_plugin.compat.npu.kv_zeroing import (
    DeepseekV41KVBlockZeroer,
    _physical_block_view,
)
from afd_plugin.compat.npu.runtime_config import HCCL_ATTESTED_PD_MODULE
from afd_plugin.compat.patches.npu.mrv2_kv_zeroing import (
    apply_dsv41_kv_zeroing_patch,
)
from tests.unit.fakes.afd_config import hccl_config
from tests.unit.fakes.kv_cache import make_native_zeroing_case


@pytest.mark.parametrize("ratio", [4, 128])
@pytest.mark.parametrize("allocation_offset", [0, 64])
def test_physical_tile_view_preserves_guarded_storage_and_bound_aliases(
    ratio, allocation_offset
):
    case = make_native_zeroing_case(ratio=ratio, allocation_offset=allocation_offset)
    bindings = [(layer, layer.kv_cache, layer.kv_cache[0]) for layer in case.layers]
    pattern = torch.arange(case.descriptor.size).remainder(251).add(1).to(torch.uint8)
    case.raw[allocation_offset : allocation_offset + case.descriptor.size].copy_(
        pattern
    )
    expected = bytearray(case.raw.numpy().tobytes())
    start = allocation_offset + case.descriptor.block_stride
    expected[start : start + case.descriptor.block_stride] = bytes(
        case.descriptor.block_stride
    )

    view = _physical_block_view(case.descriptor, case.layers, case.num_blocks)
    assert view.shape == (case.num_blocks, case.descriptor.block_stride)
    assert view.stride() == (case.descriptor.block_stride, 1)
    assert view.data_ptr() == case.caches[case.names.main].data_ptr()
    view[1].zero_()  # CPU write demonstrates the returned view's alias contract.

    assert case.raw.numpy().tobytes() == bytes(expected)
    scale = case.caches[case.names.index][1]
    assert scale.dtype == torch.float16 and scale.shape[1] == 128 // ratio
    assert torch.count_nonzero(scale[1].view(torch.uint8)) == 0
    for layer, container, bound in bindings:
        assert layer.kv_cache is container and layer.kv_cache[0] is bound


@pytest.mark.parametrize(
    "invalid",
    ["offset", "layer-stride", "size", "word-alignment", "first-layer", "capacity"],
)
def test_physical_tile_view_rejects_invalid_descriptors(invalid):
    case = make_native_zeroing_case()
    descriptor, num_blocks = case.descriptor, case.num_blocks
    if invalid == "offset":
        descriptor = replace(descriptor, offset=4)
    elif invalid == "layer-stride":
        descriptor = replace(descriptor, layer_stride=4)
    elif invalid == "size":
        descriptor = replace(descriptor, size=descriptor.size - 4)
    elif invalid == "word-alignment":
        stride = descriptor.block_stride + 2
        descriptor = replace(descriptor, block_stride=stride, size=num_blocks * stride)
    elif invalid == "first-layer":
        descriptor = replace(descriptor, layers=list(reversed(descriptor.layers)))
    else:
        num_blocks += 1
        descriptor = replace(descriptor, size=num_blocks * descriptor.block_stride)
    with pytest.raises(ValueError, match="physical (block tile|tile)"):
        _physical_block_view(descriptor, case.layers, num_blocks)


@pytest.mark.parametrize(
    "invalid", ["cross-storage", "block-count", "block-stride", "before", "after"]
)
def test_physical_tile_view_rejects_components_outside_the_bound_tile(invalid):
    case = make_native_zeroing_case()
    data, scale = case.caches[case.names.index]
    if invalid == "cross-storage":
        data = make_native_zeroing_case().caches[case.names.index][0]
    elif invalid == "block-count":
        data = data[:-1]
    elif invalid == "block-stride":
        data = data.as_strided(data.shape, (data.stride(0) - 4, *data.stride()[1:]))
    else:
        offset = (
            0
            if invalid == "before"
            else (case.allocation_offset + case.descriptor.block_stride - 2)
        )
        data = torch.empty(0, dtype=torch.uint8).set_(
            case.raw.untyped_storage(),
            offset,
            (case.num_blocks, 1, 1, 8),
            (case.descriptor.block_stride, 8, 8, 1),
        )
    case.carriers[case.names.index].bind_kv_cache((data, scale))
    with pytest.raises(ValueError, match="component escapes its physical block tile"):
        _physical_block_view(case.descriptor, case.layers, case.num_blocks)


@pytest.mark.parametrize(
    "model,afd,connector,module,adapted",
    [
        ("deepseek_v41", False, None, None, False),
        ("deepseek_v41", True, None, None, True),
        ("deepseek_v4", True, None, None, False),
        ("deepseek_v41", False, "MooncakeHybridConnector", None, False),
        ("deepseek_v41", False, "MooncakeHybridConnector", "foreign.module", False),
        ("deepseek_v41", False, "OtherConnector", HCCL_ATTESTED_PD_MODULE, False),
        (
            "deepseek_v41",
            False,
            "MooncakeHybridConnector",
            HCCL_ATTESTED_PD_MODULE,
            True,
        ),
        (
            "deepseek_v4",
            False,
            "MooncakeHybridConnector",
            HCCL_ATTESTED_PD_MODULE,
            False,
        ),
    ],
)
def test_initializer_selects_only_plugin_owned_v41_and_preserves_gpu_base(
    monkeypatch, model, afd, connector, module, adapted
):
    case = make_native_zeroing_case()
    hf = case.config.model_config.hf_config
    hf.model_type, hf.architectures = model, []
    if afd:
        case.config.additional_config = {"afd": asdict(hccl_config())}
    if connector is not None:
        case.config.kv_transfer_config = SimpleNamespace(
            kv_connector=connector, kv_connector_module_path=module
        )
    before = case.raw.clone()
    gpu_method = GPUModelRunner._init_kv_zero_meta
    monkeypatch.setattr(
        NPUModelRunner, "_init_kv_zero_meta", NPUModelRunner._init_kv_zero_meta
    )
    apply_dsv41_kv_zeroing_patch()
    case.owner._init_kv_zero_meta()
    expected_class = DeepseekV41KVBlockZeroer if adapted else KVBlockZeroer
    assert type(case.owner.kv_block_zeroer) is expected_class
    assert torch.equal(case.raw, before), "initialization must not write cache bytes"

    assert GPUModelRunner._init_kv_zero_meta is gpu_method
    gpu_method(case.owner)
    assert type(case.owner.kv_block_zeroer) is KVBlockZeroer
    case.owner.kv_block_zeroer.zero_block_ids([1])
    assert torch.equal(case.raw, before), "native list carrier remains a no-op"
