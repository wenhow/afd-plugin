# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Ordinary MTP configuration outcomes without upstream/device imports."""

from copy import deepcopy
from dataclasses import FrozenInstanceError

import pytest

from afd_plugin.compat.npu.mtp import (
    DeepseekV4MtpContract,
    deepseek_v4_mtp_weight_role,
    get_deepseek_v4_mtp_ffn_config,
    get_deepseek_v4_mtp_model_load_config,
    is_deepseek_v4_target_ffn_weight,
    resolve_deepseek_v4_mtp_contract,
)
from tests.unit.fakes.mtp import ordinary_mtp_config


@pytest.mark.parametrize("steps", [1, 2, 3])
@pytest.mark.parametrize("tp_size", [1, 2])
@pytest.mark.parametrize("role", ["attention", "ffn"])
def test_ordinary_mtp_contract_retains_native_target_and_single_draft_shape(
    steps, tp_size, role
):
    config = ordinary_mtp_config(steps=steps, tp_size=tp_size, role=role)
    before = deepcopy(config)
    contract = resolve_deepseek_v4_mtp_contract(config)
    assert contract == DeepseekV4MtpContract(steps, 8, 32, (0, 1), 16, tp_size)
    assert contract.target_query_len == steps + 1
    assert contract.draft_layer_indices == (0,)
    assert config == before
    with pytest.raises(FrozenInstanceError):
        contract.num_speculative_tokens = 1


def test_ffn_worker_isolation_and_draft_loader_view_preserve_native_config_identity():
    source = ordinary_mtp_config(role="ffn")
    before = deepcopy(source)
    isolated = get_deepseek_v4_mtp_ffn_config(source)
    loading = get_deepseek_v4_mtp_model_load_config(source)
    assert isolated.speculative_config is None
    assert isolated.model_config is loading.model_config is source.model_config
    assert loading.speculative_config == source.speculative_config
    assert loading.speculative_config is not source.speculative_config
    assert loading.speculative_config.draft_model_config is (
        source.speculative_config.draft_model_config
    )
    assert resolve_deepseek_v4_mtp_contract(loading) == (
        resolve_deepseek_v4_mtp_contract(source)
    )
    assert source == before


def test_native_ordinary_mtp_without_afd_configuration_remains_unclaimed():
    config = ordinary_mtp_config()
    config.additional_config = {}
    assert resolve_deepseek_v4_mtp_contract(config) is None


@pytest.mark.parametrize("steps", [True, False, 0, -1, 4, 1.5, "2"])
def test_ordinary_mtp_rejects_invalid_step_count(steps):
    with pytest.raises(ValueError, match="1..3 integer"):
        resolve_deepseek_v4_mtp_contract(ordinary_mtp_config(steps=steps))


@pytest.mark.parametrize(
    ("section", "field", "value", "message"),
    [
        ("model", "enforce_eager", False, "eager target and draft"),
        ("model", "enable_sleep_mode", True, "fixed storage"),
        ("speculative", "enforce_eager", False, "eager target and draft"),
        ("speculative", "enable_adaptive_verification", True, "adaptive verification"),
        ("speculative", "draft_tensor_parallel_size", 2, "TP must match"),
        ("parallel", "data_parallel_size", 2, "DP1/PP1/CP1"),
        ("parallel", "pipeline_parallel_size", 2, "DP1/PP1/CP1"),
        ("parallel", "prefill_context_parallel_size", 2, "DP1/PP1/CP1"),
        ("parallel", "decode_context_parallel_size", 2, "DP1/PP1/CP1"),
        ("parallel", "use_sequence_parallel_moe", True, "DP1/PP1/CP1"),
        ("parallel", "enable_expert_parallel", True, "DP1/PP1/CP1"),
        ("parallel", "enable_eplb", True, "DP1/PP1/CP1"),
        ("parallel", "enable_dbo", True, "requires U1"),
        ("parallel", "use_ubatching", True, "requires U1"),
        ("parallel", "num_ubatches", 2, "requires U1"),
    ],
)
def test_ordinary_mtp_rejects_unsupported_native_modes(section, field, value, message):
    config = ordinary_mtp_config()
    sections = {
        "model": config.model_config,
        "speculative": config.speculative_config,
        "parallel": config.parallel_config,
    }
    setattr(sections[section], field, value)
    with pytest.raises(ValueError, match=message):
        resolve_deepseek_v4_mtp_contract(config)


@pytest.mark.parametrize("mode", ["PIECEWISE", "FULL_DECODE_ONLY"])
def test_ordinary_mtp_rejects_target_or_draft_graph_configuration(mode):
    config = ordinary_mtp_config()
    config.compilation_config.cudagraph_mode.name = mode
    with pytest.raises(ValueError, match="eager target and draft"):
        resolve_deepseek_v4_mtp_contract(config)


@pytest.mark.parametrize("blocks", [True, 0, 2])
@pytest.mark.parametrize("side", ["target", "draft"])
def test_ordinary_mtp_rejects_multiple_or_invalid_physical_draft_blocks(blocks, side):
    config = ordinary_mtp_config()
    hf = (
        config.model_config.hf_config
        if side == "target"
        else config.speculative_config.draft_model_config.hf_config
    )
    hf.num_nextn_predict_layers = blocks
    with pytest.raises(ValueError, match="one physical draft block"):
        resolve_deepseek_v4_mtp_contract(config)


@pytest.mark.parametrize("field", ["hidden_size", "vocab_size"])
def test_ordinary_mtp_rejects_draft_dimensions_different_from_target(field):
    config = ordinary_mtp_config()
    setattr(config.speculative_config.draft_model_config.hf_config, field, 4)
    with pytest.raises(ValueError, match="dimensions must match"):
        resolve_deepseek_v4_mtp_contract(config)


@pytest.mark.parametrize("change", ["no_speculation", "dspark", "v41"])
def test_ordinary_mtp_does_not_claim_other_native_speculation_paths(change):
    config = ordinary_mtp_config()
    if change == "no_speculation":
        config.speculative_config = None
    elif change == "dspark":
        config.speculative_config.method = "dspark"
    else:
        config.model_config.hf_config.model_type = "deepseek_v41"
    assert resolve_deepseek_v4_mtp_contract(config) is None


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("connector", "CAMP2pAFDConnector"),
        ("compute_gate_on_attention", True),
        ("async", True),
        ("num_attention_ranks", 2),
        ("num_ffn_ranks", 2),
    ],
)
def test_ordinary_mtp_requires_paired_hccl_gate_on_ffn(field, value):
    config = ordinary_mtp_config()
    config.additional_config["afd"][field] = value
    with pytest.raises(ValueError, match="paired native HCCL TP"):
        resolve_deepseek_v4_mtp_contract(config)


@pytest.mark.parametrize(
    ("name", "role"),
    [
        ("mtp.0.ffn.gate.weight", "ffn"),
        ("mtp.0.ffn.gate.bias", "ffn"),
        ("mtp.0.ffn.experts.0.w1.weight", "ffn"),
        ("mtp.0.ffn.shared_experts.w2.scale", "ffn"),
        ("mtp.0.ffn_norm.weight", "attention"),
        ("mtp.0.attn_norm.weight", "attention"),
        ("mtp.0.attn.indexer.compressor.wgate.weight", "attention"),
        ("mtp.0.hc_ffn_fn", "attention"),
        ("mtp.0.hc_head_fn", "attention"),
        ("mtp.0.e_proj.weight", "attention"),
        ("mtp.0.head.weight", "attention"),
        ("mtp.0.emb.tok_emb.weight", "attention"),
        ("model.layers.0.mlp.gate.weight", None),
        ("model.mtp.0.ffn.gate.weight", None),
    ],
)
def test_mtp_weight_roles_match_complete_checkpoint_components(name, role):
    assert deepseek_v4_mtp_weight_role(name) == role


@pytest.mark.parametrize("name", ["embed.weight", "head.weight"])
@pytest.mark.parametrize("quantization", [None, "fp8", "deepseek_v4_fp8"])
def test_mtp_top_level_aliases_follow_only_the_native_quantization_branch(
    name, quantization
):
    expected = "attention" if quantization == "deepseek_v4_fp8" else None
    assert deepseek_v4_mtp_weight_role(name, quantization_name=quantization) == expected


def test_mtp_weight_roles_reject_unsupported_additional_physical_blocks():
    with pytest.raises(ValueError, match="physical mtp.0"):
        deepseek_v4_mtp_weight_role("mtp.1.ffn.gate.weight")


@pytest.mark.parametrize(
    ("name", "accepted"),
    [
        ("layers.0.ffn.gate.weight", True),
        ("model.layers.1.ffn.experts.0.w1.weight", True),
        ("model.layers.0.mlp.shared_experts.down_proj.weight", True),
        ("layers.2.ffn.gate.weight", False),
        ("layers.0.ffn_norm.weight", False),
        ("layers.0.hc_ffn_fn", False),
        ("layers.0.attn.indexer.compressor.wgate.weight", False),
        ("embed.weight", False),
        ("head.weight", False),
        ("model.norm.weight", False),
        ("mtp.0.ffn.gate.weight", False),
    ],
)
def test_mtp_target_ffn_weights_exclude_all_attention_and_vocabulary_state(
    name, accepted
):
    assert is_deepseek_v4_target_ffn_weight(name, (0, 1)) is accepted
