# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Ordinary MTP role/model seams; host operators are explicit boundaries."""

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

from afd_plugin.model_executor.models.npu import (  # noqa: E402
    deepseek_v4_mtp as adapter,
)
from tests.unit.fakes.mtp_runtime import (  # noqa: E402
    install_host_mtp_allocations,
    make_mtp_session_case,
    mtp_runtime_config,
)


@pytest.mark.parametrize("role", ["attention", "ffn"])
def test_mtp_constructs_only_role_owned_parameter_names(monkeypatch, role):
    install_host_mtp_allocations(monkeypatch, adapter)
    model = adapter.AFDDeepSeekV4MTP(vllm_config=mtp_runtime_config(role=role))
    names = set(dict(model.named_parameters()))
    assert names
    if role == "ffn":
        assert all(name.startswith("model.layers.0.mtp_block.mlp.") for name in names)
        assert model.num_moe_layers == 1
    else:
        assert "model.embed_tokens.weight" in names
        assert "model.layers.0.hc_head_fn" in names
        assert not any(".mlp." in name for name in names)


def test_target_ffn_constructs_only_complete_moes_without_vocabulary_hc_or_norm(
    monkeypatch,
):
    install_host_mtp_allocations(monkeypatch, adapter)
    model = adapter.AFDDeepseekV4MtpTargetFFN(
        vllm_config=mtp_runtime_config(role="ffn")
    )
    names = set(dict(model.named_parameters()))
    assert model.get_experts_layer_indices() == (0, 1)
    assert model.num_moe_layers == 2
    assert names
    assert all(".mlp." in name for name in names)
    hidden = torch.ones(2, 8, dtype=torch.bfloat16)
    fp32 = hidden.float() + 0.00031
    ids = torch.tensor([3, -1], dtype=torch.int64)
    output = model.compute_ffn_output(hidden, 1, input_ids=ids, hidden_states_fp32=fp32)
    expected = ((fp32 - hidden.float()) * 4096 + ids[:, None]).bfloat16()
    torch.testing.assert_close(output, expected)


def test_draft_forward_preserves_native_flattened_hc_feedback(monkeypatch):
    case = make_mtp_session_case(monkeypatch, adapter, steps=1)
    hidden = torch.arange(96, dtype=torch.float32).view(6, 16)
    embeddings = torch.arange(48, dtype=torch.float32).view(6, 8)
    positions = torch.arange(6)
    with case.session.proposal_scope(
        case.input_batch, dummy_run=False, is_profile=False
    ):
        output = case.owner.speculator.model(
            torch.arange(6), positions, hidden, inputs_embeds=embeddings
        )
        masked = torch.where(positions[:, None] == 0, 0, embeddings)
        expected = (hidden.view(6, 2, 8) + masked[:, None] + 1).flatten(1)
        torch.testing.assert_close(output, expected)
    forward = case.exchange.records[0]
    assert forward[0] == "forward"
    assert forward[1].padded_tokens == 6
    assert case.exchange.records[-2:] == [("complete", 0), ("end", "target-1", 1)]


@pytest.mark.parametrize("which", ["target", "draft"])
def test_ffn_role_native_moe_observes_independent_fp32_and_ids(monkeypatch, which):
    install_host_mtp_allocations(monkeypatch, adapter)
    config = mtp_runtime_config(role="ffn")
    model = (
        adapter.AFDDeepseekV4MtpTargetFFN(vllm_config=config)
        if which == "target"
        else adapter.AFDDeepSeekV4MTP(vllm_config=config)
    )
    hidden = torch.ones(2, 8, dtype=torch.bfloat16)
    fp32 = hidden.float() + 0.00031
    ids = torch.tensor([7, -1], dtype=torch.int64)
    output = model.compute_ffn_output(hidden, 0, input_ids=ids, hidden_states_fp32=fp32)
    torch.testing.assert_close(
        output, ((fp32 - hidden.float()) * 4096 + ids[:, None]).bfloat16()
    )
