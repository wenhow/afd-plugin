# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Selected-instance proposal binding/restoration, with host proposal bodies."""

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

from afd_plugin.compat.patches.npu.mtp_proposal import MtpProposalBinding  # noqa: E402
from afd_plugin.model_executor.models.npu import (  # noqa: E402
    deepseek_v4_mtp as adapter,
)
from tests.unit.fakes.mtp_runtime import make_mtp_session_case  # noqa: E402


def test_selected_native_instances_keep_independent_proposal_and_peer_sequences(
    monkeypatch,
):
    first = make_mtp_session_case(monkeypatch, adapter, steps=1)
    second = make_mtp_session_case(monkeypatch, adapter, steps=3)
    output1 = first.owner.speculator.propose(**first.propose_kwargs)
    output2 = second.owner.speculator.propose(**second.propose_kwargs)
    torch.testing.assert_close(output1, torch.arange(2).view(2, 1))
    torch.testing.assert_close(output2, torch.arange(6).view(2, 3))
    assert first.exchange.records[-1] == ("end", "target-1", 1)
    assert second.exchange.records[-1] == ("end", "target-1", 3)


def test_duplicate_instance_binding_rejects_before_native_execution_or_protocol(
    monkeypatch,
):
    case = make_mtp_session_case(monkeypatch, adapter)
    with pytest.raises(RuntimeError, match="instance binding"):
        MtpProposalBinding(case.session)
    assert case.exchange.records == []


def test_stale_bound_proposer_cannot_reenter_after_acknowledged_stop(monkeypatch):
    case = make_mtp_session_case(monkeypatch, adapter)
    stale = case.owner.speculator.propose
    case.exchange.acknowledged_stop = True
    case.session.close_after_stop()
    with pytest.raises(RuntimeError, match="no longer selected"):
        stale(**case.propose_kwargs)
    assert case.exchange.records == []


def test_foreign_instance_method_replacement_cannot_use_the_old_binding(monkeypatch):
    case = make_mtp_session_case(monkeypatch, adapter)
    selected = case.owner.speculator.propose
    case.owner.speculator.propose = lambda **kwargs: torch.tensor([17])
    with pytest.raises(RuntimeError, match="no longer selected"):
        selected(**case.propose_kwargs)
    assert case.exchange.records == []
