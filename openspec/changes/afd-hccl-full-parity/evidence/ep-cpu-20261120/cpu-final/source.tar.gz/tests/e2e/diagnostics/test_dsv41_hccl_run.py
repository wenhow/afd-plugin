# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""CPU CLI integration: prepared recipe and real emitters, no device execution.

Run directly with python -B -S. Events are constructed CLI inputs emitted by
the production CPU-safe diagnostic modules; they are not executor traces.
DSV41_SUMMARY_TOOL optionally selects a frozen earlier CLI for a RED run.
"""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[3]
SUMMARY = Path(
    os.environ.get(
        "DSV41_SUMMARY_TOOL", ROOT / "tools/diagnostics/summarize_dsv41_hccl_run.py"
    )
)
PREPARE = ROOT / "tools/diagnostics/prepare_dsv41_hccl_recipe.py"
TIMEOUT_SECONDS = 30
LAYERS = (0, 1)
PARENTS = (("u2-first", 2), ("u1-fallback", 1), ("u2-again", 2))


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def load_emitters():
    # Only parent package import side effects are suppressed. Both executable
    # leaves are loaded normally, without AST extraction or fake dependencies.
    for name in ("afd_plugin", "afd_plugin.connectors", "afd_plugin.connectors.npu"):
        package = types.ModuleType(name)
        package.__path__ = [str(ROOT.joinpath(*name.split(".")))]
        sys.modules[name] = package
    modules = []
    for leaf in ("hccl_overlap", "hccl_diagnostics"):
        name = "afd_plugin.connectors.npu." + leaf
        spec = importlib.util.spec_from_file_location(
            name, ROOT / "afd_plugin/connectors/npu" / (leaf + ".py")
        )
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module
        spec.loader.exec_module(module)
        modules.append(module)
    return modules


def parent_records(
    overlap, diagnostics, environment, role, transaction, stages, *, rank=0, tp=1
):
    records = []
    # Settings belong to the configured U2 session, even for a U1 parent.
    settings = overlap.HcclOverlapSettings.from_environment(environment, num_stages=2)
    selection = overlap.select_hccl_overlap(
        settings, role=role, phase="eager", num_stages=stages
    )
    streamed = stages == 2
    actual = diagnostics.HcclDiagnosticExecution(
        "eager-streamed" if streamed else "serial",
        "compute" if streamed else "parent",
        "send" if streamed else "parent",
        "recv" if streamed else "parent",
        (False, False, False) if streamed else None,
    )
    progress = diagnostics.HcclStageDiagnostics(
        selection,
        world_rank=rank + (tp if role == "attention" else 0),
        role_rank=rank,
        emit=records.append,
        # This is an emitter contract input, not a simulated device fence.
        synchronize=lambda: None,
    ).bind_execution(
        layer_indices=LAYERS, actual_execution=actual, transaction_id=transaction
    )
    if role == "attention":
        for stage in range(stages):
            for boundary in ("begin", "returned"):
                progress.record(f"prepare_{boundary}", LAYERS[0], stage)
    for layer in LAYERS:
        for stage in range(stages):
            if streamed:
                events = (
                    (
                        "compute",
                        "send_post",
                        "recv_post",
                        "loan_wait",
                        "stage_reuse_wait",
                    )
                    if role == "attention"
                    else (
                        "recv_post",
                        "loan_wait",
                        "compute",
                        "send_post",
                        "stage_reuse_wait",
                    )
                )
            else:
                events = (
                    ("compute", "send", "recv", "continuation")
                    if role == "attention"
                    else ("recv", "compute", "send")
                )
            for stem in events:
                for boundary in ("begin", "returned"):
                    progress.record(f"{stem}_{boundary}", layer, stage)
                if stem == "compute" and not streamed and role == "ffn":
                    progress.synchronize_compute(layer, stage)
    if streamed:
        for boundary in ("begin", "returned"):
            progress.record(f"parent_finish_{boundary}", LAYERS[-1], 0)
    elif role == "attention":
        for boundary in ("begin", "returned"):
            progress.record(f"collapse_{boundary}", LAYERS[-1], 0)
    return records


def inputs(directory: Path, sync: bool, *, tp=1):
    devices = (
        {"attention": [2], "ffn": [6]}
        if tp == 1
        else {"attention": [0, 2], "ffn": [4, 6]}
    )
    request = {
        "mode": "eager",
        "num_stages": 2,
        "native_tp_size": tp,
        "max_num_seqs": 2,
        "max_num_batched_tokens": 8,
        "dbo_decode_token_threshold": 6,
        "attention_devices": devices["attention"],
        "ffn_devices": devices["ffn"],
    }
    with patch.dict(sys.modules):
        overlap, diagnostics = load_emitters()
        environment = {
            name: "1" if enabled else "0"
            for name, enabled in overlap.HcclOverlapSettings(
                eager_u2_stream_overlap=True,
                graph_u2_compute_overlap=False,
                graph_u2_hybrid_dag=False,
                graph_u2_attention_three_stream=False,
                graph_u2_ffn_recv_stream=False,
                graph_u2_ffn_cross_layer=False,
                stage_diagnostics=True,
                ffn_compute_sync_diagnostics=sync,
            )
            .effective_settings()
            .items()
        }
        write_json(directory / "request.json", request)
        write_json(directory / "environment.json", environment)
        prepared = subprocess.run(
            [
                sys.executable,
                "-B",
                "-S",
                str(PREPARE),
                "--request",
                str(directory / "request.json"),
                "--environment",
                str(directory / "environment.json"),
                "--model-path",
                "/component/not-loaded",
                "--repo-path",
                "/component/not-started",
                "--output",
                str(directory / "recipe.json"),
            ],
            capture_output=True,
            timeout=TIMEOUT_SECONDS,
        )
        if prepared.returncode:
            raise AssertionError(prepared.stderr.decode(errors="replace"))
        recipe = json.loads((directory / "recipe.json").read_bytes())
        records = {}
        for role, rank, device in (
            (role, rank, device)
            for role, selected in devices.items()
            for rank, device in enumerate(selected)
        ):
            # Explicit synthetic startup input; no connector constructor/HELLO.
            startup = {
                "event": "session_configuration",
                "phase": "startup",
                "role": role,
                "role_rank": rank,
                "world_rank": rank + (tp if role == "attention" else 0),
                "local_device": device,
                "snapshot_present": True,
                "negotiated.native_tp_size": tp,
                "negotiated.max_tokens": 8,
                "negotiated.graph_execution_version": 0,
                "negotiated.eager_pipeline_version": 1,
                "negotiated.attention_size": tp,
                "negotiated.ffn_size": tp,
                "negotiated.max_stages": 2,
                **{
                    f"configured.{key}": value == "1"
                    for key, value in environment.items()
                },
            }
            label = role if tp == 1 else f"{role}-{rank}"
            records[label] = [startup]
            for transaction, stages in PARENTS:
                records[label].extend(
                    parent_records(
                        overlap,
                        diagnostics,
                        environment,
                        role,
                        transaction,
                        stages,
                        rank=rank,
                        tp=tp,
                    )
                )
    assert not {"torch", "torch_npu", "vllm", "vllm_ascend"}.intersection(sys.modules)
    return {
        "recipe": recipe,
        "records": records,
        "expected": [
            {
                "transaction_id": transaction,
                "phase": "eager",
                "num_stages": stages,
                "layer_indices": list(LAYERS),
                "active_stages": list(range(stages)),
            }
            for transaction, stages in PARENTS
        ],
    }


def run_summary(directory: Path, value, *, native_log=False):
    directory.mkdir()
    write_json(directory / "recipe.json", value["recipe"])
    manifest = {
        "schema_version": 1,
        "run_id": "constructed-cli-input",
        "recipe": {
            "path": "recipe.json",
            "sha256": sha((directory / "recipe.json").read_bytes()),
        },
        "device_namespace": "all_visible",
        "visible_devices": list(range(8)),
        "expected_transactions": value["expected"],
        "ranks": [],
    }
    for label, records in value["records"].items():
        path = directory / (label + (".log" if native_log else ".json"))
        if native_log:
            path.write_text(
                "\n".join(
                    (
                        "AFD HCCL session configuration: "
                        if row["event"] == "session_configuration"
                        else "AFD HCCL stage diagnostic: "
                    )
                    + repr(row)
                    for row in records
                )
                + "\n",
                encoding="utf-8",
            )
        else:
            write_json(path, records)
        manifest["ranks"].append(
            {
                "role": records[0]["role"],
                "role_rank": records[0]["role_rank"],
                "log_path": path.name,
                "sha256": sha(path.read_bytes()),
                "format": "log" if native_log else "json",
            }
        )
    write_json(directory / "run.json", manifest)
    protected = {path: sha(path.read_bytes()) for path in directory.iterdir()}
    completed = subprocess.run(
        [
            sys.executable,
            "-B",
            "-S",
            str(SUMMARY),
            "--run-manifest",
            str(directory / "run.json"),
            "--output",
            str(directory / "report.json"),
        ],
        capture_output=True,
        timeout=TIMEOUT_SECONDS,
    )
    (directory / "stdout.log").write_bytes(completed.stdout)
    (directory / "stderr.log").write_bytes(completed.stderr)
    report = json.loads((directory / "report.json").read_bytes())
    assert all(sha(path.read_bytes()) == digest for path, digest in protected.items())
    return completed.returncode, report


def recipe_output_case(directory: Path, output_name: str, *, prepare: bool):
    checkout = directory / "checkout"
    sources = (
        PREPARE,
        ROOT / "tools/diagnostics/plan_dsv41_hccl_recipe.py",
        ROOT / ".agents/dsv41/sources.lock.json",
        *sorted((ROOT / "afd_plugin").rglob("*.py")),
    )
    original = {path.relative_to(ROOT): path.read_bytes() for path in sources}
    source_paths = tuple(original)
    original.update(
        {
            Path("request.json"): (
                ROOT
                / "recipe/npu/P2pHcclAFDConnector/deepseek_v41/request.graph-u2.json"
            ).read_bytes(),
            Path("environment.json"): (
                ROOT
                / "recipe/npu/P2pHcclAFDConnector/deepseek_v41/environment.serial.json"
            ).read_bytes(),
            Path("checkpoint/config.json"): json.dumps(
                {
                    "model_type": "deepseek_v41",
                    "architectures": ["DeepseekV41ForCausalLM"],
                }
            ).encode(),
        }
    )
    for relative, raw in original.items():
        destination = checkout / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    output = checkout / output_name
    command = [
        sys.executable,
        "-B",
        "-S",
        str(
            checkout
            / "tools/diagnostics"
            / (
                "prepare_dsv41_hccl_recipe.py"
                if prepare
                else "plan_dsv41_hccl_recipe.py"
            )
        ),
        "--request",
        str(checkout / "request.json"),
        "--environment",
        str(checkout / "environment.json"),
        "--output",
        str(output),
    ]
    if prepare:
        command.extend(
            (
                "--model-path",
                "/component/not-loaded",
                "--repo-path",
                "/component/not-started",
                "--model-config",
                str(checkout / "checkpoint/config.json"),
            )
        )
    else:
        command.extend(("--model", str(checkout / "checkpoint")))
    completed = subprocess.run(command, capture_output=True, timeout=TIMEOUT_SECONDS)
    (directory / "stdout.log").write_bytes(completed.stdout)
    (directory / "stderr.log").write_bytes(completed.stderr)
    return completed, checkout, original, output, source_paths


class HcclRunCLITest(unittest.TestCase):
    def setUp(self):
        artifacts = os.environ.get("DSV41_CLI_ARTIFACT_ROOT")
        if artifacts:
            destination = Path(artifacts)
            destination.mkdir(parents=True, exist_ok=True)
            self.root = Path(tempfile.mkdtemp(prefix="case-", dir=destination))
        else:
            directory = tempfile.TemporaryDirectory(prefix="afd-mixed-summary-")
            self.addCleanup(directory.cleanup)
            self.root = Path(directory.name)
        self.value = inputs(self.root, sync=False)

    def test_recipe_output_cannot_replace_or_create_checkout_sources(self):
        names = (
            "afd_plugin/compat/patches/engine_core.py",
            ".agents/dsv41/sources.lock.json",
            "afd_plugin/new_recipe_output.json",
            "tools/diagnostics/prepare_dsv41_hccl_recipe.py",
            "tools/diagnostics/plan_dsv41_hccl_recipe.py",
            "request.json",
            "environment.json",
            "checkpoint/config.json",
        )
        for prepare in (True, False):
            for index, name in enumerate(names):
                with self.subTest(prepare=prepare, output=name):
                    directory = self.root / f"output-{prepare}-{index}"
                    directory.mkdir()
                    completed, checkout, original, output, _ = recipe_output_case(
                        directory, name, prepare=prepare
                    )
                    self.assertEqual(completed.returncode, 2, completed.stderr.decode())
                    self.assertIn(
                        "output must not overwrite", completed.stderr.decode()
                    )
                    self.assertEqual(
                        original,
                        {path: (checkout / path).read_bytes() for path in original},
                    )
                    if Path(name) not in original:
                        self.assertFalse(output.exists())

    def test_recipe_output_outside_checkout_sources_remains_available(self):
        for prepare in (True, False):
            with self.subTest(prepare=prepare):
                directory = self.root / f"normal-{prepare}"
                directory.mkdir()
                completed, checkout, original, output, sources = recipe_output_case(
                    directory, "prepared/recipe.json", prepare=prepare
                )
                self.assertEqual(completed.returncode, 0, completed.stderr.decode())
                manifest = json.loads(output.read_bytes())
                field = "preparation_success" if prepare else "plan_validation_success"
                self.assertIs(manifest[field], True)
                if prepare:
                    self.assertEqual(
                        manifest["source_identity"]["files"],
                        {path.as_posix(): sha(original[path]) for path in sources},
                    )
                self.assertEqual(
                    original,
                    {path: (checkout / path).read_bytes() for path in original},
                )

    def test_mixed_eager_parents_are_checked_without_device_claims(self):
        for sync in (False, True):
            for native_log in (False, True):
                with self.subTest(sync=sync, native_log=native_log):
                    source = self.root / f"source-{sync}-{native_log}"
                    source.mkdir()
                    value = inputs(source, sync)
                    code, report = run_summary(
                        self.root / f"run-{sync}-{native_log}",
                        value,
                        native_log=native_log,
                    )
                    self.assertEqual(code, 0, report)
                    self.assertTrue(report["actual_events_verified"])
                    for rank in report["ranks"]:
                        self.assertEqual(
                            [p["num_stages"] for p in rank["parents"]], [2, 1, 2]
                        )
                        serial = rank["parents"][1]
                        self.assertIs(
                            serial["actual_serial_body_events_verified"], True
                        )
                        self.assertIs(serial["parent_finish_observed"], False)
                        self.assertIs(serial["parent_completion_verified"], False)
                        self.assertIs(serial["device_completion_verified"], False)
                    for key in (
                        "npu_execution_performed",
                        "physical_overlap_verified",
                        "full_model_qualification",
                        "performance_verified",
                        "runtime_admission_checked",
                    ):
                        self.assertIs(report[key], False)

    def test_invalid_serial_parent_records_are_rejected(self):
        changes = (
            ("mode", lambda row: row.update({"actual.mode": "eager-streamed"})),
            ("stream", lambda row: row.update({"actual.compute_stream": "compute"})),
            (
                "pipeline",
                lambda row: row.update({"actual.compute_pipeline_enabled": True}),
            ),
            ("alias", lambda row: row.update({"actual.compute_send_alias": False})),
            ("stage", lambda row: row.update(stage=1)),
            ("bool-stage", lambda row: row.update(stage=False)),
            ("num-stages", lambda row: row.update(num_stages=True)),
            ("phase", lambda row: row.update(phase="capture")),
            (
                "failed-outcome",
                lambda row: row.update(outcome="raised", error_type="RuntimeError"),
            ),
        )
        for role in ("attention", "ffn"):
            for label, change in changes:
                with self.subTest(role=role, label=label):
                    value = copy.deepcopy(self.value)
                    row = next(
                        row
                        for row in value["records"][role]
                        if row.get("transaction_id") == "u1-fallback"
                        and row["event"] == "compute_begin"
                    )
                    change(row)
                    code, report = run_summary(self.root / f"bad-{role}-{label}", value)
                    self.assertEqual(code, 1, report)
                    self.assertFalse(report["success"])

    def test_missing_duplicate_or_reversed_serial_boundaries_are_rejected(self):
        for role in ("attention", "ffn"):
            for change in ("missing", "duplicate", "reversed", "reordered-parent"):
                with self.subTest(role=role, change=change):
                    value = copy.deepcopy(self.value)
                    records = value["records"][role]
                    index = next(
                        i
                        for i, row in enumerate(records)
                        if row.get("transaction_id") == "u1-fallback"
                        and row["event"] == "compute_returned"
                    )
                    if change == "missing":
                        records.pop(index)
                    elif change == "duplicate":
                        records.insert(index, copy.deepcopy(records[index]))
                    elif change == "reversed":
                        records[index - 1], records[index] = (
                            records[index],
                            records[index - 1],
                        )
                    else:
                        records.insert(1, records.pop(index))
                    code, report = run_summary(
                        self.root / f"order-{role}-{change}", value
                    )
                    self.assertEqual(code, 1, report)

    def test_serial_payload_causality_is_checked(self):
        for role, begin, end in (
            ("attention", "recv", "send"),
            ("ffn", "compute", "recv"),
        ):
            with self.subTest(role=role):
                value = copy.deepcopy(self.value)
                records = value["records"][role]
                moving = [
                    row
                    for row in records
                    if row.get("transaction_id") == "u1-fallback"
                    and row.get("layer") == 0
                    and row["event"].startswith(begin + "_")
                ]
                records[:] = [
                    row for row in records if not any(row is item for item in moving)
                ]
                index = next(
                    i
                    for i, row in enumerate(records)
                    if row.get("transaction_id") == "u1-fallback"
                    and row.get("layer") == 0
                    and row["event"] == end + "_begin"
                )
                records[index:index] = moving
                code, report = run_summary(self.root / f"causality-{role}", value)
                self.assertEqual(code, 1, report)

    def test_serial_sync_requires_the_complete_explicit_boundary(self):
        source = self.root / "sync-source"
        source.mkdir()
        original = inputs(source, sync=True)
        for change in (
            "missing-begin",
            "missing-complete",
            "reversed",
            "implicit",
            "after-send",
        ):
            with self.subTest(change=change):
                value = copy.deepcopy(original)
                records = value["records"]["ffn"]
                index = next(
                    i
                    for i, row in enumerate(records)
                    if row["event"] == "compute_sync_begin"
                )
                if change == "missing-begin":
                    records.pop(index)
                elif change == "missing-complete":
                    records.pop(index + 1)
                elif change == "reversed":
                    records[index : index + 2] = reversed(records[index : index + 2])
                elif change == "implicit":
                    records[index]["boundary"] = "host_enqueue"
                else:
                    records[index : index + 4] = (
                        records[index + 2 : index + 4] + records[index : index + 2]
                    )
                code, report = run_summary(self.root / f"sync-{change}", value)
                self.assertEqual(code, 1, report)

    def test_unexpected_sync_or_parent_finish_claims_are_rejected(self):
        for role in ("attention", "ffn"):
            for event in (
                "compute_sync_begin",
                "parent_finish_returned",
                "host_failed",
            ):
                with self.subTest(role=role, event=event):
                    value = copy.deepcopy(self.value)
                    records = value["records"][role]
                    index = next(
                        i
                        for i, row in enumerate(records)
                        if row.get("transaction_id") == "u1-fallback"
                        and row["event"] == "compute_returned"
                    )
                    row = copy.deepcopy(records[index])
                    row["event"] = event
                    if event == "compute_sync_begin":
                        row["boundary"] = "explicit_synchronize"
                    records.insert(index + 1, row)
                    code, report = run_summary(
                        self.root / f"claim-{role}-{event}", value
                    )
                    self.assertEqual(code, 1, report)

    def test_serial_session_settings_remain_frozen(self):
        for role in ("attention", "ffn"):
            for field, enabled in (
                ("configured.AFD_HCCL_EAGER_U2_STREAM_OVERLAP", False),
                ("effective.AFD_HCCL_EAGER_U2_STREAM_OVERLAP", True),
                ("parent_transport_override", True),
            ):
                with self.subTest(role=role, field=field):
                    value = copy.deepcopy(self.value)
                    row = next(
                        row
                        for row in value["records"][role]
                        if row.get("transaction_id") == "u1-fallback"
                        and row["event"] == "configuration"
                    )
                    row[field] = enabled
                    code, report = run_summary(
                        self.root / f"config-{role}-{field}", value
                    )
                    self.assertEqual(code, 1, report)

    def test_rank_local_empty_serial_body_can_omit_complete_continuations(self):
        source = self.root / "tp2-source"
        source.mkdir()
        original = inputs(source, sync=False, tp=2)
        for missing in ("both", "begin", "returned"):
            with self.subTest(missing=missing):
                value = copy.deepcopy(original)
                records = value["records"]["attention-0"]
                # The CLI has no tensor rows: this is a legal host schema for
                # a locally empty A rank, not a claim of executing TP2 or MoE.
                records[:] = [
                    row
                    for row in records
                    if not (
                        row.get("transaction_id") == "u1-fallback"
                        and (
                            row["event"].startswith("continuation_")
                            if missing == "both"
                            else row["event"] == "continuation_" + missing
                        )
                    )
                ]
                code, report = run_summary(self.root / f"continuation-{missing}", value)
                self.assertEqual(code, 0 if missing == "both" else 1, report)


if __name__ == "__main__":
    unittest.main()
