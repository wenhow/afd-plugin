# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""NPU AFD feature validation rejects unsupported combinations before execution."""

from __future__ import annotations

from contextlib import nullcontext
from copy import deepcopy
from types import SimpleNamespace

import pytest

from afd_plugin.compat.npu import (
    fail_if_unsupported_npu_afd_features,
    npu_afd_num_ubatches,
)
from afd_plugin.compat.npu.runtime_config import get_npu_ffn_config
from afd_plugin.config import AFDConfig
from tests.unit.fakes.vllm_config import (
    async_moe_config as _async_moe_config,
)
from tests.unit.fakes.vllm_config import (
    configure_hccl_ep,
    v41_dspark_config,
    v41_dummy_qualification_config,
    v41_eager_qualification_config,
    v41_full_qualification_config,
    v41_functional_qualification_config,
)
from tests.unit.fakes.vllm_config import (
    npu_vllm_config as _vllm_config,
)

TWO_UBATCH_DBO = dict(
    enable_dbo=True, use_ubatching=True, num_ubatches=2, ubatch_size=4
)
ASYNC_CAM = dict(connector="CAMAsyncAFDConnector", async_dp=True)


@pytest.fixture(autouse=True)
def clear_v41_qualification_environment(monkeypatch):
    monkeypatch.delenv("AFD_DSV41_EAGER_QUALIFICATION", raising=False)
    monkeypatch.delenv("AFD_DSV41_DUMMY_QUALIFICATION", raising=False)
    monkeypatch.delenv("AFD_DSV41_FUNCTIONAL_QUALIFICATION", raising=False)
    monkeypatch.delenv("AFD_DSV41_FULL_QUALIFICATION", raising=False)


@pytest.mark.parametrize(
    "role,connector,model_type,message",
    [
        ("attention", "CAMAsyncAFDConnector", "deepseek_v4", "FFN role"),
        ("ffn", "CAMP2pAFDConnector", "deepseek_v4", "async CAM"),
        ("ffn", "CAMAsyncAFDConnector", "deepseek_v2", "only DeepSeek V4"),
    ],
)
def test_layered_switch_rejects_other_roles_connectors_and_models(
    monkeypatch, role, connector, model_type, message
):
    config = _vllm_config(role=role, connector=connector, model_type=model_type)
    afd_config = AFDConfig(role=role, connector=connector)
    monkeypatch.setenv("AFD_ASYNC_CAM_LAYERED_GMM", "1")

    with pytest.raises(RuntimeError, match=message):
        fail_if_unsupported_npu_afd_features(config, afd_config=afd_config)


@pytest.fixture
def vllm_connector_runtime():
    # Only connector parsing requires vLLM; early config rejection is CPU safe.
    pytest.importorskip("vllm")


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize(
    "connector", ["CAMP2pAFDConnector", "CAMAsyncAFDConnector", "P2pNcclAFDConnector"]
)
@pytest.mark.parametrize(
    "model_type,architecture",
    [
        ("deepseek_v41", None),
        ("deepseek_v41", "DeepseekV41ForCausalLM"),
        ("custom", "DeepseekV41ForCausalLM"),
        ("custom", "AFDDeepseekV41ForCausalLM"),
        ("deepseek_v4", "DeepseekV41ForCausalLM"),
    ],
)
def test_npu_validation_rejects_v41_before_connector_initialization(
    role, connector, model_type, architecture
):
    config = _vllm_config(role=role, connector=connector)
    config.model_config.hf_config.model_type = model_type
    config.model_config.hf_config.architectures = (
        [architecture] if architecture else None
    )
    before = deepcopy(config)
    with pytest.raises(RuntimeError, match="DeepSeek V4.1 NPU AFD is not available"):
        fail_if_unsupported_npu_afd_features(config)
    assert config == before


@pytest.mark.parametrize("role", ["attention", "ffn"])
def test_dspark_components_do_not_enable_full_v41_model_execution(role):
    config = v41_dspark_config(role=role)
    before = deepcopy(config)

    with pytest.raises(RuntimeError, match="DeepSeek V4.1 NPU AFD is not available"):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


@pytest.fixture
def v41_eager_candidate():
    torch = pytest.importorskip("torch")
    pytest.importorskip("vllm")
    from vllm.config import CompilationMode, ModelConfig
    from vllm.config.compilation import CUDAGraphMode
    from vllm.config.multimodal import MultiModalConfig

    def build(
        *, role="attention", rank=0, tensor_parallel_size=4, language_model_only=None
    ):
        config = v41_eager_qualification_config(
            dtype=torch.bfloat16,
            compilation_mode=CompilationMode.NONE,
            cudagraph_mode=CUDAGraphMode.NONE,
            role=role,
            rank=rank,
            tensor_parallel_size=tensor_parallel_size,
        )
        if language_model_only is not None:
            # Preserve the actual ModelConfig descriptor without running its
            # checkpoint/model-inspection initialization on a CPU-only host.
            native_model = object.__new__(ModelConfig)
            vars(native_model).update(vars(config.model_config))
            native_model.multimodal_config = MultiModalConfig(
                language_model_only=language_model_only
            )
            config.model_config = native_model
        return config

    return build


@pytest.fixture
def v41_full_candidate():
    torch = pytest.importorskip("torch")
    pytest.importorskip("vllm")
    from vllm.config import CompilationMode, CUDAGraphMode

    def build(**options):
        return v41_full_qualification_config(
            dtype=torch.bfloat16,
            compilation_mode=CompilationMode.NONE,
            cudagraph_mode=(
                CUDAGraphMode.FULL_DECODE_ONLY
                if options.get("graph")
                else CUDAGraphMode.NONE
            ),
            **options,
        )

    return build


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("rank", [0, 3])
def test_ep_full_candidate_preserves_native_dp_and_a_owned_engram(
    monkeypatch, v41_full_candidate, role, rank
):
    source = configure_hccl_ep(v41_full_candidate(role=role), dp_rank=rank)
    original = deepcopy(source)
    config = get_npu_ffn_config(source) if role == "ffn" else source
    monkeypatch.setenv("AFD_DSV41_FULL_QUALIFICATION", "1")
    fail_if_unsupported_npu_afd_features(config)
    assert source == original
    assert config.parallel_config.data_parallel_rank == rank
    assert config.parallel_config.enable_expert_parallel
    assert (
        config.engram_config is None
        if role == "ffn"
        else (
            config.engram_config.cpu_offload and config.engram_config.dp_shared_memory
        )
    )


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("graph,stages", [(False, 1), (False, 2), (True, 1), (True, 2)])
@pytest.mark.parametrize(
    "dspark,pd", [(False, False), (True, False), (False, True), (True, True)]
)
def test_full_checkpoint_candidate_preserves_weights_and_a_owned_history(
    monkeypatch, v41_full_candidate, role, graph, stages, dspark, pd
):
    source = v41_full_candidate(
        role=role, graph=graph, stages=stages, dspark=dspark, pd=pd
    )
    original = deepcopy(source)
    config = get_npu_ffn_config(source) if role == "ffn" else source
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_FULL_QUALIFICATION", "1")

    fail_if_unsupported_npu_afd_features(config)

    assert config == before
    assert source == original
    assert source.engram_config.cpu_offload is True
    assert source.model_config.hf_text_config.engram_layer_ids == [1, 14]
    if role == "ffn":
        assert (
            config.engram_config
            is config.speculative_config
            is config.kv_transfer_config
            is None
        )


@pytest.mark.parametrize("other", ["EAGER", "DUMMY", "FUNCTIONAL"])
def test_full_checkpoint_candidate_cannot_mix_qualification_modes(monkeypatch, other):
    monkeypatch.setenv("AFD_DSV41_FULL_QUALIFICATION", "1")
    monkeypatch.setenv(f"AFD_DSV41_{other}_QUALIFICATION", "1")
    with pytest.raises(ValueError, match="mutually exclusive"):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("rank", [0, 3])
@pytest.mark.parametrize("load_format", ["auto", "safetensors"])
def test_v41_eager_qualification_accepts_only_explicit_role_candidate(
    monkeypatch, v41_eager_candidate, role, rank, load_format
):
    source = v41_eager_candidate(role=role, rank=rank)
    source.load_config.load_format = load_format
    original = deepcopy(source)
    config = get_npu_ffn_config(source) if role == "ffn" else source
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")

    fail_if_unsupported_npu_afd_features(config)

    assert config == before
    assert source == original
    assert source.engram_config.cpu_offload is True
    if role == "ffn":
        assert config.engram_config is None


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize(
    "language_model_only,is_encoder_decoder",
    [(False, False), (True, False), (True, True)],
)
def test_v41_eager_qualification_admits_native_wrapper_only_in_language_mode(
    monkeypatch, v41_eager_candidate, role, language_model_only, is_encoder_decoder
):
    source = v41_eager_candidate(role=role, language_model_only=language_model_only)
    assert source.model_config.is_multimodal_model is True
    source.model_config.is_encoder_decoder = is_encoder_decoder
    config = get_npu_ffn_config(source) if role == "ffn" else source
    original_engram = source.engram_config
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")
    expected = (
        nullcontext()
        if language_model_only and not is_encoder_decoder
        else pytest.raises(ValueError, match="decoder-only text")
    )

    with expected:
        fail_if_unsupported_npu_afd_features(config)

    assert config.model_config is source.model_config
    assert source.engram_config is original_engram
    assert (
        source.model_config.multimodal_config.language_model_only is language_model_only
    )


@pytest.mark.parametrize("flag", [None, "0"])
def test_v41_eager_candidate_remains_rejected_by_default(
    monkeypatch, v41_eager_candidate, flag
):
    if flag is not None:
        monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", flag)
    with pytest.raises(RuntimeError, match="DeepSeek V4.1 NPU AFD is not available"):
        fail_if_unsupported_npu_afd_features(v41_eager_candidate())


@pytest.mark.parametrize("flag", ["", "true", "01", "2"])
def test_v41_eager_qualification_requires_an_exact_flag(monkeypatch, flag):
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", flag)
    with pytest.raises(
        ValueError, match="AFD_DSV41_EAGER_QUALIFICATION must be 0 or 1"
    ):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


@pytest.mark.parametrize(
    "container,field,value,message",
    [
        (None, "use_v2_model_runner", False, "ModelRunner V2"),
        ("parallel_config", "rank", -1, "role_rank"),
        ("parallel_config", "rank", 4, "role_rank"),
        ("parallel_config", "rank", True, "role_rank"),
        ("parallel_config", "tensor_parallel_size", 2, "tensor_parallel_size"),
        ("parallel_config", "data_parallel_size", 2, "data_parallel_size"),
        ("parallel_config", "enable_expert_parallel", True, "expert parallelism"),
        ("parallel_config", "use_sequence_parallel_moe", True, "sequence parallelism"),
        ("parallel_config", "enable_dbo", True, "eager U1"),
        ("model_config", "enforce_eager", False, "enforce_eager"),
        ("model_config", "is_multimodal_model", True, "decoder-only text"),
        ("model_config", "enable_sleep_mode", True, "sleep/weight updates"),
        ("model_config", "quantization", "fp8", "deepseek_v4_fp8"),
        (None, "quant_config", None, "deepseek_v4_fp8"),
        ("load_config", "load_format", "dummy", "real auto/safetensors"),
        ("scheduler_config", "max_num_seqs", 2, "one sequence"),
        ("scheduler_config", "async_scheduling", True, "sync scheduling"),
        ("scheduler_config", "async_scheduling", None, "sync scheduling"),
        ("scheduler_config", "max_num_batched_tokens", 1025, "limits <= 1024"),
        ("model_config", "max_model_len", 1025, "limits <= 1024"),
        ("model_config", "max_model_len", 0, "limits <= 1024"),
        ("cache_config", "enable_prefix_caching", True, "prefix caching off"),
        (None, "speculative_config", SimpleNamespace(), "speculation off"),
        (None, "kv_transfer_config", SimpleNamespace(), "KV transfer/PD off"),
        (None, "weight_transfer_config", SimpleNamespace(), "sleep/weight updates"),
        (None, "lora_config", SimpleNamespace(), "LoRA"),
        (None, "engram_config", None, "Attention CPU Engram"),
        ("engram_config", "cpu_offload", False, "Attention CPU Engram"),
        ("engram_config", "dp_shared_memory", True, "Attention CPU Engram"),
        ("engram_config", "embedding_across_dp", True, "Attention CPU Engram"),
    ],
)
def test_v41_eager_qualification_rejects_configuration_outside_candidate(
    monkeypatch, v41_eager_candidate, container, field, value, message
):
    config = v41_eager_candidate()
    owner = config if container is None else vars(config)[container]
    setattr(owner, field, value)
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


def test_v41_eager_qualification_rejects_ffn_before_role_isolation(
    monkeypatch, v41_eager_candidate
):
    config = v41_eager_candidate(role="ffn")
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")
    with pytest.raises(ValueError, match="FFN Engram isolation"):
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize("tp_size", [1, 2, 8])
def test_v41_eager_qualification_rejects_other_valid_native_topologies(
    monkeypatch, v41_eager_candidate, tp_size
):
    config = v41_eager_candidate(tensor_parallel_size=tp_size)
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")
    with pytest.raises(ValueError, match="A4/F4 with native TP4"):
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize(
    "additional_config,layered_gmm,message",
    [
        (
            {"sparse_kv_offload_config": {"enabled": True}},
            False,
            "sparse KV offload off",
        ),
        ({"enable_shared_expert_dp": True}, False, "uniform native TP"),
        (
            {"finegrained_tp_config": {"mlp_tensor_parallel_size": 2}},
            False,
            "uniform native TP",
        ),
        ({}, True, "Async CAM layered GMM off"),
    ],
)
def test_v41_eager_qualification_rejects_unqualified_runtime_flags(
    monkeypatch, v41_eager_candidate, additional_config, layered_gmm, message
):
    config = v41_eager_candidate()
    config.additional_config.update(additional_config)
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")
    monkeypatch.setenv("AFD_ASYNC_CAM_LAYERED_GMM", "1" if layered_gmm else "0")
    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)


@pytest.fixture
def v41_dummy_candidate():
    torch = pytest.importorskip("torch")
    pytest.importorskip("vllm")
    from vllm.config import CompilationMode
    from vllm.config.compilation import CUDAGraphMode

    def build(
        *, role="attention", num_ubatches=0, tensor_parallel_size=1, uses_c2=False
    ):
        return v41_dummy_qualification_config(
            dtype=torch.bfloat16,
            compilation_mode=CompilationMode.NONE,
            cudagraph_mode=CUDAGraphMode.NONE,
            role=role,
            num_ubatches=num_ubatches,
            tensor_parallel_size=tensor_parallel_size,
            uses_c2=uses_c2,
        )

    return build


@pytest.mark.parametrize("flag", ["", "true", "01", "2"])
def test_v41_dummy_qualification_requires_an_exact_flag(monkeypatch, flag):
    config = v41_dspark_config()
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", flag)

    with pytest.raises(
        ValueError, match="AFD_DSV41_DUMMY_QUALIFICATION must be 0 or 1"
    ):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


@pytest.fixture
def v41_functional_candidate():
    torch = pytest.importorskip("torch")
    pytest.importorskip("vllm")
    from vllm.config import CompilationMode
    from vllm.config.compilation import CUDAGraphMode

    def build(**settings):
        return v41_functional_qualification_config(
            dtype=torch.bfloat16,
            compilation_mode=CompilationMode.NONE,
            cudagraph_mode=(
                CUDAGraphMode.FULL_DECODE_ONLY
                if settings.get("graph", False)
                else CUDAGraphMode.NONE
            ),
            **settings,
        )

    return build


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize(
    "hidden_size,index_heads,expert_count",
    [(512, 32, 8), (512, 64, 8), (1024, 32, 8), (1024, 32, 64)],
)
@pytest.mark.parametrize(
    "u2,graph", [(False, False), (True, False), (False, True), (True, True)]
)
@pytest.mark.parametrize(
    "dspark,pd_role",
    [
        (False, None),
        (True, None),
        (False, "kv_consumer"),
        (True, "kv_consumer"),
        (True, "kv_producer"),
    ],
)
def test_v41_functional_qualification_preserves_supported_combinations(
    monkeypatch,
    v41_functional_candidate,
    role,
    hidden_size,
    index_heads,
    expert_count,
    u2,
    graph,
    dspark,
    pd_role,
):
    source = v41_functional_candidate(
        role=role, u2=u2, graph=graph, dspark=dspark, pd_role=pd_role
    )
    source.model_config.hf_text_config.index_n_heads = index_heads
    source.model_config.hf_text_config.hidden_size = hidden_size
    source.model_config.hf_text_config.n_routed_experts = expert_count
    if dspark:
        source.speculative_config.draft_model_config.hf_text_config.hidden_size = (
            hidden_size
        )
    original = deepcopy(source)
    monkeypatch.setenv("AFD_DSV41_FUNCTIONAL_QUALIFICATION", "1")

    if graph and pd_role == "kv_producer":
        with pytest.raises(ValueError, match="PD requires eager"):
            if role == "ffn":
                get_npu_ffn_config(source)
            else:
                fail_if_unsupported_npu_afd_features(source)
    else:
        config = get_npu_ffn_config(source) if role == "ffn" else source
        before = deepcopy(config)
        assert fail_if_unsupported_npu_afd_features(config) is None
        assert config == before

    assert source == original


@pytest.mark.parametrize("flag", ["", "true", "01", "2"])
def test_v41_functional_qualification_requires_exact_opt_in(monkeypatch, flag):
    monkeypatch.setenv("AFD_DSV41_FUNCTIONAL_QUALIFICATION", flag)

    with pytest.raises(
        ValueError, match="AFD_DSV41_FUNCTIONAL_QUALIFICATION must be 0 or 1"
    ):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


@pytest.mark.parametrize(
    "container,field,value,message",
    [
        ("config", "engram_config", True, "Engram off"),
        ("target", "engram_layer_ids", [0], "Engram off"),
        ("target", "hidden_size", 1536, "hidden_size"),
        ("target", "hidden_size", 1024.0, "hidden_size"),
        ("target", "n_routed_experts", 16, "n_routed_experts"),
        ("target", "n_routed_experts", 64.0, "n_routed_experts"),
        ("target", "n_routed_experts", True, "n_routed_experts"),
        ("target", "index_n_heads", 16, "index_n_heads"),
        ("target", "index_n_heads", 32.0, "index_n_heads"),
        ("target", "index_head_dim", 64, "index_head_dim"),
        ("draft", "engram_layer_ids", [0], "draft Engram off"),
        ("draft", "hidden_size", 1024, "matching draft hidden_size"),
        ("target", "dspark_block_size", 4, "native checkpoint draft metadata"),
        ("target", "num_nextn_predict_layers", 2, "native checkpoint draft metadata"),
        ("speculative", "num_speculative_tokens", 3, "one or two speculative"),
        ("speculative", "num_speculative_tokens", True, "integer speculative steps"),
        ("speculative", "enforce_eager", False, "eager DSpark draft"),
        ("speculative", "enable_adaptive_verification", True, "adaptive verification"),
        ("speculative", "rejection_sample_method", "synthetic", "real acceptance"),
        ("speculative", "quantization", "fp8", "unquantized BF16 draft/KV"),
        ("speculative", "kv_cache_dtype", "fp8", "unquantized BF16 draft/KV"),
        ("scheduler", "max_num_seqs", 3, "one or two sequences"),
        ("scheduler", "max_num_seqs", True, "one or two sequences"),
        ("parallel", "num_ubatches", 3, "native U1 or U2"),
        ("parallel", "num_ubatches", True, "native U1 or U2"),
        ("parallel", "use_ubatching", False, "native U1 or U2"),
        ("parallel", "enable_dbo", 1, "native U1 or U2"),
        ("model", "quantization", "fp8", "unquantized BF16"),
        ("load", "load_format", "auto", "dummy loading"),
        ("transfer", "kv_connector_module_path", None, "attested PD connector"),
    ],
)
def test_v41_functional_qualification_rejects_out_of_scope_candidates(
    monkeypatch, v41_functional_candidate, container, field, value, message
):
    config = v41_functional_candidate(
        u2=True, graph=True, dspark=True, pd_role="kv_consumer"
    )
    containers = {
        "config": config,
        "model": config.model_config,
        "target": config.model_config.hf_text_config,
        "draft": config.speculative_config.draft_model_config.hf_text_config,
        "speculative": config.speculative_config,
        "scheduler": config.scheduler_config,
        "parallel": config.parallel_config,
        "load": config.load_config,
        "transfer": config.kv_transfer_config,
    }
    setattr(containers[container], field, value)
    original = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_FUNCTIONAL_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)

    assert config == original


@pytest.mark.parametrize("other", ["EAGER", "DUMMY"])
def test_v41_functional_qualification_cannot_mix_candidates(monkeypatch, other):
    monkeypatch.setenv("AFD_DSV41_FUNCTIONAL_QUALIFICATION", "1")
    monkeypatch.setenv(f"AFD_DSV41_{other}_QUALIFICATION", "1")

    with pytest.raises(
        ValueError, match="qualification candidates are mutually exclusive"
    ):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


def test_v41_qualification_candidates_are_mutually_exclusive(monkeypatch):
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")
    monkeypatch.setenv("AFD_DSV41_EAGER_QUALIFICATION", "1")

    with pytest.raises(
        ValueError, match="qualification candidates are mutually exclusive"
    ):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


@pytest.mark.parametrize("flag", [None, "0"])
def test_v41_dummy_candidate_remains_rejected_by_default(monkeypatch, flag):
    if flag is not None:
        monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", flag)

    with pytest.raises(RuntimeError, match="DeepSeek V4.1 NPU AFD is not available"):
        fail_if_unsupported_npu_afd_features(v41_dspark_config())


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("num_ubatches", [0, 1])
@pytest.mark.parametrize(
    "architecture", ["DeepseekV41ForCausalLM", "AFDDeepseekV41ForCausalLM"]
)
def test_v41_dummy_qualification_preserves_normal_worker_config(
    monkeypatch, v41_dummy_candidate, role, num_ubatches, architecture
):
    source = v41_dummy_candidate(role=role, num_ubatches=num_ubatches)
    source.model_config.hf_config.architectures = [architecture]
    config = get_npu_ffn_config(source) if role == "ffn" else source
    before = deepcopy(config)
    original = deepcopy(source)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    assert fail_if_unsupported_npu_afd_features(config) is None

    assert config == before
    assert source == original
    assert config.model_config is source.model_config


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize("num_ubatches", [0, 1])
def test_v41_dummy_qualification_accepts_first_c2_without_mutation(
    monkeypatch, v41_dummy_candidate, role, num_ubatches
):
    source = v41_dummy_candidate(role=role, num_ubatches=num_ubatches, uses_c2=True)
    config = get_npu_ffn_config(source) if role == "ffn" else source
    before = deepcopy(config)
    original = deepcopy(source)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    assert fail_if_unsupported_npu_afd_features(config) is None
    assert config == before and source == original


@pytest.mark.parametrize(
    "layers,ratios",
    [
        (3, [0, 0]),
        (2, [0, 0, 2]),
        (3, [0, 0, 0]),
        (3, [2, 0, 0]),
        (3, [0, 0, 1]),
        (3, [0, 0, True]),
        (4, [0, 0, 2, 2]),
    ],
)
def test_v41_dummy_qualification_rejects_other_compressed_geometry(
    monkeypatch, v41_dummy_candidate, layers, ratios
):
    config = v41_dummy_candidate(uses_c2=True)
    config.model_config.hf_text_config.num_hidden_layers = layers
    config.model_config.hf_text_config.compress_ratios = ratios
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match="num_hidden_layers|compress_ratios"):
        fail_if_unsupported_npu_afd_features(config)
    assert config == before


@pytest.mark.parametrize(
    "field,value",
    [
        ("kv_source_layer_ids", [0]),
        ("kv_source_layer_ids", [2.0]),
        ("kv_source_layer_ids", [2, 6]),
        ("index_source_layer_ids", [0]),
        ("index_source_layer_ids", [2.0]),
        ("candidate_source_layer_id", 2),
        ("candidate_source_layer_id", 20.0),
    ],
)
def test_v41_dummy_c2_qualification_keeps_native_source_ownership(
    monkeypatch, v41_dummy_candidate, field, value
):
    config = v41_dummy_candidate(uses_c2=True)
    setattr(config.model_config.hf_text_config, field, value)
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=field):
        fail_if_unsupported_npu_afd_features(config)
    assert config == before


@pytest.mark.parametrize(
    "field,value",
    [
        ("hidden_size", 1024),
        ("hidden_size", 512.0),
        ("hc_mult", 1),
        ("num_attention_heads", 1),
        ("num_key_value_heads", 2),
        ("head_dim", 128),
        ("qk_rope_head_dim", 128),
        ("q_lora_rank", 128),
        ("kv_lora_rank", 128),
        ("o_lora_rank", 128),
        ("o_groups", 2),
        ("num_hidden_layers", 3),
        ("sliding_window", 64),
        ("index_topk", 16),
        ("index_n_heads", 1),
        ("index_n_heads", 32),
        ("index_head_dim", 64),
        ("vocab_size", 8192),
        ("intermediate_size", 1024),
        ("moe_intermediate_size", 1024),
        ("n_routed_experts", 16),
        ("n_routed_experts", 64),
        ("num_experts_per_tok", 4),
        ("n_shared_experts", 2),
        ("n_group", 2),
        ("topk_group", 2),
        ("num_hash_layers", 1),
        ("compress_ratios", [2, 2]),
        ("compress_ratios", [False, False]),
    ],
)
def test_v41_dummy_qualification_rejects_other_model_geometry(
    monkeypatch, v41_dummy_candidate, field, value
):
    config = v41_dummy_candidate()
    setattr(config.model_config.hf_text_config, field, value)
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=field):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


@pytest.mark.parametrize(
    "container,field,value,message",
    [
        ("device_config", "device_type", "cuda", "NPU"),
        (None, "use_v2_model_runner", False, "ModelRunner V2"),
        ("parallel_config", "rank", 1, "role_rank"),
        ("parallel_config", "data_parallel_size", 2, "data_parallel_size"),
        ("parallel_config", "pipeline_parallel_size", 2, "pipeline_parallel_size"),
        ("parallel_config", "prefill_context_parallel_size", 2, "context_parallel"),
        ("parallel_config", "decode_context_parallel_size", 2, "context_parallel"),
        ("parallel_config", "enable_expert_parallel", True, "expert parallelism"),
        ("parallel_config", "use_sequence_parallel_moe", True, "sequence parallelism"),
        ("parallel_config", "enable_dbo", True, "eager U1"),
        ("parallel_config", "use_ubatching", True, "eager U1"),
        ("parallel_config", "num_ubatches", 2, "eager U1"),
        ("parallel_config", "num_ubatches", True, "eager U1"),
        ("model_config", "enforce_eager", False, "eager U1"),
        ("model_config", "enable_sleep_mode", True, "sleep/weight updates"),
        ("model_config", "quantization", "fp8", "unquantized BF16"),
        ("model_config", "max_model_len", 256, "max_model_len=128"),
        ("scheduler_config", "max_num_seqs", 2, "one sequence"),
        ("scheduler_config", "max_num_seqs", True, "one sequence"),
        ("scheduler_config", "max_num_batched_tokens", 32, "batch capacity=16"),
        ("scheduler_config", "async_scheduling", True, "sync scheduling"),
        ("scheduler_config", "async_scheduling", None, "sync scheduling"),
        ("scheduler_config", "enable_chunked_prefill", False, "chunked prefill"),
        ("cache_config", "block_size", 64, "block_size=128"),
        ("cache_config", "enable_prefix_caching", True, "prefix caching off"),
        ("cache_config", "cache_dtype", "fp8", "BF16 KV cache"),
        ("load_config", "load_format", "auto", "dummy loading"),
        (None, "quant_config", SimpleNamespace(), "unquantized BF16"),
        (None, "speculative_config", SimpleNamespace(), "speculation off"),
        (None, "kv_transfer_config", SimpleNamespace(), "KV transfer/PD off"),
        (None, "engram_config", SimpleNamespace(), "Engram off"),
        (None, "weight_transfer_config", SimpleNamespace(), "sleep/weight updates"),
        (None, "lora_config", SimpleNamespace(), "LoRA"),
        ("model_config", "is_encoder_decoder", True, "decoder-only text"),
        ("model_config", "is_multimodal_model", True, "decoder-only text"),
        ("compilation_config", "mode", "other", "compilation and graph modes NONE"),
        (
            "compilation_config",
            "cudagraph_mode",
            "other",
            "compilation and graph modes NONE",
        ),
    ],
)
def test_v41_dummy_qualification_rejects_other_runtime_configuration(
    monkeypatch, v41_dummy_candidate, container, field, value, message
):
    config = v41_dummy_candidate()
    owner = config if container is None else vars(config)[container]
    setattr(owner, field, value)
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


def test_v41_dummy_qualification_rejects_other_valid_native_topology(
    monkeypatch, v41_dummy_candidate
):
    config = v41_dummy_candidate(tensor_parallel_size=2)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match="A1/F1 with native TP1"):
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize("cache_dtype", ["auto", "bfloat16"])
def test_v41_dummy_qualification_accepts_only_bf16_cache_storage(
    monkeypatch, v41_dummy_candidate, cache_dtype
):
    config = v41_dummy_candidate()
    config.cache_config.cache_dtype = cache_dtype
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    assert fail_if_unsupported_npu_afd_features(config) is None


@pytest.mark.parametrize(
    "field,value,message",
    [
        ("expert_dtype", "fp8", "unquantized BF16"),
        ("quantization_config", {"quant_method": "fp8"}, "unquantized BF16"),
        ("engram_layer_ids", [0], "Engram off"),
    ],
)
def test_v41_dummy_qualification_rejects_checkpoint_only_features(
    monkeypatch, v41_dummy_candidate, field, value, message
):
    config = v41_dummy_candidate()
    setattr(config.model_config.hf_text_config, field, value)
    before = deepcopy(config)
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")

    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)

    assert config == before


@pytest.mark.parametrize(
    "additional_config,layered_gmm,message",
    [
        ({"afd": {"async": True}}, False, "async"),
        ({"sparse_kv_offload_config": {"enabled": True}}, False, "sparse KV offload"),
        ({"enable_shared_expert_dp": True}, False, "uniform native TP"),
        (
            {"finegrained_tp_config": {"mlp_tensor_parallel_size": 2}},
            False,
            "uniform native TP",
        ),
        ({}, True, "Async CAM layered GMM off"),
    ],
)
def test_v41_dummy_qualification_rejects_unqualified_runtime_flags(
    monkeypatch, v41_dummy_candidate, additional_config, layered_gmm, message
):
    config = v41_dummy_candidate()
    for key, value in additional_config.items():
        if key == "afd":
            config.additional_config[key].update(value)
        else:
            config.additional_config[key] = value
    monkeypatch.setenv("AFD_DSV41_DUMMY_QUALIFICATION", "1")
    monkeypatch.setenv("AFD_ASYNC_CAM_LAYERED_GMM", "1" if layered_gmm else "0")

    with pytest.raises(ValueError, match=message):
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize(
    "model_type,architecture",
    [
        ("deepseek_v4", None),
        ("custom", "DeepseekV4ForCausalLM"),
        ("custom", "AFDDeepseekV4ForCausalLM"),
    ],
)
def test_npu_validation_rejects_v4_without_token_id_transport(model_type, architecture):
    config = _vllm_config(connector="P2pNcclAFDConnector")
    config.model_config.hf_config.model_type = model_type
    config.model_config.hf_config.architectures = (
        [architecture] if architecture else None
    )
    with pytest.raises(RuntimeError, match="DSV4 NPU AFD supports only"):
        fail_if_unsupported_npu_afd_features(config)


def _config_with(*, model=None, max_num_batched_tokens=None, **kwargs):
    config = _vllm_config(**kwargs)
    for name, value in (model or {}).items():
        setattr(config.model_config, name, value)
    if max_num_batched_tokens is not None:
        config.scheduler_config.max_num_batched_tokens = max_num_batched_tokens
    return config


def _mla_dbo(cudagraph_mode, **model_fields):
    return _config_with(
        use_mla=True,
        cudagraph_mode=cudagraph_mode,
        model={
            "hf_text_config": SimpleNamespace(model_type="deepseek_v2", **model_fields)
        },
        **TWO_UBATCH_DBO,
    )


@pytest.mark.parametrize(
    ("config", "error"),
    [
        pytest.param(_config_with(model={"enforce_eager": False}), None, id="graph"),
        pytest.param(_config_with(**TWO_UBATCH_DBO), None, id="two-ubatches"),
        pytest.param(
            _config_with(**{**TWO_UBATCH_DBO, "num_ubatches": 4}),
            "exactly two ubatches",
            id="four-ubatches",
        ),
        pytest.param(
            _config_with(extra_config={"compute_gate_on_attention": True}),
            "compute_gate_on_attention",
            id="gate-on-attention",
        ),
        pytest.param(
            _config_with(extra_config={"quant_mode": 1}), "quant_mode=0", id="quant"
        ),
        pytest.param(
            _config_with(connector="P2pNcclAFDConnector", extra_config={"core_num": 8}),
            "does not support connector_extra_config",
            id="connector-extra-parser",
        ),
        pytest.param(_mla_dbo("FULL"), "FULL_DECODE_ONLY", id="mla-full"),
        pytest.param(
            _mla_dbo("FULL_AND_PIECEWISE"), "FULL_DECODE_ONLY", id="mla-mixed"
        ),
        pytest.param(_mla_dbo("FULL_DECODE_ONLY"), None, id="mla-decode"),
        pytest.param(_mla_dbo("FULL", index_topk=8), None, id="sparse"),
        # Compressor models select the DSA backend, whose graph-params update is
        # a no-op, so the MLA DBO graph rules do not apply.
        pytest.param(
            _mla_dbo("FULL", index_topk=512, compress_ratios=[0, 4, 128]),
            None,
            id="compressor",
        ),
        pytest.param(
            _config_with(
                use_mla=True,
                cudagraph_mode="FULL_DECODE_ONLY",
                speculative_config=object(),
                **TWO_UBATCH_DBO,
            ),
            "does not support speculative decoding",
            id="mla-draft",
        ),
        pytest.param(
            _config_with(**{**ASYNC_CAM, "async_dp": False}),
            "async=true",
            id="async-off",
        ),
        pytest.param(
            _config_with(model={"enforce_eager": False}, **ASYNC_CAM),
            "only eager",
            id="async-graph",
        ),
        pytest.param(
            _config_with(use_ubatching=True, **ASYNC_CAM),
            "DBO requires exactly two ubatches",
            id="async-native-ubatching",
        ),
        pytest.param(
            _config_with(enable_dbo=True, **ASYNC_CAM),
            "DBO requires exactly two ubatches",
            id="async-native-dbo",
        ),
        *(
            pytest.param(
                _config_with(
                    use_mla=True, extra_config={"dynamicQuant": value}, **ASYNC_CAM
                ),
                error,
                id=f"async-dynamic-quant-{value}",
            )
            for value, error in ((0, None), ("1", None), (2, "dynamicQuant"))
        ),
        pytest.param(
            _config_with(
                compute_gate_on_attention=True,
                use_v2_model_runner=True,
                use_mla=True,
                tensor_parallel_size=2,
                num_attention_ranks=2,
                extra_config={"attn_ranks_per_dp": 2},
                max_num_batched_tokens=5,
                **ASYNC_CAM,
            ),
            "divisible by attn_ranks_per_dp",
            id="async-mrv2-fractional-tp-capacity",
        ),
        pytest.param(_async_moe_config(), None, id="moe-request-tp1"),
        pytest.param(
            _async_moe_config(tensor_parallel_size=2, num_attention_ranks=2),
            None,
            id="moe-token-attention-tp2",
        ),
        pytest.param(
            _async_moe_config(role="ffn"),
            None,
            id="moe-token-ffn-tp1",
        ),
        pytest.param(
            _async_moe_config(compute_gate_on_attention=False),
            "compute_gate_on_attention",
            id="moe-missing-attention-gate",
        ),
        pytest.param(
            _async_moe_config(num_ubatches=3),
            "exactly two",
            id="moe-three-stages",
        ),
        pytest.param(
            _async_moe_config(decode_context_parallel_size=2),
            "CP",
            id="moe-decode-context-parallel",
        ),
        pytest.param(
            _async_moe_config(prefill_context_parallel_size=2),
            "CP",
            id="moe-prefill-context-parallel",
        ),
        pytest.param(
            _async_moe_config(tensor_parallel_size=2, attn_ranks_per_dp=1),
            "attn_ranks_per_dp",
            id="moe-attention-cam-tp-mismatch",
        ),
    ],
)
@pytest.mark.usefixtures("vllm_connector_runtime")
def test_npu_feature_validation(config, error):
    with (
        pytest.raises((RuntimeError, ValueError), match=error)
        if error
        else nullcontext()
    ):
        fail_if_unsupported_npu_afd_features(config)


def test_npu_afd_num_ubatches_reads_two_ubatch_dbo():
    assert npu_afd_num_ubatches(_vllm_config(**TWO_UBATCH_DBO)) == 2


@pytest.mark.parametrize("role", ["attention", "ffn"])
@pytest.mark.parametrize(
    ("factor", "max_num_batched_tokens", "rejected"),
    [
        ("0.015625", 8192, True),
        ("0.015625", 4096, False),
        ("0.5", 8192, False),
        (None, 262144, False),
        ("0", 16, True),
        ("nan", 16, True),
        ("invalid", 16, True),
        ("0.01_5625", 4096, True),
    ],
)
@pytest.mark.usefixtures("vllm_connector_runtime")
def test_npu_async_feature_validation_checks_receive_capacity(
    monkeypatch,
    role,
    factor,
    max_num_batched_tokens,
    rejected,
):
    if factor is None:
        monkeypatch.delenv("BATCH_SIZE_FACTOR", raising=False)
    else:
        monkeypatch.setenv("BATCH_SIZE_FACTOR", factor)
    config = _vllm_config(
        role=role,
        connector="CAMAsyncAFDConnector",
        async_dp=True,
        use_mla=True,
        use_v2_model_runner=True,
        num_attention_ranks=2,
        tensor_parallel_size=2 if role == "attention" else 1,
        extra_config={"attn_ranks_per_dp": 2},
    )
    config.scheduler_config.max_num_batched_tokens = max_num_batched_tokens
    if rejected:
        with pytest.raises(RuntimeError, match="BATCH_SIZE_FACTOR"):
            fail_if_unsupported_npu_afd_features(config)
    else:
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize(
    "extra_config,additional_config,model_type,use_mla,error",
    [
        (
            {},
            {"enable_shared_expert_dp": True},
            "deepseek_v2",
            True,
            "shared-expert DP",
        ),
        *[
            (
                {},
                {"finegrained_tp_config": {key: 2}},
                "deepseek_v2",
                True,
                "finegrained TP",
            )
            for key in (
                "oproj_tensor_parallel_size",
                "mlp_tensor_parallel_size",
                "embedding_tensor_parallel_size",
                "lmhead_tensor_parallel_size",
            )
        ],
        ({}, {}, "qwen3_moe", True, "DeepSeek-V2/V3 MLA"),
        ({}, {}, "deepseek_v2", False, "DeepSeek-V2/V3 MLA"),
    ],
)
@pytest.mark.usefixtures("vllm_connector_runtime")
def test_npu_async_mrv2_feature_boundaries(
    extra_config, additional_config, model_type, use_mla, error
):
    config = _vllm_config(
        connector="CAMAsyncAFDConnector",
        async_dp=True,
        compute_gate_on_attention=True,
        use_v2_model_runner=True,
        use_mla=use_mla,
        extra_config=extra_config,
    )
    config.additional_config.update(additional_config)
    config.model_config.hf_text_config.model_type = model_type
    with pytest.raises(RuntimeError, match=error):
        fail_if_unsupported_npu_afd_features(config)


@pytest.mark.parametrize(
    "model_type,use_mla",
    [("deepseek_v2", True), ("deepseek_v3", True), ("deepseek_v4", False)],
)
@pytest.mark.parametrize("tp_size,use_sp", [(1, False), (2, False), (2, True)])
@pytest.mark.parametrize("local_ubatching", [False, True])
@pytest.mark.usefixtures("vllm_connector_runtime")
def test_npu_async_mrv2_features_allow_model_layouts(
    model_type, use_mla, tp_size, use_sp, local_ubatching
):
    config = _vllm_config(
        connector="CAMAsyncAFDConnector",
        async_dp=True,
        compute_gate_on_attention=True,
        use_v2_model_runner=True,
        use_mla=use_mla,
        tensor_parallel_size=tp_size,
        use_sequence_parallel_moe=use_sp,
        use_ubatching=local_ubatching,
        num_ubatches=2,
        num_attention_ranks=2 * tp_size,
        data_parallel_size=2,
        extra_config={
            "attn_ranks_per_dp": tp_size,
            "dynamicQuant": 1,
        },
    )
    config.model_config.hf_text_config.model_type = model_type
    config.additional_config["enable_flashcomm1"] = use_sp
    fail_if_unsupported_npu_afd_features(config)
