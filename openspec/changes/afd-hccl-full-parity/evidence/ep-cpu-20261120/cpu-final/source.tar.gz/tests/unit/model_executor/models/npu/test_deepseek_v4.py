# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Old V4 role payloads on CPU; no native model/device acceptance."""

from types import SimpleNamespace

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")
pytest.importorskip("vllm_ascend")

from vllm.forward_context import override_forward_context  # noqa: E402

from afd_plugin.connectors import AFDForwardContextMetadata  # noqa: E402
from afd_plugin.model_executor.models import deepseek_v2  # noqa: E402
from afd_plugin.model_executor.models.npu import deepseek_v4 as adapter  # noqa: E402
from tests.unit.fakes.deepseek_v4 import (  # noqa: E402
    ROUTER_DELTA_SCALE,
    TARGET_HC_MULT,
    TARGET_HIDDEN_SIZE,
    TARGET_LAYERS,
    TARGET_TOKEN_CAPACITY,
    RoleBoundaryPeer,
    RoutingMoE,
    ffn_layer,
    make_target_buffer_case,
)


@pytest.fixture
def role_peer(monkeypatch):
    monkeypatch.setattr(adapter.native, "DeepseekV4MoE", RoutingMoE)
    peer = RoleBoundaryPeer(ffn_layer(adapter.AFDDeepseekV4DecoderLayer))
    metadata = AFDForwardContextMetadata(
        tokens_start_loc=[0],
        requests_start_loc=[0],
        stage_idx=0,
        connector=peer,
        tokens_lens=[2],
        num_stages=1,
    )
    monkeypatch.setattr(
        deepseek_v2, "get_afd_metadata_from_forward_context", lambda: metadata
    )
    monkeypatch.setattr(
        deepseek_v2, "maybe_apply_dbo_yield", lambda tensor, *, role: tensor
    )
    return peer


@pytest.mark.parametrize("explicit_ids", [False, True])
@pytest.mark.parametrize("independent_router_input", [False, True])
def test_role_roundtrip_preserves_router_precision_and_raw_token_ids(
    role_peer, explicit_ids, independent_router_input
):
    hidden = torch.ones(2, 4, dtype=torch.bfloat16)
    fp32 = hidden.float() + 0.00031 if independent_router_input else None
    ids = torch.tensor([7, -1], dtype=torch.int32)
    original_ids = ids.clone()
    context = SimpleNamespace(input_ids=ids, ubatch_idx=0)
    proxy = adapter.AFDDeepseekV4RemoteMoE(layer_idx=3)

    with override_forward_context(context):
        output = proxy(
            hidden,
            input_ids=ids if explicit_ids else None,
            hidden_states_fp32=fp32,
        )

    delta = 0 if fp32 is None else (fp32 - hidden.float()) * ROUTER_DELTA_SCALE
    torch.testing.assert_close(output, (delta + ids[:, None]).bfloat16().expand(2, 4))
    payload = role_peer.payloads[0]
    assert payload.context.metadata.layer_idx == 3
    assert payload.context.metadata.seq_lens == [2]
    assert payload.input_ids.dtype == torch.int64
    torch.testing.assert_close(payload.input_ids, ids.to(torch.int64))
    torch.testing.assert_close(ids, original_ids)
    if fp32 is None:
        assert payload.hidden_states_fp32 is None
    else:
        torch.testing.assert_close(payload.hidden_states_fp32, fp32)
        assert not torch.equal(payload.hidden_states_fp32, hidden.float())


@pytest.mark.parametrize("consumer", ["draft", "eagle"])
def test_target_native_forward_populates_stable_pre_hc_storage(monkeypatch, consumer):
    case = make_target_buffer_case(monkeypatch, adapter, consumer=consumer)
    buffer = case.wrapper.get_mtp_target_hidden_states()
    assert buffer is not None
    assert buffer.shape == (TARGET_TOKEN_CAPACITY, TARGET_HC_MULT * TARGET_HIDDEN_SIZE)
    assert buffer.dtype == case.config.model_config.dtype
    assert buffer.device.type == "cpu"
    buffer.fill_(-1)
    for rows in (3, 1):
        inputs = torch.arange(rows * TARGET_HIDDEN_SIZE, dtype=buffer.dtype).view(
            rows, TARGET_HIDDEN_SIZE
        )
        output = case.model(
            torch.arange(rows), torch.arange(rows), None, inputs_embeds=inputs
        )
        expected = (inputs + TARGET_LAYERS)[:, None].expand(-1, TARGET_HC_MULT, -1)
        torch.testing.assert_close(buffer[:rows], expected.flatten(1))
        torch.testing.assert_close(
            output,
            (
                expected.sum(dim=1).float()
                * (0.5 + case.config.model_config.hf_config.hc_eps)
            ).to(buffer.dtype),
        )
        assert case.wrapper.get_mtp_target_hidden_states() is buffer
    assert torch.all(buffer[3:] == -1)


@pytest.mark.parametrize(
    ("consumer", "last_rank", "role"),
    [
        (None, True, "attention"),
        ("unused", True, "attention"),
        ("draft", False, "attention"),
        ("draft", True, "ffn"),
    ],
)
def test_target_without_owned_speculation_has_no_public_hidden_buffer(
    monkeypatch, consumer, last_rank, role
):
    case = make_target_buffer_case(
        monkeypatch, adapter, consumer=consumer, last_rank=last_rank, role=role
    )
    assert case.wrapper.get_mtp_target_hidden_states() is None
