#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Audit caller-bounded HCCL startup logs and optional eager U2 host events.

This stdlib-only command reads files; it never starts a service or imports an
inference runtime. The run manifest names one prepared recipe and one separate
record file per rank, with raw SHA256 identities. Record files are JSON arrays
or native logs containing the two existing AFD HCCL record prefixes.

Optional expected_transactions validates live eager/U2 ticket milestones and
serial U1 fallback body boundaries within the same configured U2 session.
Optional expected_graph_transactions validates Graph parent host-control logs;
neither option certifies device execution or completion.
Runtime records have no run ID: the caller owns their attribution to this run.

Manifest schema_version=1: run_id, recipe={path,sha256}, ranks=[{role,
role_rank,log_path,sha256,format}], optional device_namespace (role_visible or
all_visible with visible_devices), optional expected_transactions=[{
transaction_id,phase:"eager",num_stages:1|2,layer_indices,active_stages}].
Relative paths are resolved against the manifest directory.
"""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import TypeAlias

JSONValue: TypeAlias = (
    None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]
)
Record: TypeAlias = dict[str, str | int | bool]
OVERLAP_NAMES = (
    "AFD_HCCL_EAGER_U2_STREAM_OVERLAP",
    "AFD_HCCL_GRAPH_U2_COMPUTE_OVERLAP",
    "AFD_HCCL_GRAPH_U2_HYBRID_DAG",
    "AFD_HCCL_GRAPH_U2_ATTENTION_THREE_STREAM",
    "AFD_HCCL_GRAPH_U2_FFN_RECV_STREAM",
    "AFD_HCCL_GRAPH_U2_FFN_CROSS_LAYER",
    "AFD_HCCL_STAGE_DIAGNOSTICS",
    "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS",
)
ROLES = ("attention", "ffn")
STARTUP_PREFIX = "AFD HCCL session configuration: "
STAGE_PREFIX = "AFD HCCL stage diagnostic: "
STAGED_CAPACITY = 2
LEGACY_PROTOCOL_VERSION = 2
EVENT_PAIRS = (
    ("recv_begin", "recv_returned"),
    ("compute_begin", "compute_returned"),
    ("send_begin", "send_returned"),
    ("layer_send_wait_begin", "layer_send_wait_returned"),
    ("final_send_wait_begin", "final_send_wait_returned"),
    ("send_post_begin", "send_post_returned"),
    ("recv_post_begin", "recv_post_returned"),
    ("loan_wait_begin", "loan_wait_returned"),
    ("stage_reuse_wait_begin", "stage_reuse_wait_returned"),
    ("parent_finish_begin", "parent_finish_returned"),
    ("prepare_begin", "prepare_returned"),
    ("continuation_begin", "continuation_returned"),
    ("collapse_begin", "collapse_returned"),
)
TICKET_EVENTS = (
    "send_post_begin",
    "send_post_returned",
    "recv_post_begin",
    "recv_post_returned",
    "loan_wait_begin",
    "loan_wait_returned",
    "stage_reuse_wait_begin",
    "stage_reuse_wait_returned",
)
ALIAS_NAMES = (
    "actual.compute_send_alias",
    "actual.compute_recv_alias",
    "actual.send_recv_alias",
)


class AuditError(ValueError):
    """An invalid input or a failed observable log contract."""

    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code


def require(condition: bool, code: str, message: str) -> None:
    if not condition:
        raise AuditError(code, message)


def mapping(value: JSONValue, name: str) -> dict[str, JSONValue]:
    require(type(value) is dict, "schema", f"{name} must be an object")
    return value


def sequence(value: JSONValue, name: str) -> list[JSONValue]:
    require(type(value) is list, "schema", f"{name} must be an array")
    return value


def text(value: JSONValue, name: str) -> str:
    require(
        type(value) is str
        and bool(value.strip())
        and not any(char in value for char in ("\0", "\n", "\r")),
        "schema",
        f"{name} must be nonempty text without control characters",
    )
    return value


def integer(value: JSONValue, name: str, *, minimum: int = 0) -> int:
    require(
        type(value) is int and value >= minimum,
        "schema",
        f"{name} must be an integer >= {minimum}",
    )
    return value


def integer_list(value: JSONValue, name: str) -> list[int]:
    values = [integer(item, name) for item in sequence(value, name)]
    require(len(values) == len(set(values)), "schema", f"{name} contains duplicates")
    return values


def exact(actual: JSONValue, expected: JSONValue, name: str) -> None:
    require(
        type(actual) is type(expected) and actual == expected,
        "mismatch",
        f"{name}: expected {expected!r}, observed {actual!r}",
    )


def unique_json(pairs: list[tuple[str, JSONValue]]) -> dict[str, JSONValue]:
    result = {}
    for key, value in pairs:
        require(key not in result, "schema", f"duplicate JSON key: {key}")
        result[key] = value
    return result


def reject_constant(value: str) -> None:
    raise AuditError("schema", f"non-JSON numeric constant: {value}")


def json_value(data: bytes, name: str) -> JSONValue:
    try:
        return json.loads(
            data, object_pairs_hook=unique_json, parse_constant=reject_constant
        )
    except (json.JSONDecodeError, UnicodeError) as exc:
        raise AuditError("parse", f"{name}: {exc}") from exc


def resolve_path(value: JSONValue, base: Path, name: str) -> Path:
    path = Path(text(value, name))
    return (path if path.is_absolute() else base / path).resolve()


def digest(value: JSONValue, name: str) -> str:
    value = text(value, name)
    require(
        re.fullmatch(r"[0-9a-fA-F]{64}", value) is not None,
        "schema",
        f"{name} must be a SHA256 hex digest",
    )
    return value.lower()


def protect_output(output: Path, inputs: list[Path]) -> None:
    for path in inputs:
        require(
            output != path
            and not (output.exists() and path.exists() and output.samefile(path)),
            "output_collision",
            f"output must not overwrite input or tool: {path}",
        )


def checked_bytes(
    path: Path, expected: JSONValue, identities: list[dict[str, JSONValue]]
) -> bytes:
    expected = digest(expected, str(path))
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    identities.append(
        {"path": str(path), "sha256": actual, "expected_sha256": expected}
    )
    exact(actual, expected, f"raw SHA256 for {path}")
    return data


def configured(record: Record, expected: dict[str, bool], name: str) -> None:
    keys = {key for key in record if key.startswith("configured.")}
    exact(keys, {f"configured.{key}" for key in OVERLAP_NAMES}, name)
    for key, value in expected.items():
        exact(record[f"configured.{key}"], value, f"{name}/{key}")


def record_value(value: JSONValue, name: str) -> Record:
    record = mapping(value, name)
    require(
        all(type(key) is str for key in record)
        and all(type(item) in (str, int, bool) for item in record.values()),
        "record_schema",
        f"{name} must contain flat string/integer/bool fields",
    )
    text(record.get("event"), f"{name}.event")
    return record


def read_records(data: bytes, format_name: str, name: str) -> list[Record]:
    if format_name == "json":
        return [
            record_value(item, f"{name}[{index}]")
            for index, item in enumerate(sequence(json_value(data, name), name))
        ]
    exact(format_name, "log", f"{name}.format")
    records = []
    # Native logging may color its prefix; color codes are not record data.
    for index, line in enumerate(data.decode("utf-8").splitlines(), start=1):
        line = re.sub(r"\x1b\[[0-9;]*m", "", line)
        for prefix in (STARTUP_PREFIX, STAGE_PREFIX):
            if prefix not in line:
                continue
            raw = line.split(prefix, 1)[1].strip()
            try:
                syntax = ast.parse(raw, mode="eval")
                require(
                    isinstance(syntax.body, ast.Dict),
                    "record_schema",
                    f"{name}:{index}: native record must be a dict literal",
                )
                keys = [ast.literal_eval(key) for key in syntax.body.keys]
                require(
                    all(type(key) is str for key in keys)
                    and len(keys) == len(set(keys)),
                    "record_schema",
                    f"{name}:{index}: duplicate or non-string native record key",
                )
                record = record_value(ast.literal_eval(syntax), f"{name}:{index}")
            except (SyntaxError, ValueError, TypeError) as exc:
                if isinstance(exc, AuditError):
                    raise
                raise AuditError("parse", f"{name}:{index}: invalid record") from exc
            exact(
                record["event"] == "session_configuration",
                prefix == STARTUP_PREFIX,
                f"{name}:{index}: native prefix/event",
            )
            records.append(record)
            break
    return records


def validate_recipe(recipe: dict[str, JSONValue]) -> dict[str, JSONValue]:
    exact(recipe.get("schema_version"), 1, "recipe.schema_version")
    exact(recipe.get("preparation_success"), True, "recipe.preparation_success")
    for key in (
        "runtime_admission_checked",
        "execution_performed",
        "npu_execution_performed",
        "full_model_qualification",
    ):
        exact(recipe.get(key), False, f"prepared recipe/{key}")
    plan = mapping(recipe.get("plan"), "recipe.plan")
    exact(plan.get("plan_validation_success"), True, "plan.plan_validation_success")
    request = mapping(plan.get("request"), "recipe.plan.request")
    mode = request.get("mode")
    require(mode in ("eager", "full-decode-only"), "schema", "unsupported recipe mode")
    stages = integer(request.get("num_stages"), "num_stages", minimum=1)
    require(stages in (1, 2), "schema", "only U1/U2 recipes are supported")
    tp = integer(request.get("native_tp_size"), "native_tp_size", minimum=1)
    capacity = integer(
        request.get("max_num_batched_tokens"), "max_num_batched_tokens", minimum=1
    )
    exact(request.get("num_speculative_tokens"), 0, "num_speculative_tokens")
    host = text(request.get("attention_host_id"), "attention_host_id")
    exact(request.get("ffn_host_id"), host, "same-host recipe")
    frozen = mapping(recipe.get("frozen_environment"), "frozen_environment")
    exact(set(frozen), set(OVERLAP_NAMES), "eight frozen setting names")
    for key, value in frozen.items():
        require(type(value) is str and value in ("0", "1"), "schema", key)
    exact(
        hashlib.sha256(
            json.dumps(frozen, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
        digest(recipe.get("frozen_environment_sha256"), "frozen_environment_sha256"),
        "frozen environment SHA256",
    )
    settings = {key: value == "1" for key, value in frozen.items()}
    plan_configured = mapping(
        mapping(plan.get("overlap"), "plan.overlap").get("configured"),
        "plan.overlap.configured",
    )
    exact(set(plan_configured), set(OVERLAP_NAMES), "planner setting names")
    for key, value in settings.items():
        exact(plan_configured[key], value, f"planner configured/{key}")
    if stages == 1:
        exact(settings[OVERLAP_NAMES[0]], False, "U1 eager setting")
    require(
        not settings[OVERLAP_NAMES[5]] or settings[OVERLAP_NAMES[4]],
        "schema",
        "FFN cross-layer requires FFN recv stream setting",
    )
    roles = mapping(recipe.get("roles"), "recipe.roles")
    exact(set(roles), set(ROLES), "recipe role names")
    selected_devices = []
    for role in ROLES:
        entry = mapping(roles[role], f"roles.{role}")
        devices = integer_list(entry.get("devices"), f"{role}.devices")
        exact(len(devices), tp, f"{role} single native TP world")
        exact(request.get(f"{role}_devices"), devices, f"{role} request devices")
        exact(entry.get("host_id"), host, f"{role}.host_id")
        environment = mapping(entry.get("environment"), f"{role}.environment")
        for key, value in frozen.items():
            exact(environment.get(key), value, f"{role}.environment/{key}")
        exact(
            environment.get("ASCEND_RT_VISIBLE_DEVICES"),
            ",".join(map(str, devices)),
            f"{role} visible device overlay",
        )
        ranks = sequence(entry.get("rank_mapping"), f"{role}.rank_mapping")
        exact(len(ranks), tp, f"{role}.rank_mapping count")
        for rank, item in enumerate(ranks):
            item = mapping(item, f"{role}.rank_mapping[{rank}]")
            for key, expected in (
                ("role", role),
                ("role_rank", rank),
                ("native_tp_rank", rank),
                ("native_tp_group_index", 0),
                ("device_id", devices[rank]),
                ("world_rank", rank + (tp if role == "attention" else 0)),
            ):
                exact(item.get(key), expected, f"{role} rank {rank}/{key}")
        selected_devices.extend(devices)
    exact(len(selected_devices), len(set(selected_devices)), "disjoint role devices")
    identity = mapping(recipe.get("source_identity"), "recipe.source_identity")
    files = mapping(identity.get("files"), "recipe source files")
    require(bool(files), "schema", "recipe source file identities must be nonempty")
    for path, sha in files.items():
        text(path, "recipe source path")
        digest(sha, f"recipe source/{path}")
    mapping(identity.get("contracts"), "recipe source contracts")
    return {
        "mode": mode,
        "num_stages": stages,
        "tp": tp,
        "capacity": capacity,
        "settings": settings,
        "roles": roles,
        "legacy": mode == "eager" and stages == 1,
    }


def validate_startup(
    records: list[Record],
    role: str,
    rank: int,
    local_device: int,
    recipe: dict[str, JSONValue],
) -> Record:
    name = f"{role}/{rank}"
    startups = [
        record for record in records if record["event"] == "session_configuration"
    ]
    exact(len(startups), 1, f"{name}: exactly one startup configuration")
    startup = startups[0]
    for key, value in (
        ("phase", "startup"),
        ("role", role),
        ("role_rank", rank),
        ("local_device", local_device),
        ("snapshot_present", True),
        ("negotiated.native_tp_size", recipe["tp"]),
        ("negotiated.max_tokens", recipe["capacity"]),
    ):
        exact(startup.get(key), value, f"{name}/{key}")
    configured(startup, recipe["settings"], f"{name} startup settings")
    if recipe["legacy"]:
        expected = {
            "protocol": "legacy_pair",
            "protocol_version": LEGACY_PROTOCOL_VERSION,
            "world_size": 2,
            "world_rank": int(role == "attention"),
            "pair_index": rank,
            "attention_size": recipe["tp"],
            "ffn_size": recipe["tp"],
        }
        require(
            not any(
                key in startup
                for key in (
                    "negotiated.graph_execution_version",
                    "negotiated.eager_pipeline_version",
                    "negotiated.max_stages",
                    "negotiated.attention_size",
                    "negotiated.ffn_size",
                )
            ),
            "mismatch",
            f"{name}: legacy record contains staged capability claims",
        )
    else:
        expected = {
            "world_rank": rank + (recipe["tp"] if role == "attention" else 0),
            "negotiated.graph_execution_version": int(
                recipe["mode"] == "full-decode-only"
            ),
            "negotiated.eager_pipeline_version": int(
                recipe["mode"] == "eager" and recipe["settings"][OVERLAP_NAMES[0]]
            ),
            "negotiated.attention_size": recipe["tp"],
            "negotiated.ffn_size": recipe["tp"],
            "negotiated.max_stages": STAGED_CAPACITY,
        }
        require("protocol" not in startup, "mismatch", f"{name}: legacy/staged mix")
    for key, value in expected.items():
        exact(startup.get(key), value, f"{name}/{key}")
    require(
        not any(
            key.startswith(("actual.", "effective.", "logical.", "physical."))
            for key in startup
        ),
        "record_schema",
        f"{name}: startup must not contain execution claims",
    )
    exact(records[0], startup, f"{name}: startup must precede stage records")
    return startup


def expected_transactions(
    manifest: dict[str, JSONValue], recipe: dict[str, JSONValue]
) -> list[dict[str, JSONValue]]:
    if "expected_transactions" not in manifest:
        return []
    expected = sequence(manifest["expected_transactions"], "expected_transactions")
    require(
        bool(expected), "schema", "expected_transactions must be nonempty if supplied"
    )
    require(
        recipe["mode"] == "eager"
        and recipe["num_stages"] == 2
        and recipe["tp"] in (1, 2)
        and recipe["settings"][OVERLAP_NAMES[0]]
        and recipe["settings"][OVERLAP_NAMES[6]],
        "actual_scope",
        "actual checks require live eager/U2 tickets, paired TP1/2 "
        "and stage diagnostics=1",
    )
    transactions = []
    for index, value in enumerate(expected):
        item = mapping(value, f"expected_transactions[{index}]")
        exact(
            set(item),
            {"transaction_id", "phase", "num_stages", "layer_indices", "active_stages"},
            "expected transaction fields",
        )
        transactions.append(text(item.get("transaction_id"), "transaction_id"))
        exact(item.get("phase"), "eager", "expected transaction phase")
        count = integer(item.get("num_stages"), "num_stages", minimum=1)
        require(count in (1, 2), "schema", "expected eager parent must be U1/U2")
        layers = integer_list(item.get("layer_indices"), "layer_indices")
        require(
            bool(layers) and layers == sorted(layers),
            "schema",
            "ordered layers required",
        )
        stages = integer_list(item.get("active_stages"), "active_stages")
        require(
            stages == sorted(stages) and all(stage < count for stage in stages),
            "schema",
            "active_stages must be an ordered subset of the parent stages",
        )
        if count == 1:
            exact(stages, [0], "serial fallback requires its nonempty stage 0")
    exact(len(transactions), len(set(transactions)), "unique expected transactions")
    return expected


def actual_fields(
    record: Record, name: str, *, num_stages: int = 2, compute_sync: bool = False
) -> dict[str, str | int | bool]:
    serial = num_stages == 1
    sync_event = record["event"] in ("compute_sync_begin", "compute_sync_complete")
    for key, value in (
        ("actual.mode", "serial" if serial else "eager-streamed"),
        ("actual.ffn_compute_sync", compute_sync),
        ("in_profile_run", False),
        ("is_warmup", False),
        ("boundary", "explicit_synchronize" if sync_event else "host_enqueue"),
        ("phase", "eager"),
        ("num_stages", num_stages),
    ):
        exact(record.get(key), value, f"{name}/{key}")
    allowed_actual = {
        "actual.mode",
        "actual.ffn_compute_sync",
        "actual.compute_pipeline_enabled",
        "actual.compute_stream",
        "actual.send_stream",
        "actual.recv_stream",
    } | (set() if serial else set(ALIAS_NAMES))
    exact(
        {key for key in record if key.startswith("actual.")},
        allowed_actual,
        f"{name}: actual field names",
    )
    stream_keys = ("actual.compute_stream", "actual.send_stream", "actual.recv_stream")
    labels = tuple(record.get(key) for key in stream_keys)
    if serial:
        exact(labels, ("parent",) * 3, f"{name}: serial parent streams")
        exact(
            record.get("actual.compute_pipeline_enabled"),
            False,
            f"{name}: serial has no compute pipeline",
        )
        return {
            key: value for key, value in record.items() if key.startswith("actual.")
        }
    for label, side in zip(labels, ("compute", "send", "recv"), strict=True):
        require(
            label in ("parent", side), "record_schema", f"{name}: invalid stream label"
        )
    aliases = tuple(record.get(key) for key in ALIAS_NAMES)
    require(
        all(type(value) is bool for value in aliases),
        "record_schema",
        f"{name}: aliases",
    )
    for alias, (left, right) in zip(aliases, ((0, 1), (0, 2), (1, 2)), strict=True):
        if labels[left] == "parent" or labels[right] == "parent":
            exact(alias, labels[left] == labels[right], f"{name}: parent stream alias")
    require(
        sum(aliases) != 2, "record_schema", f"{name}: non-transitive stream aliases"
    )
    exact(
        record.get("actual.compute_pipeline_enabled"),
        labels[0] != "parent",
        f"{name}: actual compute pipeline flag",
    )
    return {key: value for key, value in record.items() if key.startswith("actual.")}


def expected_graph_transactions(
    manifest: dict[str, JSONValue], recipe: dict[str, JSONValue]
) -> list[dict[str, JSONValue]]:
    if "expected_graph_transactions" not in manifest:
        return []
    require(
        "expected_transactions" not in manifest,
        "schema",
        "Graph and eager expected inventories must be supplied separately",
    )
    require(
        recipe["mode"] == "full-decode-only" and recipe["settings"][OVERLAP_NAMES[6]],
        "actual_scope",
        "Graph host checks require full-decode-only and stage diagnostics=1",
    )
    expected = sequence(
        manifest["expected_graph_transactions"], "expected_graph_transactions"
    )
    require(bool(expected), "schema", "Graph expected inventory must be nonempty")
    transactions = []
    for index, value in enumerate(expected):
        item = mapping(value, f"expected_graph_transactions[{index}]")
        exact(
            set(item),
            {
                "transaction_id",
                "phase",
                "mode",
                "reason",
                "key_digest",
                "decision_digest",
                "num_stages",
                "finish_api",
            },
            "expected Graph transaction fields",
        )
        transactions.append(text(item["transaction_id"], "transaction_id"))
        phase = text(item["phase"], "Graph phase")
        require(
            phase in ("warmup", "capture", "replay", "eager"),
            "schema",
            "unsupported Graph host phase",
        )
        mode = text(item["mode"], "Graph mode")
        require(
            mode in ("target", "dummy", "warmup", "profile")
            and (mode != "profile" or phase == "eager"),
            "schema",
            "unsupported Graph host mode/phase",
        )
        text(item["reason"], "Graph reason")
        item["decision_digest"] = digest(
            item["decision_digest"], "Graph decision_digest"
        )
        if phase == "eager":
            exact(item["key_digest"], "", "keyless eager decision")
        else:
            item["key_digest"] = digest(item["key_digest"], "Graph key_digest")
        stages = integer(item["num_stages"], "Graph num_stages", minimum=1)
        require(stages <= recipe["num_stages"], "schema", "Graph stages exceed recipe")
        finish = mapping(item["finish_api"], "Graph finish_api")
        exact(set(finish), set(ROLES), "Graph finish_api roles")
        for role in ROLES:
            allowed = (
                (
                    ("native_eager_scope", "finish_forward")
                    if role == "attention"
                    else ("execute_hccl_v41_parent",)
                )
                if phase == "eager"
                else ("complete_graph_forward",)
            )
            require(finish[role] in allowed, "schema", f"{role} Graph finish_api")
    exact(len(transactions), len(set(transactions)), "unique Graph transactions")
    return expected


def validate_graph_parent(
    records: list[Record], expected: dict[str, JSONValue], startup: Record
) -> dict[str, JSONValue]:
    name = f"{startup['role']}/{startup['role_rank']}/{expected['transaction_id']}"
    phase, role = expected["phase"], startup["role"]
    finish_api = expected["finish_api"][role]
    boundaries = [("graph_parent_reserved", "graph_reservation", "returned")]
    if phase == "replay":
        replay_api = "run_fullgraph" if role == "attention" else "graph.replay"
        boundaries.extend(
            (event, replay_api, outcome)
            for event, outcome in (
                ("graph_parent_replay_begin", "begin"),
                ("graph_parent_replay_returned", "returned"),
            )
        )
    if finish_api in ("native_eager_scope", "execute_hccl_v41_parent"):
        boundaries.append(("graph_parent_scope_returned", finish_api, "returned"))
    else:
        boundaries.extend(
            (event, finish_api, outcome)
            for event, outcome in (
                ("graph_parent_finish_begin", "begin"),
                ("graph_parent_finish_returned", "returned"),
            )
        )
    exact(
        [record["event"] for record in records],
        [event for event, _, _ in boundaries],
        f"{name}: exact successful host boundary sequence",
    )
    settings = {key: startup[f"configured.{key}"] for key in OVERLAP_NAMES}
    for record, (event, api, outcome) in zip(records, boundaries, strict=True):
        exact(
            set(record),
            {
                "event",
                "role",
                "role_rank",
                "world_rank",
                "local_device",
                "transaction_id",
                "phase",
                "mode",
                "reason",
                "key_present",
                "key_digest",
                "decision_digest",
                "num_stages",
                "boundary",
                "boundary_api",
                "outcome",
                *(f"configured.{key}" for key in OVERLAP_NAMES),
            },
            f"{name}/{event}: Graph host record fields",
        )
        for key, value in (
            ("role", role),
            ("role_rank", startup["role_rank"]),
            ("world_rank", startup["world_rank"]),
            ("local_device", startup["local_device"]),
            ("transaction_id", expected["transaction_id"]),
            ("phase", phase),
            ("mode", expected["mode"]),
            ("reason", expected["reason"]),
            ("key_present", phase != "eager"),
            ("key_digest", expected["key_digest"]),
            ("decision_digest", expected["decision_digest"]),
            ("num_stages", expected["num_stages"]),
            ("boundary", "host_control"),
            ("boundary_api", api),
            ("outcome", outcome),
        ):
            exact(record.get(key), value, f"{name}/{event}/{key}")
        configured(record, settings, f"{name}/{event} settings")
    return {
        **expected,
        "event_count": len(records),
        "host_milestones_verified": True,
        "device_completion_verified": False,
        "tensor_stage_execution_verified": False,
    }


def validate_eager_configuration(config: Record, startup: Record, stages: int) -> None:
    """Keep session settings fixed while checking the real per-parent selection."""
    name = f"{startup['role']}/{startup['role_rank']}/{config['transaction_id']}"
    settings = {key: startup[f"configured.{key}"] for key in OVERLAP_NAMES}
    configured(config, settings, f"{name} configured settings")
    exact(
        {key for key in config if key.startswith("effective.")},
        {f"effective.{key}" for key in OVERLAP_NAMES},
        f"{name}: effective settings names",
    )
    sync = startup["role"] == "ffn" and stages == 1 and settings[OVERLAP_NAMES[-1]]
    for index, key in enumerate(OVERLAP_NAMES):
        effective = (
            settings[key] and stages > 1
            if index == 0
            else settings[key]
            if index == 6
            else sync
            if index == 7
            else False
        )
        exact(config[f"effective.{key}"], effective, f"{name}: effective/{key}")
    for prefix in ("logical", "physical"):
        exact(
            {key for key in config if key.startswith(prefix + ".")},
            {f"{prefix}.{side}_stream" for side in ("compute", "send", "recv")},
            f"{name}: {prefix} stream names",
        )
        for side in ("compute", "send", "recv"):
            exact(
                config[f"{prefix}.{side}_stream"],
                side if stages > 1 else "parent",
                f"{name}: {prefix} {side} stream",
            )
    exact(config.get("parent_transport_override"), False, f"{name}: parent override")


def validate_serial_parent(
    records: list[Record], expected: dict[str, JSONValue], startup: Record
) -> dict[str, JSONValue]:
    """Validate serial body returns without inventing ticket/parent completion."""
    transaction, layers = expected["transaction_id"], expected["layer_indices"]
    name = f"{startup['role']}/{startup['role_rank']}/{transaction}"
    exact(records[0].get("event"), "configuration", f"{name}: first event")
    validate_eager_configuration(records[0], startup, 1)
    sync = startup["role"] == "ffn" and startup[f"configured.{OVERLAP_NAMES[-1]}"]
    actual = actual_fields(records[0], name, num_stages=1, compute_sync=sync)
    common_fields = {
        "world_rank",
        "role_rank",
        "role",
        "phase",
        "num_stages",
        "in_profile_run",
        "is_warmup",
        "boundary",
        "transaction_id",
        "event",
        *actual,
    }
    configuration_fields = (
        common_fields
        | {
            key
            for key in records[0]
            if key.startswith(("configured.", "effective.", "logical.", "physical."))
        }
        | {"parent_transport_override"}
    )
    boundary_layers = sorted({layers[0], layers[-1]})
    observed = []
    for index, record in enumerate(records):
        for key in ("role", "role_rank", "world_rank"):
            exact(record.get(key), startup[key], f"{name}/{key}")
        exact(record.get("transaction_id"), transaction, f"{name}: transaction")
        exact(
            actual_fields(record, name, num_stages=1, compute_sync=sync),
            actual,
            f"{name}: stable serial execution",
        )
        exact(
            set(record),
            configuration_fields if index == 0 else common_fields | {"layer", "stage"},
            f"{name}: serial record fields",
        )
        if index == 0:
            continue
        layer = integer(record.get("layer"), f"{name}.layer")
        exact(record.get("stage"), 0, f"{name}: serial stage")
        require(layer in boundary_layers, "coordinates", f"{name}: boundary layer")
        observed.append((record["event"], layer, 0))
    wanted = []
    # Native A prepares its sole stage once, before the first boundary layer.
    if startup["role"] == "attention":
        wanted.extend(
            (event, layers[0], 0) for event in ("prepare_begin", "prepare_returned")
        )
    for layer in boundary_layers:
        stems = (
            ("compute", "send", "recv")
            if startup["role"] == "attention"
            else ("recv", "compute", "send")
        )
        for stem in stems:
            wanted.extend(
                (f"{stem}_{edge}", layer, 0) for edge in ("begin", "returned")
            )
            if stem == "compute" and sync:
                wanted.extend(
                    (event, layer, 0)
                    for event in ("compute_sync_begin", "compute_sync_complete")
                )
        if startup["role"] == "attention" and (
            startup["negotiated.native_tp_size"] == 1
            or any(
                event in ("continuation_begin", "continuation_returned")
                and observed_layer == layer
                for event, observed_layer, _ in observed
            )
        ):
            # A TP2 rank with no local rows still sends/receives the global
            # payload, but native _prepare_stage returns no continuation.
            # When present, both boundaries must follow that layer's receive.
            wanted.extend(
                (f"continuation_{edge}", layer, 0) for edge in ("begin", "returned")
            )
    if startup["role"] == "attention":
        wanted.extend(
            (event, layers[-1], 0) for event in ("collapse_begin", "collapse_returned")
        )
    exact(observed, wanted, f"{name}: ordered serial body boundaries")
    return {
        "transaction_id": transaction,
        "phase": "eager",
        "num_stages": 1,
        "layer_indices": layers,
        "active_stages": [0],
        "event_count": len(records),
        "actual_stream_fields": actual,
        "actual_serial_body_events_verified": True,
        "host_milestones_verified": True,
        "explicit_compute_sync_observed": sync,
        "parent_finish_observed": False,
        "parent_completion_verified": False,
        "device_completion_verified": False,
    }


def validate_parent(
    records: list[Record], expected: dict[str, JSONValue], startup: Record
) -> dict[str, JSONValue]:
    if expected["num_stages"] == 1:
        return validate_serial_parent(records, expected, startup)
    transaction = expected["transaction_id"]
    name = f"{startup['role']}/{startup['role_rank']}/{transaction}"
    exact(records[0].get("event"), "configuration", f"{name}: first event")
    exact(records[-1].get("event"), "parent_finish_returned", f"{name}: final event")
    exact(
        sum(record["event"] == "configuration" for record in records),
        1,
        f"{name}: parent configuration count",
    )
    config = records[0]
    validate_eager_configuration(config, startup, 2)
    actual = actual_fields(config, name)
    layers = expected["layer_indices"]
    boundary_layers = {layers[0], layers[-1]}
    active = expected["active_stages"]
    allowed_events = {event for pair in EVENT_PAIRS for event in pair}
    positions = {}
    for index, record in enumerate(records):
        for key in ("role", "role_rank", "world_rank"):
            exact(record.get(key), startup[key], f"{name}/{key}")
        exact(
            actual_fields(record, name), actual, f"{name}: stable actual stream fields"
        )
        if any(key.startswith("configured.") for key in record):
            configured(
                record,
                {key: startup[f"configured.{key}"] for key in OVERLAP_NAMES},
                f"{name} record settings",
            )
        if record["event"] == "configuration":
            require(
                "layer" not in record and "stage" not in record, "record_schema", name
            )
            continue
        event = record["event"]
        require(
            event in allowed_events,
            "record_schema",
            f"{name}: unsupported event {event}",
        )
        layer = integer(record.get("layer"), f"{name}.layer")
        stage = integer(record.get("stage"), f"{name}.stage")
        if event.startswith("parent_finish_"):
            exact((layer, stage), (layers[-1], 0), f"{name}: parent finish coordinates")
        else:
            require(
                layer in boundary_layers and stage in active,
                "coordinates",
                f"{name}: progress outside first/last layers or active stages",
            )
        key = (event, layer, stage)
        require(key not in positions, "duplicate_event", f"{name}: repeated {key}")
        positions[key] = index
    for begin, returned in EVENT_PAIRS:
        coordinates = {
            (layer, stage)
            for event, layer, stage in positions
            if event in (begin, returned)
        }
        for layer, stage in coordinates:
            left, right = (begin, layer, stage), (returned, layer, stage)
            require(
                left in positions
                and right in positions
                and positions[left] < positions[right],
                "event_pair",
                f"{name}: missing or reversed {begin}/{returned} at {layer}/{stage}",
            )
    required = [
        (event, layers[-1], 0)
        for event in ("parent_finish_begin", "parent_finish_returned")
    ]
    for layer in boundary_layers:
        for stage in active:
            required.extend((event, layer, stage) for event in TICKET_EVENTS)
            if startup["role"] == "ffn":
                required.extend(
                    (event, layer, stage)
                    for event in ("compute_begin", "compute_returned")
                )
    require(
        all(key in positions for key in required),
        "missing_event",
        f"{name}: missing required first/last-layer ticket or parent finish milestones",
    )
    # These are host program-order edges in the actual ticket owners. Pair
    # closure alone would accept compute before receiving its input, or reuse
    # before consuming a loan. Optional native preparation/continuation/collapse
    # events retain their own pair checks without imposing a new global order.
    chain = (
        TICKET_EVENTS
        if startup["role"] == "attention"
        else (
            "recv_post_begin",
            "recv_post_returned",
            "loan_wait_begin",
            "loan_wait_returned",
            "compute_begin",
            "compute_returned",
            "send_post_begin",
            "send_post_returned",
            "stage_reuse_wait_begin",
            "stage_reuse_wait_returned",
        )
    )
    for layer in boundary_layers:
        for stage in active:
            ordered = [positions[(event, layer, stage)] for event in chain]
            require(
                all(
                    left < right
                    for left, right in zip(ordered, ordered[1:], strict=False)
                ),
                "event_causality",
                f"{name}: posting/loan/compute/reuse order at {layer}/{stage}",
            )
    # The pipeline accepts posts in layer-major, then stage-major order. A
    # later ticket cannot reuse a stage bank until the earlier loan is closed.
    # Only the observed boundary coordinates participate; interior layers may
    # be omitted by diagnostics and independent stages may still overlap.
    post_begin = (
        "send_post_begin" if startup["role"] == "attention" else "recv_post_begin"
    )
    post_returned = (
        "recv_post_returned" if startup["role"] == "attention" else "send_post_returned"
    )
    coordinates = [
        (layer, stage) for layer in sorted(boundary_layers) for stage in active
    ]
    for previous, current in zip(coordinates, coordinates[1:], strict=False):
        require(
            positions[(post_returned, *previous)] < positions[(post_begin, *current)],
            "event_causality",
            f"{name}: posts violate accepted layer/stage order",
        )
    for previous_layer, current_layer in zip(
        sorted(boundary_layers), sorted(boundary_layers)[1:], strict=False
    ):
        for stage in active:
            require(
                positions[("stage_reuse_wait_returned", previous_layer, stage)]
                < positions[(post_begin, current_layer, stage)],
                "event_causality",
                f"{name}: later layer posts before its stage bank is reusable",
            )
    finish_begin = positions[("parent_finish_begin", layers[-1], 0)]
    require(
        all(
            index < finish_begin
            for (event, _, _), index in positions.items()
            if event
            in (
                "send_post_returned",
                "recv_post_returned",
                "loan_wait_returned",
                "compute_returned",
            )
        ),
        "event_causality",
        f"{name}: parent finish begins before all postings and consumer loans return",
    )
    if not active:
        exact(len(records), 3, f"{name}: empty parent must not post payload")
    return {
        "transaction_id": transaction,
        "phase": "eager",
        "num_stages": 2,
        "layer_indices": layers,
        "active_stages": active,
        "event_count": len(records),
        "actual_stream_fields": actual,
        "host_milestones_verified": True,
        "parent_finish_observed": True,
        "parent_completion_verified": False,
        "device_completion_verified": False,
    }


def summarize(manifest_path: Path, output: Path, report: dict[str, JSONValue]) -> None:
    data = manifest_path.read_bytes()
    report["run_manifest"] = {
        "path": str(manifest_path),
        "sha256": hashlib.sha256(data).hexdigest(),
    }
    manifest = mapping(json_value(data, str(manifest_path)), "run manifest")
    # Collect every recognizable input before validating the surrounding
    # schema. A malformed ranks list must not turn recipe/log input into output.
    declared_paths = []
    reference = manifest.get("recipe")
    if type(reference) is dict:
        declared_paths.append(reference.get("path"))
    declared_ranks = manifest.get("ranks")
    if type(declared_ranks) is list:
        declared_paths.extend(
            entry.get("log_path") for entry in declared_ranks if type(entry) is dict
        )
    known_paths = [manifest_path, Path(__file__).resolve()]
    for value in declared_paths:
        if (
            type(value) is str
            and value.strip()
            and not any(char in value for char in ("\0", "\n", "\r"))
        ):
            known_paths.append(resolve_path(value, manifest_path.parent, "input path"))
    protect_output(output, known_paths)
    report["output_inputs_checked"] = True
    exact(manifest.get("schema_version"), 1, "run manifest schema_version")
    require(
        set(manifest)
        <= {
            "schema_version",
            "run_id",
            "recipe",
            "ranks",
            "device_namespace",
            "visible_devices",
            "expected_transactions",
            "expected_graph_transactions",
        },
        "schema",
        "unknown run manifest field",
    )
    report["run_id"] = text(manifest.get("run_id"), "run_id")
    recipe_ref = mapping(manifest.get("recipe"), "recipe reference")
    exact(set(recipe_ref), {"path", "sha256"}, "recipe reference fields")
    base = manifest_path.parent
    recipe_path = resolve_path(recipe_ref.get("path"), base, "recipe path")
    entries = [
        mapping(value, "rank entry")
        for value in sequence(manifest.get("ranks"), "ranks")
    ]
    paths = [resolve_path(entry.get("log_path"), base, "log_path") for entry in entries]
    protect_output(
        output, [manifest_path, recipe_path, Path(__file__).resolve(), *paths]
    )
    exact(len(paths), len(set(paths)), "one distinct record path per rank")
    identities = report["inputs"]
    raw_recipe = checked_bytes(recipe_path, recipe_ref.get("sha256"), identities)
    prepared = mapping(json_value(raw_recipe, str(recipe_path)), "prepared recipe")
    recipe = validate_recipe(prepared)
    report["recipe_source_identity"] = prepared["source_identity"]
    report["frozen_environment"] = prepared["frozen_environment"]
    report["frozen_environment_sha256"] = prepared["frozen_environment_sha256"]
    report["recipe_mode"] = recipe["mode"]
    namespace = manifest.get("device_namespace", "role_visible")
    require(namespace in ("role_visible", "all_visible"), "schema", "device_namespace")
    visible = None
    if namespace == "all_visible":
        visible = integer_list(manifest.get("visible_devices"), "visible_devices")
        require(bool(visible), "schema", "all_visible requires visible_devices")
    else:
        require(
            "visible_devices" not in manifest,
            "schema",
            "visible_devices needs all_visible",
        )
    report["device_namespace"] = namespace
    report["visible_devices"] = visible
    expected = expected_transactions(manifest, recipe)
    graph_expected = expected_graph_transactions(manifest, recipe)
    report["actual_events_requested"] = bool(expected or graph_expected)
    report["actual_graph_host_events_requested"] = bool(graph_expected)
    report["actual_event_scope"] = (
        "graph_parent_host_control"
        if graph_expected
        else "eager_u2_and_serial_u1_host_boundaries"
        if any(item["num_stages"] == 1 for item in expected)
        else "eager_u2_host_enqueue"
        if expected
        else "configuration_only"
    )
    expected_ranks = {(role, rank) for role in ROLES for rank in range(recipe["tp"])}
    observed_ranks = []
    for entry, path in zip(entries, paths, strict=True):
        exact(
            set(entry),
            {"role", "role_rank", "log_path", "sha256", "format"},
            "rank entry fields",
        )
        role = text(entry.get("role"), "rank role")
        rank = integer(entry.get("role_rank"), "role_rank")
        require(
            (role, rank) in expected_ranks,
            "rank_identity",
            f"unexpected rank {role}/{rank}",
        )
        require(
            (role, rank) not in observed_ranks,
            "rank_identity",
            f"duplicate rank {role}/{rank}",
        )
        observed_ranks.append((role, rank))
        device = recipe["roles"][role]["devices"][rank]
        if visible is not None:
            require(
                device in visible,
                "device_identity",
                f"{role}/{rank}: device not visible",
            )
        local_device = rank if visible is None else visible.index(device)
        records = read_records(
            checked_bytes(path, entry.get("sha256"), identities),
            text(entry.get("format"), "record format"),
            str(path),
        )
        startup = validate_startup(records, role, rank, local_device, recipe)
        stages = [
            record for record in records if record["event"] != "session_configuration"
        ]
        summary = {
            "role": role,
            "role_rank": rank,
            "declared_device_id": device,
            "expected_local_device": local_device,
            "record_path": str(path),
            "startup": startup,
            "startup_configuration_verified": True,
            "stage_record_count": len(stages),
            "stage_event_counts": dict(Counter(record["event"] for record in stages)),
            "actual_events_verified": False,
            "parents": [],
        }
        report["ranks"].append(summary)
        for record in stages:
            for key, value in (
                ("role", role),
                ("role_rank", rank),
                ("world_rank", startup["world_rank"]),
            ):
                exact(record.get(key), value, f"{role}/{rank}: stage identity/{key}")
        if expected:
            transactions = [item["transaction_id"] for item in expected]
            exact(
                {record.get("transaction_id") for record in stages},
                set(transactions),
                f"{role}/{rank}: exact transaction inventory",
            )
            cursor = 0
            for item in expected:
                parent = [
                    record
                    for record in stages
                    if record.get("transaction_id") == item["transaction_id"]
                ]
                exact(
                    stages[cursor : cursor + len(parent)],
                    parent,
                    f"{role}/{rank}: contiguous ordered parent records",
                )
                cursor += len(parent)
                summary["parents"].append(validate_parent(parent, item, startup))
            summary["actual_events_verified"] = True
        elif graph_expected:
            body_events = {event for pair in EVENT_PAIRS for event in pair} | {
                "configuration",
                "compute_sync_begin",
                "compute_sync_complete",
            }
            for record in stages:
                if record["event"].startswith("graph_parent_"):
                    continue
                require(
                    record.get("boundary") in ("host_enqueue", "explicit_synchronize")
                    and record["event"] in body_events,
                    "record_schema",
                    f"{role}/{rank}: unrecognized Graph host or tensor-body record",
                )
            graph_records = [
                record
                for record in stages
                if record["event"].startswith("graph_parent_")
            ]
            transactions = [item["transaction_id"] for item in graph_expected]
            exact(
                {record.get("transaction_id") for record in graph_records},
                set(transactions),
                f"{role}/{rank}: exact Graph transaction inventory",
            )
            cursor = 0
            for item in graph_expected:
                parent = [
                    record
                    for record in graph_records
                    if record.get("transaction_id") == item["transaction_id"]
                ]
                exact(
                    graph_records[cursor : cursor + len(parent)],
                    parent,
                    f"{role}/{rank}: contiguous ordered Graph parent records",
                )
                cursor += len(parent)
                summary["parents"].append(validate_graph_parent(parent, item, startup))
            summary["actual_events_verified"] = True
    exact(set(observed_ranks), expected_ranks, "complete expected rank inventory")
    report["startup_configuration_verified"] = True
    report["actual_events_verified"] = bool(expected or graph_expected)
    report["actual_graph_host_events_verified"] = bool(graph_expected)
    report["success"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    manifest, output = args.run_manifest.resolve(), args.output.resolve()
    report = {
        "schema_version": 1,
        "success": False,
        "startup_configuration_verified": False,
        "actual_events_requested": False,
        "actual_events_verified": False,
        "actual_graph_host_events_requested": False,
        "actual_graph_host_events_verified": False,
        "runtime_admission_checked": False,
        "npu_execution_performed": False,
        "full_model_qualification": False,
        "physical_overlap_verified": False,
        "performance_verified": False,
        "output_inputs_checked": False,
        "tool": {
            "path": str(Path(__file__).resolve()),
            "sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        },
        "inputs": [],
        "ranks": [],
        "failures": [],
        "limits": [
            "run_id and rank files are attributed by the caller. Runtime records "
            "carry no run ID, PID, recipe SHA or source SHA; mixing runs with "
            "identical records cannot be detected.",
            "Declared device selection comes from the recipe/visible-device "
            "manifest. Logs observe process-local device ordinals, not physical "
            "device identity.",
            "Recipe/source hashes identify read artifacts, not installed runtime "
            "bytes or proof that the prepared commands were launched.",
            "Startup is before native KV initialization/thread start and is not "
            "model readiness. Configured, logical/effective and actual stream "
            "fields have separate meanings.",
            "Optional execution checks cover eager/U2 ticket and serial-U1 "
            "first/last-layer host boundaries. Serial body returns do not emit "
            "parent_finish or observe COMPLETE. Explicit FFN compute-sync logs "
            "identify only the requested synchronization boundary. None proves "
            "parent/device completion, tensor correctness or physical overlap.",
            "Graph host checks cover outer reservation/replay/finish API returns. "
            "Captured tensor bodies do not log on replay; successful host records "
            "do not establish device task execution. Old Graph logs without the "
            "parent host records remain configuration-only. No Engram, full-model, "
            "performance or service acceptance is inferred.",
        ],
    }
    try:
        protect_output(output, [manifest, Path(__file__).resolve()])
        summarize(manifest, output, report)
    except (AuditError, OSError, UnicodeError) as exc:
        report["failures"].append(
            {
                "code": exc.code if isinstance(exc, AuditError) else "input_io",
                "message": str(exc),
            }
        )
        if not report["output_inputs_checked"] or (
            isinstance(exc, AuditError) and exc.code == "output_collision"
        ):
            print(json.dumps(report, indent=2), file=sys.stderr)
            return 1
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(
        json.dumps(
            {
                "success": report["success"],
                "output": str(output),
                "failures": report["failures"],
            }
        ),
        flush=True,
    )
    return 0 if report["success"] else 1


if __name__ == "__main__":
    sys.exit(main())
