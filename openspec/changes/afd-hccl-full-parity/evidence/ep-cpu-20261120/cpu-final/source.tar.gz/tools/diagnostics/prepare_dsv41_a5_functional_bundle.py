#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
"""Freeze the non-Engram A5 functional suite; no runtime imports or devices."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path

from prepare_dsv41_a5_dspark_bundle import (
    A5_RUNTIME,
    BASELINE,
    BASELINE_SHA256,
    a5_helper_successors,
    archive_files,
    json_bytes,
    read_locked_sources,
    write_archive,
)

DSPARK_BUNDLE = "reports/dsv41-a5-dspark-functional/runtime-source.tar.gz"
DSPARK_SHA256 = "311cafc72c81dd06f09a67fe903527db3820089e23a39192f971e022cc5f7c3b"
WORKER_BUNDLE = (
    "openspec/changes/afd-hccl-full-parity/evidence/"
    "a3-text-normal-worker-20261116/prepared-execute-005/source.tar.gz"
)
WORKER_SHA256 = "a8bde079dd5126e6cf0f7b6aede1c093e02489aa070f1df88d5d7478df2ece81"
LAUNCHER = "tests/npu/dsv41_a5_functional_validation.py"
PROBE = "tests/npu/dsv41_functional_worker_probe.py"
MODEL_PROBE = "tests/npu/dsv41_normal_model_probe.py"
C2_PROBE = "tests/npu/dsv41_normal_c2_probe.py"
FEATURE = "afd_plugin/compat/npu/feature_validation.py"
PRODUCTION_OVERLAYS = (
    FEATURE,
    "afd_plugin/compat/npu/runtime_config.py",
    "afd_plugin/v1/worker/npu/ffn_worker.py",
    "afd_plugin/compat/patches/engine_core.py",
    "afd_plugin/compat/npu/profiler.py",
    "afd_plugin/compat/npu/profiler_api.py",
    "afd_plugin/v1/worker/npu/ubatch_runner.py",
    "afd_plugin/compat/npu/kv_layout_connector.py",
)
OUTPUT = "reports/dsv41-a5-functional"
PRODUCTION_COUNT = 146
GRAPH_PROBE = "tests/npu/hccl_native_attention_pd_dspark_graph_probe.py"
GRAPH_PROBE_PARENT_SHA256 = (
    "87559172c4be2f2579c0630c159f8d24c872699bda3625cab4506887fe5e45b0"
)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def verified_archive(root: Path, name: str, expected: str) -> dict[str, bytes]:
    path = root / name
    if digest(path.read_bytes()) != expected:
        raise ValueError(f"immutable parent archive differs: {name}")
    files = archive_files(path)
    manifest_name = (
        "bundle-manifest.json" if "bundle-manifest.json" in files else "manifest.json"
    )
    manifest = json.loads(files.pop(manifest_name))
    expected_sources = manifest.get("sources", manifest)
    if {name: digest(raw) for name, raw in files.items()} != expected_sources:
        raise ValueError(f"parent member hashes differ: {name}")
    return files


def add_local_helpers(root: Path, files: dict[str, bytes]) -> None:
    pending = [LAUNCHER, PROBE, MODEL_PROBE, C2_PROBE]
    seen = set()
    while pending:
        name = pending.pop()
        if name in seen:
            continue
        seen.add(name)
        raw = (root / name).read_bytes()
        files[name] = raw
        for node in ast.walk(ast.parse(raw, filename=name)):
            modules = []
            if isinstance(node, ast.Import):
                modules = [alias.name for alias in node.names]
            elif isinstance(node, ast.ImportFrom) and node.module:
                modules = [node.module]
            for module in modules:
                candidates = [
                    "tests/npu/" + module.replace(".", "/") + ".py",
                    module.replace(".", "/") + ".py",
                ]
                for candidate in candidates:
                    # Keep the reviewed A5 DSpark successors frozen.
                    if (
                        candidate.startswith("tests/")
                        and (root / candidate).is_file()
                        and candidate not in files
                    ):
                        pending.append(candidate)


def staged_graph_observer(raw: bytes) -> bytes:
    """Retarget the exact reviewed observer to the shared U1/U2 stage entry.

    HcclV41UBatchRunner.run_staged bypasses the wrapper's forward. Native input
    preparation can embed the whole parent before both eager and replay, so
    embedding cannot distinguish target execution. The controlled first-layer
    Attention forward runs once per nonempty eager stage, and never in replay.
    Preserve expected counts and numerical/KV/proposal/storage/transport checks.
    """
    if digest(raw) != GRAPH_PROBE_PARENT_SHA256:
        raise ValueError("reviewed Graph observer parent differs")
    source = raw.decode("utf-8")
    replacements = (
        (
            "Observe unchanged public execution and Python target entry "
            "on the D owner.",
            "Observe public execution and Python target stage entry on the D owner.",
        ),
        (
            "    model = owner.model\n",
            "    model = owner.model.language_model.model.layers[0].self_attn\n",
        ),
        (
            '        "python_target_calls": [],\n',
            '        "python_target_calls": [],\n'
            '        "python_target_entrypoint": '
            '"language_model.model.layers[0].self_attn.forward",\n',
        ),
        (
            '    assert "forward" not in owner.model.__dict__\n',
            '    assert "forward" not in model.__dict__\n',
        ),
        (
            "    def observed_forward(*args, **kwargs):\n",
            "    def observed_forward(positions, hidden_states, scaling=None):\n",
        ),
        (
            '{"execute_ordinal": len(detail["executions"])}\n',
            '{\n'
            '                "execute_ordinal": len(detail["executions"]),\n'
            '                "token_rows": positions.numel(),\n'
            '            }\n',
        ),
        (
            "        return forward(*args, **kwargs)\n",
            "        return forward(positions, hidden_states, scaling)\n",
        ),
        (
            '            "host_records": observed,\n',
            '            "python_target_rows": [\n'
            '                call["token_rows"]\n'
            '                for call in detail["python_target_calls"][before_calls:]\n'
            '            ],\n'
            '            "host_records": observed,\n',
        ),
        (
            '        if step.total_num_scheduled_tokens:\n',
            '        detail["last_returned_execution"] = entry\n'
            '        if step.total_num_scheduled_tokens:\n',
        ),
        (
            '            assert entry["python_target_calls"] == python_calls\n',
            '            assert entry["python_target_calls"] == python_calls, entry\n'
            '            assert entry["python_target_rows"] == (\n'
            '                [TARGET_ROWS] * python_calls\n'
            '            ), entry\n',
        ),
    )
    for before, after in replacements:
        if source.count(before) != 1:
            raise ValueError(f"Graph observer replacement is not unique: {before}")
        source = source.replace(before, after)
    return source.encode("utf-8")


def graph_device_audit_successors(
    files: dict[str, bytes],
) -> dict[str, dict[str, str]]:
    """Audit host and pipeline devices against the supervisor's role placement.

    Only frozen diagnostic validators change. Keep every observed device check;
    the independent expected value comes from --devices, never from a record.
    Pin all six parents before threading the required keyword through callers.
    """
    parents = {
        "decode": "4d859ac89ea63274fa1a8323e9c0d437e657179bcab7c2f998514f09c854f3ea",
        "graph": "dc9c5f9b82380a108d4128d7160bc22f5a62bcef06a4573d3487c75f4a6cbf10",
        "u2": "b855a090969cc5e5394c11db27233f7bf74a9b5931b171a82dd9ab4bb9420ffd",
        "lifecycle": "1c0f058526a3536e46f8b69f88a069671f4a8c54dec2859289db7a488294e37c",
        "overlap": "71adb248cb11cb9aa2628874100f5a27b105b36c86eda02047285f0bd58f2150",
        "cross_layer": (
            "3180750cddfa12b4663367683e2ff5922380566bc495de360c85dd51bebd7213"
        ),
    }
    replacements = {
        "decode": [
            (
                "    children, owned = {}, {}\n",
                "    children, owned = {}, {}\n"
                "    local_devices = {\n"
                '        "attention": args.devices[ROLES.index("kv_consumer")],\n'
                '        "ffn": args.devices[ROLES.index("ffn_consumer")],\n'
                "    }\n",
            ),
            (
                '        "run_id": run_id,\n',
                '        "run_id": run_id,\n        "local_devices": local_devices,\n',
            ),
            (
                "                            graph_all_axes=args.graph_all_axes,\n",
                "                            local_devices=local_devices,\n"
                "                            graph_all_axes=args.graph_all_axes,\n",
            ),
        ],
        "graph": [
            (
                "    records, parents, *, role, graph_compute_overlap=False, "
                "graph_all_axes=False\n",
                "    records,\n    parents,\n    *,\n    role,\n    local_device,\n"
                "    graph_compute_overlap=False,\n    graph_all_axes=False,\n",
            ),
            (
                '            assert record["local_device"] == '
                '(2 if role == "attention" else 6)\n',
                '            assert record["local_device"] == local_device, (\n'
                '                role, record["local_device"], local_device\n'
                "            )\n",
            ),
            (
                "def verify_graph_decode(attention, ffn):\n",
                "def verify_graph_decode(attention, ffn, *, local_devices):\n",
            ),
            (
                '        role="attention",\n    )\n',
                '        role="attention",\n'
                '        local_device=local_devices["attention"],\n    )\n',
            ),
            (
                '    verify_graph_host_records(ffn["native_ffn"]["host_records"], '
                'parents, role="ffn")\n',
                "    verify_graph_host_records(\n"
                '        ffn["native_ffn"]["host_records"], parents, role="ffn",\n'
                '        local_device=local_devices["ffn"],\n    )\n',
            ),
        ],
        "u2": [
            (
                "def verify_graph_decode_requests(attention, ffn):\n",
                "def verify_graph_decode_requests(attention, ffn, *, local_devices):\n",
            ),
            (
                "        verify_graph_host_records(records, parents, role=role)\n",
                "        verify_graph_host_records(\n"
                "            records, parents, role=role,\n"
                "            local_device=local_devices[role],\n        )\n",
            ),
        ],
        "lifecycle": [
            (
                "    *,\n    graph_compute_overlap=False,\n",
                "    *,\n    local_devices,\n    graph_compute_overlap=False,\n",
            ),
            (
                "            role=role,\n",
                "            role=role,\n"
                "            local_device=local_devices[role],\n",
            ),
        ],
        "overlap": [
            (
                "    attention, ffn, *, graph_all_axes=False, "
                'graph_exchange_order="stage_serial"\n',
                "    attention, ffn, *, local_devices, graph_all_axes=False,\n"
                '    graph_exchange_order="stage_serial",\n',
            ),
            (
                "        ffn,\n        graph_compute_overlap=True,\n",
                "        ffn,\n        local_devices=local_devices,\n"
                "        graph_compute_overlap=True,\n",
            ),
            (
                "                device=2,\n",
                '                device=local_devices["attention"],\n',
            ),
            (
                "                device=6,\n",
                '                device=local_devices["ffn"],\n',
            ),
            (
                '        role="ffn",\n',
                '        role="ffn",\n        local_device=local_devices["ffn"],\n',
            ),
        ],
        "cross_layer": [
            (
                "def verify_cross_layer_lifecycle(attention, ffn):\n",
                "def verify_cross_layer_lifecycle(attention, ffn, *, local_devices):\n",
            ),
            (
                "        attention, ffn, graph_all_axes=True, "
                'graph_exchange_order="cross_layer_v1"\n',
                "        attention, ffn, local_devices=local_devices,\n"
                '        graph_all_axes=True, graph_exchange_order="cross_layer_v1",\n',
            ),
        ],
    }
    for function in (
        "verify_cross_layer_lifecycle",
        "verify_decode_cancel_replace",
        "verify_graph_decode_requests",
        "verify_graph_decode",
    ):
        before = (
            f'{function}(\n                        consumer, report["workers"]'
            '["ffn_consumer"]\n                    )'
        )
        after = (
            f"{function}(\n                        consumer,\n"
            '                        report["workers"]["ffn_consumer"],\n'
            "                        local_devices=local_devices,\n"
            "                    )"
        )
        replacements["decode"].append((before, after))
    result = {}
    for suffix, expected in parents.items():
        name = f"tests/npu/hccl_native_attention_pd_dspark_{suffix}_probe.py"
        raw = files[name]
        if digest(raw) != expected:
            raise ValueError(f"reviewed Graph device audit parent differs: {name}")
        source = raw.decode("utf-8").replace("\r\n", "\n")
        for before, after in replacements[suffix]:
            if source.count(before) != 1:
                raise ValueError(
                    f"Graph device replacement count differs: {name}: {before}"
                )
            source = source.replace(before, after)
        if b"\r\n" in raw:
            source = source.replace("\n", "\r\n")
        files[name] = source.encode("utf-8")
        result[name] = {"parent_sha256": expected, "sha256": digest(files[name])}
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path(OUTPUT))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    output = args.output_dir.resolve()
    if output.exists():
        parser.error("--output-dir must be fresh")
    files = verified_archive(root, DSPARK_BUNDLE, DSPARK_SHA256)
    # Refresh only the A5 indexer declarations from the immutable donor;
    # retain all other reviewed DSpark helper bytes from its parent bundle.
    donor = verified_archive(root, BASELINE, BASELINE_SHA256)
    successors, _ = a5_helper_successors(donor, root)
    for name in (A5_RUNTIME, "tests/npu/dsv41_dspark_speculator_probe.py"):
        files[name] = successors[name]
    files[GRAPH_PROBE] = staged_graph_observer(files[GRAPH_PROBE])
    device_audit = graph_device_audit_successors(files)
    original_production = {
        name: digest(raw)
        for name, raw in files.items()
        if name.startswith("afd_plugin/")
    }
    worker = verified_archive(root, WORKER_BUNDLE, WORKER_SHA256)
    production = {
        name: raw for name, raw in worker.items() if name.startswith("afd_plugin/")
    }
    if len(production) != PRODUCTION_COUNT or set(production) != set(
        original_production
    ):
        raise ValueError("normal Worker production closure differs")
    # Retain the reviewed normal-Worker closure, excluding unrelated paused MTP
    # work in the mutable checkout. Include the bounded admission, existing
    # DSpark cross-layer PD eligibility and existing failure ownership fixes,
    # including terminal RPC handling. No profiler device scene is added.
    for name in PRODUCTION_OVERLAYS:
        production[name] = (root / name).read_bytes()
    files.update(production)
    add_local_helpers(root, files)
    identity = json.loads(files["native-source-identity.json"])
    for name, raw in worker.items():
        if name.endswith(".json"):
            for source, expected in json.loads(raw).get("source_expected", {}).items():
                if source.startswith(("vllm/", "vllm_ascend/")):
                    previous = identity["source_expected"].get(source, expected)
                    if previous != expected:
                        raise ValueError(f"conflicting native source pin: {source}")
                    identity["source_expected"][source] = expected
    repositories = json.loads(
        (root / ".agents/dsv41/sources.lock.json").read_text("utf-8")
    )["repositories"]
    for package in ("vllm", "vllm_ascend"):
        names = sorted(
            n for n in identity["source_expected"] if n.startswith(package + "/")
        )
        for name, raw in read_locked_sources(repositories[package], names).items():
            if digest(raw) != identity["source_expected"][name]:
                raise ValueError(f"native Git pin differs: {name}")
    files["native-source-identity.json"] = json_bytes(identity)
    production_hashes = {name: digest(raw) for name, raw in sorted(production.items())}
    delta = {
        name: {"parent_sha256": original_production[name], "sha256": value}
        for name, value in production_hashes.items()
        if original_production[name] != value
    }
    files["functional-source-provenance.json"] = json_bytes(
        {
            "dspark_parent_sha256": DSPARK_SHA256,
            "worker_parent_sha256": WORKER_SHA256,
            "production_delta_from_dspark": delta,
            "production_overlays_from_worker": list(PRODUCTION_OVERLAYS),
            "graph_device_audit_successors": device_audit,
            "graph_observer_successor": {
                "source": GRAPH_PROBE,
                "parent_sha256": GRAPH_PROBE_PARENT_SHA256,
                "sha256": digest(files[GRAPH_PROBE]),
                "entrypoint": "language_model.model.layers[0].self_attn.forward",
            },
            "paused_old_v4_mtp_included": False,
        }
    )
    for name, raw in files.items():
        if not name.endswith((".py", ".json")):
            raise ValueError(f"non-source member: {name}")
        if name.endswith(".py"):
            compile(raw, name, "exec")
    manifest = {
        "baseline_archive_sha256": BASELINE_SHA256,
        "sources": {name: digest(raw) for name, raw in sorted(files.items())},
        "source_count": len(files),
        "production_count": len(production),
    }
    output.mkdir(parents=True)
    archive = output / "runtime-source.tar.gz"
    write_archive(archive, {**files, "bundle-manifest.json": json_bytes(manifest)})
    lock = {
        "baseline_archive_sha256": BASELINE_SHA256,
        "runtime_source_sha256": digest(archive.read_bytes()),
        "launcher_sha256": digest(files[LAUNCHER]),
        "production_sources": production_hashes,
    }
    (output / "bundle-lock.json").write_bytes(json_bytes(lock))
    preparation = {
        "status": "source_prepared_not_device_validated",
        "runtime_source_sha256": lock["runtime_source_sha256"],
        "python_sources_compiled": sum(n.endswith(".py") for n in files),
        "source_count": len(files),
        "production_count": len(production),
        "native_git_pins_verified": len(identity["source_expected"]),
        "production_delta_from_dspark": delta,
        "new_admission_source_sha256": digest(production[FEATURE]),
        "npu_validation": "pending_on_A5",
        "contains_binaries": False,
    }
    (output / "preparation.json").write_bytes(json_bytes(preparation))
    print(json.dumps(preparation, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
