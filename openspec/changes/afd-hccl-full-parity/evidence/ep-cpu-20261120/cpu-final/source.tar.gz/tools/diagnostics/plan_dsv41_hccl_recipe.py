# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Export a CPU-only HCCL recipe plan; never launch or grant runtime admission.

The JSON request supplies mode, num_stages, max_num_seqs,
max_num_batched_tokens, native_tp_size, attention_devices and ffn_devices.
Optional fields are num_speculative_tokens, capture_sizes,
max_cudagraph_capture_size, dbo_decode_token_threshold,
dbo_prefill_token_threshold, attention_host_id and ffn_host_id.

Capture prediction covers fixed-width uniform decode, EP/SP off, no LoRA,
and a caller that supplies the native UBatchRunner for U2. It does not model
dynamic speculation, varlen decode, actual graph capture or live fallback.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from collections.abc import Mapping
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import TypeAlias

JSONValue: TypeAlias = (
    None | bool | int | float | str | list["JSONValue"] | dict[str, "JSONValue"]
)
VLLM_COMMIT = "ced6857afa0ea7b2e3f0846a62e1394e90f15607"
ASCEND_COMMIT = "7e37e29a7803d6897a7113088e2b771f83205bc0"
DONOR_COMMIT = "4ddd69a391dfb5b3e362c7601399e538a31de702"
MAX_LOCAL_DEVICES = 8
SUPPORTED_STAGES = (1, 2)
OVERLAP_NAMES = (
    "AFD_HCCL_EAGER_U2_STREAM_OVERLAP",
    "AFD_HCCL_GRAPH_U2_COMPUTE_OVERLAP",
    "AFD_HCCL_GRAPH_U2_HYBRID_DAG",
    "AFD_HCCL_GRAPH_U2_ATTENTION_THREE_STREAM",
    "AFD_HCCL_GRAPH_U2_FFN_RECV_STREAM",
    "AFD_HCCL_GRAPH_U2_FFN_CROSS_LAYER",
    "AFD_HCCL_STAGE_DIAGNOSTICS",
    "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS",
)
REQUEST_FIELDS = (
    "mode",
    "num_stages",
    "max_num_seqs",
    "max_num_batched_tokens",
    "native_tp_size",
    "attention_devices",
    "ffn_devices",
    "num_speculative_tokens",
    "capture_sizes",
    "max_cudagraph_capture_size",
    "dbo_decode_token_threshold",
    "dbo_prefill_token_threshold",
    "attention_host_id",
    "ffn_host_id",
)


def integer(value: JSONValue, name: str, *, minimum: int = 1) -> int:
    if type(value) is not int or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def integer_list(value: JSONValue, name: str, *, minimum: int = 1) -> tuple[int, ...]:
    if not isinstance(value, list) or not value:
        raise ValueError(f"{name} must be a nonempty integer list")
    return tuple(integer(item, name, minimum=minimum) for item in value)


@dataclass(frozen=True)
class RecipeRequest:
    mode: str
    num_stages: int
    max_num_seqs: int
    max_num_batched_tokens: int
    native_tp_size: int
    attention_devices: tuple[int, ...]
    ffn_devices: tuple[int, ...]
    num_speculative_tokens: int = 0
    capture_sizes: tuple[int, ...] | None = None
    max_cudagraph_capture_size: int | None = None
    dbo_decode_token_threshold: int = 32
    dbo_prefill_token_threshold: int = 512
    attention_host_id: str = "local"
    ffn_host_id: str = "local"

    @classmethod
    def from_mapping(cls, raw: Mapping[str, JSONValue]) -> RecipeRequest:
        unknown = set(raw).difference(REQUEST_FIELDS)
        if unknown:
            raise ValueError(f"unknown request fields: {sorted(unknown)}")
        values = dict(raw)
        for name in (
            "num_stages",
            "max_num_seqs",
            "max_num_batched_tokens",
            "native_tp_size",
        ):
            values[name] = integer(raw.get(name), name)
        for name, default in (
            ("num_speculative_tokens", 0),
            ("dbo_decode_token_threshold", 32),
            ("dbo_prefill_token_threshold", 512),
        ):
            values[name] = integer(raw.get(name, default), name, minimum=0)
        for name in ("attention_devices", "ffn_devices"):
            values[name] = integer_list(raw.get(name), name, minimum=0)
        for name in ("attention_host_id", "ffn_host_id"):
            value = raw.get(name, "local")
            if not isinstance(value, str) or not value.strip():
                raise ValueError(f"{name} must be a nonempty host identity")
            values[name] = value
        if raw.get("capture_sizes") is not None:
            values["capture_sizes"] = integer_list(
                raw["capture_sizes"], "capture_sizes"
            )
        if raw.get("max_cudagraph_capture_size") is not None:
            values["max_cudagraph_capture_size"] = integer(
                raw["max_cudagraph_capture_size"], "max_cudagraph_capture_size"
            )
        if values["mode"] not in ("eager", "full-decode-only"):
            raise ValueError("mode must be eager or full-decode-only")
        request = cls(**values)
        if request.num_stages not in SUPPORTED_STAGES:
            raise ValueError("num_stages must be 1 or 2")
        # Native ParallelConfig validates thresholds even before a batch exists.
        if (
            request.num_stages > 1
            and min(
                request.dbo_decode_token_threshold, request.dbo_prefill_token_threshold
            )
            < request.num_stages
        ):
            raise ValueError("both DBO thresholds must be >= num_stages for U2")
        return request


def topology_plan(request: RecipeRequest) -> dict[str, JSONValue]:
    # By-path execution first needs main's checkout sys.path bootstrap; defer
    # these imports until then, also keeping --help standard-library only.
    # These modules are CPU-safe; the NPU connector namespace imports torch.
    from afd_plugin.config import HCCL_P2P_CONNECTOR, AFDConfig
    from afd_plugin.distributed.hccl import build_hccl_rank_mapping

    attention_size, ffn_size = len(request.attention_devices), len(request.ffn_devices)
    roles: dict[str, JSONValue] = {}
    for role, devices, host in (
        ("attention", request.attention_devices, request.attention_host_id),
        ("ffn", request.ffn_devices, request.ffn_host_id),
    ):
        if len(set(devices)) != len(devices) or any(
            device >= MAX_LOCAL_DEVICES for device in devices
        ):
            raise ValueError(f"{role}_devices must be unique local device IDs 0..7")
        config = AFDConfig(
            connector=HCCL_P2P_CONNECTOR,
            role=role,
            num_attention_ranks=attention_size,
            num_ffn_ranks=ffn_size,
        )
        ranks = []
        for rank, device in enumerate(devices):
            mapping = build_hccl_rank_mapping(
                config, rank, native_tp_size=request.native_tp_size
            )
            ranks.append(
                {
                    **asdict(mapping),
                    "device_id": device,
                    "native_tp_rank": rank % request.native_tp_size,
                    "native_tp_group_index": rank // request.native_tp_size,
                }
            )
        roles[role] = {"host_id": host, "ranks": ranks}
    if request.attention_host_id == request.ffn_host_id and set(
        request.attention_devices
    ).intersection(request.ffn_devices):
        raise ValueError("same-host Attention and FFN device IDs must be disjoint")
    return {
        "roles": roles,
        "mapping_scope": "prepared CPU rank coordinates, not runtime admission",
        "current_equal_role_single_tp_shape": (
            attention_size == ffn_size == request.native_tp_size
        ),
        "runtime_admission_checked": False,
    }


def overlap_plan(
    request: RecipeRequest, environment: Mapping[str, str]
) -> dict[str, JSONValue]:
    # Public configuration protocol: hccl_overlap.HcclOverlapSettings and
    # HcclOverlapSelection. Importing that module normally imports torch through
    # its parent package, so this deployment planner uses only the binary wire
    # values and the documented role/phase gates; no device stream is simulated.
    configured = {}
    raw_values = {}
    for index, name in enumerate(OVERLAP_NAMES):
        raw = environment.get(name)
        raw_values[name] = raw
        if index == 0 and request.num_stages == 1:
            configured[name] = False  # Same U1 short-circuit as the component.
            continue
        value = raw.strip() if raw is not None else ("1" if index < 6 else "0")
        if value not in ("0", "1"):
            raise ValueError(f"{name} must be 0 or 1, got {raw!r}")
        configured[name] = value == "1"
    eager, compute, hybrid, attention_streams, receive, cross_layer, stage, sync = (
        OVERLAP_NAMES
    )
    if configured[cross_layer] and not configured[receive]:
        raise ValueError(f"{cross_layer}=1 requires {receive}=1")
    phases = (
        ("eager",)
        if request.mode == "eager"
        else ("graph_warmup", "graph_capture", "graph_replay", "eager")
    )
    projections = []
    for role in ("attention", "ffn"):
        for phase in phases:
            for stages in sorted({1, request.num_stages}):
                graph_compute = phase != "eager" and stages > 1 and configured[compute]
                ffn_receive = role == "ffn" and graph_compute and configured[receive]
                projections.append(
                    {
                        "role": role,
                        "phase": phase,
                        "num_stages": stages,
                        "conditional_effective": {
                            eager: phase == "eager"
                            and stages > 1
                            and configured[eager],
                            compute: graph_compute,
                            hybrid: role == "attention"
                            and graph_compute
                            and configured[hybrid],
                            attention_streams: role == "attention"
                            and graph_compute
                            and configured[attention_streams],
                            receive: ffn_receive,
                            cross_layer: ffn_receive and configured[cross_layer],
                            stage: configured[stage],
                            sync: role == "ffn"
                            and phase == "eager"
                            and stages == 1
                            and configured[sync],
                        },
                    }
                )
    return {
        "raw_environment": raw_values,
        "configured": configured,
        "conditional_phase_projections": projections,
        "projection_condition": "caller binds the matching native session and phase",
        "actual_effective_values_observed": False,
    }


def capture_plan(request: RecipeRequest) -> dict[str, JSONValue]:
    """Predict fixed-width candidates, without constructing a graph manager.

    Source: VllmConfig._set_cudagraph_sizes and CudaGraphManager at VLLM_COMMIT;
    Ascend's ModelAclGraphManager inherits the latter at ASCEND_COMMIT. This is
    a deployment plan projection, not an upstream patch. Replace it when native
    code exposes an equivalent CPU-only descriptor/configuration export.
    """
    query_len = request.num_speculative_tokens + 1
    required = request.max_num_seqs * query_len
    result: dict[str, JSONValue] = {
        "decode_query_len": query_len,
        "whole_parent_tokens": required,
        "requested_max": request.max_cudagraph_capture_size,
        "requested_raw_sizes": (
            list(request.capture_sizes) if request.capture_sizes is not None else None
        ),
        "dbo_decode_token_threshold": request.dbo_decode_token_threshold,
        "dbo_prefill_token_threshold": request.dbo_prefill_token_threshold,
        "uniform_parent_num_ubatches": (
            request.num_stages if required >= request.dbo_decode_token_threshold else 1
        ),
        "actual_capture_observed": False,
    }
    if request.mode == "eager":
        return {**result, "applicable": False, "predicted_descriptors": []}
    if request.capture_sizes is None:
        maximum = (
            required
            if request.max_cudagraph_capture_size is None
            else request.max_cudagraph_capture_size
        )
        sizes = {required, maximum}
        size = query_len
        while size < maximum:
            sizes.add(size)
            size *= 2
        raw_sizes = sorted(sizes)
        policy = "donor recipe powers-of-two plus whole parent (explicit native inputs)"
    else:
        raw_sizes = list(request.capture_sizes)
        policy = "explicit raw capture sizes"
    # Native VllmConfig._set_cudagraph_sizes: clip raw entries to the token
    # budget before max consistency validation. This is not MRV1 spec rounding.
    config_sizes = sorted(
        {size for size in raw_sizes if size <= request.max_num_batched_tokens}
    )
    if not config_sizes:
        raise ValueError("no raw capture bucket remains within the token budget")
    config_maximum = config_sizes[-1]
    if (
        request.max_cudagraph_capture_size is not None
        and request.max_cudagraph_capture_size != config_maximum
    ):
        raise ValueError(
            "explicit max_cudagraph_capture_size must equal the largest raw bucket "
            f"after token-budget clipping ({config_maximum})"
        )
    descriptors = []
    filtered = []
    seen_tokens = set()
    for raw_size in config_sizes:
        # ModelAclGraphManager -> ModelCudaGraphManager -> CudaGraphManager:
        # _init_candidates rounds before max/sequence clipping and deduplication.
        tokens = ((raw_size + query_len - 1) // query_len) * query_len
        num_reqs = tokens // query_len
        if (
            tokens > required
            or tokens > config_maximum
            or num_reqs > request.max_num_seqs
        ):
            filtered.append({"raw_size": raw_size, "rounded_tokens": tokens})
            continue
        if tokens in seen_tokens:
            continue
        seen_tokens.add(tokens)
        for stages in SUPPORTED_STAGES:
            # _maybe_ubatch_twin uses >= threshold and first requires enough
            # tokens for every microbatch. A UBatchRunner is an explicit premise.
            if stages > 1 and (
                request.num_stages == 1
                or tokens < stages
                or tokens < request.dbo_decode_token_threshold
            ):
                continue
            boundaries = [index * (tokens // stages) for index in range(stages)]
            boundaries.append(tokens)  # Native floor split; trailing remainder.
            descriptors.append(
                {
                    "cg_mode": "FULL",
                    "num_tokens": tokens,
                    "num_reqs": num_reqs,
                    "uniform_token_count": query_len,
                    "num_ubatches": stages,
                    "stage_token_ranges": [
                        [boundaries[index], boundaries[index + 1]]
                        for index in range(stages)
                    ],
                }
            )
    if required not in seen_tokens:
        raise ValueError(
            f"full-coverage recipe needs the whole parent {request.max_num_seqs} "
            f"sequences x query length {query_len} = {required} tokens before U2; "
            "the native-normalized buckets do not cover it (live fallback is unchanged)"
        )
    return {
        **result,
        "applicable": True,
        "raw_size_policy": policy,
        "recipe_raw_sizes": raw_sizes,
        "native_config_sizes": config_sizes,
        "native_config_maximum": config_maximum,
        "budget_clipped_raw_sizes": sorted(
            {size for size in raw_sizes if size > request.max_num_batched_tokens}
        ),
        "v2_filtered_rounded_buckets": filtered,
        "predicted_descriptors": sorted(
            descriptors, key=lambda descriptor: -descriptor["num_tokens"]
        ),
    }


def build_plan(
    request: RecipeRequest, environment: Mapping[str, str]
) -> dict[str, JSONValue]:
    return {
        "schema_version": 1,
        "plan_validation_success": True,
        "runtime_admission_checked": False,
        "actual_effective_values_observed": False,
        "npu_execution_performed": False,
        "request": asdict(request),
        "capture": capture_plan(request),
        "topology": topology_plan(request),
        "overlap": overlap_plan(request, environment),
        "source_contracts": {
            "donor": DONOR_COMMIT,
            "vllm": VLLM_COMMIT,
            "vllm_ascend": ASCEND_COMMIT,
            "capture": [
                "vllm/config/vllm.py:VllmConfig._set_cudagraph_sizes",
                "vllm_ascend/worker/v2/model_runner.py:NPUModelRunner.__init__",
                "vllm_ascend/worker/v2/aclgraph_utils.py:ModelAclGraphManager",
                "vllm/v1/worker/gpu/cudagraph_utils.py:CudaGraphManager._init_candidates",
                "vllm/v1/worker/gpu/cudagraph_utils.py:CudaGraphManager._maybe_ubatch_twin",
                "vllm/v1/worker/ubatch_utils.py:check_ubatch_thresholds",
                "vllm/v1/worker/ubatch_utils.py:maybe_create_ubatch_slices",
            ],
            "overlap": "afd_plugin/connectors/npu/hccl_overlap.py",
            "topology": "afd_plugin/distributed/hccl.py:build_hccl_rank_mapping",
        },
        "limits": [
            "Exit 0 validates a deployment plan; runtime admission and NPU "
            "acceptance remain separate.",
            "Fixed-width uniform decode only; dynamic speculation, varlen "
            "decode, SP and LoRA are outside this predictor.",
            "Default sizes are explicit recipe policy, not vLLM's "
            "platform-dependent default sizes.",
            "Conditional overlap gates require actual session binding; "
            "no device streams or rank logs were observed.",
            "Full-coverage recipe validation does not change runtime "
            "graph miss/fallback behavior.",
        ],
    }


def checkpoint_config_identity(model: Path) -> dict[str, JSONValue]:
    path = model / "config.json"
    raw = path.read_bytes()
    config = json.loads(raw)
    if not isinstance(config, dict):
        raise ValueError("checkpoint config.json must be an object")
    text = config.get("text_config", config)
    if not isinstance(text, dict):
        raise ValueError("checkpoint text_config must be an object")
    if config.get("model_type") != "deepseek_v41" or config.get("architectures") != [
        "DeepseekV41ForCausalLM"
    ]:
        raise ValueError(
            "--model config must identify the native DeepseekV41ForCausalLM family"
        )
    return {
        "path": str(path.resolve()),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "model_type": config["model_type"],
        "architectures": config["architectures"],
        "raw_text_config_present": "text_config" in config,
        "num_hidden_layers": text.get("num_hidden_layers"),
        "hidden_size": text.get("hidden_size"),
        "weights_or_runtime_config_validated": False,
    }


def protect_output(
    parser: argparse.ArgumentParser,
    output: Path,
    inputs: tuple[Path | None, ...],
) -> None:
    """Keep recipe JSON outside its inputs and this checkout's source files."""
    repo = Path(__file__).resolve().parents[2]
    protected = {
        path.resolve()
        for path in (
            *inputs,
            Path(__file__),
            repo / "tools/diagnostics/prepare_dsv41_hccl_recipe.py",
            repo / ".agents/dsv41/sources.lock.json",
        )
        if path is not None
    }
    output = output.resolve()
    if output in protected or output.is_relative_to((repo / "afd_plugin").resolve()):
        parser.error("output must not overwrite an input or checkout source")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--request", type=Path, required=True, help="recipe request JSON"
    )
    parser.add_argument(
        "--output", type=Path, required=True, help="plan or failure JSON"
    )
    parser.add_argument(
        "--model", type=Path, help="optional checkpoint config identity"
    )
    parser.add_argument(
        "--environment",
        type=Path,
        help="optional JSON snapshot of the eight HCCL settings",
    )
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[2]
    protect_output(
        parser,
        args.output,
        (
            args.request,
            args.environment,
            args.model / "config.json" if args.model is not None else None,
        ),
    )
    # Running this file by path does not otherwise put the checkout on sys.path.
    sys.path.insert(0, str(repo))
    try:
        request_bytes = args.request.read_bytes()
        raw_request = json.loads(request_bytes)
        if not isinstance(raw_request, dict):
            raise ValueError("request JSON must be an object")
        if "mode" not in raw_request:
            raise ValueError("mode is required")
        environment_bytes = args.environment.read_bytes() if args.environment else None
        environment = (
            json.loads(environment_bytes)
            if environment_bytes is not None
            else {
                name: os.environ[name] for name in OVERLAP_NAMES if name in os.environ
            }
        )
        if not isinstance(environment, dict) or any(
            name not in OVERLAP_NAMES or not isinstance(value, str)
            for name, value in environment.items()
        ):
            raise ValueError(
                "environment JSON must map only the eight HCCL names to strings"
            )
        plan = build_plan(RecipeRequest.from_mapping(raw_request), environment)
        plan["inputs"] = {
            "request_path": str(args.request.resolve()),
            "request_sha256": hashlib.sha256(request_bytes).hexdigest(),
            "environment_source": "file" if args.environment else "process snapshot",
            "environment_path": (
                str(args.environment.resolve()) if args.environment else None
            ),
            "environment_sha256": (
                hashlib.sha256(environment_bytes).hexdigest()
                if environment_bytes is not None
                else None
            ),
        }
        if args.model:
            plan["checkpoint_config"] = checkpoint_config_identity(args.model)
        lock_path = repo / ".agents/dsv41/sources.lock.json"
        lock_bytes = lock_path.read_bytes()
        lock = json.loads(lock_bytes)["repositories"]
        for name, commit in (
            ("vllm", VLLM_COMMIT),
            ("vllm_ascend", ASCEND_COMMIT),
            ("hccl_donor", DONOR_COMMIT),
        ):
            if lock[name]["commit"] != commit:
                raise ValueError(
                    f"source lock changed: review {name} prediction before use"
                )
        plan["local_identity"] = {
            str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (
                Path(__file__).resolve(),
                lock_path,
                repo / "afd_plugin/distributed/hccl.py",
                repo / "afd_plugin/distributed/topology.py",
                repo / "afd_plugin/config.py",
                repo / "afd_plugin/connectors/npu/hccl_overlap.py",
            )
        }
        exit_code = 0
    except (OSError, ValueError, TypeError, KeyError) as error:
        plan = {
            "plan_validation_success": False,
            "runtime_admission_checked": False,
            "actual_effective_values_observed": False,
            "npu_execution_performed": False,
            "error_type": type(error).__name__,
            "error": str(error),
        }
        exit_code = 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(plan, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"plan_validation_success={exit_code == 0}; output={args.output}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
