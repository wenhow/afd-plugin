# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Collect QLI V2 ELF/OPP availability without importing or initializing NPU."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path

SYMBOLS = (
    "aclnnVllmAscendQuantLightningIndexerV2",
    "aclnnVllmAscendQuantLightningIndexerV2GetWorkspaceSize",
    "aclnnQuantLightningIndexerV2",
    "aclnnQuantLightningIndexerV2GetWorkspaceSize",
    "aclnnQuantLightningIndexerV2Metadata",
    "aclnnQuantLightningIndexerV2MetadataGetWorkspaceSize",
)
COMMAND_TIMEOUT_SECONDS = 30


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def inspect_library(path: Path) -> dict:
    record = {"path": str(path), "exists": path.is_file()}
    if not record["exists"]:
        return record
    record["resolved_path"] = str(path.resolve(strict=True))
    record["sha256_before"] = digest(path)
    command = ["nm", "-D", "--defined-only", str(path)]
    result = subprocess.run(
        command, capture_output=True, text=True, timeout=COMMAND_TIMEOUT_SECONDS
    )
    exports = {
        line.split()[-1].split("@")[0]
        for line in result.stdout.splitlines()
        if line.split()
    }
    record.update(
        command=command,
        returncode=result.returncode,
        stderr=result.stderr,
        defined_symbols={symbol: symbol in exports for symbol in SYMBOLS},
        sha256_after=digest(path),
    )
    record["unchanged"] = record["sha256_before"] == record["sha256_after"]
    return record


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--cann-home", type=Path, required=True)
    args = parser.parse_args()
    package = args.package.resolve(strict=True)
    cann_home = args.cann_home.resolve(strict=True)
    vendor = package / "vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
    libraries = (
        vendor / "op_api/lib/libcust_opapi.so",
        cann_home / "lib64/libopapi.so",
    )
    records = [inspect_library(path) for path in libraries]
    matching_paths = [
        {"path": str(path.relative_to(vendor)), "sha256": digest(path)}
        for path in sorted(vendor.rglob("*lightning*"))
        if path.is_file()
    ]
    opp_config = (
        vendor / "op_impl/ai_core/tbe/config/ascend910_93/"
        "aic-ascend910_93-ops-info.json"
    )
    config_bytes = opp_config.read_bytes()
    config = json.loads(config_bytes)
    related_ops = {
        name: definition
        for name, definition in config.items()
        if "lightning" in name.lower()
    }
    inspected = all(
        record["exists"] and record["returncode"] == 0 and record["unchanged"]
        for record in records
    )
    custom = records[0]
    custom_exports_present = inspected and all(
        custom["defined_symbols"][symbol] for symbol in SYMBOLS[:2]
    )
    print(
        json.dumps(
            {
                "package": str(package),
                "cann_home": str(cann_home),
                "libraries": records,
                "opp_config": {
                    "path": str(opp_config),
                    "sha256_before": hashlib.sha256(config_bytes).hexdigest(),
                    "sha256_after": digest(opp_config),
                    "related_ops": related_ops,
                },
                "related_vendor_files": matching_paths,
                "inspection_completed": inspected,
                "exact_custom_api_exports_present": custom_exports_present,
                "npu_imported_or_initialized": False,
                "kernel_executed": False,
                "native_component_accepted": False,
            },
            indent=2,
            sort_keys=True,
        )
    )
    return 0 if inspected else 1


if __name__ == "__main__":
    raise SystemExit(main())
