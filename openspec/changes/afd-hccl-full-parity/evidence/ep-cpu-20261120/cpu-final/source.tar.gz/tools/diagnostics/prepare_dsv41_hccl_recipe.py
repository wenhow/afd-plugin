#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Prepare frozen A/F argv and environment JSON; never execute either role.

Use the recipe planner's request and optional eight-setting environment JSON.
--model-path and --repo-path are absolute POSIX paths on the target host;
--model-config optionally identifies a local config.json without reading weights.
Only same-host placement, one native TP world per role and DSpark/PD off are
projected onto the existing standalone FFN entry point. Model admission remains
closed: the emitted environment explicitly disables the qualification opt-in.

Example (CPU only, including under python -S):
  python prepare_dsv41_hccl_recipe.py --request request.json --output recipe.json \
    --model-path /models/DeepSeek-V4.1-Flash --repo-path /workspace/afd-plugin
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path, PurePosixPath

# This CLI and the planner share a directory; importing the planner is stdlib
# only. Its CPU rank-mapping imports happen after main adds the checkout path.
import plan_dsv41_hccl_recipe as planner

JSONValue = planner.JSONValue
MAX_TCP_PORT = 65_535
DEFAULT_API_PORT = 18_031
DEFAULT_AFD_PORT = 29_600
DEFAULT_ATTENTION_MASTER_PORT = 29_501
DEFAULT_FFN_MASTER_PORT = 29_511
DEFAULT_ATTENTION_RPC_PORT = 29_550
DEFAULT_FFN_RPC_PORT = 29_560
DEFAULT_ATTENTION_VLLM_PORT = 29_700
DEFAULT_FFN_VLLM_PORT = 29_800
PROCESS_GROUP_TIMEOUT_SECONDS = 1_200
SHUTDOWN_TIMEOUT_SECONDS = 180
SUPPORTED_EAGER_PIPELINE_TP = (1, 2)
PLUGINS = (
    "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,"
    "ascend_service_profiling,afd"
)


def target_path(value: str, name: str) -> str:
    if (
        not PurePosixPath(value).is_absolute()
        or "\\" in value
        or any(character in value for character in ("\x00", "\n", "\r"))
    ):
        raise ValueError(f"{name} must be an absolute POSIX target path")
    return value


def source_identity(repo: Path) -> dict[str, JSONValue]:
    lock_path = repo / ".agents/dsv41/sources.lock.json"
    lock = json.loads(lock_path.read_bytes())["repositories"]
    contracts = {
        "vllm": planner.VLLM_COMMIT,
        "vllm_ascend": planner.ASCEND_COMMIT,
        "hccl_donor": planner.DONOR_COMMIT,
    }
    for name, commit in contracts.items():
        if lock[name]["commit"] != commit:
            raise ValueError(f"source lock changed: review {name} before preparation")
    plugin_python_paths = tuple(sorted((repo / "afd_plugin").rglob("*.py")))
    paths = (
        Path(__file__).resolve(),
        Path(planner.__file__).resolve(),
        lock_path,
        *plugin_python_paths,
    )
    return {
        "contracts": contracts,
        "files": {
            str(path.relative_to(repo)).replace("\\", "/"): hashlib.sha256(
                path.read_bytes()
            ).hexdigest()
            for path in paths
        },
        "plugin_python_source_scope": "all checkout afd_plugin Python files",
        "plugin_python_source_files": len(plugin_python_paths),
        "runtime_imports_performed": False,
        "native_cli_parsing_performed": False,
        "installed_sources_checked": False,
    }


def port_allocations(args: argparse.Namespace, tp_size: int) -> dict[str, JSONValue]:
    allocations = {
        "api": [args.api_port],
        # Reserve every legacy U1 pair port too, even when staged uses one store.
        "afd": list(range(args.afd_port, args.afd_port + tp_size)),
        "attention_master": [args.attention_master_port],
        "ffn_master": [args.ffn_master_port],
        "attention_rpc": [args.attention_rpc_port],
        "ffn_rpc": [args.ffn_rpc_port],
        "attention_vllm": [args.attention_vllm_port],
        "ffn_vllm": [args.ffn_vllm_port],
    }
    occupied: dict[int, str] = {}
    for name, ports in allocations.items():
        for port in ports:
            if not 1 <= port <= MAX_TCP_PORT:
                raise ValueError(f"{name} port must be in 1..{MAX_TCP_PORT}")
            if port in occupied:
                raise ValueError(f"port {port} collides: {occupied[port]} and {name}")
            occupied[port] = name
    return {"allocations": allocations, "availability_checked": False}


def common_argv(
    request: planner.RecipeRequest, plan: dict[str, JSONValue]
) -> list[str]:
    compilation: dict[str, JSONValue] = {
        "mode": 0,
        "cudagraph_mode": ("NONE" if request.mode == "eager" else "FULL_DECODE_ONLY"),
        "pass_config": {"enable_sp": False},
        "use_inductor_graph_partition": False,
    }
    if request.mode == "full-decode-only":
        # Supply the raw recipe buckets to native's first normalization layer.
        # The planner's V2 descriptors are predictions, not CLI capture sizes.
        compilation["cudagraph_capture_sizes"] = plan["capture"]["recipe_raw_sizes"]
        compilation["max_cudagraph_capture_size"] = plan["capture"][
            "native_config_maximum"
        ]
    return [
        "--tensor-parallel-size",
        str(request.native_tp_size),
        "--pipeline-parallel-size",
        "1",
        "--data-parallel-size",
        "1",
        "--data-parallel-size-local",
        "1",
        "--prefill-context-parallel-size",
        "1",
        "--decode-context-parallel-size",
        "1",
        "--distributed-executor-backend",
        "mp",
        "--no-enable-expert-parallel",
        "--enable-dbo" if request.num_stages == 2 else "--no-enable-dbo",
        "--ubatch-size",
        "0",
        "--dbo-decode-token-threshold",
        str(request.dbo_decode_token_threshold),
        "--dbo-prefill-token-threshold",
        str(request.dbo_prefill_token_threshold),
        "--language-model-only",
        "--dtype",
        "bfloat16",
        "--quantization",
        "deepseek_v4_fp8",
        "--load-format",
        "safetensors",
        "--tokenizer-mode",
        "deepseek_v41",
        "--trust-remote-code",
        # With chunked prefill disabled, native requires a budget covering the
        # model length. Do not pair a small recipe budget with a hidden 1024.
        "--max-model-len",
        str(request.max_num_batched_tokens),
        "--max-num-seqs",
        str(request.max_num_seqs),
        "--max-num-batched-tokens",
        str(request.max_num_batched_tokens),
        "--no-async-scheduling",
        "--no-enable-prefix-caching",
        "--no-enable-chunked-prefill",
        "--generation-config",
        "vllm",
        "--enforce-eager" if request.mode == "eager" else "--no-enforce-eager",
        "--compilation-config",
        json.dumps(compilation, sort_keys=True),
        "--shutdown-timeout",
        str(SHUTDOWN_TIMEOUT_SECONDS),
    ]


def build_manifest(
    args: argparse.Namespace,
    request: planner.RecipeRequest,
    environment: dict[str, str],
) -> dict[str, JSONValue]:
    if request.attention_host_id != request.ffn_host_id:
        raise ValueError(
            "standalone recipe preparation currently requires same-host roles"
        )
    if (
        len(request.attention_devices) != request.native_tp_size
        or len(request.ffn_devices) != request.native_tp_size
    ):
        raise ValueError(
            "standalone DP1 recipe requires each role device count == native_tp_size"
        )
    if request.num_speculative_tokens != 0:
        raise ValueError(
            "standalone FFN entry requires DSpark off (num_speculative_tokens=0)"
        )
    if request.max_num_batched_tokens < request.max_num_seqs:
        raise ValueError("token budget must cover the whole uniform decode parent")
    model, cwd = (
        target_path(args.model_path, "model-path"),
        target_path(args.repo_path, "repo-path"),
    )
    for name, value in (
        ("python", args.python),
        ("afd-host", args.afd_host),
        ("api-host", args.api_host),
    ):
        if not value.strip() or any(char in value for char in ("\x00", "\n", "\r")):
            raise ValueError(f"{name} must be nonempty without control characters")
    if args.afd_host in ("0.0.0.0", "::"):
        raise ValueError("afd-host must be a rendezvous destination, not a wildcard")
    plan = planner.build_plan(request, environment)
    frozen = {
        name: "1" if plan["overlap"]["configured"][name] else "0"
        for name in planner.OVERLAP_NAMES
    }
    if (
        request.mode == "eager"
        and request.num_stages == 2
        and frozen[planner.OVERLAP_NAMES[0]] == "1"
        and request.native_tp_size not in SUPPORTED_EAGER_PIPELINE_TP
    ):
        raise ValueError("eager U2 overlap=1 requires paired native TP1 or TP2")
    ports = port_allocations(args, request.native_tp_size)
    common = common_argv(request, plan)
    shared_environment = {
        **frozen,
        "VLLM_USE_V2_MODEL_RUNNER": "1",
        "VLLM_PLUGINS": PLUGINS,
        "VLLM_WORKER_MULTIPROC_METHOD": "spawn",
        "VLLM_WORKER_SHUTDOWN_TIMEOUT_SECONDS": str(SHUTDOWN_TIMEOUT_SECONDS),
        "VLLM_ASCEND_ENABLE_FLASHCOMM1": "0",
        "AFD_DSV41_EAGER_QUALIFICATION": "0",
        "AFD_DSV41_MXFP8_SCALE_PATCH": "0",
        "PYTHONUNBUFFERED": "1",
    }
    roles: dict[str, JSONValue] = {}
    for role, devices, master, rpc, native_port in (
        (
            "attention",
            request.attention_devices,
            args.attention_master_port,
            args.attention_rpc_port,
            args.attention_vllm_port,
        ),
        (
            "ffn",
            request.ffn_devices,
            args.ffn_master_port,
            args.ffn_rpc_port,
            args.ffn_vllm_port,
        ),
    ):
        additional = {
            "afd": {
                "role": role,
                "connector": "P2pHcclAFDConnector",
                "host": args.afd_host,
                "port": args.afd_port,
                "num_attention_ranks": len(request.attention_devices),
                "num_ffn_ranks": len(request.ffn_devices),
                "compute_gate_on_attention": False,
                "afd_process_group_timeout_s": PROCESS_GROUP_TIMEOUT_SECONDS,
                "connector_extra_config": {
                    "max_tokens": request.max_num_batched_tokens
                },
            },
            "enable_cpu_binding": False,
            "enable_flashcomm1": False,
            "enable_dsa_cp": False,
        }
        entry = (
            [
                "-m",
                "vllm.entrypoints.cli.main",
                "serve",
                model,
                "--host",
                args.api_host,
                "--port",
                str(args.api_port),
            ]
            if role == "attention"
            else ["-m", "afd_plugin.entrypoints.npu_ffn", "--model", model]
        )
        roles[role] = {
            "host_id": request.attention_host_id,
            "cwd": cwd,
            "devices": list(devices),
            "rank_mapping": plan["topology"]["roles"][role]["ranks"],
            "argv": [
                args.python,
                "-B",
                *entry,
                *common,
                "--master-port",
                str(master),
                "--data-parallel-rpc-port",
                str(rpc),
                "--additional-config",
                json.dumps(additional, sort_keys=True),
            ],
            "environment": {
                **shared_environment,
                "ASCEND_RT_VISIBLE_DEVICES": ",".join(map(str, devices)),
                "VLLM_PORT": str(native_port),
            },
        }
    return {
        "schema_version": 1,
        "preparation_success": True,
        "runtime_admission_checked": False,
        "execution_performed": False,
        "npu_execution_performed": False,
        "full_model_qualification": False,
        "plan": plan,
        "frozen_environment": frozen,
        "frozen_environment_sha256": hashlib.sha256(
            json.dumps(frozen, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
        "roles": roles,
        "ports": ports,
        "limits": [
            "Prepared argv only: native CLI parsing, model admission, operators, "
            "weights, resources and network availability were not validated.",
            "The model guard and qualification opt-in remain closed; these "
            "commands are not a supported full-model service recipe.",
            "The explicit environment overlays a separately prepared CANN/vendor "
            "environment. It must override inherited values for both roles.",
            "Only the eight HCCL settings and explicit manifest options are "
            "frozen. Other Ascend-native defaults, Engram, quantization and "
            "operator environments do not reproduce the old A5 qualification "
            "candidate or establish full native configuration/numerical parity.",
            "Legacy eager U1 retains its pair protocol. Configured startup "
            "records, staged per-parent diagnostics and actual overlap are "
            "distinct evidence.",
            "DSpark, PD, cross-host placement and multiple TP groups per role "
            "are excluded from this standalone entry-point projection.",
        ],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--model-path", required=True, help="absolute POSIX target model path"
    )
    parser.add_argument(
        "--repo-path", required=True, help="absolute POSIX target checkout path"
    )
    parser.add_argument(
        "--model-config", type=Path, help="optional local config.json identity only"
    )
    parser.add_argument(
        "--environment", type=Path, help="optional eight-setting JSON snapshot"
    )
    parser.add_argument("--python", default="python3", help="target Python executable")
    parser.add_argument("--afd-host", default="127.0.0.1")
    parser.add_argument("--api-host", default="127.0.0.1")
    for name, default in (
        ("api-port", DEFAULT_API_PORT),
        ("afd-port", DEFAULT_AFD_PORT),
        ("attention-master-port", DEFAULT_ATTENTION_MASTER_PORT),
        ("ffn-master-port", DEFAULT_FFN_MASTER_PORT),
        ("attention-rpc-port", DEFAULT_ATTENTION_RPC_PORT),
        ("ffn-rpc-port", DEFAULT_FFN_RPC_PORT),
        ("attention-vllm-port", DEFAULT_ATTENTION_VLLM_PORT),
        ("ffn-vllm-port", DEFAULT_FFN_VLLM_PORT),
    ):
        parser.add_argument(f"--{name}", type=int, default=default)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parents[2]
    planner.protect_output(
        parser, args.output, (args.request, args.environment, args.model_config)
    )
    sys.path.insert(0, str(repo))
    try:
        request_bytes = args.request.read_bytes()
        raw_request = json.loads(request_bytes)
        if not isinstance(raw_request, dict):
            raise ValueError("request JSON must be an object")
        environment_bytes = args.environment.read_bytes() if args.environment else None
        environment = (
            json.loads(environment_bytes)
            if environment_bytes is not None
            else {
                name: os.environ[name]
                for name in planner.OVERLAP_NAMES
                if name in os.environ
            }
        )
        if not isinstance(environment, dict) or any(
            name not in planner.OVERLAP_NAMES or not isinstance(value, str)
            for name, value in environment.items()
        ):
            raise ValueError(
                "environment JSON must map only the eight HCCL names to strings"
            )
        manifest = build_manifest(
            args, planner.RecipeRequest.from_mapping(raw_request), environment
        )
        manifest["inputs"] = {
            "request_path": str(args.request.resolve()),
            "request_sha256": hashlib.sha256(request_bytes).hexdigest(),
            "environment_source": "file" if args.environment else "process snapshot",
            "environment_path": str(args.environment.resolve())
            if args.environment
            else None,
            "environment_sha256": hashlib.sha256(environment_bytes).hexdigest()
            if environment_bytes is not None
            else None,
            "target_model_path": args.model_path,
            "target_repo_path": args.repo_path,
        }
        if args.model_config is not None:
            if args.model_config.name != "config.json":
                raise ValueError("model-config must name a local config.json file")
            manifest["model_config_identity"] = planner.checkpoint_config_identity(
                args.model_config.parent
            )
        manifest["source_identity"] = source_identity(repo)
        exit_code = 0
    except (OSError, ValueError, TypeError, KeyError) as error:
        manifest = {
            "schema_version": 1,
            "preparation_success": False,
            "runtime_admission_checked": False,
            "execution_performed": False,
            "npu_execution_performed": False,
            "full_model_qualification": False,
            "error_type": type(error).__name__,
            "error": str(error),
        }
        exit_code = 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"preparation_success={exit_code == 0}; output={args.output}")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
