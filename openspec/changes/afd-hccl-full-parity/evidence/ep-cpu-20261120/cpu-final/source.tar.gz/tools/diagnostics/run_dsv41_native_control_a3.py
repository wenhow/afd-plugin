# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Freeze or explicitly execute a single native BF16 C2 control on A3.

Default/help and preparation use stdlib only. The native control keeps the
diagnostic launch synchronization and metadata observations of execute003;
it measures neither performance nor AFD numerical equivalence. Execution is
explicit and requires the already frozen capsule and existing native package.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import runpy
import shlex
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback
from pathlib import Path, PurePosixPath

DRIVER = "tools/diagnostics/run_dsv41_native_control_a3.py"
PROBE = "tests/npu/dsv41_normal_native_probe.py"
PROBE_SHA = "907dc82fb4a13a221d49d09a1c3a63d64358535d5c7fe673a49b1ab0ab58472c"
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-text-normal-worker-20261116"
PARENT = FAMILY + "/prepared-execute-003/source.tar.gz"
PARENT_SHA = "8361ef3091efff2bb2fb93d2c4bedf98a2c066502668e47c22c0cf85562f7623"
CPU_DRIVER = ".tmp/run_text_normal_worker_cpu_a3.py"
CPU_SHA = "de451cc4a415bfb0fa9102eae6829f27da36bbeb3670769f0fe348b34d5929eb"
DEVICE_DRIVER = ".tmp/run_text_normal_worker_device_a3.py"
DEVICE_SHA = "7e1261d24850df592f8160602f6433c825f1d070e8e456dbc8a3c291b3add60b"
EXECUTE_DRIVER = ".tmp/run_text_normal_execute_a3.py"
EXECUTE_SHA = "00d0aede311a7e3abd3ab3dcb5609df76be060ca43406fb0b6fbc7fe7f51964e"
ENVIRONMENT = ".tmp/normal-execute-environment.json"
ENVIRONMENT_SHA = "70417471b4595fcf38198df89147a5314dfbf569b2bbe2f3dd1cd1303b25052c"
MODEL = "/mnt/workspace/models/DeepSeek-V4.1-Flash"
PYTHON = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0/bin/python"
NATIVE_PLUGINS = (
    "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,"
    "ascend_service_profiling"
)
QUALIFICATION_ENVIRONMENTS = (
    "AFD_DSV41_DUMMY_QUALIFICATION",
    "AFD_DSV41_EAGER_QUALIFICATION",
)
SOURCE_FILES = 460
PRODUCTION_FILES = 146
INSTALLED_IDENTITIES = 197
READONLY_IDENTITIES = 3753
EXPECTED_IDLE_BOARDS = 8
CHUNK_BYTES = 64 * 1024
DEFAULT_TIMEOUT_SECONDS = 360
MAX_TIMEOUT_SECONDS = 600
SSH_GRACE_SECONDS = 180
COMPLETION_POLL_SECONDS = 60
POLL_SECONDS = 0.2
REAP_SECONDS = 10
MAX_ARCHIVE_BYTES = 32 * 1024 * 1024


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + "\n", "utf-8")


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


@contextlib.contextmanager
def frozen_helpers(raw: bytes):
    """Load only SHA-locked stdlib helpers; never change their module globals."""
    if len(raw) > MAX_ARCHIVE_BYTES:
        raise ValueError("source archive exceeds the capsule size limit")
    with tempfile.TemporaryDirectory(prefix="native-control-helpers-") as temporary:
        root = Path(temporary)
        with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as stream:
            bootstrap = stream.extractfile(CPU_DRIVER).read()
        assert sha(bootstrap) == CPU_SHA
        cpu_path = root / CPU_DRIVER
        cpu_path.parent.mkdir(parents=True)
        cpu_path.write_bytes(bootstrap)
        cpu = load_module("native_control_frozen_cpu", cpu_path)
        files, manifest = cpu.read_archive(raw)
        for name, digest in (
            (DEVICE_DRIVER, DEVICE_SHA),
            (EXECUTE_DRIVER, EXECUTE_SHA),
        ):
            assert manifest[name] == digest, name
        for name in (DEVICE_DRIVER, EXECUTE_DRIVER, cpu.BASE):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(files[name])
        device = load_module("native_control_frozen_device", root / DEVICE_DRIVER)
        execute = load_module("native_control_frozen_execute", root / EXECUTE_DRIVER)
        base = load_module("native_control_frozen_ssh", root / cpu.BASE)
        yield files, manifest, cpu, device, execute, base


def capsule_record(files, manifest, execute, device):
    assert len(files) == SOURCE_FILES
    assert manifest[CPU_DRIVER] == CPU_SHA
    assert manifest[PROBE] == PROBE_SHA
    assert manifest[ENVIRONMENT] == ENVIRONMENT_SHA
    assert len([name for name in files if name.startswith("afd_plugin/")]) == (
        PRODUCTION_FILES
    )
    previous_raw = files[device.ENVIRONMENT_RECORD]
    assert sha(previous_raw) == device.ENVIRONMENT_RECORD_SHA
    record = json.loads(files[ENVIRONMENT])
    previous = json.loads(previous_raw)
    execute.validate_environment_record(record, previous, sha(previous_raw))
    return record, previous


def prepare(args) -> int:
    root = args.repo_root.resolve()
    raw = (root / PARENT).read_bytes()
    assert sha(raw) == PARENT_SHA
    with frozen_helpers(raw) as (parent, _, cpu, device, execute, _):
        assert len(parent) == SOURCE_FILES - 2
        files = dict(parent)
        assert DRIVER not in files and PROBE not in files
        files[DRIVER] = (root / DRIVER).read_bytes()
        files[PROBE] = (root / PROBE).read_bytes()
        manifest = {name: sha(content) for name, content in sorted(files.items())}
        record, previous = capsule_record(files, manifest, execute, device)
        pins = {**cpu.source_pins(files), **dict(execute.ADDITIONAL_NATIVE_PINS)}
        assert len(pins) == INSTALLED_IDENTITIES
        for name, content in files.items():
            if name.endswith(".py"):
                compile(content, name, "exec")
        output = args.output_dir.resolve()
        output.mkdir(parents=True, exist_ok=False)
        packed = cpu.archive_bytes(files)
        (output / "source.tar.gz").write_bytes(packed)
        write_json(output / "manifest.json", manifest)
        preparation = {
            "source_archive_sha256": sha(packed),
            "parent_archive_path": PARENT,
            "parent_archive_sha256": PARENT_SHA,
            "parent_source_files": len(parent),
            "all_parent_members_byte_equal": all(
                files[n] == v for n, v in parent.items()
            ),
            "added_to_parent": [DRIVER, PROBE],
            "changed_parent_members": [],
            "source_files": len(files),
            "python_files_compiled": sum(n.endswith(".py") for n in files),
            "production_files": PRODUCTION_FILES,
            "production_parent_equal_count": PRODUCTION_FILES,
            "production_changes": {},
            "driver_sha256": manifest[DRIVER],
            "probe_sha256": manifest[PROBE],
            "native_source_identities": len(pins),
            "environment_record_sha256": manifest[ENVIRONMENT],
            "active_artifact_identities": len(record["active_artifacts"]),
            "previous_active_artifact_identities": len(previous["active_artifacts"]),
            "toolchain_atb_identities": len(record["toolchain_artifacts"]),
            "model": args.model,
            "python": args.python,
            "device": 0,
            "timeout_seconds": args.timeout,
            "native_plugins": NATIVE_PLUGINS,
            "removed_qualification_environment_keys": list(QUALIFICATION_ENVIRONMENTS),
            "prepared_only": True,
            "ssh_executed": False,
            "device_executed": False,
            "native_control_component_accepted": False,
            "numerical_equivalence_accepted": False,
            "full_checkpoint_accepted": False,
            "scope": (
                "single native Worker C2 dummy prefill/decode/sample/retirement control"
            ),
        }
        assert args.python == record["paths"]["python"]
        write_json(output / "preparation.json", preparation)
    print(json.dumps(preparation, indent=2))
    return 0


def native_environment(execute, snapshot, owned, record):
    env = execute.selected_environment(snapshot, owned, record)
    for key in QUALIFICATION_ENVIRONMENTS:
        env.pop(key, None)
    assert env["VLLM_PLUGINS"] == NATIVE_PLUGINS
    assert env["ASCEND_LAUNCH_BLOCKING"] == "1"
    return env


def native_child(args) -> int:
    root = args.remote_root.resolve()
    snapshot, results = root / "snapshot", root / "results"
    sys.path.insert(0, str(snapshot / "tests/npu"))
    report, code = {}, 1
    try:
        assert all(key not in os.environ for key in QUALIFICATION_ENVIRONMENTS)
        assert os.environ["VLLM_PLUGINS"] == NATIVE_PLUGINS
        sys.argv = [
            str(snapshot / PROBE),
            "--run",
            "--model",
            args.model,
            "--output-dir",
            str(results / "native"),
            "--device",
            "0",
            "--timeout",
            str(args.timeout),
        ]
        try:
            runpy.run_path(str(snapshot / PROBE), run_name="__main__")
            code = 0
        except SystemExit as error:
            code = error.code if type(error.code) is int else 1
    except BaseException:
        report["original_exception"] = traceback.format_exc()
        raise
    finally:
        report["returncode"] = code
        report["afd_modules_imported"] = sorted(
            name
            for name in sys.modules
            if name == "afd_plugin" or name.startswith("afd_plugin.")
        )
        report["qualification_environment_keys_present"] = [
            key for key in QUALIFICATION_ENVIRONMENTS if key in os.environ
        ]
        report["native_plugins"] = os.environ.get("VLLM_PLUGINS")
        record = json.loads((snapshot / ENVIRONMENT).read_text())
        paths = record["paths"]
        report["modules"] = {
            name: {
                "path": str(Path(module.__file__).resolve()),
                "sha256": sha(Path(module.__file__).read_bytes()),
            }
            for name, module in tuple(sys.modules.items())
            if name in ("vllm", "vllm_ascend", "torch_npu")
            and module.__file__ is not None
        }
        mapped, forbidden = {}, []
        for line in Path("/proc/self/maps").read_text().splitlines():
            name = line.split()[-1]
            if ".so" not in name or not name.startswith("/"):
                continue
            if (
                name.startswith(paths["parent_root"] + "/package/")
                or name.startswith(paths["previous_active_root"] + "/package/")
                or "/cann-9.0.1/" in name
            ):
                forbidden.append(name)
            if any(
                token in name
                for token in ("/vllm_ascend/", "/torch_npu/", "/cann-9.2.0/")
            ):
                path = Path(name).resolve(strict=True)
                mapped[str(path)] = sha(path.read_bytes())
        report["mapped_native_libraries"] = mapped
        report["forbidden_parent_or_cann90_mappings"] = sorted(set(forbidden))
        write_json(results / "native-runtime.json", report)
    return code


def supervise_native(args, device, snapshot, results, env):
    command = [
        args.python,
        "-B",
        str(args.remote_root / "runner.py"),
        "--native-child",
        "--remote-root",
        str(args.remote_root),
        "--model",
        args.model,
        "--python",
        args.python,
        "--timeout",
        str(args.timeout),
    ]
    started = time.monotonic()
    owned, killed, timed_out, error = {}, [], False, None
    with (results / "native.log").open("wb") as log:
        child = subprocess.Popen(
            command,
            cwd=snapshot,
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        try:
            device.observe_owned(child.pid, owned)
            write_json(
                results / "native-process.json",
                {
                    "pid": child.pid,
                    "start_ticks": owned[child.pid],
                    "command": command,
                },
            )
            while child.poll() is None:
                device.observe_owned(child.pid, owned)
                if time.monotonic() - started >= args.timeout:
                    timed_out = True
                    raise TimeoutError("native control child deadline expired")
                time.sleep(POLL_SECONDS)
        except BaseException:
            error = traceback.format_exc()
        finally:
            killed.extend(device.kill_owned(owned))
            child.wait(timeout=REAP_SECONDS)
    result = {
        "command": command,
        "pid": child.pid,
        "returncode": child.returncode,
        "owned_pid_start_ticks": owned,
        "timed_out": timed_out,
        "killed_owned_pids": killed,
        "surviving_owned_pids": device.live_owned(owned),
        "error": error,
        "elapsed_seconds": time.monotonic() - started,
    }
    write_json(results / "native-supervision.json", result)
    return result


def verify_native_result(report, runtime, record, execute):
    for name in (
        "success",
        "run",
        "native_control_component_accepted",
        "model_loaded",
        "normal_native_init_device_completed",
        "normal_native_load_model_returned",
        "attention_kv_initialized",
        "inference_executed",
        "loaded_parameters_unchanged",
        "native_scheduler_prefill_decode_retirement_accepted",
        "native_groups_destroyed",
    ):
        assert report[name] is True, name
    assert report["cleanup_failures"] == []
    assert report["actual_device"] == "npu:0"
    assert report["loaded_model"]["parameter_count"] == 79
    assert (
        report["loaded_parameters_after_execution"]
        == report["loaded_model"]["parameters"]
    )
    assert report["worker_class"]["qualified_name"] == (
        "vllm_ascend.worker.worker.NPUWorker"
    )
    assert report["runner_class"]["qualified_name"] == (
        "vllm_ascend.worker.v2.model_runner.NPUModelRunner"
    )
    for name in (
        "cross_role_weight_equivalence_verified",
        "numerical_equivalence_accepted",
        "full_checkpoint_accepted",
        "afd_configuration_created",
        "afd_runtime_bootstrap_called",
    ):
        assert report[name] is False, name
    assert runtime["returncode"] == 0
    assert runtime["afd_modules_imported"] == []
    assert runtime["qualification_environment_keys_present"] == []
    assert runtime["native_plugins"] == NATIVE_PLUGINS
    assert runtime["forbidden_parent_or_cann90_mappings"] == []
    paths = record["paths"]
    origin = runtime["modules"]["vllm_ascend"]["path"]
    assert origin.startswith(paths["active_package"] + "/vllm_ascend/")
    mapped = runtime["mapped_native_libraries"]
    extension = str(
        PurePosixPath(paths["active_package"]) / execute.EXTENSION_RELATIVE_PATH
    )
    assert mapped[extension] == record["expected_native_library_sha256"][extension]
    assert any(
        mapped.get(str(PurePosixPath(paths["active_package"]) / name))
        == record["expected_direct_library_sha256"]
        for name in execute.DIRECT_LIBRARY_RELATIVE_PATHS
    )


def run_remote(args) -> int:
    root = args.remote_root.resolve()
    raw = (root / "source.tar.gz").read_bytes()
    preparation = json.loads((root / "preparation.json").read_text())
    with frozen_helpers(raw) as (files, manifest, cpu, device, execute, _):
        assert sha(raw) == preparation["source_archive_sha256"]
        assert manifest[DRIVER] == sha(Path(__file__).read_bytes())
        assert (args.model, args.python, args.timeout) == (
            preparation["model"],
            preparation["python"],
            preparation["timeout_seconds"],
        )
        record, previous = capsule_record(files, manifest, execute, device)
        snapshot, results = root / "snapshot", root / "results"
        snapshot.mkdir()
        results.mkdir()
        for name, content in files.items():
            path = snapshot / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)
        site = Path(args.python).parent.parent / "lib/python3.12/site-packages"
        native = {
            str(site / name): digest
            for name, digest in {
                **cpu.source_pins(files),
                **dict(execute.ADDITIONAL_NATIVE_PINS),
            }.items()
        }
        evidence, paths = record["required_custom_symbols_evidence"], record["paths"]
        assert len(native) == INSTALLED_IDENTITIES
        expected = {
            **native,
            **record["active_artifacts"],
            **previous["active_artifacts"],
            **record["toolchain_artifacts"],
            str(PurePosixPath(paths["parent_root"]) / paths["parent_record"]): record[
                "parent_record_sha256"
            ],
            evidence["path"]: evidence["sha256"],
        }
        assert len(expected) == READONLY_IDENTITIES
        source_before = {name: sha((snapshot / name).read_bytes()) for name in manifest}
        assert source_before == manifest
        write_json(results / "source-before.json", source_before)
        before, after, source_after, supervision = {}, {}, {}, {}
        idle_before, idle_after, readiness, error = 0, 0, None, None
        report, runtime, package_before, package_after = {}, {}, {}, {}
        started = time.monotonic()
        env = native_environment(execute, snapshot, root / "owned", record)

        def package_hashes():
            return {
                **{
                    str(p): sha(p.read_bytes())
                    for p in Path(paths["active_package"]).rglob("*")
                    if p.is_file()
                },
                paths["active_record"]: sha(Path(paths["active_record"]).read_bytes()),
            }

        def observe_idle(label):
            completed = subprocess.run(
                ["npu-smi", "info"], env=env, capture_output=True, timeout=30
            )
            (results / ("npu-" + label + ".log")).write_bytes(
                completed.stdout + completed.stderr
            )
            assert completed.returncode == 0
            return completed.stdout.count(b"No running processes found in NPU")

        try:
            before = {name: sha(Path(name).read_bytes()) for name in expected}
            write_json(results / "readonly-before.json", before)
            assert before == expected
            package_before = package_hashes()
            assert package_before == record["active_artifacts"]
            readiness = execute.verify_native_environment_files(record)
            write_json(results / "native-build-readiness.json", readiness)
            idle_before = observe_idle("before")
            assert idle_before == EXPECTED_IDLE_BOARDS
            write_json(results / "native-environment.json", env)
            supervision = supervise_native(args, device, snapshot, results, env)
            if (results / "native/result.json").is_file():
                report = json.loads((results / "native/result.json").read_text())
            if (results / "native-runtime.json").is_file():
                runtime = json.loads((results / "native-runtime.json").read_text())
            assert supervision["returncode"] == 0
            assert not supervision["timed_out"] and not supervision["killed_owned_pids"]
            assert (
                not supervision["surviving_owned_pids"] and supervision["error"] is None
            )
            verify_native_result(report, runtime, record, execute)
        except BaseException:
            error = traceback.format_exc()
        postflight_errors = []
        for phase, action in (
            ("idle", lambda: observe_idle("after")),
            (
                "readonly",
                lambda: {name: sha(Path(name).read_bytes()) for name in expected},
            ),
            (
                "source",
                lambda: {
                    name: sha((snapshot / name).read_bytes()) for name in manifest
                },
            ),
            ("package", package_hashes),
        ):
            try:
                value = action()
                if phase == "idle":
                    idle_after = value
                elif phase == "readonly":
                    after = value
                elif phase == "source":
                    source_after = value
                else:
                    package_after = value
            except BaseException:
                postflight_errors.append(
                    {"phase": phase, "traceback": traceback.format_exc()}
                )
        write_json(results / "readonly-after.json", after)
        write_json(results / "source-after.json", source_after)
        success = bool(
            error is None
            and not postflight_errors
            and before == after == expected
            and source_after == manifest
            and package_before == package_after == record["active_artifacts"]
            and idle_before == idle_after == EXPECTED_IDLE_BOARDS
        )
        summary = {
            "success": success,
            "native_control_component_accepted": success,
            "source_archive_sha256": sha(raw),
            "source_files": len(files),
            "production_files": PRODUCTION_FILES,
            "production_changes": {},
            "all_parent_members_byte_equal": True,
            "installed_source_identities": len(native),
            "readonly_identities": len(expected),
            "environment_record_sha256": manifest[ENVIRONMENT],
            "readonly_unchanged": before == after == expected,
            "source_unchanged": source_before == source_after == manifest,
            "package_members_unchanged": package_before
            == package_after
            == record["active_artifacts"],
            "idle_boards_before": idle_before,
            "idle_boards_after": idle_after,
            "native_supervision": supervision,
            "error": error,
            "postflight_errors": postflight_errors,
            "native_build_readiness": readiness,
            "inference_executed": report.get("inference_executed") is True,
            "elapsed_seconds": time.monotonic() - started,
            "cross_role_weight_equivalence_verified": False,
            "numerical_equivalence_accepted": False,
            "full_checkpoint_accepted": False,
            "performance_measurement": False,
        }
        write_json(results / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if success else 1


def upload_source(base, remote: str, raw: bytes, execution: Path):
    blocks = []
    for offset in range(0, len(raw), CHUNK_BYTES):
        block = raw[offset : offset + CHUNK_BYTES]
        script = (
            "import hashlib,json,pathlib,sys;"
            f"p=pathlib.Path({remote!r})/'source.tar.gz';b=sys.stdin.buffer.read();"
            f"assert len(b)=={len(block)};"
            f"assert hashlib.sha256(b).hexdigest()=={sha(block)!r};"
            f"assert (p.stat().st_size if p.exists() else 0)=={offset};"
            f"f=p.open({'xb' if offset == 0 else 'ab'!r});f.write(b);f.close();"
            "print(json.dumps({'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}))"
        )
        reply = json.loads(base.ssh("python3 -c " + shlex.quote(script), block))
        assert reply == {"bytes": len(block), "sha256": sha(block)}
        blocks.append({"offset": offset, **reply})
    verify = (
        "import hashlib,pathlib;print(hashlib.sha256((pathlib.Path("
        + repr(remote)
        + ")/'source.tar.gz').read_bytes()).hexdigest())"
    )
    assert base.ssh("python3 -c " + shlex.quote(verify)).decode().strip() == sha(raw)
    write_json(
        execution / "upload.json", {"blocks": blocks, "archive_sha256": sha(raw)}
    )


def execute_prepared(args) -> int:
    prepared = args.execute_prepared.resolve()
    raw = (prepared / "source.tar.gz").read_bytes()
    preparation_raw = (prepared / "preparation.json").read_bytes()
    preparation = json.loads(preparation_raw)
    with frozen_helpers(raw) as (files, manifest, _, device, execute, base):
        assert sha(raw) == preparation["source_archive_sha256"]
        assert manifest[DRIVER] == sha(Path(__file__).read_bytes())
        capsule_record(files, manifest, execute, device)
        execution = prepared / args.execution_label
        execution.mkdir(exist_ok=False)
        create = (
            "import tempfile;print(tempfile.mkdtemp("
            "prefix='text-native-control-20261117-',dir="
            + repr(device.REMOTE_PARENT)
            + "))"
        )
        remote = base.ssh("python3 -c " + shlex.quote(create)).decode().strip()
        assert PurePosixPath(remote).parent == PurePosixPath(device.REMOTE_PARENT)
        write_json(
            execution / "identity.json",
            {
                "remote_root": remote,
                "source_archive_sha256": sha(raw),
                "preparation_sha256": sha(preparation_raw),
            },
        )
        upload_source(base, remote, raw, execution)
        inputs = {"runner.py": files[DRIVER], "preparation.json": preparation_raw}
        deliver = (
            "import json,pathlib,sys;root=pathlib.Path("
            + repr(remote)
            + ");data=json.loads(sys.stdin.buffer.read());"
            "[(root/n).write_bytes(bytes.fromhex(v)) for n,v in data.items()]"
        )
        base.ssh(
            "python3 -c " + shlex.quote(deliver),
            json.dumps({n: value.hex() for n, value in inputs.items()}).encode(),
        )
        command = [
            "python3",
            remote + "/runner.py",
            "--remote-root",
            remote,
            "--python",
            preparation["python"],
            "--model",
            preparation["model"],
            "--timeout",
            str(preparation["timeout_seconds"]),
        ]
        # The SSH launcher waits, but the bounded supervising driver has its
        # own session and durable stdout. Losing the launcher does not close
        # the driver's pipes or launch it a second time.
        launcher_timeout = preparation["timeout_seconds"] + SSH_GRACE_SECONDS - 30
        launch = (
            "import json,pathlib,subprocess;root=pathlib.Path("
            + repr(remote)
            + ");f=(root/'driver-launch.json').open('x');"
            "log=(root/'supervision.log').open('xb');p=subprocess.Popen("
            + repr(command)
            + ",stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,"
            "start_new_session=True,close_fds=True);"
            "s=pathlib.Path(f'/proc/{p.pid}/stat').read_text();"
            "ticks=s.rsplit(') ',1)[1].split()[19];"
            "json.dump({'pid':p.pid,'start_ticks':ticks},f);f.close();log.close();"
            f"print(p.wait(timeout={launcher_timeout}))"
        )
        ssh = [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=15",
            base.SSH_HOST,
        ]
        transport = {
            "driver_command": command,
            "ssh_command": [*ssh, "python3 -c " + shlex.quote(launch)],
            "returncode": None,
            "timed_out": False,
        }
        try:
            process = subprocess.run(
                [*ssh, "python3 -c " + shlex.quote(launch)],
                capture_output=True,
                timeout=preparation["timeout_seconds"] + SSH_GRACE_SECONDS,
            )
            transport["returncode"] = process.returncode
            log = process.stdout + process.stderr
        except subprocess.TimeoutExpired as error:
            transport["timed_out"] = True
            log = (error.stdout or b"") + (error.stderr or b"")
        (execution / "remote-output.log").write_bytes(log)
        write_json(execution / "transport.json", transport)
        marker_script = "\n".join(
            (
                "import json,pathlib",
                f"root=pathlib.Path({remote!r})",
                "def active(pid,ticks):",
                " try:",
                "  s=pathlib.Path(f'/proc/{pid}/stat').read_text()",
                "  f=s.rsplit(') ',1)[1].split()",
                "  return f[19]==str(ticks) and f[0]!='Z'",
                " except FileNotFoundError: return False",
                "marker=root/'driver-exit.json'",
                "result=None",
                "if marker.exists():",
                " m=json.loads(marker.read_text())",
                " owned={m['pid']:m['start_ticks']}",
                " p=root/'results/native-supervision.json'",
                " if p.exists():",
                "  owned.update(json.loads(p.read_text())['owned_pid_start_ticks'])",
                " p=root/'results/native-process.json'",
                " if p.exists():",
                "  n=json.loads(p.read_text());owned[n['pid']]=n['start_ticks']",
                " if not any(active(pid,tick) for pid,tick in owned.items()): result=m",
                "print(json.dumps(result))",
            )
        )
        deadline = time.monotonic() + COMPLETION_POLL_SECONDS
        marker = None
        while marker is None and time.monotonic() < deadline:
            try:
                observation = subprocess.run(
                    [*ssh, "python3 -c " + shlex.quote(marker_script)],
                    capture_output=True,
                    timeout=min(15, max(0.1, deadline - time.monotonic())),
                    check=True,
                )
                marker = json.loads(observation.stdout)
            except (subprocess.SubprocessError, ValueError):
                pass
            if marker is None:
                time.sleep(min(5, max(0, deadline - time.monotonic())))
        write_json(execution / "completion-observation.json", marker)
        if marker is None:
            print(
                "remote completion unconfirmed; results were not collected",
                file=sys.stderr,
            )
            return 1
        assert marker["source_archive_sha256"] == sha(raw)
        collect = (
            "import pathlib,sys,tarfile;root=pathlib.Path("
            + repr(remote)
            + ");names=['results','driver-exit.json','driver-process.json',"
            "'driver-launch.json','supervision.log','driver-failure.json'];"
            "stream=tarfile.open(fileobj=sys.stdout.buffer,"
            "mode='w|gz');"
            "[stream.add(root/n,arcname=n) for n in names if (root/n).exists()];"
            "stream.close()"
        )
        results_raw = base.ssh("python3 -c " + shlex.quote(collect))
        (execution / "results.tar.gz").write_bytes(results_raw)
        with tarfile.open(fileobj=io.BytesIO(results_raw), mode="r:gz") as stream:
            names = stream.getnames()
            if "results/summary.json" not in names:
                write_json(
                    execution / "collection-failure.json",
                    {
                        "reason": "remote driver finished without a result summary",
                        "completed_marker": marker,
                        "collected_members": names,
                    },
                )
                return 1
            summary = json.load(stream.extractfile("results/summary.json"))
        write_json(execution / "summary.json", summary)
        print(json.dumps(summary, indent=2))
        return (
            0
            if (
                transport["returncode"] == marker["returncode"] == 0
                and not transport["timed_out"]
                and summary["success"] is True
            )
            else 1
        )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--execute-prepared", type=Path)
    modes.add_argument("--remote-root", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--native-child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--repo-root", type=Path, default=Path(__file__).resolve().parents[2]
    )
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--execution-label", default="native-001")
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--python", default=PYTHON)
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS)
    args = parser.parse_args()
    if not 0 < args.timeout <= MAX_TIMEOUT_SECONDS:
        parser.error("--timeout must be in 1..600 seconds")
    if args.native_child and args.remote_root is None:
        parser.error("--native-child requires --remote-root")
    if args.prepare_only != (args.output_dir is not None):
        parser.error(
            "--prepare-only requires --output-dir, which belongs only to preparation"
        )
    if args.output_dir is not None and args.output_dir.exists():
        parser.error("--output-dir must be fresh")
    if not args.execution_label or any(
        c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.execution_label
    ):
        parser.error("--execution-label must be a safe lowercase name")
    if args.native_child:
        return native_child(args)
    if args.prepare_only:
        return prepare(args)
    if args.execute_prepared is not None:
        return execute_prepared(args)
    if args.remote_root is not None:
        root = args.remote_root.resolve()
        fields = Path("/proc/self/stat").read_text().rsplit(") ", 1)[1].split()
        write_json(
            root / "driver-process.json",
            {"pid": os.getpid(), "start_ticks": fields[19]},
        )
        code = 1
        try:
            code = run_remote(args)
        except BaseException:
            write_json(
                root / "driver-failure.json", {"traceback": traceback.format_exc()}
            )
            raise
        finally:
            write_json(
                root / "driver-exit.json",
                {
                    "returncode": code,
                    "pid": os.getpid(),
                    "start_ticks": fields[19],
                    "source_archive_sha256": sha((root / "source.tar.gz").read_bytes()),
                },
            )
        return code
    print(
        json.dumps(
            {
                "prepared_only": False,
                "runtime_imported": False,
                "ssh_executed": False,
                "device_executed": False,
                "native_control_component_accepted": False,
                "scope": (
                    "stdlib metadata; use --prepare-only, then --execute-prepared"
                ),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
