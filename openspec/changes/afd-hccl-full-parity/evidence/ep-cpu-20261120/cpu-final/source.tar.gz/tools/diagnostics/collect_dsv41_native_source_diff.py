#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Collect only native Python mismatches from an existing preflight report.

This stdlib-only command reads the reported package roots without importing
them. It neither initializes a device nor changes an installation or Git tree.
The archive is diagnostic evidence, not permission to ignore a source mismatch.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import platform
import subprocess
import sys
import tarfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

NATIVE_PACKAGES = ("vllm", "vllm_ascend", "torch_npu")
MAX_SOURCE_BYTES = 2 * 1024 * 1024
MAX_TOTAL_SOURCE_BYTES = 8 * 1024 * 1024
MAX_GIT_OUTPUT_BYTES = 2 * 1024 * 1024
GIT_TIMEOUT_SECONDS = 20
ARCHIVE_NAME = "native-source-diff.tar.gz"


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def json_bytes(value: dict) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")


def git_command(directory: Path, arguments: list[str]) -> dict:
    try:
        completed = subprocess.run(
            [
                "git",
                "--no-optional-locks",
                "-c",
                "diff.autoRefreshIndex=false",
                "-C",
                str(directory),
                *arguments,
            ],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=GIT_TIMEOUT_SECONDS,
            check=False,
        )
        if len(completed.stdout) + len(completed.stderr) > MAX_GIT_OUTPUT_BYTES:
            return {"available": False, "error": "Git output exceeds collection bound"}
        return {
            "available": completed.returncode == 0,
            "returncode": completed.returncode,
            "stdout": completed.stdout.decode("utf-8", errors="replace"),
            "stderr": completed.stderr.decode("utf-8", errors="replace"),
        }
    except (OSError, subprocess.TimeoutExpired) as error:
        return {"available": False, "error": str(error)}


def collect(args: argparse.Namespace) -> dict:
    report_path = args.runtime_report.resolve(strict=True)
    report_raw = report_path.read_bytes()
    runtime = json.loads(report_raw)
    roots = {
        name: Path(value).resolve(strict=True)
        for name, value in runtime["roots"].items()
        if name in NATIVE_PACKAGES
    }
    sources = runtime["sources"]
    selected = {
        name: record for name, record in sources.items() if record["matches"] is False
    }
    if not selected:
        raise ValueError("runtime report contains no native source mismatches")
    output = args.output_dir.resolve()
    if output.exists():
        raise ValueError("--output-dir must be a fresh directory")
    if any(output.is_relative_to(root) for root in roots.values()):
        raise ValueError("--output-dir must be outside native package roots")
    files, records, package_files = {}, {}, {}
    total_bytes = 0
    # Validate and read all inputs before creating output; report paths cannot
    # redirect collection outside a known package root or select other files.
    for name, record in sorted(selected.items()):
        relative = PurePosixPath(name)
        if (
            relative.is_absolute()
            or len(relative.parts) < 2
            or ".." in relative.parts
            or str(relative) != name
            or "\\" in name
            or ":" in name
            or relative.suffix != ".py"
            or relative.parts[0] not in roots
        ):
            raise ValueError(f"noncanonical native Python source: {name}")
        package = relative.parts[0]
        path = roots[package].joinpath(*relative.parts[1:]).resolve(strict=True)
        if not path.is_relative_to(roots[package]):
            raise ValueError(f"native source resolves outside package root: {name}")
        if path.stat().st_size > MAX_SOURCE_BYTES:
            raise ValueError(f"native source exceeds collection bound: {name}")
        raw = path.read_bytes()
        total_bytes += len(raw)
        if len(raw) > MAX_SOURCE_BYTES or total_bytes > MAX_TOTAL_SOURCE_BYTES:
            raise ValueError("native source collection exceeds byte bound")
        actual = sha256(raw)
        files["sources/" + name] = raw
        records[name] = {
            "path": str(path),
            "reported_path": record["path"],
            "expected_sha256": record["expected_sha256"],
            "preflight_sha256": record["sha256"],
            "collected_sha256": actual,
            "same_bytes_as_preflight": actual == record["sha256"],
            "matches_expected_now": actual == record["expected_sha256"],
            "bytes": len(raw),
        }
        package_files.setdefault(package, []).append(path)
    git = {}
    for package, paths in package_files.items():
        directory = roots[package]
        details = {"root": git_command(directory, ["rev-parse", "--show-toplevel"])}
        if details["root"]["available"]:
            git_root = Path(details["root"]["stdout"].strip()).resolve(strict=True)
            if output.is_relative_to(git_root):
                raise ValueError("--output-dir must be outside native Git repositories")
            names = [path.relative_to(git_root).as_posix() for path in paths]
            details.update(
                head=git_command(git_root, ["rev-parse", "HEAD"]),
                status=git_command(
                    git_root, ["status", "--porcelain=v1", "--", *names]
                ),
                tracked_diff=git_command(
                    git_root,
                    ["diff", "--no-ext-diff", "--no-textconv", "HEAD", "--", *names],
                ),
            )
        git[package] = details
    report = {
        "collection_success": True,
        "scope": "read-only native source collection; no compatibility acceptance",
        "runtime_imported": False,
        "device_initialized": False,
        "installed_sources_modified": False,
        "compatibility_accepted": False,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "collector_sha256": sha256(Path(__file__).read_bytes()),
        "python": sys.executable,
        "python_version": platform.python_version(),
        "preflight_report": str(report_path),
        "preflight_report_sha256": sha256(report_raw),
        "preflight_status": runtime["status"],
        "package_versions_from_preflight": runtime["package_versions"],
        "package_roots": {name: str(path) for name, path in roots.items()},
        "preflight_source_count": len(sources),
        "mismatch_count": len(selected),
        "sources": records,
        "git": git,
        "source_archive_members": {name: sha256(raw) for name, raw in files.items()},
    }
    files["collection.json"] = json_bytes(report)
    files["original-native-runtime.json"] = report_raw
    output.mkdir(parents=True)
    archive = output / ARCHIVE_NAME
    with tarfile.open(archive, "w:gz") as stream:
        for name, raw in sorted(files.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw)
            item.mode = 0o644
            stream.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive) as stream:
        reread = {item.name: stream.extractfile(item).read() for item in stream}
    if reread != files:
        raise ValueError("source archive round-trip mismatch")
    (output / "collection.json").write_bytes(json_bytes(report))
    return {
        "collection_success": True,
        "mismatch_count": len(selected),
        "all_collected_bytes_match_preflight": all(
            record["same_bytes_as_preflight"] for record in records.values()
        ),
        "archive": str(archive),
        "archive_sha256": sha256(archive.read_bytes()),
        "runtime_imported": False,
        "compatibility_accepted": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-report", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    try:
        result = collect(args)
    except (OSError, ValueError, KeyError, TypeError, tarfile.TarError) as error:
        print(json.dumps({"collection_success": False, "error": str(error)}))
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
