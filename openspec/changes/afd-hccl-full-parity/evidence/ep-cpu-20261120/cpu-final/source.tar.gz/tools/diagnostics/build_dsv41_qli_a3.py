# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Build the pinned A3 C2 QLI dependency in an isolated eleven-op vendor.

Default/help are stdlib-only metadata. Explicit --run compiles original native
sources without starting an inference runtime, loading the Torch NPU extension,
or executing an NPU operator. Native compiler tools load their normal host libs.
Use --background to retain a durable owned PID/start-tick launch record.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback
from contextlib import suppress
from pathlib import Path

SOURCE_COMMIT = "7e37e29a7803d6897a7113088e2b771f83205bc0"
ENVIRONMENT_SHA256 = "c0d04190352a00139c662162211e419b9d829b3f4932f654dcbbf50c14c4184c"
PARENT_RECORD_SHA256 = (
    "c5bfab43df090a2a215bd973d5cf4f37176ea0f23c89193f135954a558b63dd1"
)
ACTIVE_RECORD_SHA256 = (
    "98864facddbda0289a9cd6d304d05507f0d441b01f78569ec511c3dd31109a04"
)
SOURCE_MANIFEST_SHA256 = (
    "33755e7b57dc2877441970b665c84d8965ffe704e5dab1933887ef8c7881473f"
)
SOURCE_ARCHIVE_SHA256 = (
    "48903d0bb34ca3f29fd4b60d2638290483818f47e3325dff50298e1458b4a35d"
)
SCRATCH_PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
OUTPUT_PREFIX = "normal-c2-qli-20261117-"
SOURCE_FILE_COUNT = 4476
MAX_BUILD_SECONDS = 1800
POLL_SECONDS = 1
TERMINATE_SECONDS = 10
COMMAND_TIMEOUT_SECONDS = 30
TEN_OPS = (
    "scatter_nd_update_sk",
    "hc_pre",
    "hc_post",
    "sparse_flash_mla",
    "sparse_flash_mla_metadata",
    "moe_gating_top_k",
    "moe_gating_top_k_hash",
    "rms_norm_cast",
    "inplace_partial_rotary_mul",
    "quant_lightning_indexer_v2_metadata",
)
SELECTED_OPS = TEN_OPS + ("quant_lightning_indexer_v2",)
REQUIRED_SYMBOLS = (
    "aclnnVllmAscendQuantLightningIndexerV2",
    "aclnnVllmAscendQuantLightningIndexerV2GetWorkspaceSize",
)
CACHE_DIRECTORIES = (
    ("ASCEND_CACHE_PATH", "ascend-cache"),
    ("ASCEND_WORK_PATH", "ascend-work"),
    ("ASCEND_PROCESS_LOG_PATH", "ascend-logs"),
    ("TORCH_EXTENSIONS_DIR", "torch-extensions"),
    ("TRITON_CACHE_DIR", "triton-cache"),
    ("TMPDIR", "tmp"),
    ("XDG_CACHE_HOME", "cache"),
    ("VLLM_ASCEND_BUILD_CACHE_DIR", "build-cache"),
)


def digest(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path: Path, value: dict) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )


def file_manifest(directory: Path) -> dict:
    return {
        path.relative_to(directory).as_posix(): {
            "sha256": digest(path),
            "bytes": path.stat().st_size,
        }
        for path in sorted(directory.rglob("*"))
        if path.is_file()
    }


def original_differences(source: Path, manifest: dict) -> list[str]:
    return [
        name
        for name, expected in manifest.items()
        if not (source / name).is_file() or digest(source / name) != expected["sha256"]
    ]


def read_process(pid: int) -> dict | None:
    try:
        raw = (Path("/proc") / str(pid) / "stat").read_text()
    except (FileNotFoundError, ProcessLookupError):
        return None
    fields = raw[raw.rfind(")") + 2 :].split()
    return {
        "pid": pid,
        "ppid": int(fields[1]),
        "pgid": int(fields[2]),
        "start_ticks": int(fields[19]),
        "state": fields[0],
    }


def owned_live(owned: dict) -> list[dict]:
    live = []
    for pid, expected in owned.items():
        observed = read_process(int(pid))
        if (
            observed is not None
            and observed["start_ticks"] == expected["start_ticks"]
            and observed["state"] != "Z"
        ):
            live.append(observed)
    return live


def discover_owned(owned: dict, process_group: int) -> None:
    table = {}
    for entry in Path("/proc").iterdir():
        if entry.name.isdecimal():
            observed = read_process(int(entry.name))
            if observed is not None:
                table[observed["pid"]] = observed
    changed = True
    while changed:
        changed = False
        for pid, observed in table.items():
            if str(pid) in owned:
                continue
            parent = table.get(observed["ppid"])
            parent_owned = (
                parent is not None
                and str(parent["pid"]) in owned
                and parent["start_ticks"] == owned[str(parent["pid"])]["start_ticks"]
            )
            if observed["pgid"] == process_group or parent_owned:
                owned[str(pid)] = observed
                changed = True


def stop_owned(owned: dict, process_group: int) -> list[dict]:
    # Signal only identities observed in this stage's fresh process group/tree.
    for sig in (signal.SIGTERM, signal.SIGKILL):
        deadline = time.monotonic() + TERMINATE_SECONDS
        while True:
            discover_owned(owned, process_group)
            live = owned_live(owned)
            if not live:
                return []
            for item in reversed(live):
                current = read_process(item["pid"])
                if (
                    current is None
                    or current["start_ticks"] != item["start_ticks"]
                    or current["state"] == "Z"
                ):
                    continue
                with suppress(ProcessLookupError):
                    os.kill(item["pid"], sig)
            if time.monotonic() >= deadline:
                break
            time.sleep(min(POLL_SECONDS, max(0, deadline - time.monotonic())))
    return owned_live(owned)


def run_stage(
    root: Path,
    record: dict,
    environment: dict,
    deadline: float,
    name: str,
    command: list[str],
    cwd: Path,
) -> None:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise TimeoutError("Native build deadline exhausted before " + name)
    item = {"name": name, "command": command, "cwd": str(cwd), "owned": {}}
    record["stages"].append(item)
    save(root / "progress.json", record)
    with (root / (name + ".log")).open("wb") as output:
        process = subprocess.Popen(
            command,
            cwd=cwd,
            env=environment,
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
            close_fds=True,
        )
        identity = read_process(process.pid)
        if identity is None:
            process.wait()
            raise RuntimeError("Build stage exited before PID identity was recorded")
        item.update(pid=process.pid, start_ticks=identity["start_ticks"])
        item["owned"][str(process.pid)] = identity
        save(root / "progress.json", record)
        try:
            while True:
                discover_owned(item["owned"], process.pid)
                item["returncode"] = process.poll()
                if item["returncode"] is not None:
                    break
                if time.monotonic() >= deadline:
                    item["timed_out"] = True
                    raise TimeoutError("Native build deadline exhausted during " + name)
                time.sleep(min(POLL_SECONDS, deadline - time.monotonic()))
            item["survivors"] = owned_live(item["owned"])
            if item["returncode"] != 0 or item["survivors"]:
                raise RuntimeError(
                    "Native stage failed or retained child processes: " + name
                )
        except BaseException:
            item["cleanup_survivors"] = stop_owned(item["owned"], process.pid)
            try:
                process.wait(timeout=TERMINATE_SECONDS)
            except subprocess.TimeoutExpired:
                item["cleanup_wait_timed_out"] = True
            item["returncode"] = process.returncode
            raise
        finally:
            save(root / "progress.json", record)


def exported_symbols(path: Path, output: Path) -> set[str]:
    result = subprocess.run(
        ["nm", "-D", "--defined-only", str(path)],
        check=True,
        capture_output=True,
        text=True,
        timeout=COMMAND_TIMEOUT_SECONDS,
    )
    output.write_text(result.stdout, encoding="utf-8")
    return {line.split()[-1] for line in result.stdout.splitlines() if line.split()}


def terminate_build(signum: int, _frame) -> None:
    raise KeyboardInterrupt("Owned build received signal " + str(signum))


def build_owned(root: Path) -> int:
    signal.signal(signal.SIGTERM, terminate_build)
    assert root.parent == Path(SCRATCH_PARENT) and root.name.startswith(OUTPUT_PREFIX)
    assert not (root / "build-result.json").exists()
    identity = json.loads((root / "input-identity.json").read_text())
    assert digest(Path(__file__)) == identity["builder_sha256"]
    with (root / "child-started.json").open("x", encoding="utf-8") as output:
        json.dump(read_process(os.getpid()), output)
    environment_path = root / "environment-input.json"
    assert digest(environment_path) == ENVIRONMENT_SHA256
    inputs = json.loads(environment_path.read_text())
    parent = Path(inputs["paths"]["parent_root"])
    active = Path(inputs["paths"]["active_root"])
    parent_record_path = parent / "final-extension-result.json"
    active_record_path = active / "metadata-build-result.json"
    assert digest(parent_record_path) == PARENT_RECORD_SHA256
    assert digest(active_record_path) == ACTIVE_RECORD_SHA256
    parent_record = json.loads(parent_record_path.read_text())
    active_record = json.loads(active_record_path.read_text())
    assert active_record == inputs["active_record"]
    assert active_record["source_commit"] == SOURCE_COMMIT
    assert active_record["status"] == "built-not-loaded"
    assert active_record["readonly_unchanged"] is True
    assert active_record["selected_ops"] == list(TEN_OPS)
    source_archive = parent / "upstream-source.tar.gz"
    source_manifest = parent / "upstream-source-manifest.json"
    assert digest(source_archive) == SOURCE_ARCHIVE_SHA256
    assert digest(source_manifest) == SOURCE_MANIFEST_SHA256
    manifest = json.loads(source_manifest.read_text())["files"]
    assert len(manifest) == SOURCE_FILE_COUNT
    readonly = dict(parent_record["readonly_after"])
    readonly.update(inputs["toolchain_artifacts"])
    readonly.update(inputs["active_artifacts"])
    readonly.update(
        {
            str(parent_record_path): PARENT_RECORD_SHA256,
            str(active_record_path): ACTIVE_RECORD_SHA256,
            str(source_archive): SOURCE_ARCHIVE_SHA256,
            str(source_manifest): SOURCE_MANIFEST_SHA256,
        }
    )
    # Snapshot every original parent/active source byte, including cache inputs.
    for directory in (parent / "source", active / "source"):
        assert not original_differences(directory, manifest)
        for name, item in manifest.items():
            readonly[str(directory / name)] = item["sha256"]
    third_party = parent / "source/csrc/third_party"
    cache_manifests = {}
    for name in ("pkg", "makeself", "catlass"):
        cache = third_party / name
        assert cache.is_dir()
        cache_manifests[name] = file_manifest(cache)
        for relative, item in cache_manifests[name].items():
            readonly[str(cache / relative)] = item["sha256"]
    before = {name: digest(Path(name)) for name in readonly}
    assert before == readonly
    save(root / "readonly-before.json", before)
    save(root / "third-party-inputs.json", cache_manifests)
    environment = os.environ.copy()
    environment.update(active_record["environment"])
    environment["ASCEND_CUSTOM_OPP_PATH"] = ""
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    for key, name in CACHE_DIRECTORIES:
        directory = root / name
        directory.mkdir()
        environment[key] = str(directory)
    record = {
        "status": "building",
        "root": str(root),
        "result_path": str(root / "build-result.json"),
        "source_commit": SOURCE_COMMIT,
        "source_archive_sha256": SOURCE_ARCHIVE_SHA256,
        "source_manifest_sha256": SOURCE_MANIFEST_SHA256,
        "original_source_count": len(manifest),
        "builder_sha256": digest(Path(__file__)),
        "builder_path": str(Path(__file__).resolve()),
        "environment_input_sha256": ENVIRONMENT_SHA256,
        "parent_root": str(parent),
        "parent_record_sha256": PARENT_RECORD_SHA256,
        "active_parent_root": str(active),
        "active_parent_record_sha256": ACTIVE_RECORD_SHA256,
        "selected_ops": list(SELECTED_OPS),
        "required_symbols": list(REQUIRED_SYMBOLS),
        "max_native_build_seconds": MAX_BUILD_SECONDS,
        "toolchain": active_record["toolchain"],
        "environment": {key: environment[key] for key in active_record["environment"]},
        "stages": [],
        "readonly_inputs_checked": len(before),
        "runtime_extension_loaded": False,
        "device_queried": False,
        "native_operations_accepted": False,
        "shared_venv_install": False,
        "cross_cann_compiled_objects_reused": False,
    }
    source = root / "source"
    deadline = time.monotonic() + MAX_BUILD_SECONDS
    try:
        shutil.copy2(source_manifest, root)
        shutil.copy2(source_archive, root)
        with tarfile.open(source_archive) as stream:
            stream.extractall(root, filter="data")
        assert not original_differences(source, manifest)
        for name, expected in cache_manifests.items():
            destination = source / "csrc/third_party" / name
            shutil.copytree(
                third_party / name,
                destination,
                dirs_exist_ok=True,
                ignore=shutil.ignore_patterns(".git", "__pycache__"),
            )
            actual = file_manifest(destination)
            assert all(
                actual[key] == value
                for key, value in expected.items()
                if ".git" not in Path(key).parts
                and "__pycache__" not in Path(key).parts
            )
        run_stage(
            root,
            record,
            environment,
            deadline,
            "build-native-eleven-ops",
            [
                "bash",
                "build.sh",
                "--pkg",
                "--ops=" + ",".join(SELECTED_OPS),
                "--soc=ascend910_93",
            ],
            source / "csrc",
        )
        installers = list((source / "csrc/build").glob("cann-ops-transformer*.run"))
        assert len(installers) == 1
        record["installer"] = {
            "path": str(installers[0].relative_to(root)),
            "sha256": digest(installers[0]),
        }
        package = root / "package"
        shutil.copytree(
            active / "package/vllm_ascend",
            package / "vllm_ascend",
            ignore=shutil.ignore_patterns("_cann_ops_custom", "__pycache__"),
        )
        for name, item in active_record["artifacts"].items():
            if "/_cann_ops_custom/" not in name:
                assert digest(root / name) == item["sha256"]
        run_stage(
            root,
            record,
            environment,
            deadline,
            "install-owned-vendor",
            [
                "bash",
                str(installers[0]),
                "--install-path=" + str(package / "vllm_ascend/_cann_ops_custom"),
            ],
            root,
        )
        vendor_relative = active_record["vendor_relative_path"]
        vendor = root / vendor_relative
        record["native_aicpu_outputs"] = {}
        for name, expected in active_record["native_aicpu_outputs"].items():
            original, destination = active / name, root / name
            assert digest(original) == expected["sha256"]
            if destination.exists():
                assert digest(destination) == expected["sha256"]
                action = "native-install-identical"
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(original, destination)
                action = "copied-original-native-output"
            assert digest(destination) == expected["sha256"]
            record["native_aicpu_outputs"][name] = {**expected, "provenance": action}
        assert len(record["native_aicpu_outputs"]) == 2
        library = vendor / "op_api/lib/libcust_opapi.so"
        old_library = active / vendor_relative / "op_api/lib/libcust_opapi.so"
        old_symbols = exported_symbols(
            old_library, root / "parent-exported-symbols.txt"
        )
        new_symbols = exported_symbols(library, root / "exported-symbols.txt")
        old_api = {name for name in old_symbols if name.startswith("aclnn")}
        assert old_api and old_api <= new_symbols
        assert set(REQUIRED_SYMBOLS) <= new_symbols
        op_name = "VllmAscendQuantLightningIndexerV2"
        info_path = (
            vendor
            / "op_impl/ai_core/tbe/config/ascend910_93"
            / "aic-ascend910_93-ops-info.json"
        )
        info = json.loads(info_path.read_text())
        assert op_name in info
        kernel_root = vendor / "op_impl/ai_core/tbe/kernel/ascend910_93"
        kernel_objects = sorted(kernel_root.rglob(op_name + "_*.o"))
        assert kernel_objects, "Native QLI V2 AICore kernel objects are missing"
        kernel_outputs = [info_path]
        for path in kernel_objects:
            config = path.with_suffix(".json")
            assert config.is_file()
            kernel_outputs.extend((path, config))
        record["native_qli_opp_outputs"] = {
            "logical_op": op_name,
            "soc": "ascend910_93",
            "op_info_entry": info[op_name],
            "artifacts": {
                path.relative_to(root).as_posix(): {
                    "sha256": digest(path),
                    "bytes": path.stat().st_size,
                }
                for path in kernel_outputs
            },
            "kernel_object_count": len(kernel_objects),
            "kernel_executed": False,
        }
        record["exported_symbols"] = {
            "path": str(root / "exported-symbols.txt"),
            "relative_path": "exported-symbols.txt",
            "sha256": digest(root / "exported-symbols.txt"),
            "required_symbols": list(REQUIRED_SYMBOLS),
            "observed_symbols": {
                name: name in new_symbols for name in REQUIRED_SYMBOLS
            },
            "missing_symbols": sorted(set(REQUIRED_SYMBOLS) - new_symbols),
        }
        record["all_parent_api_symbols_retained"] = True
        record["parent_api_symbol_count"] = len(old_api)
        record["vendor_relative_path"] = vendor_relative
        record["package_relative_path"] = "package"
        record["reused_same_cann92_extension_and_python"] = True
        for name, item in active_record["artifacts"].items():
            if "/_cann_ops_custom/" not in name:
                assert digest(root / name) == item["sha256"]
        record["artifacts"] = {
            "package/" + name: item for name, item in file_manifest(package).items()
        }
        for name in (
            "libcust_opapi.so",
            "vllm_ascend_C.cpython-312-aarch64-linux-gnu.so",
            "libvllm_ascend_kernels.so",
        ):
            for index, path in enumerate(sorted(package.rglob(name))):
                header = subprocess.run(
                    ["readelf", "-h", "-d", str(path)],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=COMMAND_TIMEOUT_SECONDS,
                )
                assert "AArch64" in header.stdout
                (root / f"elf-{name}-{index}.txt").write_text(
                    header.stdout, encoding="utf-8"
                )
        record["status"] = "built-not-loaded"
    except BaseException as error:
        record.update(
            status="failed",
            error_type=type(error).__name__,
            error=str(error),
            traceback=traceback.format_exc(),
        )
    finally:
        record["original_source_differences"] = original_differences(source, manifest)
        record["parent_original_source_differences"] = original_differences(
            parent / "source", manifest
        )
        record["active_parent_original_source_differences"] = original_differences(
            active / "source", manifest
        )
        if source.is_dir():
            record["generated_source_files"] = {
                name: item
                for name, item in file_manifest(source).items()
                if name not in manifest
            }
        after = {}
        errors = {}
        for name in readonly:
            try:
                after[name] = digest(Path(name))
            except OSError as error:
                errors[name] = str(error)
        save(root / "readonly-after.json", after)
        record["readonly_errors"] = errors
        record["readonly_unchanged"] = not errors and before == after
        if not record["readonly_unchanged"] or any(
            record[key]
            for key in (
                "original_source_differences",
                "parent_original_source_differences",
                "active_parent_original_source_differences",
            )
        ):
            record["status"] = "failed"
        save(root / "build-result.json", record)
    print(
        json.dumps(
            {"status": record["status"], "root": str(root), "stages": record["stages"]}
        ),
        flush=True,
    )
    return 0 if record["status"] == "built-not-loaded" else 1


def execute_owned(root: Path) -> int:
    try:
        return build_owned(root)
    except BaseException as error:
        # Preflight errors occur before the native-stage record exists. Preserve
        # them separately; never replace a completed or failed build record.
        path = root / "preflight-failure.json"
        with path.open("x", encoding="utf-8") as output:
            json.dump(
                {
                    "status": "failed",
                    "error_type": type(error).__name__,
                    "error": str(error),
                    "traceback": traceback.format_exc(),
                    "runtime_extension_loaded": False,
                    "device_queried": False,
                    "shared_venv_install": False,
                },
                output,
                indent=2,
            )
        return 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--background", action="store_true")
    parser.add_argument("--environment-record", type=Path)
    parser.add_argument("--execute-owned-root", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.execute_owned_root is not None:
        if args.run or args.background or args.environment_record is not None:
            parser.error("owned child mode accepts only --execute-owned-root")
        return execute_owned(args.execute_owned_root.resolve())
    if args.background and not args.run:
        parser.error("--background requires --run")
    metadata = {
        "scope": "original native eleven-op build; no runtime or NPU acceptance",
        "source_commit": SOURCE_COMMIT,
        "selected_ops": list(SELECTED_OPS),
        "required_symbols": list(REQUIRED_SYMBOLS),
        "max_native_build_seconds": MAX_BUILD_SECONDS,
        "runtime_imported": False,
        "build_started": False,
    }
    if not args.run:
        print(json.dumps(metadata, indent=2))
        return 0
    if sys.platform != "linux" or args.environment_record is None:
        parser.error("--run requires Linux and --environment-record")
    environment_path = args.environment_record.resolve()
    if digest(environment_path) != ENVIRONMENT_SHA256:
        parser.error("environment record does not match reviewed frozen identity")
    root = Path(tempfile.mkdtemp(prefix=OUTPUT_PREFIX, dir=SCRATCH_PARENT))
    script = root / "build_dsv41_qli_a3.py"
    shutil.copy2(Path(__file__).resolve(), script)
    shutil.copy2(environment_path, root / "environment-input.json")
    save(
        root / "input-identity.json",
        {
            **metadata,
            "builder_sha256": digest(script),
            "environment_record_sha256": ENVIRONMENT_SHA256,
        },
    )
    if args.background:
        with (root / "supervision.log").open("wb") as output:
            process = subprocess.Popen(
                [sys.executable, "-B", str(script), "--execute-owned-root", str(root)],
                stdin=subprocess.DEVNULL,
                stdout=output,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                close_fds=True,
            )
        identity = read_process(process.pid)
        assert identity is not None
        save(
            root / "launch.json",
            {**identity, "root": str(root), "builder_sha256": digest(script)},
        )
        print(
            json.dumps({"root": str(root), "launch": identity, "build_started": True})
        )
        return 0
    return execute_owned(root)


if __name__ == "__main__":
    raise SystemExit(main())
