# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""One native ordinary-MTP proposal and its actual model-call ownership."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import AbstractContextManager, contextmanager
from dataclasses import dataclass
from threading import get_ident
from typing import TYPE_CHECKING, Literal, Protocol

import torch
from torch import nn
from vllm.config.compilation import CUDAGraphMode
from vllm.v1.worker.gpu.input_batch import InputBatch
from vllm_ascend.worker.v2.spec_decode.mtp.speculator import AscendMTPSpeculator

from afd_plugin.compat.npu.mtp import (
    DeepseekV4MtpContract,
    resolve_deepseek_v4_mtp_contract,
)

if TYPE_CHECKING:
    from vllm_ascend.worker.v2.model_runner import NPUModelRunner

    from afd_plugin.compat.patches.npu.mtp_proposal import MtpProposalBinding
    from afd_plugin.connectors.npu.hccl_staged_transport import HcclStagedTransport

MtpExecutionMode = Literal["target", "profile", "dummy"]
MtpSegment = Literal["prefill", "decode"]


@dataclass(frozen=True, slots=True)
class MtpDraftCall:
    """Actual call intent; its wire representation belongs to the exchange."""

    target_transaction_id: str
    logical_step: int
    num_steps: int
    segment: MtpSegment
    mode: MtpExecutionMode
    valid_tokens: int
    padded_tokens: int
    draft_layer: int = 0


@dataclass(frozen=True, slots=True)
class MtpCompletedTarget:
    transaction_id: str
    input_batch: InputBatch
    mode: MtpExecutionMode


class MtpProposalExchange(Protocol):
    """The paired exchange owns ACCEPT/COMPLETE and proposal-END agreement."""

    @property
    def transport(self) -> HcclStagedTransport: ...

    @property
    def acknowledged_stop(self) -> bool: ...

    def draft_forward(
        self,
        call: MtpDraftCall,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
    ) -> AbstractContextManager[None]: ...

    def finish_proposal(self, target_transaction_id: str, num_steps: int) -> None: ...

    def fail(self) -> None: ...


class HcclMtpSession:
    """Keep native sampling/feedback intact while pairing each real MoE call.

    Model-call COMPLETE does not finish a proposal. Only successful return of
    the original proposer, exact-N validation and peer END agreement do so.
    Failed owners retain the selected models and all in-flight tensor views.
    """

    def __init__(
        self,
        owner: NPUModelRunner,
        contract: DeepseekV4MtpContract,
        exchange: MtpProposalExchange,
    ) -> None:
        if resolve_deepseek_v4_mtp_contract(owner.vllm_config) != contract:
            raise ValueError("MTP session contract differs from the native owner")
        speculator = owner.speculator
        if not isinstance(speculator, AscendMTPSpeculator):
            raise ValueError("MTP session requires the selected native MTP speculator")
        transport = exchange.transport
        if (
            transport.role != "attention"
            or not transport.initialized
            or transport.closed
            or transport.terminal
            or transport.plan is not None
            or transport.graph_reservation is not None
        ):
            raise ValueError("MTP session requires an initialized idle Attention wire")
        self.owner = owner
        self.contract = contract
        self.exchange = exchange
        self.speculator = speculator
        self.target_model = owner.model
        self.draft_model: nn.Module = speculator.model
        self._thread = get_ident()
        self._target: MtpCompletedTarget | None = None
        self._proposal: MtpCompletedTarget | None = None
        self._forward_active = False
        self._next_step = 0
        self._retained: list[torch.Tensor] = []
        self._binding: MtpProposalBinding | None = None
        self._failed = False
        self._closed = False

    @property
    def failed(self) -> bool:
        return self._failed

    @property
    def closed(self) -> bool:
        return self._closed

    @property
    def proposal_active(self) -> bool:
        return self._proposal is not None

    def _require_owner(self) -> None:
        if self._closed or self._failed:
            raise RuntimeError("MTP session is closed or failed")
        if get_ident() != self._thread:
            raise RuntimeError("MTP session belongs to its native execution thread")
        if (
            self.owner.speculator is not self.speculator
            or self.owner.model is not self.target_model
            or self.speculator.model is not self.draft_model
        ):
            raise RuntimeError("MTP session native model/speculator ownership changed")
        if resolve_deepseek_v4_mtp_contract(self.owner.vllm_config) != self.contract:
            raise RuntimeError("MTP session configuration changed")

    def bind_proposer(self) -> None:
        self._require_owner()
        if self._binding is not None:
            raise RuntimeError("MTP proposal is already bound")
        # Circular ownership: the instance binding consumes this session's
        # context manager; importing it only when installed avoids a registry.
        from afd_plugin.compat.patches.npu.mtp_proposal import MtpProposalBinding

        self._binding = MtpProposalBinding(self)

    def record_completed_target(self, target: MtpCompletedTarget) -> None:
        self._require_owner()
        if self.proposal_active:
            raise RuntimeError("cannot replace a target during its MTP proposal")
        if not target.transaction_id or target.mode not in (
            "target",
            "profile",
            "dummy",
        ):
            raise ValueError(
                "MTP target requires an identity and native execution mode"
            )
        if self.exchange.transport.plan is not None:
            raise RuntimeError("MTP target must complete before recording its proposal")
        self._target = target

    @contextmanager
    def proposal_scope(
        self, input_batch: InputBatch, *, dummy_run: bool, is_profile: bool | None
    ) -> Iterator[None]:
        self._require_owner()
        if self.proposal_active:
            raise RuntimeError("nested MTP proposals are not supported")
        target = self._target
        if target is None or target.input_batch is not input_batch:
            raise RuntimeError(
                "MTP proposal requires its actual completed target batch"
            )
        mode = "profile" if is_profile else "dummy" if dummy_run else "target"
        if mode != target.mode:
            raise ValueError("MTP proposal mode differs from its completed target")
        if input_batch.num_reqs <= 0 or input_batch.num_tokens_after_padding <= 0:
            raise ValueError("empty native batches do not produce an MTP proposal")
        for manager in (
            self.speculator.prefill_cudagraph_manager,
            self.speculator.decode_cudagraph_manager,
        ):
            if manager is not None and manager.cudagraph_mode != CUDAGraphMode.NONE:
                raise ValueError("ordinary MTP requires both native managers in NONE")
        self._proposal = target
        self._next_step = 0
        try:
            yield
            if (
                self._forward_active
                or self._next_step != self.contract.num_speculative_tokens
            ):
                raise RuntimeError(
                    "native MTP proposal did not complete exactly N forwards"
                )
            self.exchange.finish_proposal(
                target.transaction_id, self.contract.num_speculative_tokens
            )
        except BaseException:
            self.fail()
            raise
        else:
            self._proposal = None
            self._target = None
            self._retained.clear()

    @contextmanager
    def draft_forward(
        self,
        model: nn.Module,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        inputs_embeds: torch.Tensor | None,
    ) -> Iterator[None]:
        self._require_owner()
        if model is not self.draft_model:
            raise RuntimeError("MTP forward belongs to a different loaded draft model")
        target = self._proposal
        if target is None or self._forward_active:
            raise RuntimeError("MTP forward requires one active native proposal")
        step = self._next_step
        if step >= self.contract.num_speculative_tokens:
            raise RuntimeError("native MTP proposal exceeded its N model forwards")
        rows = input_ids.shape[0]
        expected = (
            target.input_batch.num_tokens_after_padding
            if step == 0
            else target.input_batch.num_reqs
        )
        if (
            input_ids.ndim != 1
            or positions.ndim != 1
            or rows != expected
            or positions.shape[0] != rows
            or hidden_states.shape[0] != rows
            or rows > self.contract.max_tokens
            or (inputs_embeds is not None and inputs_embeds.shape[0] != rows)
        ):
            raise ValueError(
                "MTP model rows differ from the actual native proposal segment"
            )
        valid = (
            0
            if target.mode != "target"
            else (
                target.input_batch.num_tokens
                if step == 0
                else target.input_batch.num_reqs
            )
        )
        call = MtpDraftCall(
            target.transaction_id,
            step,
            self.contract.num_speculative_tokens,
            "prefill" if step == 0 else "decode",
            target.mode,
            valid,
            rows,
        )
        self._retained.extend((input_ids, positions, hidden_states))
        if inputs_embeds is not None:
            self._retained.append(inputs_embeds)
        self._forward_active = True
        try:
            with self.exchange.draft_forward(call, input_ids, positions):
                yield
            self._next_step += 1
        finally:
            self._forward_active = False

    def retain_draft_output(self, output: torch.Tensor) -> None:
        if not self._forward_active:
            raise RuntimeError(
                "MTP feedback retention requires the active draft forward"
            )
        self._retained.append(output)

    def fail(self) -> None:
        if not self._failed:
            self._failed = True
            self.exchange.fail()

    def close_after_stop(self) -> None:
        if self._closed:
            return
        if self._failed or self.proposal_active or not self.exchange.acknowledged_stop:
            raise RuntimeError("MTP binding can close only after quiescent peer STOP")
        if self._binding is not None:
            self._binding.restore_after_stop()
        self._target = None
        self._retained.clear()
        self._closed = True
