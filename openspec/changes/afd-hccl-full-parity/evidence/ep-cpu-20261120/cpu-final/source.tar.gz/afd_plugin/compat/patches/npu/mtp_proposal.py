# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Bind the exact native proposer on one selected ordinary-MTP instance."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import torch
from vllm.v1.worker.gpu.input_batch import InputBatch
from vllm_ascend.worker.v2.spec_decode.autoregressive.speculator import (
    AscendAutoRegressiveSpeculator,
)

if TYPE_CHECKING:
    from afd_plugin.v1.worker.npu.hccl_mtp import HcclMtpSession


class MtpProposalBinding:
    def __init__(self, owner: HcclMtpSession) -> None:
        speculator = owner.speculator
        if "propose" in speculator.__dict__:
            raise RuntimeError("MTP proposer already has an instance binding")
        native = speculator.propose
        if native.__func__ is not AscendAutoRegressiveSpeculator.propose:
            raise ValueError("MTP binding requires the pinned native propose method")
        self.owner = owner
        self.speculator = speculator
        self._native = native
        self._restored = False
        speculator.propose = self.propose

    # Upstream: AscendAutoRegressiveSpeculator.propose, 7e37e29a7803d6897a7113088e2b771f83205bc0,
    # vllm_ascend/worker/v2/spec_decode/autoregressive/speculator.py:302-362.
    # Reason/functionality: keep one actual native proposal's N forward calls
    # inside its selected instance/session, including native dummy/profile.
    # Signature: exact native annotations/defaults; native has no return annotation.
    # Delegation exception: native propose owns two managers, attention builders,
    # feedback and sampling; copying this large lifecycle would duplicate owners.
    # Cost: one host scope and bounded validation per proposal; no tensor reads.
    # Remove when native speculators expose proposal/forward lifecycle callbacks.
    def propose(
        self,
        input_batch: InputBatch,
        attn_metadata: dict[str, Any],
        slot_mappings: dict[str, torch.Tensor],
        last_hidden_states: torch.Tensor,
        aux_hidden_states: list[torch.Tensor] | None,
        num_sampled: torch.Tensor,
        num_rejected: torch.Tensor,
        last_sampled: torch.Tensor,
        next_prefill_tokens: torch.Tensor,
        temperature: torch.Tensor,
        seeds: torch.Tensor,
        dp_sync: Any = None,
        dummy_run: bool = False,
        skip_attn_for_dummy_run: bool = False,
        mm_inputs: tuple[list[torch.Tensor], torch.Tensor] | None = None,
        is_profile: Any = None,
    ):
        # ### PATCH START: one native ordinary-MTP proposal
        if self._restored or self.speculator.propose != self.propose:
            raise RuntimeError("MTP instance proposal binding is no longer selected")
        with self.owner.proposal_scope(
            input_batch, dummy_run=dummy_run, is_profile=is_profile
        ):
            # ### PATCH END: one native ordinary-MTP proposal
            return self._native(
                input_batch=input_batch,
                attn_metadata=attn_metadata,
                slot_mappings=slot_mappings,
                last_hidden_states=last_hidden_states,
                aux_hidden_states=aux_hidden_states,
                num_sampled=num_sampled,
                num_rejected=num_rejected,
                last_sampled=last_sampled,
                next_prefill_tokens=next_prefill_tokens,
                temperature=temperature,
                seeds=seeds,
                dp_sync=dp_sync,
                dummy_run=dummy_run,
                skip_attn_for_dummy_run=skip_attn_for_dummy_run,
                mm_inputs=mm_inputs,
                is_profile=is_profile,
            )

    def restore_after_stop(self) -> None:
        if self._restored:
            return
        if (
            self.owner.proposal_active
            or self.owner.failed
            or not self.owner.exchange.acknowledged_stop
        ):
            raise RuntimeError(
                "native proposer restoration requires quiescent peer STOP"
            )
        if self.speculator.propose != self.propose:
            raise RuntimeError("cannot restore a foreign native proposer binding")
        del self.speculator.propose
        self._restored = True
