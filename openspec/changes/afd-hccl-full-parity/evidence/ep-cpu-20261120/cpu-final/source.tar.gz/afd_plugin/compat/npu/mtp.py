# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Ordinary V4 MTP's fixed eager contract, independently of qualification."""

from __future__ import annotations

from copy import copy
from dataclasses import dataclass
from typing import TYPE_CHECKING, Literal

from afd_plugin.config import HCCL_P2P_CONNECTOR, parse_optional_afd_config

if TYPE_CHECKING:
    from vllm.config import VllmConfig

MAX_MTP_SPECULATIVE_TOKENS = 3
MTP_DRAFT_ARCHITECTURE = "DeepSeekV4MTPModel"
MTP_TARGET_ARCHITECTURE = "DeepseekV4ForCausalLM"


@dataclass(frozen=True, slots=True)
class DeepseekV4MtpContract:
    """Only values; no proposer, mutable configuration or tensor ownership."""

    num_speculative_tokens: int
    hidden_size: int
    vocab_size: int
    target_layer_indices: tuple[int, ...]
    max_tokens: int
    native_tp_size: int

    def __post_init__(self) -> None:
        if (
            type(self.num_speculative_tokens) is not int
            or not 1 <= self.num_speculative_tokens <= MAX_MTP_SPECULATIVE_TOKENS
        ):
            raise ValueError("ordinary MTP requires 1..3 integer speculative tokens")
        for value in (self.hidden_size, self.vocab_size, self.max_tokens):
            if type(value) is not int or value <= 0:
                raise ValueError("ordinary MTP dimensions must be positive integers")
        if self.target_query_len > self.max_tokens:
            raise ValueError("ordinary MTP target query exceeds token capacity")
        if type(self.native_tp_size) is not int or self.native_tp_size not in (1, 2):
            raise ValueError("ordinary MTP requires native TP1 or TP2")
        if (
            not isinstance(self.target_layer_indices, tuple)
            or not self.target_layer_indices
            or any(type(layer) is not int for layer in self.target_layer_indices)
            or self.target_layer_indices != tuple(range(len(self.target_layer_indices)))
        ):
            raise ValueError("ordinary MTP requires the complete ordered target layers")

    @property
    def target_query_len(self) -> int:
        return self.num_speculative_tokens + 1

    @property
    def draft_layer_indices(self) -> tuple[int, ...]:
        return (0,)


def resolve_deepseek_v4_mtp_contract(
    vllm_config: VllmConfig,
) -> DeepseekV4MtpContract | None:
    """Validate the fixed ordinary-MTP component, without changing admission.

    The existing model/connector qualification checks still run in the real
    worker. Payload dtype/device and initialized native TP coordinates belong
    to the subsequent HCCL binding, not this configuration-only value object.
    """
    model = vllm_config.model_config
    target = model.hf_config
    if target.model_type != "deepseek_v4":
        return None
    speculative = vllm_config.speculative_config
    if speculative is None or speculative.method != "mtp":
        return None
    afd = parse_optional_afd_config(vllm_config, validate=False)
    if afd is None:
        return None
    if not target.architectures or any(
        architecture.removeprefix("AFD") != MTP_TARGET_ARCHITECTURE
        for architecture in target.architectures
    ):
        raise ValueError("ordinary MTP requires the exact DeepseekV4 target")
    draft = speculative.draft_model_config.hf_config
    if draft.architectures != [MTP_DRAFT_ARCHITECTURE]:
        raise ValueError("ordinary MTP requires the native DeepSeekV4MTPModel draft")
    if (
        type(target.num_nextn_predict_layers) is not int
        or target.num_nextn_predict_layers != 1
        or type(draft.num_nextn_predict_layers) is not int
        or draft.num_nextn_predict_layers != 1
    ):
        raise ValueError("ordinary MTP requires one physical draft block")
    if draft.hidden_size != target.hidden_size or draft.vocab_size != target.vocab_size:
        raise ValueError("ordinary MTP target/draft dimensions must match")
    if (
        not vllm_config.use_v2_model_runner
        or model.enforce_eager is not True
        or speculative.enforce_eager is not True
        or vllm_config.compilation_config.mode.name != "NONE"
        or vllm_config.compilation_config.cudagraph_mode.name != "NONE"
    ):
        raise ValueError("ordinary MTP requires V2 with eager target and draft")
    if speculative.enable_adaptive_verification:
        raise ValueError("ordinary MTP requires adaptive verification disabled")
    parallel = vllm_config.parallel_config
    if (
        parallel.data_parallel_size != 1
        or parallel.pipeline_parallel_size != 1
        or parallel.prefill_context_parallel_size != 1
        or parallel.decode_context_parallel_size != 1
        or parallel.use_sequence_parallel_moe
        or parallel.enable_expert_parallel
        or parallel.enable_eplb
    ):
        raise ValueError("ordinary MTP requires DP1/PP1/CP1, non-SP and non-EP")
    if parallel.use_ubatching or parallel.enable_dbo or parallel.num_ubatches != 1:
        raise ValueError("ordinary MTP requires U1 with DBO disabled")
    if speculative.draft_tensor_parallel_size != parallel.tensor_parallel_size:
        raise ValueError("ordinary MTP draft native TP must match the target")
    if (
        vllm_config.lora_config is not None
        or vllm_config.kv_transfer_config is not None
        or vllm_config.engram_config is not None
        or model.enable_sleep_mode
        or vllm_config.weight_transfer_config is not None
    ):
        raise ValueError("ordinary MTP requires fixed storage without LoRA/PD/Engram")
    if (
        afd.connector != HCCL_P2P_CONNECTOR
        or afd.compute_gate_on_attention
        or afd.async_dp
        or afd.num_attention_ranks != parallel.tensor_parallel_size
        or afd.num_ffn_ranks != parallel.tensor_parallel_size
    ):
        raise ValueError("ordinary MTP requires gate-on-FFN and paired native HCCL TP")
    if type(target.num_hidden_layers) is not int or target.num_hidden_layers <= 0:
        raise ValueError("ordinary MTP requires positive integer target layers")
    return DeepseekV4MtpContract(
        speculative.num_speculative_tokens,
        target.hidden_size,
        target.vocab_size,
        tuple(range(target.num_hidden_layers)),
        vllm_config.scheduler_config.max_num_batched_tokens,
        parallel.tensor_parallel_size,
    )


def get_deepseek_v4_mtp_ffn_config(vllm_config: VllmConfig) -> VllmConfig:
    """Make F's worker view before native proposer/distributed construction."""
    if resolve_deepseek_v4_mtp_contract(vllm_config) is None:
        raise ValueError("FFN MTP isolation requires an ordinary V4 MTP contract")
    isolated = copy(vllm_config)
    isolated.speculative_config = None
    return isolated


def get_deepseek_v4_mtp_model_load_config(vllm_config: VllmConfig) -> VllmConfig:
    """Keep validated spec fields only while loading F's target/draft roles.

    This view must never be used to construct F's Worker or a native proposer.
    Native load_eagle_model passes the requested ModelConfig separately; target
    and MTP constructors still read target/spec fields from this VllmConfig.
    """
    if resolve_deepseek_v4_mtp_contract(vllm_config) is None:
        raise ValueError("role loading requires an ordinary V4 MTP contract")
    loading = copy(vllm_config)
    loading.speculative_config = copy(vllm_config.speculative_config)
    return loading


def deepseek_v4_mtp_weight_role(
    name: str, *, quantization_name: str | None = None
) -> Literal["attention", "ffn"] | None:
    """Classify native checkpoint components before its unchanged MTP loader.

    Native 7e37e29a admits mtp.0 and, for deepseek_v4_fp8 only, the two top-level
    embedding/head aliases. Norm and attention compressor gate names stay on A.
    """
    if quantization_name == "deepseek_v4_fp8" and name in (
        "embed.weight",
        "head.weight",
    ):
        return "attention"
    components = name.split(".")
    if len(components) < 3 or components[0] != "mtp":
        return None
    if components[1] != "0":
        raise ValueError("ordinary MTP checkpoint requires physical mtp.0 only")
    return "ffn" if components[2] == "ffn" else "attention"


def is_deepseek_v4_target_ffn_weight(
    name: str, target_layer_indices: tuple[int, ...]
) -> bool:
    """Admit only native target MoE components, excluding all A-owned state."""
    components = name.removeprefix("model.").split(".")
    return (
        len(components) >= 4
        and components[0] == "layers"
        and components[1].isdecimal()
        and int(components[1]) in target_layer_indices
        and components[2] in ("ffn", "mlp")
    )
