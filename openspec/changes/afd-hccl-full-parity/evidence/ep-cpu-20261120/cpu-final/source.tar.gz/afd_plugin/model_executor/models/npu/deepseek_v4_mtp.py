# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Role-local ordinary V4 MTP, preserving native HC feedback and weight loading."""

from collections.abc import Iterable
from typing import TYPE_CHECKING

import torch
from torch import nn
from transformers import DeepseekV2Config
from vllm.config import VllmConfig
from vllm.sequence import IntermediateTensors
from vllm_ascend.models.deepseek_v4 import model as native_target
from vllm_ascend.models.deepseek_v4 import mtp as native

from afd_plugin.compat.npu.mtp import (
    deepseek_v4_mtp_weight_role,
    is_deepseek_v4_target_ffn_weight,
    resolve_deepseek_v4_mtp_contract,
)
from afd_plugin.config import parse_afd_config
from afd_plugin.model_executor.models.npu.deepseek_v4 import (
    AFDDeepseekV4DecoderLayer,
    _refresh_ascend_fused_moe,
)

if TYPE_CHECKING:
    from afd_plugin.v1.worker.npu.hccl_mtp import HcclMtpSession


class AFDDeepseekV4MtpFFNLayer(native_target.DeepseekV4DecoderLayer):
    # Upstream constructor: deepseek_v4/model.py:677-737,
    # Ascend 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: F executes only the complete native MoE and must not
    # allocate Attention/HC/norm state for either target or draft. Exact signature.
    # Cost: one native MoE; no extra tensor copies/reductions. Remove when native
    # role construction can select an MoE-only decoder component.
    def __init__(
        self,
        vllm_config: VllmConfig,
        prefix: str,
        config: DeepseekV2Config | None = None,
        topk_indices_buffer: torch.Tensor | None = None,
        is_draft_layer: bool = False,
    ) -> None:
        # ### PATCH START: MoE-only ordinary-MTP F layer
        nn.Module.__init__(self)
        if resolve_deepseek_v4_mtp_contract(vllm_config) is None:
            raise ValueError("MoE-only layer requires the ordinary V4 MTP contract")
        if parse_afd_config(vllm_config, validate=False).role != "ffn":
            raise ValueError("MoE-only ordinary-MTP layers belong to FFN")
        expected = (
            vllm_config.speculative_config.draft_model_config.hf_config
            if is_draft_layer
            else vllm_config.model_config.hf_config
        )
        if config is None:
            config = expected
        if config is not expected or topk_indices_buffer is not None:
            raise ValueError(
                "MTP FFN layer requires its native config without A buffers"
            )
        self.layer_idx = int(prefix.split(".")[-1])
        self.config = config
        self.use_sequence_parallel_moe = False
        _refresh_ascend_fused_moe()
        self.mlp = native_target.DeepseekV4MoE(
            config=config,
            parallel_config=vllm_config.parallel_config,
            quant_config=vllm_config.quant_config,
            prefix=f"{prefix}.mlp",
            is_draft_layer=is_draft_layer,
        )
        # ### PATCH END: MoE-only ordinary-MTP F layer


class AFDDeepseekV4MtpTargetFFNModel(nn.Module):
    def __init__(self, vllm_config: VllmConfig, prefix: str) -> None:
        super().__init__()
        contract = resolve_deepseek_v4_mtp_contract(vllm_config)
        if contract is None:
            raise ValueError("FFN target model requires the ordinary V4 MTP contract")
        self.layers = nn.ModuleList(
            AFDDeepseekV4MtpFFNLayer(vllm_config, f"{prefix}.layers.{index}")
            for index in contract.target_layer_indices
        )


class AFDDeepseekV4MtpTargetFFN(native_target.AscendDeepseekV4ForCausalLM):
    # Upstream: Ascend deepseek_v4/model.py:1054-1075 @
    # 7e37e29a7803d6897a7113088e2b771f83205bc0. Signature matches (no return type).
    # Reason/functionality: target F owns complete MoEs only, with no vocabulary
    # table, head, HC/norm or Attention allocations. Keep native MoE introspection
    # and quant loader. Cost: remove A-only storage; no added compute/reduction.
    # Remove when native constructors accept role-local model factories.
    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        # ### PATCH START: MoE-only ordinary-MTP target
        nn.Module.__init__(self)
        contract = resolve_deepseek_v4_mtp_contract(vllm_config)
        if contract is None:
            raise ValueError("FFN target requires the ordinary V4 MTP contract")
        self.contract = contract
        self.config = vllm_config.model_config.hf_config
        self.quant_config = vllm_config.quant_config
        self.model = AFDDeepseekV4MtpTargetFFNModel(
            vllm_config, native_target.maybe_prefix(prefix, "model")
        )
        self.num_moe_layers = len(contract.target_layer_indices)
        self.set_moe_parameters()
        # ### PATCH END: MoE-only ordinary-MTP target

    def get_experts_layer_indices(self) -> tuple[int, ...]:
        return self.contract.target_layer_indices

    def compute_ffn_output(
        self,
        hidden_states: torch.Tensor,
        layer_idx: int,
        *,
        input_ids: torch.Tensor,
        hidden_states_fp32: torch.Tensor,
    ) -> torch.Tensor:
        if layer_idx not in self.contract.target_layer_indices:
            raise ValueError("target MoE layer is outside the complete model")
        return self.model.layers[layer_idx].mlp(
            hidden_states, input_ids=input_ids, hidden_states_fp32=hidden_states_fp32
        )

    # Upstream native target loader: deepseek_v4/model.py:1146-1377 @
    # 7e37e29a7803d6897a7113088e2b771f83205bc0. Signature matches exactly.
    # Reason/functionality: select only complete target MoE checkpoint subtrees.
    # Delegation exception: preserve the large native quant/expert name mapping
    # and loaded-parameter accounting. Cost: name tests only, no tensor copies.
    # Remove when native loaders expose role-specific checkpoint selection.
    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        # ### PATCH START: target MoE namespace only
        role_weights = (
            (name, weight)
            for name, weight in weights
            if is_deepseek_v4_target_ffn_weight(
                name, self.contract.target_layer_indices
            )
        )
        # ### PATCH END: target MoE namespace only
        return super().load_weights(role_weights)


class AFDDeepSeekMultiTokenPredictorLayer(native.DeepSeekMultiTokenPredictorLayer):
    # Upstream: deepseek_v4/mtp.py:63-122, Ascend
    # 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: retain A's native projections/HC/head and construct
    # only the role-local decoder, including learned (non-hash) draft MoE on F.
    # Signature matches exactly. Native forward/HC helpers remain inherited.
    # Cost: no F embedding/head/index allocations; no extra compute or reduction.
    # Remove when native model construction accepts role-local layer factories.
    def __init__(self, vllm_config: VllmConfig, prefix: str) -> None:
        # ### PATCH START: validated ordinary-MTP role
        nn.Module.__init__(self)
        if resolve_deepseek_v4_mtp_contract(vllm_config) is None:
            raise ValueError("MTP role construction requires the ordinary V4 contract")
        role = parse_afd_config(vllm_config, validate=False).role
        # ### PATCH END: validated ordinary-MTP role
        config = vllm_config.speculative_config.draft_model_config.hf_config
        self.config = config
        self.use_v2_model_runner = vllm_config.use_v2_model_runner
        quant_config = vllm_config.quant_config

        # ### PATCH START: A-owned draft state
        topk_indices_buffer = None
        if role == "attention":
            self.e_proj = native.ReplicatedLinear(
                config.hidden_size,
                config.hidden_size,
                bias=False,
                quant_config=quant_config,
                prefix=f"{prefix}.e_proj",
                return_bias=False,
            )
            self.h_proj = native.ReplicatedLinear(
                config.hidden_size,
                config.hidden_size,
                bias=False,
                quant_config=quant_config,
                prefix=f"{prefix}.h_proj",
                return_bias=False,
            )
            self.enorm = native.RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
            self.hnorm = native.RMSNorm(config.hidden_size, eps=config.rms_norm_eps)
            self.device = native.current_platform.device_type
            self.is_v32 = hasattr(config, "index_topk")
            if self.is_v32:
                topk_indices_buffer = torch.empty(
                    vllm_config.scheduler_config.max_num_batched_tokens,
                    config.index_topk,
                    dtype=torch.int32,
                    device=self.device,
                )
            self.shared_head = native.SharedHead(
                config=config, prefix=prefix, quant_config=quant_config
            )
        # ### PATCH END: A-owned draft state
        # ### PATCH START: role-local draft decoder
        decoder_type = (
            AFDDeepseekV4DecoderLayer
            if role == "attention"
            else AFDDeepseekV4MtpFFNLayer
        )
        self.mtp_block = decoder_type(
            vllm_config,
            prefix,
            config=self.config,
            topk_indices_buffer=topk_indices_buffer,
            is_draft_layer=True,
        )
        # ### PATCH END: role-local draft decoder
        # ### PATCH START: A-owned HC head
        if role == "attention":
            self.hc_eps = config.hc_eps
            self.hc_mult = hc_mult = config.hc_mult
            hc_dim = hc_mult * config.hidden_size
            self.hc_head_fn = nn.Parameter(
                torch.empty(hc_mult, hc_dim, dtype=torch.float32)
            )
            self.hc_head_base = nn.Parameter(torch.empty(hc_mult, dtype=torch.float32))
            self.hc_head_scale = nn.Parameter(torch.empty(1, dtype=torch.float32))
            self.norm_eps = config.rms_norm_eps
            self.hc_norm = native.RMSNorm(
                hc_dim, eps=config.rms_norm_eps, has_weight=False, dtype=torch.float32
            )
        # ### PATCH END: A-owned HC head


class AFDDeepSeekMultiTokenPredictor(native.DeepSeekMultiTokenPredictor):
    # Upstream: deepseek_v4/mtp.py:191-211, Ascend
    # 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: construct the validated role-local physical block;
    # token embedding/logits remain A-owned. Signature matches (no return type).
    # Cost: one block; native logical N-step reuse and head sharing are unchanged.
    # Remove when native predictor constructors accept role/layer dependencies.
    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        # ### PATCH START: validated physical draft block
        nn.Module.__init__(self)
        contract = resolve_deepseek_v4_mtp_contract(vllm_config)
        if contract is None:
            raise ValueError("MTP predictor requires the ordinary V4 contract")
        role = parse_afd_config(vllm_config, validate=False).role
        # ### PATCH END: validated physical draft block
        config = vllm_config.model_config.hf_config
        self.mtp_start_layer_idx = config.num_hidden_layers
        # ### PATCH START: one physical block, independent logical N
        self.num_mtp_layers = len(contract.draft_layer_indices)
        self.layers = nn.ModuleDict(
            {
                str(idx): AFDDeepSeekMultiTokenPredictorLayer(
                    vllm_config, f"{prefix}.{idx}"
                )
                for idx in contract.draft_layer_indices
            }
        )
        if role == "attention":
            self.embed_tokens = native.VocabParallelEmbedding(
                config.vocab_size, config.hidden_size
            )
            self.logits_processor = native.LogitsProcessor(config.vocab_size)
        # ### PATCH END: one physical block, independent logical N


@native.support_torch_compile
class AFDDeepSeekV4MTP(native.DeepSeekV4MTP):
    # Upstream: deepseek_v4/mtp.py:252-258, Ascend
    # 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: select role-local predictor without loading the full
    # unsplit draft. Signature matches exactly, including absent return type.
    # Cost: native A/F allocations only; no extra TP reduction. Remove when the
    # native loader/model exposes role construction and proposal callbacks.
    def __init__(self, *, vllm_config: VllmConfig, prefix: str = ""):
        # ### PATCH START: role-local MTP model
        nn.Module.__init__(self)
        if resolve_deepseek_v4_mtp_contract(vllm_config) is None:
            raise ValueError("MTP model requires the ordinary V4 contract")
        self.afd_role = parse_afd_config(vllm_config, validate=False).role
        self._mtp_session: HcclMtpSession | None = None
        # ### PATCH END: role-local MTP model
        self.config = vllm_config.model_config.hf_config
        self.quant_config = vllm_config.quant_config
        # ### PATCH START: role-local native predictor type
        self.model = AFDDeepSeekMultiTokenPredictor(
            vllm_config=vllm_config, prefix=native.maybe_prefix(prefix, "mtp")
        )
        # ### PATCH END: role-local native predictor type
        self.set_moe_parameters()

    def bind_mtp_session(self, session: "HcclMtpSession") -> None:
        if (
            self.afd_role != "attention"
            or self._mtp_session is not None
            or session.draft_model is not self
        ):
            raise ValueError("MTP session must own this unbound Attention draft model")
        self._mtp_session = session

    # Upstream: deepseek_v4/mtp.py:284-294, Ascend
    # 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: accepted draft-call scope surrounds the real native
    # body; retain its flattened HC feedback without changing logits/sampling.
    # Signature matches exactly. Cost: one host scope per actual model call.
    # Remove when native MTP exposes actual-model-call lifecycle hooks.
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        hidden_states: torch.Tensor,
        intermediate_tensors: IntermediateTensors | None = None,
        inputs_embeds: torch.Tensor | None = None,
        spec_step_idx: int = 0,
    ) -> torch.Tensor:
        # ### PATCH START: actual native draft call
        session = self._mtp_session
        if self.afd_role != "attention" or session is None:
            raise RuntimeError(
                "native MTP forward requires its bound Attention session"
            )
        with session.draft_forward(
            self, input_ids, positions, hidden_states, inputs_embeds
        ):
            # ### PATCH END: actual native draft call
            hidden_states = self.model(
                input_ids, positions, hidden_states, inputs_embeds, spec_step_idx
            )
            # ### PATCH START: preserve native feedback lifetime
            session.retain_draft_output(hidden_states)
            # ### PATCH END: preserve native feedback lifetime
            return hidden_states

    def compute_ffn_output(
        self,
        hidden_states: torch.Tensor,
        layer_idx: int,
        *,
        input_ids: torch.Tensor,
        hidden_states_fp32: torch.Tensor,
    ) -> torch.Tensor:
        if self.afd_role != "ffn" or layer_idx != 0:
            raise ValueError("MTP FFN execution requires the sole physical draft layer")
        moe = self.model.layers["0"].mtp_block.mlp
        if not isinstance(moe, native.DeepseekV4MoE):
            raise RuntimeError("MTP FFN role must own the complete native draft MoE")
        return moe(
            hidden_states, input_ids=input_ids, hidden_states_fp32=hidden_states_fp32
        )

    # Upstream: deepseek_v4/mtp.py:303-559, Ascend
    # 7e37e29a7803d6897a7113088e2b771f83205bc0.
    # Reason/functionality: filter exact checkpoint components by role before
    # native quantized/expert mapping. Signature matches exactly.
    # Delegation exception: the large native loader owns expert/scale/FP8 aliases
    # and loaded-parameter accounting; copying it would duplicate quant owners.
    # Cost: one name-component test per checkpoint weight; no tensor copies.
    # Remove when native loaders accept a role-specific checkpoint predicate.
    def load_weights(self, weights: Iterable[tuple[str, torch.Tensor]]) -> set[str]:
        # ### PATCH START: exact role checkpoint namespace
        quantization = (
            None if self.quant_config is None else self.quant_config.get_name()
        )
        role_weights = (
            (name, weight)
            for name, weight in weights
            if deepseek_v4_mtp_weight_role(name, quantization_name=quantization)
            == self.afd_role
        )
        # ### PATCH END: exact role checkpoint namespace
        return super().load_weights(role_weights)
