import json,sys
from pathlib import Path
root=Path(__file__).resolve().parent
snapshot=root/'snapshot'
sys.path[:0]=[str(snapshot/'tests/npu'),str(snapshot)]
import dsv41_dspark_a5_validation as shared
output=root/'kv-script-check'
output.mkdir()
report={'success':False,'inference_executed':False,'scope':'actual A3 native KV setup through the frozen functional helper'}
try:
    report['npu_before']=shared.npu_snapshot(output/'npu-before.log')
    assert report['npu_before']['all_eight_idle']
    command=[sys.executable,'-B',str(root/'check_scripts-kv.py'),'--snapshot',str(snapshot),'--model','/mnt/workspace/models/DeepSeek-V4.1-Flash','--output-dir',str(output/'worker'),'--device','1','--child','load']
    report['process']=shared.run_bounded(command,shared.source_environment(snapshot),snapshot,output/'native-kv.log',480)
    worker=json.loads((output/'worker/result.json').read_text())
    report['worker_success']=worker['success']
    report['worker_traceback']=worker.get('traceback')
    report['success']=report['process']['success'] and worker['success'] and worker['attention_kv_initialized'] and worker['parameters_unchanged_after_kv']
finally:
    report['npu_after']=shared.npu_snapshot(output/'npu-after.log')
    report['success']=report['success'] and report['npu_after']['all_eight_idle']
    shared.write_json(output/'summary.json',report)
print(json.dumps(report),flush=True)
raise SystemExit(0 if report['success'] else 1)
