import argparse, hashlib, json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--phase',required=True); a=p.parse_args()
root=Path(__file__).resolve().parent
r=json.loads((root/'environment-record.json').read_text())
counts={}
for group in ('active_artifacts','toolchain_artifacts','expected_native_library_sha256'):
    entries=r[group]
    for path, expected in entries.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected, path
    counts[group]=len(entries)
man=json.loads((root/'snapshot/bundle-manifest.json').read_text())
for name,expected in man['sources'].items():
    raw=(root/'snapshot'/name).read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected,name
    if name.endswith('.py'): compile(raw,name,'exec')
report={'passed':True,'phase':a.phase,'preserved':counts,'frozen_sources':len(man['sources']),'archive_sha256':hashlib.sha256((root/'bundle/runtime-source.tar.gz').read_bytes()).hexdigest()}
(root/(a.phase+'-preservation.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
