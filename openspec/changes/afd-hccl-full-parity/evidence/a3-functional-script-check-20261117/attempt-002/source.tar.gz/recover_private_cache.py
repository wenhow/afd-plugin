import json
from pathlib import Path
root=Path('/mnt/workspace/tmp/afd-c0-20261104.hVgsIf/functional-script-check-20261117-aed7k8py')
summary=json.loads((root/'results/summary.json').read_text())
assert summary['npu_after']['all_eight_idle']
for check in summary['checks']:
    process=check['process']
    assert not process['surviving_owned_pids']
    for pid,ticks in process['owned_pid_start_ticks'].items():
        stat=Path('/proc')/pid/'stat'
        if stat.exists():
            fields=stat.read_text().rsplit(') ',1)[1].split()
            assert fields[19]!=str(ticks) or fields[0]=='Z', pid
cache=root/'cache/torch-extensions'
removed=[]
for path in cache.rglob('lock'):
    assert path.resolve().is_relative_to(cache.resolve()) and path.is_file()
    removed.append({'path':str(path),'mtime_ns':path.stat().st_mtime_ns,'bytes':path.stat().st_size})
    path.unlink()
report={'all_original_process_identities_dead':True,'task_private_locks_removed':removed}
Path('private-cache-lock-recovery.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
