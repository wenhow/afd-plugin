# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Preparation primitives for a live native P aux/DSpark-prefix component.

Importing this helper is standard-library only. It does not run a worker,
publish Ready, or claim live integration. A supervised successor driver supplies
real native groups, the P owner, scheduling, sample/proposal and transfer peers.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Literal
from uuid import UUID

if TYPE_CHECKING:
    from collections.abc import Callable

    import torch
    from vllm.config import VllmConfig
    from vllm.model_executor.layers.vocab_parallel_embedding import (
        VocabParallelEmbedding,
    )
    from vllm.v1.kv_cache_interface import KVCacheConfig
    from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector
    from vllm.v1.worker.gpu.model_states.interface import ModelState
    from vllm_ascend.worker.v2.block_table import AscendBlockTables
    from vllm_ascend.worker.v2.input_batch import AscendInputBuffers
    from vllm_ascend.worker.v2.spec_decode.dspark.speculator import (
        AscendDSparkSpeculator,
    )

    from afd_plugin.compat.npu.dspark_pd import (
        DsparkPdPrefixConsumer,
        DsparkPdWriteReport,
    )
    from afd_plugin.compat.npu.kv_layout_native import KVCacheValue

GREEDY_TOKEN = 7
REJECTED_VERIFICATION_TOKEN = 8
SECOND_VERIFICATION_ROW = 1
VERIFICATION_ROWS = 3
ROUTER_DELTA = 0.00031
ROUTER_SCALE = 4096
DRAFT_WORKSPACE_LANE = 1
WORKSPACE_LANES = 2
TARGET_GRAPH_CAPTURE_SIZES = (VERIFICATION_ROWS,)
TARGET_GRAPH_WARMUP_RUNS = 1
TARGET_U2_REQUESTS = 2
TARGET_U2_STAGES = 2
TARGET_U2_TOKENS = TARGET_U2_REQUESTS * VERIFICATION_ROWS
MARKOV_ANCHOR_CHANNEL = 0
MARKOV_LOGIT_MARGIN_FACTOR = 4
MAX_DRAFT_NORM_WEIGHT = 1


@dataclass(frozen=True)
class LivePrefixBindings:
    """Keep the actual loaded model and registration generation together."""

    config: VllmConfig
    target: torch.nn.Module
    speculator: AscendDSparkSpeculator
    model_state: ModelState
    input_buffers: AscendInputBuffers
    block_tables: AscendBlockTables
    kv_config: KVCacheConfig
    caches: dict[str, KVCacheValue]
    consumer: DsparkPdPrefixConsumer
    active: ActiveKVConnector
    embedding_cpu: torch.Tensor


def create_live_prefix_config(
    model: str,
    output_dir: Path,
    *,
    role: Literal["kv_producer", "kv_consumer"],
    engine_id: str,
    host: str,
    handshake_port: int,
    afd_port: int,
    afd_role: Literal["attention", "ffn"] = "attention",
    target_graph: bool = False,
    target_u2: bool = False,
    graph_exchange_order: Literal["stage_serial", "cross_layer_v1"] = "stage_serial",
    eager_stream_overlap: bool = False,
) -> VllmConfig:
    """Fix DSpark/PD, optionally D target Graph, before any owner exists.

    F uses the same original D declaration before its normal runtime isolation.
    The native draft stays eager in both modes; the default remains eager U1.
    """
    from dsv41_dspark_speculator_probe import (
        BLOCK_SIZE,
        HC_MULT,
        HIDDEN_SIZE,
        MAX_BATCHED_TOKENS,
        MAX_MODEL_LEN,
        MAX_REQUESTS,
        SEED,
        SPECULATIVE_TOKENS,
        TARGET_LAYERS,
        bounded_hf_config,
    )
    from vllm.config import CompilationConfig, CompilationMode, CUDAGraphMode
    from vllm.config.kv_transfer import KVTransferConfig
    from vllm.engine.arg_utils import EngineArgs

    from afd_plugin.compat.npu import apply_afd_ascend_config_patch_if_needed
    from afd_plugin.compat.npu.runtime_config import validate_deepseek_v41_pd

    assert type(target_graph) is bool and type(target_u2) is bool
    assert type(eager_stream_overlap) is bool
    if eager_stream_overlap and (
        target_graph or not target_u2 or role != "kv_consumer"
    ):
        raise ValueError("eager streams require the eager native U2 PD consumer")
    if target_graph and role != "kv_consumer":
        raise ValueError("target Graph requires the PD consumer declaration")
    if target_u2 and not (target_graph or eager_stream_overlap):
        raise ValueError("target U2 requires consumer Graph or explicit eager streams")
    if graph_exchange_order not in ("stage_serial", "cross_layer_v1"):
        raise ValueError("unsupported target Graph exchange order")
    if graph_exchange_order == "cross_layer_v1" and not (target_graph and target_u2):
        raise ValueError("cross-layer exchange requires consumer target Graph U2")
    # Use the original EngineArgs entry with the complete immutable PD/AFD
    # declaration. This isolated worker loads native plugins only, so install
    # the same namespace shim used by normal AFD config construction before
    # VllmConfig.__post_init__ calls Ascend's strict config factory.
    apply_afd_ascend_config_patch_if_needed()
    if target_u2:
        # Normal register_afd installs this connector-owned configuration seam.
        # This isolated component loads native plugins only; install that same
        # seam before first construction rather than changing the validated
        # backend or restoring ubatch fields after the config is bound.
        import afd_plugin.compat.patches.config_validation  # noqa: F401

    source = Path(model) / "config.json"
    original = source.read_bytes()
    raw = json.loads(original)
    for container in (raw, raw.get("text_config", {})):
        container.pop("quantization_config", None)
        container.pop("compression_config", None)
        container["expert_dtype"] = "bf16"
    controlled = output_dir / "controlled-model"
    controlled.mkdir(parents=True, exist_ok=False)
    (output_dir / "checkpoint-config-original.json").write_bytes(original)
    (controlled / "config.json").write_text(
        json.dumps(raw, indent=2) + "\n", encoding="utf-8"
    )
    (controlled / "provenance.json").write_text(
        json.dumps(
            {
                "source_config": str(source),
                "source_config_sha256": hashlib.sha256(original).hexdigest(),
                "dummy_unquantized_configuration_only": True,
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    transfer = KVTransferConfig(
        kv_connector="MooncakeHybridConnector",
        kv_connector_module_path="afd_plugin.compat.npu.kv_layout_connector",
        kv_role=role,
        engine_id=engine_id,
        kv_buffer_device="npu",
        kv_ip=host,
        kv_port=handshake_port,
        kv_connector_extra_config={
            "prefill": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
            "decode": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
        },
    )
    if target_graph:
        capture_sizes = (TARGET_U2_TOKENS,) if target_u2 else TARGET_GRAPH_CAPTURE_SIZES
        compilation = CompilationConfig(
            mode=CompilationMode.NONE,
            cudagraph_mode=CUDAGraphMode.FULL_DECODE_ONLY,
            cudagraph_capture_sizes=list(capture_sizes),
            max_cudagraph_capture_size=max(capture_sizes),
            cudagraph_num_of_warmups=TARGET_GRAPH_WARMUP_RUNS,
            use_inductor_graph_partition=False,
        )
    else:
        compilation = CompilationConfig(
            mode=CompilationMode.NONE,
            cudagraph_mode=CUDAGraphMode.NONE,
            use_inductor_graph_partition=False,
        )
    connector_extra: dict[str, str | int] = {"max_tokens": MAX_BATCHED_TOKENS}
    if target_graph:
        connector_extra["graph_exchange_order"] = graph_exchange_order
    ubatch_thresholds = (
        {
            "dbo_decode_token_threshold": TARGET_U2_TOKENS,
            "dbo_prefill_token_threshold": TARGET_U2_TOKENS,
        }
        if target_u2
        else {}
    )
    config = EngineArgs(
        model=str(controlled),
        # Native KV consumers enable embedding inputs even in language-only
        # mode. Their Scheduler still constructs the registered processor,
        # which requires the original tokenizer; keep its files read-only.
        tokenizer=model,
        trust_remote_code=True,
        skip_tokenizer_init=False,
        language_model_only=True,
        dtype="bfloat16",
        hf_overrides=bounded_hf_config,
        load_format="dummy",
        enforce_eager=not target_graph,
        max_model_len=MAX_MODEL_LEN,
        max_num_seqs=TARGET_U2_REQUESTS if target_u2 else MAX_REQUESTS,
        max_num_batched_tokens=MAX_BATCHED_TOKENS,
        enable_chunked_prefill=True,
        enable_prefix_caching=False,
        tensor_parallel_size=1,
        enable_expert_parallel=False,
        enable_dbo=False,
        ubatch_size=TARGET_U2_STAGES if target_u2 else 0,
        async_scheduling=False,
        block_size=BLOCK_SIZE,
        seed=SEED,
        compilation_config=compilation,
        speculative_config={
            "method": "dspark",
            "num_speculative_tokens": SPECULATIVE_TOKENS,
            "draft_tensor_parallel_size": 1,
            "draft_sample_method": "greedy",
            "enable_adaptive_verification": False,
            "enforce_eager": True,
        },
        kv_transfer_config=transfer,
        additional_config={
            "enable_cpu_binding": False,
            "enable_flashcomm1": False,
            "enable_dsa_cp": False,
            "multistream_dsv4_dsa_overlap": False,
            "multistream_overlap_shared_expert": False,
            "multistream_engram_overlap": False,
            "afd": {
                "connector": "P2pHcclAFDConnector",
                "role": afd_role,
                "host": host,
                "num_attention_ranks": 1,
                "num_ffn_ranks": 1,
                "port": afd_port,
                "connector_extra_config": connector_extra,
            },
        },
        **ubatch_thresholds,
    ).create_engine_config()
    validate_deepseek_v41_pd(config)
    assert config.model_config.tokenizer == model
    assert not config.model_config.skip_tokenizer_init
    assert config.model_config.multimodal_config.language_model_only
    assert config.model_config.hf_text_config.hidden_size == HIDDEN_SIZE
    assert config.model_config.hf_text_config.hc_mult == HC_MULT
    assert config.model_config.hf_text_config.num_hidden_layers == TARGET_LAYERS
    assert config.num_speculative_tokens == SPECULATIVE_TOKENS
    assert config.model_config.quantization is config.quant_config is None
    assert config.speculative_config.draft_model_config.quantization is None
    assert config.speculative_config.draft_model_config.architectures == [
        "DeepseekV41DSparkModel"
    ]
    assert config.speculative_config.enforce_eager is True
    assert config.model_config.enforce_eager is (not target_graph)
    assert config.compilation_config.mode == CompilationMode.NONE
    assert not config.compilation_config.use_inductor_graph_partition
    assert config.parallel_config.use_ubatching is target_u2
    assert not config.parallel_config.enable_dbo
    assert config.scheduler_config.max_num_seqs == (
        TARGET_U2_REQUESTS if target_u2 else MAX_REQUESTS
    )
    if target_u2:
        assert config.parallel_config.num_ubatches == TARGET_U2_STAGES
        assert config.parallel_config.dbo_decode_token_threshold == TARGET_U2_TOKENS
        assert config.parallel_config.dbo_prefill_token_threshold == TARGET_U2_TOKENS
    if target_graph:
        assert (
            config.compilation_config.cudagraph_mode == CUDAGraphMode.FULL_DECODE_ONLY
        )
        assert config.compilation_config.cudagraph_capture_sizes == list(capture_sizes)
        assert config.compilation_config.max_cudagraph_capture_size == max(
            capture_sizes
        )
        assert (
            config.compilation_config.cudagraph_num_of_warmups
            == TARGET_GRAPH_WARMUP_RUNS
        )
    else:
        assert config.compilation_config.cudagraph_mode == CUDAGraphMode.NONE
    assert config.kv_transfer_config.kv_role == role
    # Native Ascend makes each P/D engine unique during platform validation.
    # Retain that actual identity throughout consumer/handshake/scheduling.
    actual_engine_id = config.kv_transfer_config.engine_id
    prefix = engine_id + "-"
    assert actual_engine_id.startswith(prefix)
    suffix = actual_engine_id.removeprefix(prefix)
    assert UUID(hex=suffix).hex == suffix
    assert not config.compilation_config.static_forward_context
    return config


def build_live_prefix_target(
    config: VllmConfig,
    device: torch.device,
    *,
    remote_moe: bool = False,
    target_logits_policy: Literal["constant7", "reject-second-verification-row"]
    | None = None,
):
    """Build a controlled HC4 target using real native carriers and V4.1 forward.

    Only this target's Attention/HC/local MoE arithmetic is controlled. The
    loaded draft is a different, fully native model with no substituted leaves.
    A declared logits policy changes only this target's returned logits after
    the real head projection. None preserves the original head/logits behavior.
    """
    import torch
    from dsv41_dspark_speculator_probe import (
        AUX_LAYER_IDS,
        HC_MULT,
        HIDDEN_SIZE,
        MAX_MODEL_LEN,
        ROPE_HEAD_SIZE,
        TARGET_LAYERS,
        VOCAB_SIZE,
        create_target_interface,
    )
    from torch import nn
    from vllm.forward_context import get_forward_context
    from vllm.model_executor.layers.logits_processor import LogitsProcessor
    from vllm_ascend.models.deepseek_v41.model import DeepseekV41SharedAttentionState
    from vllm_ascend.ops.rope_dsv4 import ComplexExpRotaryEmbedding
    from vllm_ascend.ops.vocab_parallel_embedding import AscendLogitsProcessor

    from afd_plugin.model_executor.models.npu.deepseek_v41 import (
        AFDDeepseekV41AttentionDecoderLayer,
        AFDDeepseekV41AttentionForCausalLM,
        AFDDeepseekV41AttentionLLMForCausalLM,
        AFDDeepseekV41AttentionModel,
        AFDDeepseekV41RemoteMoE,
    )

    assert config.model_config.hf_text_config.hidden_size == HIDDEN_SIZE
    assert config.model_config.hf_text_config.hc_mult == HC_MULT
    if target_logits_policy not in (
        None,
        "constant7",
        "reject-second-verification-row",
    ):
        raise ValueError("unsupported controlled target logits policy")

    class ControlledTargetLogitsProcessor(AscendLogitsProcessor):
        def forward(
            self,
            lm_head: VocabParallelEmbedding,
            hidden_states: torch.Tensor,
            embedding_bias: torch.Tensor | None = None,
            skip_gather: bool = False,
        ) -> torch.Tensor | None:
            # Keep the genuine target LM-head call, including its native gather.
            # The draft has a separate logits processor and shares only weights.
            native_logits = super().forward(
                lm_head, hidden_states, embedding_bias, skip_gather
            )
            assert native_logits is not None
            assert native_logits.shape[0] in (
                1,
                TARGET_U2_REQUESTS,
                VERIFICATION_ROWS,
                TARGET_U2_TOKENS,
            )
            logits = torch.full_like(native_logits, -torch.inf)
            logits[:, GREEDY_TOKEN] = 0
            if (
                target_logits_policy == "reject-second-verification-row"
                and logits.shape[0] in (VERIFICATION_ROWS, TARGET_U2_TOKENS)
            ):
                logits[
                    SECOND_VERIFICATION_ROW::VERIFICATION_ROWS, GREEDY_TOKEN
                ] = -torch.inf
                logits[
                    SECOND_VERIFICATION_ROW::VERIFICATION_ROWS,
                    REJECTED_VERIFICATION_TOKEN,
                ] = 0
            return logits

    # Reuse its actual public cache constructors, embedding and head; do not
    # reuse the old tiny model's hardcoded HC1 closure or mutate its constants.
    interface = create_target_interface(config)
    carriers = {carrier.prefix: carrier for carrier in interface.model.cache_carriers}
    capacity = config.scheduler_config.max_num_batched_tokens
    shared = DeepseekV41SharedAttentionState(
        torch.full((capacity, 1), -1, dtype=torch.int32, device=device),
        torch.full((capacity, 1, 2), -1, dtype=torch.int32, device=device),
        None,
        None,
    )

    class PrefixAttention(nn.Module):
        def __init__(self, index):
            super().__init__()
            self.layer_idx, self.shared_state = index, shared
            self.cache_name = f"model.layers.{index}.self_attn.swa_cache"
            self.cache_layer = carriers[self.cache_name]
            with torch.device(device):
                self.rotary_emb = ComplexExpRotaryEmbedding(
                    config,
                    self.cache_name.removesuffix(".swa_cache") + ".attn",
                    ROPE_HEAD_SIZE,
                    ROPE_HEAD_SIZE,
                    MAX_MODEL_LEN,
                    10000,
                    1.0,
                    apply_yarn_scaling=False,
                )

        def forward(self, positions, hidden_states, scaling=None):
            cache = self.cache_layer.kv_cache[0]
            metadata = get_forward_context().attn_metadata[self.cache_name]
            slots = metadata.slot_mapping
            assert cache.ndim == 4 and cache.shape[-1] == HIDDEN_SIZE
            assert slots.shape == (hidden_states.shape[0], 2)
            # Preserve the real padded physical block stride. Flattening these
            # dimensions may copy a shared-page view and lose the actual KV
            # write ownership when several planes share one physical tile.
            block = slots[:, 0].clamp_min(0).long()
            position = slots[:, 1].clamp_min(0).long()
            previous = cache[block, (position - 1).clamp_min(0), 0]
            previous = previous.masked_fill((slots[:, 0] <= 0).unsqueeze(1), 0)
            retained = cache[block, position, 0]
            cache[block, position, 0] = torch.where(
                (slots[:, 0] > 0).unsqueeze(1), hidden_states, retained
            )
            return (
                hidden_states.float() + previous.float() + positions[:, None]
            ).bfloat16()

    class LocalMoE(nn.Module):
        def forward(
            self,
            hidden_states,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel=False,
        ):
            assert not already_sequence_parallel
            return (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()

    class ControlledDecoder(AFDDeepseekV41AttentionDecoderLayer):
        def __init__(self, index):
            nn.Module.__init__(self)
            self.layer_idx, self.hc_mult = index, HC_MULT
            self.self_attn = PrefixAttention(index)
            self.mlp = (
                AFDDeepseekV41RemoteMoE(layer_idx=index) if remote_moe else LocalMoE()
            )
            self.use_sequence_parallel = False
            self.input_layernorm = nn.Identity()
            self.engram = None
            self.hc_attn_fn = self.hc_ffn_fn = 0
            self.hc_attn_scale = self.hc_ffn_scale = 0
            self.hc_attn_base = self.hc_ffn_base = 0

        def hc_pre(self, x, fn, scale, base, pre_mix=None):
            post = x.new_ones((x.shape[0], HC_MULT), dtype=torch.float32)
            comb = x.new_zeros((x.shape[0], HC_MULT, HC_MULT))
            return x[:, 0], post, comb, post / HC_MULT

        def hc_post(self, x, residual, post, comb):
            return (residual.float() + x.float().unsqueeze(1)).bfloat16()

        def rms_norm_cast(self, hidden_states):
            return hidden_states.clone(), hidden_states.float() + ROUTER_DELTA

    core = AFDDeepseekV41AttentionModel.__new__(AFDDeepseekV41AttentionModel)
    nn.Module.__init__(core)
    core.config = config.model_config.hf_text_config
    core.hc_mult, core.has_engram = HC_MULT, False
    core.engram_hash = None
    # Native target construction reserves the pre-collapse HC buffer for every
    # draft-model speculator, including DSpark. GPU.sample_tokens reads this
    # public target method before passing ordered aux to original propose.
    speculative = config.speculative_config
    needs_mtp = speculative is not None and (
        speculative.use_eagle() or speculative.uses_draft_model()
    )
    core._mtp_hidden_buffer = (
        torch.empty(
            capacity,
            HC_MULT * HIDDEN_SIZE,
            device=device,
            dtype=config.model_config.dtype,
        )
        if needs_mtp
        else None
    )
    core.use_sequence_parallel = False
    core.start_layer, core.end_layer = 0, TARGET_LAYERS
    core.layers = nn.ModuleList(ControlledDecoder(i) for i in range(TARGET_LAYERS))
    core.shared_attention_state = shared
    core.norm = nn.Identity()
    core.aux_hidden_state_layers = ()
    core.embed_tokens = interface.model.embed_tokens
    language = AFDDeepseekV41AttentionLLMForCausalLM.__new__(
        AFDDeepseekV41AttentionLLMForCausalLM
    )
    nn.Module.__init__(language)
    language.model, language.lm_head = core, interface.lm_head
    language.logits_processor = (
        LogitsProcessor(VOCAB_SIZE)
        if target_logits_policy is None
        else ControlledTargetLogitsProcessor(VOCAB_SIZE)
    )
    target = AFDDeepseekV41AttentionForCausalLM.__new__(
        AFDDeepseekV41AttentionForCausalLM
    )
    nn.Module.__init__(target)
    target.language_model = language
    target.native_cache_carriers = interface.model.cache_carriers
    embedding_cpu = (
        torch.arange(VOCAB_SIZE, device="cpu")[:, None].float()
        + torch.arange(HIDDEN_SIZE, device="cpu")[None, :].float() / HIDDEN_SIZE
    ).bfloat16()
    with torch.no_grad():
        core.embed_tokens.weight.zero_()
        core.embed_tokens.weight[:VOCAB_SIZE].copy_(embedding_cpu.to(device))
        language.lm_head.weight.zero_()
        language.lm_head.weight[GREEDY_TOKEN].fill_(1)
    target.set_aux_hidden_state_layers(AUX_LAYER_IDS)
    assert core.aux_hidden_state_layers == AUX_LAYER_IDS
    return target, embedding_cpu


def initialize_bounded_markov_fixture(
    speculator: AscendDSparkSpeculator,
) -> dict:
    """Declare dummy Markov parameters before the first native proposal.

    The shared LM head has only row 7 populated. Native RMS normalization
    bounds its base logit by the hidden width (allowing BF16 rounding).
    A larger, exactly representable Markov margin makes this fixture's draft
    deterministic while preserving the native head, sampling and rejection.
    These are synthetic component weights, not checkpoint accuracy evidence.
    """
    import torch
    from dsv41_dspark_speculator_probe import HIDDEN_SIZE, VOCAB_SIZE
    from vllm.model_executor.model_loader.weight_utils import default_weight_loader

    draft = speculator.model
    assert speculator.speculative_config.dspark_draft_topk is None
    assert draft.logits_processor.scale == 1
    assert draft.logits_processor.soft_cap is None
    assert draft.model.config.rms_norm_eps > 0
    norm_weight = draft.model.norm.weight
    assert torch.isfinite(norm_weight).all().item()
    assert norm_weight.abs().max().item() <= MAX_DRAFT_NORM_WEIGHT
    head = torch.zeros_like(draft.lm_head.weight)
    assert head.shape == (VOCAB_SIZE, HIDDEN_SIZE)
    head[GREEDY_TOKEN].fill_(1)
    assert torch.equal(draft.lm_head.weight, head)
    markov = draft.model.markov_head
    last_layer = draft.model.mtp_start_layer_idx + draft.model.num_dspark_layers - 1
    assert draft.model.layers[str(last_layer)].markov_head is markov
    first = torch.zeros_like(markov.markov_w1.weight)
    second = torch.zeros_like(markov.markov_w2.weight)
    margin = MARKOV_LOGIT_MARGIN_FACTOR * HIDDEN_SIZE
    first[:, MARKOV_ANCHOR_CHANNEL] = 1
    second[GREEDY_TOKEN, MARKOV_ANCHOR_CHANNEL] = margin
    parameters = []
    for name, parameter, value in (
        ("markov_w1.weight", markov.markov_w1.weight, first),
        ("markov_w2.weight", markov.markov_w2.weight, second),
    ):
        pointer = parameter.data_ptr()
        before = parameter.detach().cpu().view(torch.uint8).numpy().tobytes()
        default_weight_loader(parameter, value)
        assert parameter.data_ptr() == pointer
        assert torch.equal(parameter, value)
        after = parameter.detach().cpu().view(torch.uint8).numpy().tobytes()
        parameters.append(
            {
                "name": name,
                "before_sha256": hashlib.sha256(before).hexdigest(),
                "after_sha256": hashlib.sha256(after).hexdigest(),
                "data_ptr_before": pointer,
                "data_ptr_after": parameter.data_ptr(),
            }
        )
    return {
        "scope": "Predeclared synthetic Markov parameters; not checkpoint accuracy",
        "anchor_channel": MARKOV_ANCHOR_CHANNEL,
        "draft_token": GREEDY_TOKEN,
        "logit_margin": margin,
        "max_norm_weight": MAX_DRAFT_NORM_WEIGHT,
        "parameters": parameters,
    }


def create_loaded_prefix_consumer(
    config: VllmConfig,
    target: torch.nn.Module,
    speculator: AscendDSparkSpeculator,
    device: torch.device,
    *,
    agree_batch: Callable[[DsparkPdWriteReport], tuple[DsparkPdWriteReport, ...]],
) -> DsparkPdPrefixConsumer:
    """Bind the actual loaded target/draft before TE registration or execution."""
    from vllm.distributed import get_tp_group

    from afd_plugin.compat.npu.dspark_pd import DsparkPdPrefixConsumer

    group = get_tp_group()
    return DsparkPdPrefixConsumer(
        config,
        speculator,
        target_model=target,
        device=device,
        source_engine_id=config.kv_transfer_config.engine_id,
        tp_rank=group.rank_in_group,
        tp_size=group.world_size,
        agree_batch=agree_batch,
    )


def register_live_prefix_storage(
    config: VllmConfig,
    kv_config: KVCacheConfig,
    caches: dict[str, KVCacheValue],
    consumer: DsparkPdPrefixConsumer,
):
    """Retain the production bind-before-register order on the real singleton."""
    from vllm.distributed.kv_transfer import (
        ensure_kv_transfer_initialized,
        get_kv_transfer_group,
        has_kv_transfer_group,
    )
    from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector, get_kv_connector

    from afd_plugin.compat.npu.kv_layout_connector import MooncakeHybridConnector

    assert config is consumer.vllm_config
    assert consumer.speculator.kv_cache_config is kv_config
    assert not has_kv_transfer_group()
    kv_config.dspark_draft_layer_names = frozenset(consumer.binding.draft_layer_names)
    ensure_kv_transfer_initialized(config, kv_config)
    connector = get_kv_transfer_group()
    assert type(connector) is MooncakeHybridConnector
    assert connector.connector_worker.kv_cache_config is kv_config
    connector.bind_dspark_model(consumer)
    active = get_kv_connector(config, caches)
    assert isinstance(active, ActiveKVConnector)
    assert active.kv_connector is connector
    return active


def load_live_prefix_bindings(
    config: VllmConfig,
    device: torch.device,
    *,
    agree_batch: Callable[[DsparkPdWriteReport], tuple[DsparkPdWriteReport, ...]],
    report: dict,
) -> LivePrefixBindings:
    """Load and register real dependencies under an already initialized TP1 world.

    The isolated caller owns native platform/custom-op setup, process groups and
    final supervised teardown. It must retain this result, inject its original
    objects into the P owner, and use production execute/sample publication.
    This function does not execute a target, propose, publish Ready or transfer.
    """
    import torch
    from dsv41_dspark_speculator_probe import bind_native_attention, native_source
    from vllm.config import set_current_vllm_config
    from vllm.distributed import get_tp_group
    from vllm.utils.torch_utils import set_default_torch_dtype
    from vllm.v1.worker.workspace import init_workspace_manager, use_workspace_lane
    from vllm_ascend.utils import register_ascend_customop, set_potential_max_tokens
    from vllm_ascend.worker.v2.spec_decode.dspark.speculator import (
        AscendDSparkSpeculator,
    )
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    from afd_plugin.compat.patches.npu.ascend_config import init_ascend_config

    group = get_tp_group()
    assert group.world_size == 1 and group.rank_in_group == 0
    assert config.kv_transfer_config.kv_role == "kv_producer"
    assert not config.compilation_config.static_forward_context
    # Native EngineArgs/worker perform these before loading. The compatibility
    # entry retains Ascend's strict namespace while excluding only AFD settings.
    init_ascend_config(config)
    set_potential_max_tokens(config)
    init_workspace_manager(device, num_ubatches=1, num_lanes=WORKSPACE_LANES)
    with (
        set_current_vllm_config(config),
        torch.device(device),
        set_default_torch_dtype(torch.bfloat16),
        torch.inference_mode(),
        torch_cuda_wrapper(),
    ):
        register_ascend_customop(config)
        target, embedding_cpu = build_live_prefix_target(config, device)
        speculator = AscendDSparkSpeculator(config, device)
        speculator.update_stream = torch.npu.Stream(device=device)
        with use_workspace_lane(DRAFT_WORKSPACE_LANE):
            speculator.load_model(target)
        consumer = create_loaded_prefix_consumer(
            config, target, speculator, device, agree_batch=agree_batch
        )
        model_state, buffers, tables, kv_config, caches = bind_native_attention(
            config, target, speculator, device, report
        )
        active = register_live_prefix_storage(config, kv_config, caches, consumer)
    report["live_prefix_preparation"] = {
        "native_speculator_class": type(speculator).__module__
        + "."
        + type(speculator).__qualname__,
        "native_speculator_loaded": True,
        "consumer_bound_before_registration": True,
        "target_aux_layer_ids": list(target.model.aux_hidden_state_layers),
        "draft_layer_names": list(consumer.binding.draft_layer_names),
        "target_controlled_arithmetic": True,
        "draft_leaves_substituted": False,
        "native_target_execute_executed": False,
        "native_sample_or_propose_executed": False,
        "ready_published": False,
        "remote_read_or_lease_verified": False,
        "native_sources": {
            "speculator": native_source(AscendDSparkSpeculator),
            "load_model": native_source(AscendDSparkSpeculator.load_model),
            "set_attn": native_source(AscendDSparkSpeculator.set_attn),
            "workspace": native_source(init_workspace_manager),
        },
    }
    return LivePrefixBindings(
        config,
        target,
        speculator,
        model_state,
        buffers,
        tables,
        kv_config,
        caches,
        consumer,
        active,
        embedding_cpu,
    )
