/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

#ifndef CATLASS_LAYOUT_LAYOUT_HPP
#define CATLASS_LAYOUT_LAYOUT_HPP

#include "../../gmm_infra/base_defs.hpp"
#include "../../gmm_infra/layout/matrix.hpp"
#include "../../gmm_infra/layout/vector.hpp"

#endif  // CATLASS_LAYOUT_LAYOUT_HPP
