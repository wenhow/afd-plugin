/**
 * Copyright (c) 2025 Huawei Technologies Co., Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * CANN Open Software License Agreement Version 2.0 (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 * See LICENSE in the root of the software repository for the full text of the License.
 */

/*
 * SPDX-License-Identifier: MIT
 * Copyright (c) Huawei Technologies Co., Ltd. 2026-2026. All rights reserved.
 * Description: grouped_matmul_swiglu_quant_v2_layered_a8w4_msd_mid header file
 * Create: 2026-09-20
 * Note:
 * History: 2026-09-20 port from cam_async repository
 */

/*!
 * \file grouped_matmul_swiglu_quant_v2_a8w4_msd_mid.h
 * \brief
 */

#ifndef OP_KERNEL_GROUPED_MATMUL_SWIGLU_QUANT_V2_LAYERED_A8W4_MSD_MID_H
#define OP_KERNEL_GROUPED_MATMUL_SWIGLU_QUANT_V2_LAYERED_A8W4_MSD_MID_H

#include "grouped_matmul_swiglu_quant_v2_layered_utils.h"

#ifdef GMM_SWIGLU_QUANT_V2_A8W4_MSD

namespace GroupedMatmulDequantSwigluQuant {
using namespace matmul;
using namespace AscendC;

constexpr uint32_t BUFFER_NUM = 1;

template <typename T>
__aicore__ inline void DataCopyPad2DA8W4(const LocalTensor<T> dst, const GlobalTensor<T> src, uint32_t dim1,
                                         uint32_t dim0, uint32_t srcDim0)
{
    DataCopyExtParams params;
    params.blockCount = dim1;
    params.blockLen = dim0 * sizeof(T);
    params.srcStride = (srcDim0 - dim0) * sizeof(T);
    // 32: int32 -> float16; to prevent cross-row data from entering the same 32B block, align each row to an even block
    // count in advance
    params.dstStride = Ceil(dim0 * sizeof(T), 32) % 2;

    DataCopyPadExtParams<T> padParams{true, 0, 0, 0};
    DataCopyPad(dst, src, params, padParams);
}

template <typename T>
__aicore__ inline void DataCopyPad2DA8W4ND(const LocalTensor<T> dst, const GlobalTensor<T> src, uint32_t dim1,
                                           uint32_t dim0, uint32_t srcDim0)
{
    DataCopyExtParams params;
    params.blockCount = dim1;
    params.blockLen = dim0 * sizeof(T);
    params.srcStride = (srcDim0 - dim0) * sizeof(T);
    params.dstStride = 0;

    DataCopyPadExtParams<T> padParams{true, 0, 0, 0};
    DataCopyPad(dst, src, params, padParams);
    return;
}

template <typename T>
__aicore__ inline void DataCopyPad2DA8W4(const GlobalTensor<T> dst, const LocalTensor<T> src, uint32_t dim1,
                                         uint32_t dim0, uint32_t srcDim0, uint32_t dstDim0)
{
    DataCopyExtParams params;
    params.blockCount = dim1;
    params.blockLen = dim0 * sizeof(T);
    // 32: UB access granularity is 32B
    params.srcStride = (srcDim0 - dim0) * sizeof(T) / 32;
    params.dstStride = (dstDim0 - dim0) * sizeof(T);
    DataCopyPad(dst, src, params);
}

template <class mmType> class GMMA8W4MidProcess {
  public:
    using bT = typename mmType::BT;

  public:
    // Patch reason: keep both MSD tile resources initialized without repeated TPipe allocations.
    // Patch functionality: baseline starts active; preserve selection across workspace slices.
    // Signature: adds adaptiveMatmul/adaptiveTiling; remove with upstream adaptive tiling.
    // ### PATCH START: adaptive MSD tile
    __aicore__ inline GMMA8W4MidProcess(typename mmType::MT &matmul, typename mmType::MT &adaptiveMatmul,
                                       const TCubeTiling *adaptiveTiling)
        : mm(matmul), adaptiveMm(adaptiveMatmul), activeMm(&matmul),
          adaptiveBaseM(adaptiveTiling->baseM), adaptiveBaseN(adaptiveTiling->baseN)
    {
    }
    // ### PATCH END: adaptive MSD tile
    __aicore__ inline void Init(const GMAddrParams gmAddrParams,
                                const GMMSwigluQuantV2BaseParams *__restrict gmmSwigluQuantV2BaseParamsIN);
    __aicore__ inline void Process(WorkSpaceSplitConfig &workspaceSplitConfig, int64_t workspaceSplitLoopIdx);

  private:
    __aicore__ inline void MMCompute(uint32_t groupIdx, MNConfig &mnConfig, WorkSpaceSplitConfig &workspaceSplitConfig);
    __aicore__ inline void SetMNConfig(const int32_t splitValue, MNConfig &mnConfig);
    __aicore__ inline void UpdateMnConfig(MNConfig &mnConfig);

  private:
    typename mmType::MT &mm;
    // ### PATCH START: adaptive MSD tile
    typename mmType::MT &adaptiveMm;
    typename mmType::MT *activeMm;
    uint32_t adaptiveBaseM;
    uint32_t adaptiveBaseN;
    // ### PATCH END: adaptive MSD tile
    const uint32_t HALF_ALIGN = 16;
    GlobalTensor<int4b_t> xGM;
    GlobalTensor<int4b_t> xGM1;
    GlobalTensor<int4b_t> xGM2;
    GlobalTensor<int4b_t> weightGM;

    GlobalTensor<half> mmOutGM;
    GlobalTensor<half> mmOutGM1;
    GlobalTensor<half> mmOutGM2;
    GlobalTensor<int64_t> groupListGM;
    GlobalTensor<uint64_t> weightScaleGM;

    // define the que
    uint32_t subBlockIdx = 0;
    uint32_t coreIdx = 0;
    uint32_t quantGroupSize = 0;
    uint32_t vecCount = 0;
    uint32_t xRowSumCount = 0;
    const GMMSwigluQuantV2BaseParams *__restrict gmmSwigluQuantV2BaseParams;
};

template <typename mmType>
__aicore__ inline void
GMMA8W4MidProcess<mmType>::Init(const GMAddrParams gmAddrParams,
                                const GMMSwigluQuantV2BaseParams *__restrict gmmSwigluQuantV2BaseParamsIN)
{
    if ASCEND_IS_AIC {
        gmmSwigluQuantV2BaseParams = gmmSwigluQuantV2BaseParamsIN;
        xRowSumCount = gmmSwigluQuantV2BaseParams->M;
        xGM1.SetGlobalBuffer((__gm__ int4b_t *)gmAddrParams.workSpaceGM); // The result obtained from the pre-processing
        xGM2.SetGlobalBuffer(
            (__gm__ int4b_t *)((__gm__ int8_t *)gmAddrParams.workSpaceGM + gmAddrParams.workSpaceOffset1));
        weightGM.SetGlobalBuffer(GetLayerTensorAddr<int4b_t>(gmAddrParams.curLayer, gmAddrParams.layerNum, gmAddrParams.weightGM));
        weightScaleGM.SetGlobalBuffer(GetLayerTensorAddr<uint64_t>(gmAddrParams.curLayer, gmAddrParams.layerNum, gmAddrParams.weightScaleGM));
        groupListGM.SetGlobalBuffer((__gm__ int64_t *)gmAddrParams.groupListGM);
        mmOutGM1.SetGlobalBuffer(
            (__gm__ half *)((__gm__ int8_t *)gmAddrParams.workSpaceGM + gmAddrParams.workSpaceOffset2));
        mmOutGM2.SetGlobalBuffer(
            (__gm__ half *)((__gm__ int8_t *)gmAddrParams.workSpaceGM + gmAddrParams.workSpaceOffset3));
        quantGroupSize = gmmSwigluQuantV2BaseParams->K /
                         gmmSwigluQuantV2BaseParams->quantGroupNum; // Constrained to be a divisibility relationship
        subBlockIdx = GetSubBlockIdx();
        coreIdx = GetBlockIdx();
    }
}

template <typename mmType> __aicore__ inline void GMMA8W4MidProcess<mmType>::UpdateMnConfig(MNConfig &mnConfig)
{
    if constexpr (bT::format == CubeFormat::NZ) {
        mnConfig.wBaseOffset += AlignUp<16>(mnConfig.k) * AlignUp<32>(mnConfig.n); // 16: nz format last two dim size
    } else {
        mnConfig.wBaseOffset += mnConfig.k * mnConfig.n;
    }
    mnConfig.nAxisBaseOffset += mnConfig.n;
    mnConfig.mAxisBaseOffset += mnConfig.m;
    mnConfig.xBaseOffset += mnConfig.m * mnConfig.k;
    mnConfig.yBaseOffset += mnConfig.m * mnConfig.n;
}

// Patch reason: capacity does not describe an expert's intersection with the active slice.
// Patch functionality: choose a tile only when modeled tail traffic and task count do not grow.
// Signature: unchanged. Remove when upstream supports device adaptive MSD tiling.
template <typename mmType>
__aicore__ inline void GMMA8W4MidProcess<mmType>::SetMNConfig(const int32_t splitValue, MNConfig &mnConfig)
{
    mnConfig.m = static_cast<int64_t>(splitValue);
    // ### PATCH START: adaptive MSD tile
    if (splitValue <= 0) {
        return;
    }
    constexpr uint64_t MSD_M_ALIGNMENT = 16;
    constexpr uint64_t MSD_N_ALIGNMENT = 64;
    const uint64_t rows = static_cast<uint64_t>(splitValue);
    const uint64_t columns = static_cast<uint64_t>(mnConfig.n);
    const uint64_t baseM = gmmSwigluQuantV2BaseParams->baseM;
    const uint64_t baseN = gmmSwigluQuantV2BaseParams->baseN;
    const uint64_t baselineRows = (rows + baseM - 1) / baseM;
    const uint64_t baselineColumns = (columns + baseN - 1) / baseN;
    const uint64_t alternativeRows = (rows + adaptiveBaseM - 1) / adaptiveBaseM;
    const uint64_t alternativeColumns = (columns + adaptiveBaseN - 1) / adaptiveBaseN;
    const uint64_t alignedRows = (rows + MSD_M_ALIGNMENT - 1) / MSD_M_ALIGNMENT * MSD_M_ALIGNMENT;
    const uint64_t alignedColumns = (columns + MSD_N_ALIGNMENT - 1) / MSD_N_ALIGNMENT * MSD_N_ALIGNMENT;
    // Common K/2 cancels from the packed A+B byte comparison.
    const uint64_t baselineCost = alignedRows * baselineColumns + alignedColumns * baselineRows;
    const uint64_t alternativeCost = alignedRows * alternativeColumns + alignedColumns * alternativeRows;
    const bool useAlternative = alternativeCost <= baselineCost &&
        alternativeRows * alternativeColumns <= baselineRows * baselineColumns && alternativeRows < baselineRows;
    auto *selectedMm = useAlternative ? &adaptiveMm : &mm;
    if (selectedMm != activeMm) {
        activeMm->End();
        // End clears the shared ND/unit-flag layout state; restore it before reuse.
        AscendC::SetMMRowMajor();
        activeMm = selectedMm;
    }
    mnConfig.baseM = useAlternative ? adaptiveBaseM : baseM;
    mnConfig.baseN = useAlternative ? adaptiveBaseN : baseN;
    mnConfig.singleM = mnConfig.baseM;
    mnConfig.singleN = mnConfig.baseN;
    mnConfig.blockDimN = Ceil(mnConfig.n, mnConfig.singleN);
    // ### PATCH END: adaptive MSD tile
}

// Patch reason: all AICs must select consistently even with no assigned tile.
// Patch functionality: configure the selected object before the existing task loop.
// Signature: unchanged; remove with upstream adaptive tiling.
template <typename mmType>
__aicore__ inline void GMMA8W4MidProcess<mmType>::Process(WorkSpaceSplitConfig &workspaceSplitConfig,
                                                          int64_t workspaceSplitLoopIdx)
{
    if ASCEND_IS_AIC {
        if (workspaceSplitLoopIdx >= workspaceSplitConfig.loopCount || workspaceSplitLoopIdx < 0) {
            return;
        }
        xGM = (workspaceSplitLoopIdx % 2 == 0 ? xGM1 : xGM2);
        mmOutGM = (workspaceSplitLoopIdx % 2 == 0 ? mmOutGM1 : mmOutGM2);
        MNConfig mnConfig;
        mnConfig.baseM = gmmSwigluQuantV2BaseParams->baseM;
        mnConfig.baseN = gmmSwigluQuantV2BaseParams->baseN;
        mnConfig.singleM = gmmSwigluQuantV2BaseParams->baseM;
        mnConfig.singleN = gmmSwigluQuantV2BaseParams->baseN;
        mnConfig.k = gmmSwigluQuantV2BaseParams->K; // tilingData
        mnConfig.n = gmmSwigluQuantV2BaseParams->N; // tilingData
        mnConfig.blockDimN = Ceil(mnConfig.n, mnConfig.singleN);
        int32_t prevSplitValue = workspaceSplitLoopIdx * workspaceSplitConfig.notLastTaskSize;
        int32_t totalTmp = 0;
        if (gmmSwigluQuantV2BaseParams->groupListType == 1) {
            for (uint32_t i = 0; i < workspaceSplitConfig.rightMatrixExpertStartIndex; i++) {
                totalTmp += groupListGM.GetValue(i);
            }
        }
        for (uint32_t groupIdx = workspaceSplitConfig.rightMatrixExpertStartIndex, preCount = 0;
             groupIdx <= workspaceSplitConfig.rightMatrixExpertEndIndex; ++groupIdx) {
            UpdateMnConfig(mnConfig);
            int32_t currSplitValue = 0;
            if (gmmSwigluQuantV2BaseParams->groupListType == 0) {
                currSplitValue = static_cast<int32_t>(groupListGM.GetValue(groupIdx));
            } else {
                totalTmp += static_cast<int32_t>(groupListGM.GetValue(groupIdx));
                currSplitValue = totalTmp;
            }
            currSplitValue = currSplitValue > (workspaceSplitLoopIdx + 1) * gmmSwigluQuantV2BaseParams->mLimit
                                 ? (workspaceSplitLoopIdx + 1) * gmmSwigluQuantV2BaseParams->mLimit
                                 : currSplitValue;

            int32_t splitValue = (currSplitValue - prevSplitValue) * 2; // 2: int8 has been split in 2 int4
            prevSplitValue = currSplitValue;

            SetMNConfig(splitValue, mnConfig);
            if (mnConfig.m <= 0 || mnConfig.k <= 0 || mnConfig.n <= 0) {
                continue;
            }
            mnConfig.blockDimM = Ceil(mnConfig.m, mnConfig.singleM);
            // ### PATCH START: adaptive MSD tile
            activeMm->SetOrgShape(mnConfig.m, mnConfig.n, mnConfig.k);
            // ### PATCH END: adaptive MSD tile
            uint32_t curCount = preCount + mnConfig.blockDimN * mnConfig.blockDimM;
            uint32_t curBlock = coreIdx >= preCount ? coreIdx : coreIdx + gmmSwigluQuantV2BaseParams->coreNum;
            while (curBlock < curCount) {
                mnConfig.mIdx = (curBlock - preCount) / mnConfig.blockDimN;
                mnConfig.nIdx = (curBlock - preCount) % mnConfig.blockDimN;
                MMCompute(groupIdx, mnConfig, workspaceSplitConfig);
                curBlock += gmmSwigluQuantV2BaseParams->coreNum;
            }
            preCount = curCount % gmmSwigluQuantV2BaseParams->coreNum;
        }
    }
}

// Patch reason: task-grid and Matmul resource selection must agree.
// Patch functionality: issue each tile through the active object.
// Signature: unchanged; remove with upstream adaptive tiling.
template <typename mmType>
__aicore__ inline void GMMA8W4MidProcess<mmType>::MMCompute(uint32_t groupIdx, MNConfig &mnConfig,
                                                            WorkSpaceSplitConfig &workspaceSplitConfig)
{
    // ### PATCH START: adaptive MSD tile
    auto &mm = *activeMm;
    // ### PATCH END: adaptive MSD tile
    uint32_t tailN = mnConfig.nIdx * mnConfig.singleN;
    uint32_t curSingleN = mnConfig.singleN;
    if (unlikely(mnConfig.nIdx == mnConfig.blockDimN - 1)) {
        curSingleN = gmmSwigluQuantV2BaseParams->N - tailN;
    }
    uint32_t curSingleM = mnConfig.singleM;
    if (unlikely(mnConfig.mIdx == mnConfig.blockDimM - 1)) {
        curSingleM = mnConfig.m - mnConfig.mIdx * mnConfig.singleM;
    }
    uint64_t weightOffset = 0;
    mm.SetSingleShape(curSingleM, curSingleN, quantGroupSize); // 8, 256, 512 --> 514us
    GlobalTensor<int4b_t> weightSlice;
    uint64_t outOffset = mnConfig.mIdx * mnConfig.singleM * mnConfig.n + tailN;
    mnConfig.workspaceOffset = outOffset + mnConfig.yBaseOffset;
    for (uint32_t loopK = 0; loopK < gmmSwigluQuantV2BaseParams->quantGroupNum; loopK++) {
        mm.SetTensorA(
            xGM[mnConfig.xBaseOffset + mnConfig.mIdx * mnConfig.k * mnConfig.singleM + loopK * quantGroupSize]);
        // layered: weightGM/weightScaleGM were bound to the current layer at Init; expert offsets
        // within the layer are element offsets (per-layer single-tensor semantics).
        {
            if constexpr (mmType::BT::format == CubeFormat::NZ) {
                weightOffset =
                    static_cast<uint64_t>(groupIdx) * gmmSwigluQuantV2BaseParams->N * gmmSwigluQuantV2BaseParams->K +
                    tailN * gmmSwigluQuantV2BaseParams->K;
                weightSlice = weightGM[weightOffset + loopK * quantGroupSize * 64];
            } else {
                weightOffset =
                    static_cast<uint64_t>(groupIdx) * gmmSwigluQuantV2BaseParams->N * gmmSwigluQuantV2BaseParams->K +
                    tailN;
                weightSlice = weightGM[weightOffset + loopK * quantGroupSize * gmmSwigluQuantV2BaseParams->N];
            }
        }
        if (mnConfig.blockDimM == 1) {
            weightSlice.SetL2CacheHint(CacheMode::CACHE_MODE_DISABLE);
        }
        mm.SetTensorB(weightSlice);
        {
            mm.SetQuantVector(
                weightScaleGM[groupIdx * gmmSwigluQuantV2BaseParams->N * gmmSwigluQuantV2BaseParams->quantGroupNum +
                              loopK * gmmSwigluQuantV2BaseParams->N + tailN]);
        }
        mm.Iterate();
        mm.GetTensorC(mmOutGM[mnConfig.workspaceOffset], loopK == 0 ? 0 : 1);
    }
}
} // namespace GroupedMatmulDequantSwigluQuant
#endif // GMM_SWIGLU_QUANT_V2_A8W4_MSD
#endif // OP_KERNEL_GROUPED_MATMUL_SWIGLU_QUANT_V2_LAYERED_A8W4_MSD_MID_H
