"""Freeze or run the normal three-layer C2 A/F load and native KV successor.

Preparation is local only. Runtime inherits the exact init_device capsule,
installed-source identity, isolated active native package and complete CANN9.2
environment. Both roles load concurrently. Any failed exit or owned kill fails.
The exact KV001 parent is retained, with only the reviewed C2 qualification
module/test/fake and these two new probe/driver sources overlaid. Other 145
production modules retain exact parent bytes. No pure-SWA hooks are installed.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import runpy
import shlex
import subprocess
import sys
import tarfile
import time
import traceback
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-text-normal-worker-20261116"
KV_PARENT = FAMILY + "/prepared-kv-001/source.tar.gz"
KV_PARENT_SHA = "b09760e92c2683963ea00c3b9c478feb20a9fc700601ce9c42718ef922258b51"
DEVICE_DRIVER = ".tmp/run_text_normal_worker_device_a3.py"
DEVICE_DRIVER_SHA = "7e1261d24850df592f8160602f6433c825f1d070e8e456dbc8a3c291b3add60b"
CPU_DRIVER = ".tmp/run_text_normal_worker_cpu_a3.py"
DRIVER = ".tmp/run_text_normal_c2_a3.py"
PROBE = "tests/npu/dsv41_normal_c2_probe.py"
PRODUCTION_FILES = 146
PARENT_SOURCE_FILES = 453
SOURCE_FILES = 455
QUALIFICATION_OVERLAYS = (
    "afd_plugin/compat/npu/feature_validation.py",
    "tests/unit/compat/npu/test_feature_validation.py",
    "tests/unit/fakes/vllm_config.py",
)
QUALIFICATION_SHA256 = (
    "406c7c2adfd320a8fcdd6e4087f5346435b2f1889077b496ec6ac73622f73649",
    "4476d82187dffff3c85f6e88469cacaca71b437da8aa97ba379422f6760b6b3f",
    "783150b778732aaf15cc5f42f1c3d171d51a20fa1bfe82c542f60fbba73c302a",
)
DEFAULT_PAIR_TIMEOUT_SECONDS = 300
SSH_TIMEOUT_SECONDS = 720
POLL_SECONDS = 0.2
REAP_SECONDS = 10
DEFAULT_AFD_PORT = 30010
ATTENTION_KV_BUDGET_BYTES = 8 * 1024 * 1024
ATTENTION_CACHE_LAYERS = 6
HOST_TIMEOUT_SECONDS = 180


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", "utf-8")


def prepare(args):
    parent_raw = (ROOT / KV_PARENT).read_bytes()
    assert sha(parent_raw) == KV_PARENT_SHA
    assert sha((ROOT / DEVICE_DRIVER).read_bytes()) == DEVICE_DRIVER_SHA
    device = load_module("normal_model_device_capsule", ROOT / DEVICE_DRIVER)
    cpu = load_module("normal_model_cpu_capsule", ROOT / CPU_DRIVER)
    parent, _ = cpu.read_archive(parent_raw)
    assert len(parent) == PARENT_SOURCE_FILES
    assert sha(parent[DEVICE_DRIVER]) == DEVICE_DRIVER_SHA
    files = {
        **parent,
        DRIVER: Path(__file__).read_bytes(),
        PROBE: (ROOT / PROBE).read_bytes(),
        **{name: (ROOT / name).read_bytes() for name in QUALIFICATION_OVERLAYS},
    }
    assert all(
        sha(files[name]) == digest
        for name, digest in zip(
            QUALIFICATION_OVERLAYS, QUALIFICATION_SHA256, strict=True
        )
    )
    assert len(files) == SOURCE_FILES
    changed = sorted(name for name, raw in parent.items() if files[name] != raw)
    assert changed == sorted(QUALIFICATION_OVERLAYS)
    assert sorted(set(files) - set(parent)) == sorted((DRIVER, PROBE))
    production = [name for name in files if name.startswith("afd_plugin/")]
    assert len(production) == PRODUCTION_FILES
    assert all(
        files[name] == parent[name]
        for name in production
        if name != QUALIFICATION_OVERLAYS[0]
    )
    assert "afd_plugin/compat/patches/npu/dsv41_swa_cache.py" not in files
    python_files = [name for name in files if name.endswith(".py")]
    for name in python_files:
        compile(files[name], name, "exec")
    assert len(cpu.source_pins(files)) == 191
    archive = cpu.archive_bytes(files)
    frozen, manifest = cpu.read_archive(archive)
    assert frozen == files
    output = ROOT / FAMILY / args.label
    output.mkdir(parents=True, exist_ok=False)
    (output / "source.tar.gz").write_bytes(archive)
    (output / "runner.py").write_bytes(files[DRIVER])
    write_json(output / "manifest.json", manifest)
    record = {
        "source_archive_sha256": sha(archive),
        "parent_archive_sha256": KV_PARENT_SHA,
        "parent_archive_path": KV_PARENT,
        "source_files": len(files),
        "production_files": len(production),
        "python_files_compiled": len(python_files),
        "all_parent_members_byte_equal": not changed,
        "changed_parent_members": changed,
        "production_byte_equal_parent": False,
        "production_parent_equal_count": PRODUCTION_FILES - 1,
        "production_changes": {
            QUALIFICATION_OVERLAYS[0]: {
                "before": sha(parent[QUALIFICATION_OVERLAYS[0]]),
                "after": sha(files[QUALIFICATION_OVERLAYS[0]]),
            }
        },
        "qualification_overlay_sha256": {
            name: sha(files[name]) for name in QUALIFICATION_OVERLAYS
        },
        "parent_source_files": PARENT_SOURCE_FILES,
        "native_pin_inputs_byte_equal_parent": cpu.source_pins(files)
        == cpu.source_pins(parent),
        "pure_swa_patch_installed": False,
        "native_geometry": {
            "num_layers": 3,
            "compress_ratios": [0, 0, 2],
            "kv_source_layer_ids": [2],
            "index_source_layer_ids": [2],
            "candidate_source_layer_id": 20,
        },
        "native_source_identities": 191,
        "active_artifact_identities": device.ACTIVE_ARTIFACTS,
        "toolchain_atb_identities": device.TOOLCHAIN_ARTIFACTS,
        "added_to_parent": sorted(set(files) - set(parent)),
        "driver_sha256": manifest[DRIVER],
        "probe_sha256": manifest[PROBE],
        "roles": [{"role": "attention", "device": 0}, {"role": "ffn", "device": 1}],
        "pair_timeout_seconds": args.timeout,
        "afd_port": args.afd_port,
        "prepared_only": True,
        "ssh_executed": False,
        "device_executed": False,
        "host_cpu_executed": False,
        "model_loaded": False,
        "attention_kv_initialized": False,
        "initialize_attention_kv_requested": args.initialize_attention_kv,
        "native_attention_kv_component_accepted": False,
        "native_c2_kv_component_accepted": False,
        "inference_executed": False,
        "scope": (
            "normal dummy model load/native A KV/HELLO/STOP; no forward/sample"
            if args.initialize_attention_kv
            else "normal dummy model load/HELLO/STOP; no A KV or forward/sample"
        ),
    }
    write_json(output / "preparation.json", record)
    write_json(
        output / "source-proof.json",
        {
            "parent_source_archive_sha256": KV_PARENT_SHA,
            "source_archive_sha256": sha(archive),
            "changed_parent_members": {
                name: {"before": sha(parent[name]), "after": sha(files[name])}
                for name in changed
            },
            "added_members": {name: sha(files[name]) for name in (DRIVER, PROBE)},
            "unchanged_parent_members": len(parent) - len(changed),
            "production_unchanged_except_qualification": True,
            "python_compiled": python_files,
            "native_pin_inputs_unchanged": cpu.source_pins(files)
            == cpu.source_pins(parent),
            "ssh_executed": False,
            "device_executed": False,
        },
    )
    print(json.dumps(record, indent=2))


def native_host_child(args):
    # Only the explicitly selected A3 native interpreter reaches this branch.
    # CPU checks import the real installed dependencies but must never init NPU.
    import torch
    import torch_npu  # noqa: F401

    root = args.remote_root
    snapshot, results = root / "snapshot", root / "results"
    before = torch.npu.is_initialized()
    code = 1
    try:
        if args.native_child == "pytest":
            import pytest

            code = int(
                pytest.main(
                    [
                        QUALIFICATION_OVERLAYS[1],
                        "-o",
                        "addopts=",
                        "-q",
                        "-ra",
                        "--tb=short",
                        "-p",
                        "no:cacheprovider",
                        "--disable-warnings",
                        "--junitxml=" + str(results / "junit.xml"),
                    ]
                )
            )
        else:
            sys.path.insert(0, str(snapshot / "tests/npu"))
            sys.argv = [
                str(snapshot / PROBE),
                "--run-config",
                "--model",
                args.model,
                "--output-dir",
                str(results / args.role),
                "--role",
                args.role,
            ]
            try:
                runpy.run_path(str(snapshot / PROBE), run_name="__main__")
                code = 0
            except SystemExit as error:
                code = error.code
    finally:
        after = torch.npu.is_initialized()
        label = "pytest" if args.native_child == "pytest" else args.role
        write_json(
            results / (label + "-native-state.json"),
            {
                "npu_initialized_before": before,
                "npu_initialized_after": after,
                "returncode": code,
            },
        )
    return code if code else int(before or after)


def run_host_checks(
    args, device, snapshot, results, record, manifest, expected, before
):
    runs = []
    common = [
        args.python,
        "-B",
        str(snapshot / DRIVER),
        "--remote-root",
        str(args.remote_root),
        "--host-cpu",
        "--model",
        args.model,
    ]
    for label in ("pytest", "attention", "ffn"):
        command = [
            *common,
            "--native-child",
            "pytest" if label == "pytest" else "config",
        ]
        if label != "pytest":
            command.extend(("--role", label))
        environment = device.selected_environment(
            snapshot, args.remote_root / (label + "-owned"), record
        )
        write_json(results / (label + "-environment.json"), environment)
        owned, timed_out, killed = {}, False, []
        started = time.monotonic()
        with (results / (label + ".log")).open("wb") as log:
            process = subprocess.Popen(
                command,
                cwd=snapshot,
                env=environment,
                stdout=log,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            try:
                while process.poll() is None:
                    device.observe_owned(process.pid, owned)
                    if time.monotonic() - started >= HOST_TIMEOUT_SECONDS:
                        timed_out = True
                        break
                    time.sleep(POLL_SECONDS)
            finally:
                killed = device.kill_owned(owned)
                process.wait(timeout=REAP_SECONDS)
        state_path = results / (label + "-native-state.json")
        state = json.loads(state_path.read_text()) if state_path.is_file() else None
        report_path = results / label / "result.json"
        report = json.loads(report_path.read_text()) if report_path.is_file() else None
        runs.append(
            {
                "label": label,
                "command": command,
                "returncode": process.returncode,
                "timed_out": timed_out,
                "killed_owned_pids": killed,
                "surviving_owned_pids": device.live_owned(owned),
                "owned_pid_start_ticks": owned,
                "native_state": state,
                "report": report,
            }
        )
    junit = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    if (results / "junit.xml").is_file():
        for case in ET.parse(results / "junit.xml").iter("testcase"):
            junit["tests"] += 1
            for name, tag in (
                ("failures", "failure"),
                ("errors", "error"),
                ("skipped", "skipped"),
            ):
                junit[name] += case.find(tag) is not None
    roles_ok = all(
        run["report"] is not None
        and run["report"].get("success") is True
        and run["report"].get("run_config") is True
        and run["report"].get("run") is False
        and run["report"].get("dummy_qualification_accepted") is True
        and run["report"]
        .get("configuration", {})
        .get("native_geometry", {})
        .get("num_layers")
        == 3
        and run["report"].get("compress_ratios") == [0, 0, 2]
        and run["report"].get("candidate_source_layer") == 20
        and run["report"].get("model_loaded") is False
        and run["report"].get("attention_kv_initialized") is False
        and run["report"].get("inference_executed") is False
        for run in runs[1:]
    )
    after = {name: sha(Path(name).read_bytes()) for name in expected}
    source_after = {name: sha((snapshot / name).read_bytes()) for name in manifest}
    write_json(results / "readonly-after.json", after)
    write_json(results / "source-after.json", source_after)
    no_npu = all(
        run["native_state"] is not None
        and run["native_state"]["npu_initialized_before"] is False
        and run["native_state"]["npu_initialized_after"] is False
        for run in runs
    )
    accepted = bool(
        all(
            run["returncode"] == 0
            and not run["timed_out"]
            and not run["killed_owned_pids"]
            and not run["surviving_owned_pids"]
            for run in runs
        )
        and junit["tests"] > 0
        and junit["failures"] == junit["errors"] == junit["skipped"] == 0
        and roles_ok
        and no_npu
        and before == after == expected
        and source_after == manifest
    )
    summary = {
        "success": accepted,
        "host_cpu_accepted": accepted,
        "source_archive_sha256": sha((args.remote_root / "source.tar.gz").read_bytes()),
        "source_files": len(manifest),
        "production_files": PRODUCTION_FILES,
        "installed_source_identities": 191,
        "active_artifact_identities": device.ACTIVE_ARTIFACTS,
        "toolchain_atb_identities": device.TOOLCHAIN_ARTIFACTS,
        "runs": runs,
        "junit": junit,
        "npu_initialized_before_after_false": no_npu,
        "readonly_unchanged": before == after == expected,
        "source_unchanged": source_after == manifest,
        "worker_init_executed": False,
        "model_loaded": False,
        "attention_kv_initialized": False,
        "inference_executed": False,
        "native_c2_kv_component_accepted": False,
    }
    write_json(results / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if accepted else 1


def verify_pair_messages(reports, snapshot):
    # Load the real stdlib codec leaf; avoid package/runtime initialization in
    # the supervisor. Validate actual canonical messages, not guessed schemas.
    codec = load_module(
        "normal_model_control_codec",
        snapshot / "afd_plugin/connectors/npu/hccl_protocol.py",
    )
    expected_caps = codec.HcclCapabilities(512, 4096, 16, (0, 1, 2), 1, 0)
    expected_types = ("HELLO", "HELLO", "STOP", "STOP_ACK")
    payloads = {}
    for role, peer, directions in (
        ("attention", 0, ("send_returned", "receive_returned") * 2),
        ("ffn", 1, ("receive_returned", "send_returned") * 2),
    ):
        records = reports[role]["pair_control_messages"]
        assert len(records) == 4
        payloads[role] = []
        for index, entry in enumerate(records):
            assert type(entry["ordinal"]) is int and entry["ordinal"] == index
            assert type(entry["peer_pair_rank"]) is int
            assert entry["peer_pair_rank"] == peer
            assert entry["role"] == role and entry["direction"] == directions[index]
            raw = json.dumps(entry["encoded_message"], separators=(",", ":")).encode()
            message = codec.decode_hccl_control_message(raw)
            canonical = codec.encode_hccl_control_message(message)
            assert sha(canonical) == entry["sha256"]
            assert message.kind.value == expected_types[index]
            if index < 2:
                assert message.capabilities == expected_caps
                expected_role = "attention" if index == 0 else "ffn"
                assert message.role.value == expected_role
            payloads[role].append(canonical)
    assert payloads["attention"] == payloads["ffn"]
    return {
        "canonical_messages_per_role": 4,
        "hello_and_peer_stop_ack_verified": True,
        "forward_transactions": 0,
        "raw_socket_bytes_observed": False,
    }


def supervise_pair(args, device, snapshot, results, record):
    started = time.monotonic()
    processes, logs, owned = {}, {}, {}
    error, timed_out, killed = None, False, []
    try:
        for role, ordinal in (("attention", 0), ("ffn", 1)):
            env = device.selected_environment(
                snapshot, args.remote_root / (role + "-owned"), record
            )
            write_json(results / (role + "-environment.json"), env)
            command = [
                args.python,
                "-B",
                str(snapshot / PROBE),
                "--run",
                "--role",
                role,
                "--model",
                args.model,
                "--output-dir",
                str(results / role),
                "--device",
                str(ordinal),
                "--afd-port",
                str(args.afd_port),
                "--timeout",
                str(args.timeout),
            ]
            if args.initialize_attention_kv and role == "attention":
                command.append("--initialize-attention-kv")
            logs[role] = (results / (role + ".log")).open("wb")
            processes[role] = subprocess.Popen(
                command,
                cwd=snapshot,
                env=env,
                stdout=logs[role],
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            owned[role] = {}
            device.observe_owned(processes[role].pid, owned[role])
        while any(child.poll() is None for child in processes.values()):
            for role, child in processes.items():
                if child.poll() is None:
                    device.observe_owned(child.pid, owned[role])
                elif child.returncode != 0:
                    raise RuntimeError(f"{role} exited with {child.returncode}")
            if time.monotonic() - started >= args.timeout:
                timed_out = True
                raise TimeoutError("normal A/F paired model load timed out")
            time.sleep(POLL_SECONDS)
        for role, child in processes.items():
            if child.returncode != 0:
                raise RuntimeError(f"{role} exited with {child.returncode}")
    except BaseException:
        error = traceback.format_exc()
    finally:
        for role in processes:
            killed.extend(device.kill_owned(owned[role]))
        for role, child in processes.items():
            child.wait(timeout=REAP_SECONDS)
            logs[role].close()
    runs = []
    for role, child in processes.items():
        path = results / role / "result.json"
        runs.append(
            {
                "role": role,
                "pid": child.pid,
                "returncode": child.returncode,
                "owned_pid_start_ticks": owned[role],
                "surviving_owned_pids": device.live_owned(owned[role]),
                "report": json.loads(path.read_text()) if path.is_file() else None,
            }
        )
    return {
        "runs": runs,
        "timed_out": timed_out,
        "killed_owned_pids": sorted(set(killed)),
        "error": error,
        "elapsed_seconds": time.monotonic() - started,
    }


def run_remote(args):
    root = args.remote_root.resolve()
    device = load_module("normal_model_device_runner", root / "device_runner.py")
    assert sha((root / "device_runner.py").read_bytes()) == DEVICE_DRIVER_SHA
    cpu = load_module("normal_model_cpu_runner", root / "cpu_runner.py")
    raw = (root / "source.tar.gz").read_bytes()
    files, manifest = cpu.read_archive(raw)
    preparation = json.loads((root / "preparation.json").read_text())
    assert sha(raw) == preparation["source_archive_sha256"]
    assert len(files) == SOURCE_FILES
    assert manifest[PROBE] == preparation["probe_sha256"]
    assert manifest[DRIVER] == sha(Path(__file__).read_bytes())
    assert (args.timeout, args.afd_port) == (
        preparation["pair_timeout_seconds"],
        preparation["afd_port"],
    )
    assert args.initialize_attention_kv == preparation.get(
        "initialize_attention_kv_requested", False
    )
    snapshot, results = root / "snapshot", root / "results"
    snapshot.mkdir()
    results.mkdir()
    for name, data in files.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    record = json.loads(files[device.ENVIRONMENT_RECORD])
    assert sha(files[device.ENVIRONMENT_RECORD]) == device.ENVIRONMENT_RECORD_SHA
    site = Path(args.python).parent.parent / "lib/python3.12/site-packages"
    native = {
        str(site / name): digest for name, digest in cpu.source_pins(files).items()
    }
    assert len(native) == 191
    assert len(record["active_artifacts"]) == device.ACTIVE_ARTIFACTS
    assert len(record["toolchain_artifacts"]) == device.TOOLCHAIN_ARTIFACTS
    expected = {
        **native,
        **record["active_artifacts"],
        **record["toolchain_artifacts"],
        device.PARENT_ROOT + "/final-extension-result.json": device.PARENT_RECORD_SHA,
    }
    actual_before = {name: sha(Path(name).read_bytes()) for name in expected}
    write_json(results / "readonly-before.json", actual_before)
    if actual_before != expected:
        raise RuntimeError("frozen native/package/CANN/ATB identity changed before run")
    package = Path(device.ACTIVE_ROOT, "package")
    active_record_path = str(Path(device.ACTIVE_ROOT, "metadata-build-result.json"))
    assert {
        **{str(p): sha(p.read_bytes()) for p in package.rglob("*") if p.is_file()},
        active_record_path: sha(Path(active_record_path).read_bytes()),
    } == record["active_artifacts"]
    env = device.selected_environment(snapshot, root / "owned-preflight", record)
    if args.host_cpu:
        return run_host_checks(
            args, device, snapshot, results, record, manifest, expected, actual_before
        )
    before = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-before.log").write_bytes(before.stdout + before.stderr)
    idle_before = before.stdout.count(b"No running processes found in NPU")
    pair, error, protocol = {}, None, None
    started = time.monotonic()
    try:
        if before.returncode != 0 or idle_before != device.EXPECTED_IDLE_BOARDS:
            raise RuntimeError("all eight boards must be idle before model loading")
        pair = supervise_pair(args, device, snapshot, results, record)
        if pair["error"] is None:
            reports = {run["role"]: run["report"] for run in pair["runs"]}
            protocol = verify_pair_messages(reports, snapshot)
    except BaseException:
        error = traceback.format_exc()
    after = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-after.log").write_bytes(after.stdout + after.stderr)
    idle_after = after.stdout.count(b"No running processes found in NPU")
    actual_after = {name: sha(Path(name).read_bytes()) for name in expected}
    source_after = {name: sha((snapshot / name).read_bytes()) for name in manifest}
    write_json(results / "readonly-after.json", actual_after)
    write_json(results / "source-after.json", source_after)
    roles_ok = len(pair.get("runs", [])) == 2
    extension = (
        device.ACTIVE_ROOT
        + "/package/vllm_ascend/vllm_ascend_C.cpython-312-aarch64-linux-gnu.so"
    )
    for run in pair.get("runs", []):
        role, report = run["role"], run["report"] or {}
        runtime = report.get("runtime", {})
        origin = runtime.get("modules", {}).get("vllm_ascend", {}).get("path", "")
        mapped = runtime.get("mapped_native_libraries", {})
        roles_ok = roles_ok and (
            run["returncode"] == 0
            and not run["surviving_owned_pids"]
            and report.get("success") is True
            and report.get("run") is True
            and report.get("native_model_load_component_accepted") is True
            and report.get("normal_role_init_device_completed") is True
            and report.get("normal_load_model_returned") is True
            and report.get("normal_connector_hello_completed") is True
            and report.get("model_loaded") is True
            and report.get("initialize_attention_kv_requested")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("attention_kv_initialized")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("native_attention_kv_component_accepted")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("native_c2_kv_component_accepted")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("pure_swa_patch_installed") is False
            and report.get("compress_ratios") == [0, 0, 2]
            and report.get("candidate_source_layer") == 20
            and report.get("configuration", {})
            .get("native_geometry", {})
            .get("num_layers")
            == 3
            and report.get("inference_executed") is False
            and report.get("numerical_equivalence_accepted") is False
            and report.get("full_checkpoint_accepted") is False
            and report.get("native_groups_destroyed") is True
            and report.get("cleanup_failures") == []
            and report.get("actual_device")
            == ("npu:0" if role == "attention" else "npu:1")
            and report.get("loaded_model", {}).get("parameter_count", 0) > 0
            and report.get("loaded_model", {}).get("parameter_bytes", 0) > 0
            and origin.startswith(device.ACTIVE_ROOT + "/package/vllm_ascend/")
            and mapped.get(extension)
            == record["expected_native_library_sha256"][extension]
            and not any(
                device.PARENT_ROOT in name or "/cann-9.0.1/" in name for name in mapped
            )
        )
        if role == "ffn":
            roles_ok = roles_ok and (
                report.get("ffn_empty_cache_initialized") is True
                and report.get("ffn_public_poll_observed_peer_stop_and_owner_exit")
                is True
            )
        else:
            roles_ok = roles_ok and report.get("ffn_empty_cache_initialized") is False
            if args.initialize_attention_kv:
                kv = report.get("attention_kv", {})
                storages = kv.get("underlying_storages", {})
                roles_ok = roles_ok and (
                    kv.get("native_initialize_from_config_returned") is True
                    and kv.get("budget_bytes") == ATTENTION_KV_BUDGET_BYTES
                    and 0 < kv.get("actual_storage_bytes", 0) <= kv["budget_bytes"]
                    and len(kv.get("bindings", {})) == ATTENTION_CACHE_LAYERS
                    and kv.get("native_tuple_aliases_verified") is True
                    and len(kv.get("source_tuple", {}).get("state", [])) == 1
                    and len(kv.get("source_tuple", {}).get("swa", [])) == 3
                    and len(storages) == 1
                    and all(
                        entry["bytes"] > 0
                        and (results / role / entry["raw_file"]).stat().st_size
                        == entry["bytes"]
                        and sha((results / role / entry["raw_file"]).read_bytes())
                        == entry["sha256"]
                        for entry in storages.values()
                    )
                    and kv.get("loaded_parameters_unchanged") is True
                    and kv.get("loaded_parameters_after")
                    == report["loaded_model"]["parameters"]
                    and kv.get("initial_kv_contents_verified") is False
                    and kv.get("memory_profile_executed") is False
                    and kv.get("model_warmup_executed") is False
                    and kv.get("scheduler_created") is False
                    and kv.get("fresh_block_zeroer_executed") is False
                )
    success = bool(
        error is None
        and pair.get("error") is None
        and roles_ok
        and not pair.get("timed_out", True)
        and not pair.get("killed_owned_pids", [None])
        and protocol is not None
        and before.returncode == after.returncode == 0
        and idle_before == idle_after == device.EXPECTED_IDLE_BOARDS
        and actual_before == actual_after == expected
        and source_after == manifest
    )
    summary = {
        "success": success,
        "native_model_load_component_accepted": success,
        "pair_supervision": pair,
        "protocol": protocol,
        "error": error,
        "source_archive_sha256": sha(raw),
        "source_files": len(files),
        "production_files": PRODUCTION_FILES,
        "production_byte_equal_kv_parent": False,
        "production_parent_equal_count": PRODUCTION_FILES - 1,
        "production_changes": preparation["production_changes"],
        "pure_swa_patch_installed": False,
        "installed_source_identities": len(native),
        "active_artifact_identities": device.ACTIVE_ARTIFACTS,
        "toolchain_atb_identities": device.TOOLCHAIN_ARTIFACTS,
        "readonly_unchanged": actual_before == actual_after == expected,
        "source_unchanged": source_after == manifest,
        "idle_boards_before": idle_before,
        "idle_boards_after": idle_after,
        "elapsed_seconds": time.monotonic() - started,
        "initialize_attention_kv_requested": args.initialize_attention_kv,
        "attention_kv_initialized": bool(success and args.initialize_attention_kv),
        "native_attention_kv_component_accepted": bool(
            success and args.initialize_attention_kv
        ),
        "native_c2_kv_component_accepted": bool(
            success and args.initialize_attention_kv
        ),
        "inference_executed": False,
        "full_checkpoint_accepted": False,
        "numerical_equivalence_accepted": False,
    }
    write_json(results / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if success else 1


def execute_prepared(args):
    prepared = args.execute_prepared.resolve()
    device = load_module("normal_model_device_upload", ROOT / DEVICE_DRIVER)
    assert sha((ROOT / DEVICE_DRIVER).read_bytes()) == DEVICE_DRIVER_SHA
    cpu = load_module("normal_model_cpu_upload", ROOT / CPU_DRIVER)
    raw = (prepared / "source.tar.gz").read_bytes()
    files, _ = cpu.read_archive(raw)
    preparation = json.loads((prepared / "preparation.json").read_text())
    assert sha(raw) == preparation["source_archive_sha256"]
    if not args.host_cpu:
        host_summary = json.loads((prepared / "host-cpu-001/summary.json").read_text())
        assert host_summary["host_cpu_accepted"] is True
        assert host_summary["source_archive_sha256"] == sha(raw)
    execution = prepared / (
        args.execution_label or ("host-cpu-001" if args.host_cpu else "device-001")
    )
    execution.mkdir(exist_ok=False)
    base = load_module("normal_model_ssh", ROOT / cpu.BASE)
    uploader = load_module("normal_model_chunk_upload", ROOT / cpu.UPLOAD_HELPER)
    create = (
        "import tempfile;print(tempfile.mkdtemp("
        "prefix='text-normal-c2-20261117-',dir=" + repr(device.REMOTE_PARENT) + "))"
    )
    remote = base.ssh("python3 -c " + shlex.quote(create)).decode().strip()
    write_json(
        execution / "identity.json", {"remote_root": remote, "archive_sha256": sha(raw)}
    )
    uploader.upload_source(base, remote, raw, execution)
    inputs = {
        "runner.py": files[DRIVER],
        "device_runner.py": files[DEVICE_DRIVER],
        "cpu_runner.py": files[CPU_DRIVER],
        "preparation.json": (prepared / "preparation.json").read_bytes(),
    }
    deliver = (
        "import json,pathlib,sys;root=pathlib.Path("
        + repr(remote)
        + ");inputs=json.loads(sys.stdin.buffer.read());"
        "[(root/n).write_bytes(bytes.fromhex(raw)) for n,raw in inputs.items()]"
    )
    base.ssh(
        "python3 -c " + shlex.quote(deliver),
        json.dumps({n: raw.hex() for n, raw in inputs.items()}).encode(),
    )
    command_args = [
        "python3",
        remote + "/runner.py",
        "--remote-root",
        remote,
        "--python",
        args.python,
        "--model",
        args.model,
        "--timeout",
        str(preparation["pair_timeout_seconds"]),
        "--afd-port",
        str(preparation["afd_port"]),
    ]
    if preparation.get("initialize_attention_kv_requested", False):
        command_args.append("--initialize-attention-kv")
    command_args.append("--host-cpu" if args.host_cpu else "--device")
    command = shlex.join(command_args)
    process = subprocess.run(
        [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=15",
            base.SSH_HOST,
            command,
        ],
        capture_output=True,
        timeout=SSH_TIMEOUT_SECONDS,
    )
    (execution / "remote-output.log").write_bytes(process.stdout + process.stderr)
    results_raw = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
    (execution / "results.tar.gz").write_bytes(results_raw)
    with tarfile.open(fileobj=io.BytesIO(results_raw)) as stream:
        summary = json.load(stream.extractfile("results/summary.json"))
    write_json(execution / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if process.returncode == 0 and summary["success"] is True else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--remote-root", type=Path)
    modes.add_argument("--execute-prepared", type=Path)
    parser.add_argument("--label")
    parser.add_argument("--initialize-attention-kv", action="store_true")
    execution_modes = parser.add_mutually_exclusive_group()
    execution_modes.add_argument("--host-cpu", action="store_true")
    execution_modes.add_argument("--device", action="store_true")
    parser.add_argument("--execution-label")
    parser.add_argument(
        "--native-child", choices=("pytest", "config"), help=argparse.SUPPRESS
    )
    parser.add_argument("--role", choices=("attention", "ffn"), help=argparse.SUPPRESS)
    parser.add_argument("--model", default="/mnt/workspace/models/DeepSeek-V4.1-Flash")
    parser.add_argument(
        "--python", default="/mnt/workspace/code/.venvs/afd-v030-dsv41-c0/bin/python"
    )
    parser.add_argument("--timeout", type=int, default=DEFAULT_PAIR_TIMEOUT_SECONDS)
    parser.add_argument("--afd-port", type=int, default=DEFAULT_AFD_PORT)
    args = parser.parse_args()
    if args.timeout <= 0 or not 0 < args.afd_port < 65536:
        parser.error("positive timeout and port in 1..65535 required")
    if args.prepare_only and (
        not args.label
        or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.label)
    ):
        parser.error("--prepare-only requires a safe lowercase --label")
    if not args.prepare_only and args.label is not None:
        parser.error("--label belongs only to preparation")
    if args.execute_prepared is not None and args.initialize_attention_kv:
        parser.error("--execute-prepared reads the KV mode from frozen preparation")
    if args.prepare_only and (args.host_cpu or args.device):
        parser.error("--host-cpu/--device select execution, not preparation")
    if args.execution_label is not None and (
        args.execute_prepared is None
        or not args.execution_label
        or any(
            c not in "abcdefghijklmnopqrstuvwxyz0123456789-"
            for c in args.execution_label
        )
    ):
        parser.error(
            "--execution-label requires --execute-prepared and a safe lowercase label"
        )
    if args.native_child is not None and (
        args.remote_root is None
        or not args.host_cpu
        or (args.native_child == "config" and args.role is None)
    ):
        parser.error(
            "native children require --remote-root --host-cpu; config requires --role"
        )
    if args.role is not None and args.native_child != "config":
        parser.error("--role belongs only to a native config child")
    if args.native_child is not None:
        return native_host_child(args)
    if args.prepare_only:
        prepare(args)
        return 0
    if args.execute_prepared is not None:
        return execute_prepared(args)
    return run_remote(args)


if __name__ == "__main__":
    raise SystemExit(main())
