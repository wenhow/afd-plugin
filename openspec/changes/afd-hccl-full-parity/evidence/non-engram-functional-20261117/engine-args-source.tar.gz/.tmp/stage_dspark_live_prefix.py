"""Freeze live native P/Ready/read and optional D verification in an owned build."""

import argparse
import hashlib
import importlib.util
import io
import json
import os
import shlex
import shutil
import subprocess
import sys
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = (
    "openspec/changes/afd-hccl-v2-microbatch/evidence/"
    "a3-forward-counts-20261109/run_a3_forward_counts.py"
)
IDENTITY = (
    "openspec/changes/afd-hccl-full-parity/evidence/"
    "eager-configuration-source-identity-20261113.json"
)
HELPER = (
    "openspec/changes/afd-hccl-v2-graph/evidence/"
    "a3-native-manager-20261109/run_a3_graph_manager.py"
)
PROBE = "tests/npu/hccl_native_attention_pd_probe.py"
FAMILY = (
    "openspec/changes/afd-hccl-full-parity/evidence/"
    "a3-dspark-native-live-prefix-20261115"
)
BASELINE = (
    "openspec/changes/afd-hccl-full-parity/evidence/"
    "a3-native-pd-zeroing-20261114/zero-green-001/source.tar.gz"
)
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
DRIVER = ".tmp/stage_dspark_live_prefix.py"
COLLECTOR = ".tmp/collect_dspark_live_prefix.py"
LIFECYCLE_REQUESTS = 2
LIFECYCLE_QUERY_ROWS = 3
LIFECYCLE_SOURCES = 3
EXTRA_IDENTITY = ".tmp/native-pd-storage-extra-source-identity.json"
EXTRA_SOURCES = (
    "vllm_ascend/ops/vocab_parallel_embedding.py",
    "vllm/v1/worker/gpu/states.py",
    "vllm_ascend/worker/v2/states.py",
    "vllm/v1/worker/gpu/spec_decode/rejection_sampler_utils.py",
    "vllm/config/__init__.py",
    "vllm/distributed/__init__.py",
    "vllm/distributed/kv_transfer/__init__.py",
    "vllm/model_executor/layers/attention_layer_base.py",
    "vllm/model_executor/offloader/__init__.py",
    "vllm/v1/worker/gpu/model_states/__init__.py",
    "vllm/v1/worker/gpu/structured_outputs.py",
    "vllm/platforms/__init__.py",
    "vllm/plugins/__init__.py",
    "vllm/v1/core/sched/__init__.py",
    "vllm/v1/worker/gpu/spec_decode/speculator.py",
    "vllm/v1/worker/gpu/spec_decode/dspark/speculator.py",
    "vllm/v1/worker/gpu/spec_decode/dflash/speculator.py",
    "vllm/v1/worker/gpu/input_batch.py",
    "vllm/v1/worker/gpu/block_table.py",
    "vllm/config/speculative.py",
    "vllm/engine/arg_utils.py",
    "vllm/model_executor/model_loader/dummy_loader.py",
    "vllm/model_executor/model_loader/base_loader.py",
    "vllm_ascend/worker/v2/spec_decode/dspark/speculator.py",
    "vllm_ascend/worker/v2/spec_decode/dflash/speculator.py",
    "vllm_ascend/models/deepseek_v41/model.py",
    "vllm_ascend/models/deepseek_v41/dspark.py",
    "vllm_ascend/distributed/kv_transfer/kv_p2p/sfa_pd_rd2h/dspark_context.py",
    "vllm_ascend/ops/linear.py",
    "vllm_ascend/ops/layernorm.py",
    "vllm/model_executor/layers/linear.py",
    "vllm/model_executor/layers/layernorm.py",
    "vllm_ascend/worker/worker.py",
    "vllm_ascend/patch/worker/patch_v2/patch_model_runner.py",
    "vllm_ascend/patch/worker/patch_bind_kv_cache.py",
    "vllm_ascend/core/single_type_kv_cache_manager.py",
    "vllm_ascend/patch/platform/patch_kv_cache_coordinator.py",
    "vllm_ascend/patch/platform/patch_kv_cache_utils.py",
    "vllm_ascend/core/scheduler_profiling_chunk.py",
    "vllm_ascend/models/deepseek_v41/cache_config.py",
    "vllm_ascend/worker/v2/attn_utils.py",
    "vllm_ascend/patch/platform/patch_speculative_config.py",
    "vllm_ascend/ops/rope_dsv4.py",
    "vllm_ascend/worker/v2/kvpp.py",
    "vllm/model_executor/layers/logits_processor.py",
    "vllm/model_executor/layers/vocab_parallel_embedding.py",
    "vllm/v1/worker/gpu/spec_decode/dspark/utils.py",
    "vllm/v1/worker/gpu/spec_decode/eagle/utils.py",
    "vllm/v1/worker/gpu/spec_decode/eagle/eagle3_utils.py",
    "vllm/v1/worker/gpu/attn_utils.py",
    "vllm/model_executor/models/interfaces.py",
    "vllm_ascend/worker/v2/spec_decode/dflash/aclgraph.py",
    "vllm_ascend/worker/v2/model_states/__init__.py",
    "vllm_ascend/worker/v2/model_states/default.py",
    "vllm_ascend/worker/v2/block_table.py",
    "vllm_ascend/worker/v2/input_batch.py",
    "vllm_ascend/attention/dsa_v41.py",
    "vllm_ascend/quantization/utils.py",
    "vllm/transformers_utils/config.py",
    "vllm/transformers_utils/model_arch_config_convertor.py",
    "vllm/transformers_utils/configs/deepseek_v41.py",
    "vllm/config/model.py",
    "vllm_ascend/platform.py",
    "vllm/v1/worker/workspace.py",
    "vllm/v1/attention/backends/utils.py",
    "vllm_ascend/worker/v2/utils.py",
    "vllm_ascend/ops/triton/v2/spec_decode/prepare_dflash_inputs.py",
)
ASCEND_COMMIT = "7e37e29a7803d6897a7113088e2b771f83205bc0"
VLLM_COMMIT = "ced6857afa0ea7b2e3f0846a62e1394e90f15607"
NATIVE_BUILDER_SHA = "ebdde66efbe20ac57f1e2a9a8f9cf4bc99be192b0d48b2ea30f3276ccd680b64"
FINAL_NATIVE_BUILDER_SHA = (
    "2a7b6bfae7ef855f65db450b21f94bed32e7efe5f086dad62d79e066f8533fa5"
)
OVERLAYS = (
    "tests/npu/dsv41_dspark_speculator_probe.py",
    "tests/npu/dsv41_dspark_proposal_probe.py",
    "tests/npu/hccl_native_attention_pd_aux_probe.py",
    "tests/npu/hccl_native_attention_profile_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_decode_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_ready_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_owner_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_run_probe.py",
    "tests/npu/dsv41_dspark_projection_model_probe.py",
    "tests/npu/dsv41_dspark_projection_ops_probe.py",
    PROBE,
    "tests/npu/hccl_native_attention_pd_model_probe.py",
    "tests/npu/hccl_native_attention_pd_scheduler_probe.py",
    "tests/npu/hccl_native_attention_pd_producer_probe.py",
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepare_speculator_env(snapshot):
    # This new component uses the complete installed CANN 9.2 toolchain.
    # Its ATB product lives beside the toolkit and is pinned independently.
    inherited = os.environ.copy()
    for key in ("PATH", "LD_LIBRARY_PATH", "PYTHONPATH"):
        inherited[key] = ":".join(
            value
            for value in inherited.get(key, "").split(":")
            if value and not value.startswith("/mnt/workspace/code/.ascend/cann-")
        )
    for key in (
        "ASCEND_HOME_PATH",
        "ASCEND_OPP_PATH",
        "ASCEND_AICPU_PATH",
        "ASCEND_TOOLKIT_HOME",
        "TBE_IMPL_PATH",
        "ASCEND_CUSTOM_OPP_PATH",
    ):
        inherited.pop(key, None)
    inherited["ASCEND_SLOG_PRINT_TO_STDOUT"] = "0"
    script = """set -e
source /mnt/workspace/code/.ascend/cann-9.2.0/ascend-toolkit/set_env.sh >/dev/null
export LD_LIBRARY_PATH=/opt/buildtools/python-3.12.9/lib:\
/usr/local/Ascend/driver/lib64/driver:\
/usr/local/Ascend/driver/lib64/common:${LD_LIBRARY_PATH}
export PATH=/mnt/workspace/code/.venvs/afd-v030-dsv41-c0/bin:${PATH}
source /mnt/workspace/code/.ascend/cann-9.2.0/nnal/atb/set_env.sh >/dev/null
env -0
"""
    prepared = subprocess.run(
        ["bash", "-c", script],
        env=inherited,
        capture_output=True,
        timeout=30,
        check=True,
    )
    env = {
        key.decode(): value.decode()
        for field in prepared.stdout.split(b"\0")
        if field
        for key, value in [field.split(b"=", 1)]
    }
    assert Path(env["ASCEND_HOME_PATH"]).resolve() == Path(
        "/mnt/workspace/code/.ascend/cann-9.2.0/cann-9.2.0"
    )
    old_home = "/mnt/workspace/code/.ascend/cann-9.0.1/"
    for key in ("PATH", "LD_LIBRARY_PATH", "PYTHONPATH"):
        assert all(
            not value.startswith(old_home) for value in env.get(key, "").split(":")
        )
    env["PYTHONPATH"] = str(snapshot) + ":" + env.get("PYTHONPATH", "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    env["VLLM_PLUGINS"] = (
        "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,ascend_service_profiling"
    )
    return env


parser = argparse.ArgumentParser()
parser.add_argument("--label")
parser.add_argument("--mode", choices=("live-prefix", "decode"), default="live-prefix")
parser.add_argument(
    "--target-logits-policy",
    choices=("constant7", "reject-second-verification-row"),
    default="constant7",
)
parser.add_argument("--native-build-root", type=Path, required=True)
parser.add_argument(
    "--native-build-record",
    choices=("final-extension-result.json",),
    default="final-extension-result.json",
)
parser.add_argument("--zeroing-patch", action="store_true")
parser.add_argument("--draft-layer-patch", action="store_true")
parser.add_argument("--observe-ready-frontier", action="store_true")
parser.add_argument("--prepare-only", action="store_true")
parser.add_argument("--remote-root", type=Path)
parser.add_argument("--cann-cache-identity", action="store_true")
parser.add_argument("--binding-cache-source", type=Path)
parser.add_argument("--extra-opp-build-root", type=Path)
parser.add_argument("--continue-after-rejection", action="store_true")
parser.add_argument("--eager-u2-lifecycle", action="store_true")
args = parser.parse_args()
if args.eager_u2_lifecycle and (
    args.mode != "decode"
    or args.target_logits_policy != "constant7"
    or args.continue_after_rejection
    or args.observe_ready_frontier
):
    parser.error(
        "Eager U2 lifecycle requires decode/constant7 without rejection "
        "continuation or Ready-frontier queries"
    )
if args.eager_u2_lifecycle and not args.remote_root:
    parser.error(
        "Eager U2 lifecycle requires a frozen source archive; use "
        "prepare_ready_eager_lifecycle.py and the frozen launcher"
    )
if args.continue_after_rejection and (
    args.mode != "decode"
    or args.target_logits_policy != "reject-second-verification-row"
):
    parser.error("Rejection continuation requires decode with the reject policy")
if args.remote_root:
    remote = args.remote_root
    snapshot, results = remote / "snapshot", remote / "results"
    snapshot.mkdir()
    results.mkdir()
    with tarfile.open(remote / "source.tar.gz") as stream:
        stream.extractall(snapshot, filter="data")
    manifest = json.loads((snapshot / "manifest.json").read_text())
    assert all(
        sha((snapshot / name).read_bytes()) == digest
        for name, digest in manifest.items()
    )
    expected = json.loads((snapshot / IDENTITY).read_text())["source_expected"]
    expected.update(
        json.loads((snapshot / EXTRA_IDENTITY).read_text())["source_expected"]
    )
    site = Path(VENV) / "lib/python3.12/site-packages"
    checks = {
        name: sha((site / name).read_bytes()) == digest
        for name, digest in expected.items()
    }
    (results / "source-check.json").write_text(json.dumps(checks, indent=2) + "\n")
    assert all(checks.values())
    base = load_module("q3_component_environment", snapshot / BASE)
    helper = load_module("q3_device_supervision", snapshot / HELPER)
    env = prepare_speculator_env(snapshot)
    env["ASCEND_RT_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
    native_root = args.native_build_root.resolve(strict=True)
    assert native_root.parent == Path(PARENT) and native_root.name.startswith(
        "dspark-7e-draft-ops-20261114."
    )
    build_record = json.loads((native_root / args.native_build_record).read_text())
    (results / "native-build-record-selection.json").write_text(
        json.dumps(
            {
                "record": args.native_build_record,
                "sha256": sha((native_root / args.native_build_record).read_bytes()),
            },
            indent=2,
        )
        + "\n"
    )
    assert (
        build_record["status"] == "built-not-loaded"
        and build_record["readonly_unchanged"]
    )
    assert (
        not build_record["original_source_differences"]
        and not build_record["runtime_extension_loaded"]
    )
    assert build_record["source_commit"] == ASCEND_COMMIT
    assert build_record["toolchain"] == "complete-native-CANN-9.2.0"
    assert build_record["environment"]["ASCEND_HOME_PATH"] == env["ASCEND_HOME_PATH"]
    assert build_record["cross_cann_compiled_objects_reused"] is False
    assert build_record["reused_extension_and_direct_library"] is False
    builder = native_root / "build_native_draft_ops_cann92.py"
    assert (
        build_record["builder_sha256"]
        == sha(builder.read_bytes())
        == NATIVE_BUILDER_SHA
    )
    (results / "native-builder.py").write_bytes(builder.read_bytes())
    final_builder = native_root / "final_native_draft_extension_cann92.py"
    assert (
        build_record["continuation_builder_sha256"]
        == sha(final_builder.read_bytes())
        == FINAL_NATIVE_BUILDER_SHA
    )
    assert build_record["native_cann_header_priority_restored"] is True
    assert build_record["reused_cann92_generated_objects"] is False
    assert build_record["installed_cann92_opp_unchanged"] is True
    (results / "native-final-builder.py").write_bytes(final_builder.read_bytes())
    package = native_root / "package"
    assert list((package / "vllm_ascend").glob("vllm_ascend_C*.so"))
    native_files = {
        str(path): sha(path.read_bytes())
        for path in package.rglob("*")
        if path.is_file()
    }
    for name, record in build_record["artifacts"].items():
        assert sha((native_root / name).read_bytes()) == record["sha256"]
    assert native_files == {
        str(native_root / name): record["sha256"]
        for name, record in build_record["artifacts"].items()
    }
    (results / "native-build-result.json").write_bytes(
        (native_root / args.native_build_record).read_bytes()
    )
    (results / "native-package-identity.json").write_text(
        json.dumps(native_files, indent=2) + "\n"
    )
    vendor = package / "vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
    assert (vendor / "op_api/lib/libcust_opapi.so").is_file()
    env["PYTHONPATH"] = str(package) + ":" + env["PYTHONPATH"]
    env["ASCEND_CUSTOM_OPP_PATH"] = str(vendor) + (
        ":" + env["ASCEND_CUSTOM_OPP_PATH"] if env.get("ASCEND_CUSTOM_OPP_PATH") else ""
    )
    env["LD_LIBRARY_PATH"] = (
        str(vendor / "op_api/lib")
        + ":"
        + str(package / "vllm_ascend")
        + ":"
        + env["LD_LIBRARY_PATH"]
    )
    extra_opp_files = {}
    if args.extra_opp_build_root:
        extra_root = args.extra_opp_build_root.resolve(strict=True)
        assert extra_root.parent == Path(PARENT)
        assert extra_root.name.startswith("dspark-7e-qli-20261116-")
        identity = json.loads(
            (snapshot / ".tmp/qli-metadata-build-identity.json").read_text()
        )
        assert str(extra_root) == identity["remote"]
        record_path = extra_root / "metadata-build-result.json"
        record_raw = record_path.read_bytes()
        assert sha(record_raw) == identity["record_sha256"]
        extra_record = json.loads(record_raw)
        assert extra_record["status"] == "built-not-loaded"
        assert extra_record["source_commit"] == ASCEND_COMMIT
        assert extra_record["selected_ops"] == build_record["selected_ops"] + [
            "quant_lightning_indexer_v2_metadata"
        ]
        assert (
            extra_record["environment"]["ASCEND_HOME_PATH"] == env["ASCEND_HOME_PATH"]
        )
        assert extra_record["readonly_unchanged"]
        assert not extra_record["original_source_differences"]
        assert not extra_record["parent_original_source_differences"]
        assert not extra_record["runtime_extension_loaded"]
        extra_opp_files = {
            str(extra_root / name): item["sha256"]
            for name, item in extra_record["artifacts"].items()
        }
        assert extra_opp_files == {
            str(path): sha(path.read_bytes())
            for path in (extra_root / "package").rglob("*")
            if path.is_file()
        }
        extra_opp_files[str(record_path)] = sha(record_raw)
        assert extra_record["package_relative_path"] == "package"
        assert extra_record["reused_same_cann92_extension_and_python"]
        assert extra_record["all_parent_api_symbols_retained"]
        assert extra_record["native_enable_aicpu"]
        assert extra_record["ten_op_parent_artifacts_unchanged"]
        assert len(extra_record["native_aicpu_outputs"]) == 2
        for name, item in extra_record["native_aicpu_outputs"].items():
            assert sha((extra_root / name).read_bytes()) == item["sha256"]
        for name, item in build_record["artifacts"].items():
            if "/_cann_ops_custom/" not in name:
                assert sha((extra_root / name).read_bytes()) == item["sha256"]
        extra_package = extra_root / "package"
        extra_vendor = extra_root / extra_record["vendor_relative_path"]
        assert (
            extra_vendor.resolve()
            == (
                extra_package
                / "vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
            ).resolve()
        )
        env["PYTHONPATH"] = (
            str(extra_package)
            + ":"
            + ":".join(
                path for path in env["PYTHONPATH"].split(":") if path != str(package)
            )
        )
        env["ASCEND_CUSTOM_OPP_PATH"] = str(extra_vendor)
        old_native_paths = {str(vendor / "op_api/lib"), str(package / "vllm_ascend")}
        env["LD_LIBRARY_PATH"] = (
            str(extra_vendor / "op_api/lib")
            + ":"
            + str(extra_package / "vllm_ascend")
            + ":"
            + ":".join(
                path
                for path in env["LD_LIBRARY_PATH"].split(":")
                if path not in old_native_paths
            )
        )
        (results / "extra-opp-build-result.json").write_bytes(record_raw)
        (results / "extra-opp-before.json").write_text(
            json.dumps(extra_opp_files, indent=2) + "\n"
        )
    env["ASCEND_CACHE_PATH"] = str(remote / "ascend-cache")
    env["ASCEND_WORK_PATH"] = str(remote / "ascend-work")
    env["ASCEND_PROCESS_LOG_PATH"] = str(remote / "ascend-logs")
    env["TORCH_EXTENSIONS_DIR"] = str(remote / "torch-extensions")
    env["XDG_CACHE_HOME"] = str(remote / "cache")
    for subdir in ("ascend-cache", "ascend-work", "ascend-logs"):
        (remote / subdir).mkdir()
    toolchain_expected = {}
    if args.cann_cache_identity:
        original = Path(env["ASCEND_HOME_PATH"]).resolve(strict=True)
        assert (
            b"Version=9.2.0"
            in (original / "share/info/runtime/version.info").read_bytes()
        )
        metadata = sorted(
            set((original / "share/info").rglob("version.info"))
            | set((original / "share/info").rglob("*install.info"))
        )
        version_files = {}
        for entry in metadata:
            relative = entry.relative_to(original).as_posix()
            raw = entry.read_bytes()
            target = results / "toolchain-metadata" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            version_files[relative] = sha(raw)
            toolchain_expected[str(entry)] = sha(raw)
        legacy = original / "aarch64-linux/ascend_toolkit_install.info"
        legacy_bytes = legacy.read_bytes()
        toolchain_expected[str(legacy)] = sha(legacy_bytes)
        (results / "toolchain-native-install.info").write_bytes(legacy_bytes)
        for relative in (
            "triton/backends/ascend/utils.py",
            "triton/backends/ascend/compiler.py",
            "triton/runtime/jit.py",
            "triton/compiler/compiler.py",
        ):
            entry = site / relative
            toolchain_expected[str(entry)] = sha(entry.read_bytes())
            target = results / "toolchain-source" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(entry.read_bytes())
        # Native model import can JIT the toolkit's Python operator bindings.
        # Pin their original inputs and the installed vendor used by that API.
        for source_root in (
            original / "python/site-packages/cann_ops_transformer",
            site / "fla_npu/opp",
        ):
            for entry in sorted(source_root.rglob("*")):
                if entry.is_file() and "__pycache__" not in entry.parts:
                    toolchain_expected[str(entry)] = sha(entry.read_bytes())
        for relative in (
            "tools/bisheng_compiler/bin/bisheng",
            "tools/bisheng_compiler/bin/ld.lld",
            "aarch64-linux/lib64/libascendcl.so",
        ):
            entry = original / relative
            toolchain_expected[str(entry)] = sha(entry.read_bytes())
        atb = Path(env["ATB_HOME_PATH"]).resolve(strict=True)
        atb_files = {
            str(entry): sha(entry.read_bytes())
            for entry in atb.rglob("*.so*")
            if entry.is_file()
        }
        assert atb_files
        toolchain_expected.update(atb_files)
        atb_setup = Path("/mnt/workspace/code/.ascend/cann-9.2.0/nnal/atb/set_env.sh")
        toolchain_expected[str(atb_setup)] = sha(atb_setup.read_bytes())
        (results / "atb-identity.json").write_text(
            json.dumps(
                {
                    "home": str(atb),
                    "setup": str(atb_setup),
                    "expected": atb_files,
                    "CANN_runtime": str(original),
                    "separate_ATB_distribution": True,
                },
                indent=2,
            )
            + "\n"
        )
        env["TRITON_CACHE_DIR"] = str(remote / "triton-cache")
        preflight = subprocess.run(
            [
                VENV + "/bin/python",
                "-B",
                "-c",
                "from triton.backends.ascend.utils import get_cann_version_file_hash;"
                "print(get_cann_version_file_hash())",
            ],
            env=env,
            capture_output=True,
            timeout=30,
        )
        (results / "toolchain-preflight.log").write_bytes(
            preflight.stdout + preflight.stderr
        )
        assert (
            preflight.returncode == 0
            and preflight.stdout.decode().strip().splitlines()[-1] == sha(legacy_bytes)
        )
        (results / "toolchain-identity.json").write_text(
            json.dumps(
                {
                    "original_home": str(original),
                    "metadata_files": version_files,
                    "expected": toolchain_expected,
                    "native_install_info_sha256": sha(legacy_bytes),
                    "native_cache_identity_verified_without_device": True,
                    "isolated_triton_cache": env["TRITON_CACHE_DIR"],
                    "cache_identity_mirror_used": False,
                },
                indent=2,
            )
            + "\n"
        )
    seed_record = None
    if args.binding_cache_source:
        seed = args.binding_cache_source.resolve(strict=True)
        assert seed.parent == Path(PARENT) and seed.name.startswith(
            "dspark-native-speculator-20261114-"
        )
        assert seed != remote
        seed_results = seed / "results"
        assert (
            json.loads((seed_results / "native-package-identity.json").read_text())
            == native_files
        )
        assert (
            json.loads((seed_results / "toolchain-identity.json").read_text())[
                "expected"
            ]
            == toolchain_expected
        )
        prior_cache = json.loads(
            (seed_results / "generated-cache-identity.json").read_text()
        )
        expected_cache = {
            name: digest
            for name, digest in prior_cache.items()
            if name.startswith("torch-extensions/")
        }
        assert expected_cache and any(name.endswith(".so") for name in expected_cache)
        seed_cache = seed / "torch-extensions"
        assert not any(path.is_symlink() for path in seed_cache.rglob("*"))
        actual_cache = {
            str(path.relative_to(seed)): sha(path.read_bytes())
            for path in seed_cache.rglob("*")
            if path.is_file()
        }
        assert actual_cache == expected_cache
        shutil.copytree(seed_cache, remote / "torch-extensions")
        copied = {
            str(path.relative_to(remote)): sha(path.read_bytes())
            for path in (remote / "torch-extensions").rglob("*")
            if path.is_file()
        }
        assert copied == expected_cache
        seed_record = {
            "source_root": str(seed),
            "source_before": actual_cache,
            "copied_initial": copied,
            "parent_native_package_and_toolchain_match_seed": True,
            "active_native_extension_and_python_match_parent": True,
            "active_opp_changed_from_seed": bool(args.extra_opp_build_root),
            "active_opp_vendor": env["ASCEND_CUSTOM_OPP_PATH"],
        }
        (results / "binding-cache-seed.json").write_text(
            json.dumps(seed_record, indent=2) + "\n"
        )
    versions = subprocess.run(
        [
            VENV + "/bin/python",
            "-B",
            "-c",
            "import importlib.metadata as m,json,platform;"
            "print(json.dumps({'python':platform.python_version(),"
            "'packages':{k:m.version(k) for k in ['torch','torch-npu','vllm',"
            "'vllm-ascend','fastapi','triton','triton-ascend']}},indent=2))",
        ],
        env=env,
        capture_output=True,
        check=True,
        timeout=30,
    )
    (results / "versions.json").write_bytes(versions.stdout)
    (results / "effective-env.json").write_text(
        json.dumps(
            {
                key: env.get(key)
                for key in (
                    "ASCEND_RT_VISIBLE_DEVICES",
                    "VLLM_USE_V2_MODEL_RUNNER",
                    "VLLM_PLUGINS",
                    "LD_LIBRARY_PATH",
                    "PYTHONPATH",
                    "ASCEND_HOME_PATH",
                    "ASCEND_OPP_PATH",
                    "ASCEND_CUSTOM_OPP_PATH",
                    "ASCEND_CACHE_PATH",
                    "ASCEND_WORK_PATH",
                    "ASCEND_PROCESS_LOG_PATH",
                    "PATH",
                    "TRITON_CACHE_DIR",
                    "TORCH_EXTENSIONS_DIR",
                    "XDG_CACHE_HOME",
                )
            },
            indent=2,
        )
        + "\n"
    )
    dependency_preflight = subprocess.run(
        [
            VENV + "/bin/python",
            "-B",
            str(snapshot / PROBE),
            "--output-dir",
            str(results / "dependency-before"),
        ],
        env=env,
        capture_output=True,
        timeout=30,
    )
    (results / "mooncake-preflight.log").write_bytes(
        dependency_preflight.stdout + dependency_preflight.stderr
    )
    assert dependency_preflight.returncode == 0
    dependency_before = json.loads(
        (results / "dependency-before/result.json").read_text()
    )["dependencies"]
    assert dependency_before["single_distribution_owns_resolved_extension"]
    assert not dependency_before["engine_imported"]
    (results / "mooncake-identity.json").write_text(
        json.dumps(dependency_before, indent=2) + "\n"
    )
    before = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, check=True, timeout=30
    )
    (results / "before.log").write_bytes(before.stdout + before.stderr)
    assert before.stdout.count(b"No running processes found in NPU") == 8
    probe_name = (
        "hccl_native_attention_pd_dspark_run_probe.py"
        if args.mode == "live-prefix"
        else "hccl_native_attention_pd_dspark_decode_probe.py"
    )
    result_subdir = args.mode
    command = [
        VENV + "/bin/python",
        "-B",
        str(snapshot / "tests/npu" / probe_name),
        "--model",
        "/mnt/workspace/models/DeepSeek-V4.1-Flash",
        "--devices",
        "0,2,4" if args.mode == "live-prefix" else "0,2,4,6",
        "--timeout",
        "360",
        "--run",
        "--output-dir",
        str(results / result_subdir),
    ]
    if args.observe_ready_frontier:
        command.append("--observe-ready-frontier")
    if args.mode == "decode":
        command.extend(("--target-logits-policy", args.target_logits_policy))
    if args.continue_after_rejection:
        command.append("--continue-after-rejection")
    if args.eager_u2_lifecycle:
        command.extend(
            (
                "--target-u2",
                "--target-cancel-replace",
                "--eager-stream-overlap",
            )
        )
    owned, killed, timed_out = {}, [], False
    started = time.monotonic()
    with (results / "probe.log").open("wb") as output:
        process = subprocess.Popen(
            command,
            cwd=snapshot,
            env=env,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
        while process.poll() is None:
            helper.collect_owned_processes(process.pid, owned)
            if time.monotonic() - started > 420:
                timed_out = True
                killed = helper.kill_owned(owned)
                break
            time.sleep(0.25)
        process.wait(timeout=10)
    after = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "after.log").write_bytes(after.stdout + after.stderr)
    dependency_postflight = subprocess.run(
        [
            VENV + "/bin/python",
            "-B",
            str(snapshot / PROBE),
            "--output-dir",
            str(results / "dependency-after"),
        ],
        env=env,
        capture_output=True,
        timeout=30,
    )
    (results / "mooncake-postflight.log").write_bytes(
        dependency_postflight.stdout + dependency_postflight.stderr
    )
    assert dependency_postflight.returncode == 0
    dependency_after = json.loads(
        (results / "dependency-after/result.json").read_text()
    )["dependencies"]
    (results / "mooncake-after.json").write_text(
        json.dumps(dependency_after, indent=2) + "\n"
    )
    assert dependency_after == dependency_before
    after_checks = {
        name: sha((snapshot / name).read_bytes()) == digest
        for name, digest in manifest.items()
    }
    installed_after = {
        name: sha((site / name).read_bytes()) == digest
        for name, digest in expected.items()
    }
    if toolchain_expected:
        toolchain_after = {
            name: sha(Path(name).read_bytes()) == digest
            for name, digest in toolchain_expected.items()
        }
        (results / "toolchain-after.json").write_text(
            json.dumps(toolchain_after, indent=2) + "\n"
        )
        assert all(toolchain_after.values())
    (results / "source-after.json").write_text(
        json.dumps({"snapshot": after_checks, "installed": installed_after}, indent=2)
        + "\n"
    )
    (results / "owned.json").write_text(
        json.dumps(
            {
                "processes": owned,
                "killed_pids": killed,
                "start_ticks_checked_before_kill": True,
            },
            indent=2,
        )
        + "\n"
    )
    native_after = {
        name: sha(Path(name).read_bytes()) == digest
        for name, digest in native_files.items()
    }
    (results / "native-package-after.json").write_text(
        json.dumps(native_after, indent=2) + "\n"
    )
    assert all(native_after.values())
    extra_opp_after = {
        name: sha(Path(name).read_bytes()) == digest
        for name, digest in extra_opp_files.items()
    }
    (results / "extra-opp-after.json").write_text(
        json.dumps(extra_opp_after, indent=2) + "\n"
    )
    assert all(extra_opp_after.values())
    generated_cache = {
        str(path.relative_to(remote)): sha(path.read_bytes())
        for directory in ("torch-extensions", "cache", "triton-cache")
        for path in (remote / directory).rglob("*")
        if path.is_file()
    }
    (results / "generated-cache-identity.json").write_text(
        json.dumps(generated_cache, indent=2) + "\n"
    )
    if seed_record:
        seed_record["source_after"] = {
            str(path.relative_to(seed)): sha(path.read_bytes())
            for path in seed_cache.rglob("*")
            if path.is_file()
        }
        assert seed_record["source_after"] == seed_record["source_before"]
        (results / "binding-cache-seed.json").write_text(
            json.dumps(seed_record, indent=2) + "\n"
        )
    path = results / result_subdir / "summary.json"
    native = json.loads(path.read_text()) if path.exists() else {}
    workers = native.get("workers", {})
    roles = (
        ("kv_producer", "kv_consumer", "ffn")
        if args.mode == "live-prefix"
        else ("kv_producer", "kv_consumer", "ffn_producer", "ffn_consumer")
    )
    scoped_workers_valid = set(workers) == set(roles) and all(
        workers[role].get("success") is True
        and workers[role].get("full_model_accepted") is False
        and workers[role].get("full_worker_accepted") is False
        and workers[role].get("model_admission_accepted") is False
        and workers[role].get("engram_accepted") is False
        and workers[role].get("graph_accepted") is False
        and workers[role].get("u2_accepted") is False
        and workers[role].get("performance_accepted") is False
        for role in roles
    )
    consumer_protocol = native.get("pair_protocols", {}).get("consumer", {})
    consumer = workers.get("kv_consumer", {})
    eager_lifecycle_valid = not args.eager_u2_lifecycle or (
        native.get("target_graph_requested") is False
        and native.get("target_u2_requested") is True
        and native.get("target_cancel_replace_requested") is True
        and native.get("eager_stream_overlap_requested") is True
        and native.get("graph_compute_overlap_requested") is False
        and native.get("graph_all_axes_requested") is False
        and native.get("graph_exchange_order_requested") == "stage_serial"
        and native.get("observe_ready_frontier_requested") is False
        and consumer_protocol.get(
            "native_dspark_eager_stream_lifecycle_component_accepted"
        )
        is True
        and consumer_protocol.get("native_dspark_request_lifecycle_component_accepted")
        is True
        and consumer_protocol.get("physical_overlap_accepted") is False
        and consumer_protocol.get("performance_accepted") is False
        and type(consumer_protocol.get("distinct_destination_requests")) is int
        and consumer_protocol.get("distinct_destination_requests") == LIFECYCLE_SOURCES
        and consumer_protocol.get("request_slot_reuse_observed") is True
        and consumer_protocol.get("physical_block_reuse_guaranteed") is False
        and type(consumer_protocol.get("actual_request_count")) is int
        and consumer_protocol.get("actual_request_count") == LIFECYCLE_REQUESTS
        and type(consumer_protocol.get("actual_query_rows_per_request")) is int
        and consumer_protocol.get("actual_query_rows_per_request")
        == LIFECYCLE_QUERY_ROWS
        and consumer.get("two_request_native_decode_accepted") is True
        and consumer.get("native_dspark_request_lifecycle_accepted") is True
        and consumer.get("native_dspark_request_lifecycle", {}).get("accepted") is True
        and consumer.get("target_eager_decode", {}).get("accepted") is True
    )
    success = (
        process.returncode == 0
        and not timed_out
        and not killed
        and native.get("success") is True
        and scoped_workers_valid
        and eager_lifecycle_valid
        and (
            not args.observe_ready_frontier
            or workers.get("kv_producer", {}).get("ready_frontier", {}).get("status")
            == "passed"
        )
        and native.get("returncodes") == {role: 0 for role in roles}
        and not native.get("timed_out")
        and native.get("forced_killed_pids") == []
        and workers["kv_producer"].get("native_sample_and_proposal_returned") is True
        and workers["kv_producer"].get("typed_done_observed") is True
        and workers["kv_consumer"].get("typed_read_and_whole_pool_oracle_passed")
        is True
        and all(
            workers[role].get("native_ffn", {}).get("native_daemon_retired") is True
            for role in roles
            if role.startswith("ffn")
        )
        and (
            args.mode == "live-prefix"
            or workers["kv_consumer"].get("native_decode_and_verification_accepted")
            is True
        )
        and (
            not args.continue_after_rejection
            or (
                workers["kv_consumer"].get(
                    "native_post_rejection_continuation_accepted"
                )
                is True
                and native.get("native_post_rejection_continuation_accepted") is True
            )
        )
        and after.returncode == 0
        and after.stdout.count(b"No running processes found in NPU") == 8
        and all(after_checks.values())
        and all(installed_after.values())
    )
    summary = {
        "mode": args.mode,
        "target_logits_policy": args.target_logits_policy
        if args.mode == "decode"
        else None,
        "draft_layer_patch": args.draft_layer_patch,
        "continue_after_rejection_requested": args.continue_after_rejection,
        "eager_u2_lifecycle_requested": args.eager_u2_lifecycle,
        "observe_ready_frontier_requested": args.observe_ready_frontier,
        "scope": (
            "Three retained controlled live P/eager prefixes and one D owner: "
            "real eager U2 stream session, cancellation, survivor completion "
            "and fresh-prefix Q3/U1 replacement; original native N2 "
            "execute/sample/propose/consumer and typed Ready/TE/DONE. "
            "No full-model/Worker/serving/Graph/Engram or physical-overlap/"
            "performance acceptance"
            if args.eager_u2_lifecycle
            else "Controlled live target P with native N2 runner init, original "
            "production AFD execute/sample/propose/consumer and real typed "
            "Ready/TE/DONE; no full AFD constructor/model admission/checkpoint/"
            "Graph/U2/Engram/performance acceptance"
        ),
        "command": command,
        "native_dspark_eager_stream_lifecycle_component_accepted": (
            consumer_protocol.get(
                "native_dspark_eager_stream_lifecycle_component_accepted"
            )
            if args.eager_u2_lifecycle
            else False
        ),
        "target_graph_requested": False,
        "target_u2_requested": args.eager_u2_lifecycle,
        "target_cancel_replace_requested": args.eager_u2_lifecycle,
        "eager_stream_overlap_requested": args.eager_u2_lifecycle,
        "graph_compute_overlap_requested": False,
        "graph_all_axes_requested": False,
        "graph_exchange_order_requested": "stage_serial",
        "physical_overlap_accepted": False,
        "performance_accepted": False,
        "graph_mode": "NONE",
        "eager_overlap_disabled": not args.eager_u2_lifecycle,
        "source_files_checked": len(checks),
        "source_files_match": all(checks.values()),
        "extra_opp_build_root": str(args.extra_opp_build_root)
        if args.extra_opp_build_root
        else None,
        "extra_opp_artifacts_unchanged": all(extra_opp_after.values()),
        "elapsed_seconds": time.monotonic() - started,
        "returncode": process.returncode,
        "timed_out": timed_out,
        "killed_owned_pids": killed,
        "inner_timed_out": native.get("timed_out"),
        "inner_forced_killed_pids": native.get("forced_killed_pids"),
        "idle_boards_before": 8,
        "idle_boards_after": after.stdout.count(b"No running processes found in NPU"),
        "success": success,
    }
    launch_path = remote / "supervision-launch.json"
    if launch_path.is_file():
        (results / "supervision-launch.json").write_bytes(launch_path.read_bytes())
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))
    raise SystemExit(0 if success else 1)

if args.extra_opp_build_root:
    parser.error(
        "Extra OPP requires a frozen build identity; use "
        "prepare_ready_csa2_fixture.py and launch_ready_frozen_a3.py"
    )
if not args.label or any(
    char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in args.label
):
    parser.error("label required")
destination = ROOT / FAMILY / args.label
destination.mkdir(parents=True, exist_ok=False)
with tarfile.open(ROOT / BASELINE) as stream:
    contents = {
        entry.name: stream.extractfile(entry).read()
        for entry in stream
        if entry.isfile() and entry.name != "manifest.json"
    }
production_changes = (
    "afd_plugin/compat/npu/kv_zeroing.py",
    "afd_plugin/compat/patches/npu/mrv2_kv_zeroing.py",
    "afd_plugin/compat/npu/runtime.py",
    "afd_plugin/compat/npu/kv_layout_connector.py",
)
for name in (
    *OVERLAYS,
    DRIVER,
    COLLECTOR,
    *(production_changes if args.zeroing_patch else ()),
):
    contents[name] = (ROOT / name).read_bytes()
extra_expected = {}
for name in EXTRA_SOURCES:
    ascend_source = name.startswith("vllm_ascend/")
    source_repo = ROOT.parent / ("vllm-ascend" if ascend_source else "vllm")
    source_commit = ASCEND_COMMIT if ascend_source else VLLM_COMMIT
    raw = subprocess.check_output(
        ["git", "-C", str(source_repo), "show", source_commit + ":" + name]
    )
    extra_expected[name] = sha(raw)
base_expected = json.loads(contents[IDENTITY])["source_expected"]
assert all(
    name not in base_expected or base_expected[name] == digest
    for name, digest in extra_expected.items()
), "Extra source identities must preserve existing locked objects"
installed_expected = base_expected | extra_expected
contents[EXTRA_IDENTITY] = (
    json.dumps(
        {
            "commits": {"vllm": VLLM_COMMIT, "vllm_ascend": ASCEND_COMMIT},
            "source_expected": extra_expected,
        },
        indent=2,
    )
    + "\n"
).encode()
with tarfile.open(
    ROOT / "openspec/changes/afd-hccl-full-parity/evidence/"
    "a3-dspark-prefix-cause-cpu-20261114/green-001/source.tar.gz"
) as stream:
    accepted_production = {
        entry.name: stream.extractfile(entry).read()
        for entry in stream
        if entry.isfile()
        and entry.name.startswith("afd_plugin/")
        and entry.name.endswith(".py")
    }
if args.draft_layer_patch:
    layer_family = (
        ROOT / "openspec/changes/afd-hccl-full-parity/evidence/"
        "a3-dspark-draft-layers-cpu-20261115/green-001"
    )
    with tarfile.open(layer_family / "results.tar.gz") as stream:
        cpu_result = json.load(stream.extractfile("results/summary.json"))
    assert cpu_result["returncode"] == 0 and not cpu_result["timed_out"]
    assert cpu_result["junit"] == {
        "tests": 49,
        "failures": 0,
        "errors": 0,
        "skipped": 0,
    }
    assert cpu_result["installed_unchanged"] and cpu_result["snapshot_unchanged"]
    with tarfile.open(layer_family / "source.tar.gz") as stream:
        layer_production = {
            entry.name: stream.extractfile(entry).read()
            for entry in stream
            if entry.isfile()
            and entry.name.startswith("afd_plugin/")
            and entry.name.endswith(".py")
        }
    assert set(layer_production) == set(accepted_production)
    assert {
        name
        for name, raw in layer_production.items()
        if accepted_production[name] != raw
    } == {"afd_plugin/compat/npu/dspark_pd.py"}
    accepted_production = layer_production
# Each successor is selected from its separate CPU-verified source archive.
# Paused ordinary-MTP work stays excluded.
contents["afd_plugin/compat/npu/dspark_pd.py"] = accepted_production[
    "afd_plugin/compat/npu/dspark_pd.py"
]
actual_production = {
    name: raw
    for name, raw in contents.items()
    if name.startswith("afd_plugin/") and name.endswith(".py")
}
assert args.zeroing_patch and len(actual_production) == 145
assert actual_production == accepted_production, (
    "Live prefix snapshot must match selected CPU-verified production145"
)
manifest = {name: sha(raw) for name, raw in contents.items()}
contents["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:gz") as stream:
    for name, raw in contents.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(raw)
        stream.addfile(entry, io.BytesIO(raw))
payload = buffer.getvalue()
(destination / "source.tar.gz").write_bytes(payload)
if args.prepare_only:
    (destination / "preparation.json").write_text(
        json.dumps(
            {
                "archive_sha256": sha(payload),
                "source_files": len(manifest),
                "production_files": len(actual_production),
                "production_baseline": (
                    "draft-layer-cpu-green-001"
                    if args.draft_layer_patch
                    else "cause-cpu-green-001"
                ),
                "helper_sha256": {name: manifest[name] for name in OVERLAYS},
                "installed_sources_to_check": len(installed_expected),
                "draft_layer_patch": args.draft_layer_patch,
                "mode": args.mode,
                "target_logits_policy": args.target_logits_policy
                if args.mode == "decode"
                else None,
                "observe_ready_frontier_requested": args.observe_ready_frontier,
                "continue_after_rejection_requested": args.continue_after_rejection,
                "eager_u2_lifecycle_requested": args.eager_u2_lifecycle,
                "native_build_root": args.native_build_root.as_posix(),
                "native_build_record": args.native_build_record,
                "cann_cache_identity": args.cann_cache_identity,
                "binding_cache_source": (
                    args.binding_cache_source.as_posix()
                    if args.binding_cache_source
                    else None
                ),
                "device_test_executed": False,
                "scope": "Prepared only; no remote operation or acceptance",
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    print("Prepared offline: " + str(destination))
    raise SystemExit(0)
base = load_module("q3_source_environment", ROOT / BASE)
remote = (
    base.ssh(
        "python3 -c "
        + shlex.quote(
            "import tempfile;print(tempfile.mkdtemp("
            "prefix='dspark-native-live-prefix-20261115-',dir=" + repr(PARENT) + "))"
        )
    )
    .decode()
    .strip()
)
(destination / "identity.json").write_text(
    json.dumps(
        {
            "head": subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
            ).strip(),
            "remote": remote,
            "manifest": manifest,
            "archive_sha256": sha(payload),
            "mode": args.mode,
            "target_logits_policy": (
                args.target_logits_policy if args.mode == "decode" else None
            ),
            "observe_ready_frontier_requested": args.observe_ready_frontier,
            "continue_after_rejection_requested": args.continue_after_rejection,
            "eager_u2_lifecycle_requested": args.eager_u2_lifecycle,
            "execution_method": "detached outer; existing device bounds retained",
            "production_baseline": (
                "draft-layer-cpu-green-001"
                if args.draft_layer_patch
                else "cause-cpu-green-001"
            ),
            "scope": (
                "Frozen CPU-verified production145; live P/sample/"
                "proposal/Ready/TE harness; paused MTP excluded"
            ),
        },
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)
base.ssh("cat > " + shlex.quote(remote + "/source.tar.gz"), payload)
base.ssh(
    "cat > " + shlex.quote(remote + "/stage_dspark_live_prefix.py"),
    Path(__file__).read_bytes(),
)
command = (
    "python3 -B "
    + shlex.quote(remote + "/stage_dspark_live_prefix.py")
    + " --remote-root "
    + shlex.quote(remote)
    + " --mode "
    + args.mode
    + " --target-logits-policy "
    + args.target_logits_policy
    + " --native-build-record "
    + shlex.quote(args.native_build_record)
    + " --native-build-root "
    + shlex.quote(args.native_build_root.as_posix())
)
if args.cann_cache_identity:
    command += " --cann-cache-identity"
if args.draft_layer_patch:
    command += " --draft-layer-patch"
if args.observe_ready_frontier:
    command += " --observe-ready-frontier"
if args.continue_after_rejection:
    command += " --continue-after-rejection"
if args.eager_u2_lifecycle:
    command += " --eager-u2-lifecycle"
if args.binding_cache_source:
    command += " --binding-cache-source " + shlex.quote(
        args.binding_cache_source.as_posix()
    )
launch_script = """import json,pathlib,subprocess,sys
root=pathlib.Path(REMOTE_ROOT)
with (root/'supervision.log').open('wb') as output:
    process=subprocess.Popen(COMMAND,stdin=subprocess.DEVNULL,stdout=output,
        stderr=subprocess.STDOUT,start_new_session=True,close_fds=True)
    stat=pathlib.Path('/proc')/str(process.pid)/'stat'
    raw=stat.read_text()
    record={'pid':process.pid,'start_ticks':int(raw[raw.rfind(')')+2:].split()[19]),
        'command':COMMAND,'scope':('Detached outer; existing device bounds retained; '
            'not cleanup acceptance')}
    (root/'supervision-launch.json').write_text(json.dumps(record,indent=2)+'\\n')
    print(json.dumps(record),flush=True)
    returncode=process.wait(timeout=500)
print((root/'supervision.log').read_text(errors='replace'),flush=True)
sys.exit(returncode)
""".replace("REMOTE_ROOT", repr(remote)).replace("COMMAND", repr(shlex.split(command)))
try:
    run = subprocess.run(
        [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            base.SSH_HOST,
            "python3 -c " + shlex.quote(launch_script),
        ],
        capture_output=True,
        timeout=520,
    )
except subprocess.TimeoutExpired as error:
    (destination / "remote.log").write_bytes(
        (error.stdout or b"") + (error.stderr or b"")
    )
    (destination / "transport.json").write_text(
        json.dumps(
            {"returncode": None, "timed_out": True, "remote_exit_verified": False},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    raise
(destination / "remote.log").write_bytes(run.stdout + run.stderr)
(destination / "transport.json").write_text(
    json.dumps(
        {
            "returncode": run.returncode,
            "timed_out": False,
            "remote_exit_verified": False,
        },
        indent=2,
    )
    + "\n",
    encoding="utf-8",
)
if run.returncode == 255:
    print("SSH disconnected; collect the existing attempt after checking ownership")
    raise SystemExit(run.returncode)
collection = subprocess.run(
    [sys.executable, "-B", str(ROOT / COLLECTOR), "--label", args.label],
    check=False,
)
print(run.stdout.decode(errors="replace"))
print(run.stderr.decode(errors="replace"))
if collection.returncode != 0:
    raise SystemExit(collection.returncode)
raise SystemExit(run.returncode)
