"""Freeze a two-process CPU Gloo report probe without device execution."""

import argparse
import ast
import hashlib
import importlib.util
import io
import json
import os
import shlex
import signal
import subprocess
import tarfile
from contextlib import suppress
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = "openspec/changes/afd-hccl-v2-microbatch/evidence/a3-forward-counts-20261109/run_a3_forward_counts.py"
IDENTITY = "openspec/changes/afd-hccl-full-parity/evidence/eager-configuration-source-identity-20261113.json"
RUNS = "openspec/changes/afd-hccl-full-parity/evidence/a3-p-report-gloo-cpu-20261114"
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
PROBE = "tests/npu/dsv41_pd_report_probe.py"
OVERLAYS = (PROBE, "tests/unit/fakes/kv_connector.py", "tests/unit/fakes/dspark_pd.py")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_base(root):
    spec = importlib.util.spec_from_file_location("gloo_probe_base", root / BASE)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


parser = argparse.ArgumentParser()
parser.add_argument("--label")
parser.add_argument("--remote-root", type=Path)
args = parser.parse_args()
if args.remote_root:
    remote = args.remote_root
    snapshot, results = remote / "snapshot", remote / "results"
    snapshot.mkdir()
    results.mkdir()
    with tarfile.open(remote / "source.tar.gz") as stream:
        stream.extractall(snapshot, filter="data")
    manifest = json.loads((snapshot / "manifest.json").read_bytes())
    assert all(sha((snapshot / name).read_bytes()) == digest for name, digest in manifest.items())
    expected = json.loads((snapshot / IDENTITY).read_bytes())["source_expected"]
    site = Path(VENV) / "lib/python3.12/site-packages"
    checks = {name: sha((site / name).read_bytes()) == digest for name, digest in expected.items()}
    (results / "source-check.json").write_text(json.dumps(checks, indent=2) + "\n")
    assert all(checks.values())
    env = load_base(snapshot).prepare_env(snapshot)
    env["OMP_NUM_THREADS"] = "1"
    phases = {}
    for scenario in ("success", "draft-failure"):
        output = results / scenario
        output.mkdir()
        command = [VENV + "/bin/python", "-B", "-m", "torch.distributed.run", "--standalone", "--nproc-per-node=2", PROBE,
                   "--scenario", scenario, "--output-dir", str(output)]
        process = subprocess.Popen(command, cwd=snapshot, env=env, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, start_new_session=True)
        terminated = False
        try:
            stdout, stderr = process.communicate(timeout=90)
            returncode = process.returncode
        except subprocess.TimeoutExpired:
            terminated = True
            with suppress(ProcessLookupError):
                os.killpg(process.pid, signal.SIGTERM)
            try:
                stdout, stderr = process.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate(timeout=5)
            returncode = 124
        raw = stdout + stderr
        (output / "torchrun.log").write_bytes(raw)
        phases[scenario] = {"command": command, "returncode": returncode,
                            "launcher_pid": process.pid, "supervisor_terminated": terminated}
        print(raw.decode(errors="replace")[-20000:])
        if returncode:
            break
    passed = len(phases) == 2 and all(phase["returncode"] == 0 for phase in phases.values())
    summary = {"scope": "Two actual processes/CPU Gloo group and native P sample/proposal/final report with declared CPU model leaves; no NPU or full-model acceptance",
               "source_files_checked": len(checks), "source_files_match": all(checks.values()),
               "phases": phases, "passed": passed}
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    raise SystemExit(0 if passed else 1)

if not args.label or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in args.label):
    parser.error("valid label required")
destination = ROOT / RUNS / args.label
destination.mkdir(parents=True, exist_ok=False)
previous = ROOT / "openspec/changes/afd-hccl-full-parity/evidence/a3-p-ready-frontier-cpu-20261113/combined-002/source.tar.gz"
with tarfile.open(previous) as stream:
    contents = {member.name: stream.extractfile(member).read() for member in stream if member.isfile() and member.name != "manifest.json"}
runtime = {name: data for name, data in contents.items() if name.startswith("afd_plugin/") and name.endswith(".py")}
assert len(runtime) == 143
preserved_local = {
    "afd_plugin/compat/patches/npu/model_loader.py": "88fb8e5f0f539fa00dc4491400506fa15e080471d1c4ba1efcbd030798fbb6db",
    "afd_plugin/model_executor/models/npu/deepseek_v4.py": "907107429562f154ae07f3b81cf77adfda6669dcd57767086a212bed73d67230",
    "afd_plugin/v1/worker/npu/hccl_v41_execution.py": "fde490f5d0995f51d52a3e721fba409bfffbf6ca340f4d90ea7ec64ffdfd4a10",
    "afd_plugin/v1/worker/npu/hccl_v41_ubatch_runner.py": "5eb91545be95489a7357de70ae6620cc1cbbdc22fd35c8e6971b2301654af6d7",
}
local_differences = {}
for name, frozen in runtime.items():
    local = (ROOT / name).read_bytes()
    if local != frozen:
        assert name in preserved_local and sha(local) == preserved_local[name], name
        local_differences[name] = {
            "frozen_sha256": sha(frozen), "preserved_local_sha256": sha(local),
            "ast_equal": ast.dump(ast.parse(frozen)) == ast.dump(ast.parse(local)),
            "local_bytes_used": False,
        }
for name in OVERLAYS:
    contents[name] = (ROOT / name).read_bytes()
contents[".tmp/stage_pd_report_gloo.py"] = Path(__file__).read_bytes()
manifest = {name: sha(data) for name, data in contents.items()}
contents["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:gz") as stream:
    for name, data in contents.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        stream.addfile(member, io.BytesIO(data))
payload = buffer.getvalue()
(destination / "source.tar.gz").write_bytes(payload)
base = load_base(ROOT)
remote = base.ssh("python3 -c " + shlex.quote("import tempfile;print(tempfile.mkdtemp(prefix='p-report-gloo-cpu-20261114-',dir=" + repr(PARENT) + "))")).decode().strip()
(destination / "identity.json").write_text(json.dumps({"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "remote": remote, "archive_sha256": sha(payload), "manifest": manifest,
    "preserved_local_differences": local_differences,
    "scope": "All 143 staged runtime files identical to combined-002; only the new CPU probe and two shared fixture parameterizations overlaid. Four pre-existing local differences are preserved and explicitly excluded from this frozen execution."}, indent=2) + "\n", encoding="utf-8")
base.ssh("cat > " + shlex.quote(remote + "/source.tar.gz"), payload)
base.ssh("cat > " + shlex.quote(remote + "/stage_pd_report_gloo.py"), Path(__file__).read_bytes())
command = "python3 -B " + shlex.quote(remote + "/stage_pd_report_gloo.py") + " --remote-root " + shlex.quote(remote)
run = subprocess.run(["ssh", "-F", base.SSH_CONFIG, "-o", "BatchMode=yes", base.SSH_HOST, command], capture_output=True, timeout=240)
(destination / "remote.log").write_bytes(run.stdout + run.stderr)
result = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
(destination / "results.tar.gz").write_bytes(result)
short = ROOT / ".tmp" / ("pgloo-" + args.label)
short.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(result)) as stream:
    stream.extractall(short, filter="data")
(destination / "collection.json").write_text(json.dumps({"archive_sha256": sha(result), "returncode": run.returncode,
    "short_extraction": str(short)}, indent=2) + "\n", encoding="utf-8")
print(run.stdout.decode(errors="replace"))
print(run.stderr.decode(errors="replace"))
raise SystemExit(run.returncode)
