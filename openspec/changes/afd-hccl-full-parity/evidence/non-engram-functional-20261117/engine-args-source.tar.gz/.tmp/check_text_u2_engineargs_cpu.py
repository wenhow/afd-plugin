"""Construct a declared ordinary V4.1 text U2 config without executing a model."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import traceback
from pathlib import Path

MAX_MODEL_LEN = 128
MAX_BATCHED_TOKENS = 16
MAX_REQUESTS = 2
U2_STAGES = 2
LAYERS = 2
HIDDEN_SIZE = 512
VOCAB_SIZE = 128
PD_HANDSHAKE_PORT = 23570
PD_CONNECTOR_MODULE = "afd_plugin.compat.npu.kv_layout_connector"


def transfer_record(transfer):
    if transfer is None:
        return None
    return {
        "kv_connector": transfer.kv_connector,
        "kv_connector_module_path": transfer.kv_connector_module_path,
        "kv_role": transfer.kv_role,
        "kv_buffer_device": transfer.kv_buffer_device,
        "kv_ip": transfer.kv_ip,
        "kv_port": transfer.kv_port,
        "engine_id": transfer.engine_id,
        "kv_connector_extra_config": copy.deepcopy(transfer.kv_connector_extra_config),
    }


def bounded_text_config(hf_config):
    """Declare the controlled, unquantized, no-Engram model before validation."""
    values = {
        "hidden_size": HIDDEN_SIZE,
        "num_hidden_layers": LAYERS,
        "num_attention_heads": 1,
        "num_key_value_heads": 1,
        "head_dim": HIDDEN_SIZE,
        "qk_rope_head_dim": 64,
        "q_lora_rank": 128,
        "kv_lora_rank": HIDDEN_SIZE,
        "o_lora_rank": 128,
        "o_groups": 1,
        "hc_mult": 4,
        "vocab_size": VOCAB_SIZE,
        "intermediate_size": HIDDEN_SIZE,
        "moe_intermediate_size": HIDDEN_SIZE,
        "n_routed_experts": 8,
        "n_shared_experts": 1,
        "num_experts_per_tok": 2,
        "n_group": 1,
        "topk_group": 1,
        "num_hash_layers": 0,
        "max_position_embeddings": MAX_MODEL_LEN,
        "sliding_window": 128,
        "compress_ratios": [2] * LAYERS,
        "index_head_dim": 128,
        "index_n_heads": 64,
        "index_topk": 512,
        "engram_layer_ids": [],
        "vision_n_layers": 0,
        "quantization_config": None,
        "expert_dtype": "bf16",
        "bos_token_id": 1,
        "eos_token_id": 2,
        "pad_token_id": 0,
    }
    raw = hf_config.to_dict()
    raw["model_type"] = hf_config.model_type
    raw.update(values)
    if "text_config" in raw:
        raw["text_config"] = {**raw["text_config"], **values}
    raw["vision_config"] = {"num_hidden_layers": 0}
    return type(hf_config)(**raw)


def run(args, report):
    # Native imports are confined to this explicitly requested host check.
    import torch
    import torch_npu  # noqa: F401
    from vllm.platforms import current_platform
    from vllm.plugins import load_general_plugins

    report["npu_initialized_before"] = torch.npu.is_initialized()
    assert report["npu_initialized_before"] is False
    assert current_platform.device_type == "npu"
    current_platform.pre_register_and_update()
    load_general_plugins()

    from vllm.config import CompilationConfig, CompilationMode, CUDAGraphMode
    from vllm.config.kv_transfer import KVTransferConfig
    from vllm.engine.arg_utils import EngineArgs

    from afd_plugin.compat.npu import apply_afd_ascend_config_patch_if_needed

    apply_afd_ascend_config_patch_if_needed()
    import afd_plugin.compat.patches.config_validation  # noqa: F401

    source = Path(args.model) / "config.json"
    source_bytes = source.read_bytes()
    raw = json.loads(source_bytes)
    for container in (raw, raw.get("text_config", {})):
        container.pop("quantization_config", None)
        container.pop("compression_config", None)
        container["expert_dtype"] = "bf16"
    controlled = args.output_dir / "controlled-model"
    controlled.mkdir()
    (controlled / "config.json").write_text(json.dumps(raw) + "\n", "utf-8")
    (args.output_dir / "checkpoint-config-original.json").write_bytes(source_bytes)
    graph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY if args.target_graph else CUDAGraphMode.NONE
    )
    transfer = None
    tokenizer_sources = {}
    if args.pd_consumer:
        transfer = KVTransferConfig(
            kv_connector="MooncakeHybridConnector",
            kv_connector_module_path=PD_CONNECTOR_MODULE,
            kv_role="kv_consumer",
            kv_buffer_device="npu",
            kv_ip="127.0.0.1",
            kv_port=PD_HANDSHAKE_PORT,
            engine_id="ordinary-text-u2-host-" + args.role,
            kv_connector_extra_config={
                "prefill": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
                "decode": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
            },
        )
        tokenizer_sources = {
            name: hashlib.sha256((Path(args.model) / name).read_bytes()).hexdigest()
            for name in ("tokenizer.json", "tokenizer_config.json")
        }
    declaration = {
        "role": args.role,
        "ubatch_size": U2_STAGES,
        "enable_dbo": False,
        "enforce_eager": not args.target_graph,
        "compilation_mode": "NONE",
        "cudagraph_mode": graph_mode.name,
        "speculative_config": None,
        "kv_transfer_config": transfer_record(transfer),
        "tokenizer": args.model if args.pd_consumer else None,
        "skip_tokenizer_init": not args.pd_consumer,
        "language_model_only": True,
        "enable_prefix_caching": False,
    }
    report["first_engine_args_declaration"] = declaration
    report["source_config_sha256"] = hashlib.sha256(source_bytes).hexdigest()
    report["tokenizer_source_sha256"] = tokenizer_sources
    config = EngineArgs(
        model=str(controlled),
        trust_remote_code=True,
        tokenizer=declaration["tokenizer"],
        skip_tokenizer_init=declaration["skip_tokenizer_init"],
        language_model_only=True,
        dtype="bfloat16",
        hf_overrides=bounded_text_config,
        load_format="dummy",
        enforce_eager=declaration["enforce_eager"],
        max_model_len=MAX_MODEL_LEN,
        max_num_seqs=MAX_REQUESTS,
        max_num_batched_tokens=MAX_BATCHED_TOKENS,
        enable_chunked_prefill=True,
        enable_prefix_caching=False,
        tensor_parallel_size=1,
        enable_expert_parallel=False,
        enable_dbo=False,
        ubatch_size=U2_STAGES,
        dbo_decode_token_threshold=U2_STAGES,
        dbo_prefill_token_threshold=U2_STAGES,
        async_scheduling=False,
        seed=0,
        compilation_config=CompilationConfig(
            mode=CompilationMode.NONE,
            cudagraph_mode=graph_mode,
            cudagraph_capture_sizes=[4] if args.target_graph else [],
            max_cudagraph_capture_size=4 if args.target_graph else None,
            use_inductor_graph_partition=False,
        ),
        speculative_config=None,
        kv_transfer_config=transfer,
        additional_config={
            "enable_cpu_binding": False,
            "afd": {
                "connector": "P2pHcclAFDConnector",
                "role": args.role,
                "host": "127.0.0.1",
                "num_attention_ranks": 1,
                "num_ffn_ranks": 1,
                "port": 29990,
                "connector_extra_config": {"max_tokens": MAX_BATCHED_TOKENS},
            },
        },
    ).create_engine_config()
    report["actual"] = {
        "ubatch_size": config.parallel_config.ubatch_size,
        "num_ubatches": config.parallel_config.num_ubatches,
        "use_ubatching": config.parallel_config.use_ubatching,
        "enable_dbo": config.parallel_config.enable_dbo,
        "model_type": config.model_config.hf_text_config.model_type,
        "model_is_multimodal": config.model_config.is_multimodal_model,
        "language_model_only": (
            config.model_config.multimodal_config.language_model_only
        ),
        "engram_layer_ids": config.model_config.hf_text_config.engram_layer_ids,
        "engram_config": config.engram_config,
        "speculative_config": config.speculative_config,
        "kv_transfer_config": transfer_record(config.kv_transfer_config),
        "tokenizer": config.model_config.tokenizer,
        "skip_tokenizer_init": config.model_config.skip_tokenizer_init,
        "enable_prefix_caching": config.cache_config.enable_prefix_caching,
        "enable_mm_embeds": config.model_config.multimodal_config.enable_mm_embeds,
        "allow_missing_mm_embeddings": (
            config.model_config.multimodal_config.allow_missing_mm_embeddings
        ),
        "enforce_eager": config.model_config.enforce_eager,
        "compilation_mode": config.compilation_config.mode.name,
        "cudagraph_mode": config.compilation_config.cudagraph_mode.name,
        "dbo_unsupported_features": config._get_dbo_unsupported_features(),
    }
    assert report["actual"]["dbo_unsupported_features"] == []
    assert config.parallel_config.use_ubatching is True
    assert type(config.parallel_config.num_ubatches) is int
    assert config.parallel_config.num_ubatches == U2_STAGES
    assert config.parallel_config.ubatch_size == U2_STAGES
    assert config.speculative_config is config.engram_config is None
    if args.pd_consumer:
        actual_transfer = config.kv_transfer_config
        assert actual_transfer is not None
        assert actual_transfer.kv_connector == "MooncakeHybridConnector"
        assert actual_transfer.kv_connector_module_path == PD_CONNECTOR_MODULE
        assert actual_transfer.kv_role == "kv_consumer"
        assert actual_transfer.kv_buffer_device == "npu"
        assert actual_transfer.kv_ip == "127.0.0.1"
        assert actual_transfer.kv_port == PD_HANDSHAKE_PORT
        assert actual_transfer.engine_id.startswith(
            declaration["kv_transfer_config"]["engine_id"] + "-"
        )
        for side in ("prefill", "decode"):
            assert actual_transfer.kv_connector_extra_config[side] == {
                "tp_size": 1,
                "dp_size": 1,
                "pp_size": 1,
            }
        assert config.model_config.tokenizer == args.model
        assert config.model_config.skip_tokenizer_init is False
        assert config.model_config.multimodal_config.enable_mm_embeds is True
        assert config.model_config.multimodal_config.allow_missing_mm_embeddings is True
        assert tokenizer_sources == {
            name: hashlib.sha256((Path(args.model) / name).read_bytes()).hexdigest()
            for name in tokenizer_sources
        }
    else:
        assert config.kv_transfer_config is None
        assert config.model_config.skip_tokenizer_init is True
    assert config.cache_config.enable_prefix_caching is False
    assert config.model_config.hf_text_config.engram_layer_ids == []
    assert config.model_config.is_multimodal_model is True
    assert config.model_config.multimodal_config.language_model_only is True
    assert config.model_config.enforce_eager is (not args.target_graph)
    assert config.compilation_config.cudagraph_mode == graph_mode
    assert source.read_bytes() == source_bytes
    report["npu_initialized_after"] = torch.npu.is_initialized()
    assert report["npu_initialized_after"] is False
    report["status"] = "passed"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true")
    parser.add_argument("--model")
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--role", choices=("attention", "ffn"), default="attention")
    parser.add_argument("--target-graph", action="store_true")
    parser.add_argument(
        "--pd-consumer",
        action="store_true",
        help="declare the original attested PD consumer view before validation",
    )
    args = parser.parse_args()
    if not args.run:
        print(json.dumps({"status": "not_run", "scope": __doc__}))
        return
    if args.model is None or args.output_dir is None:
        parser.error("--run requires --model and --output-dir")
    args.output_dir.mkdir(parents=True, exist_ok=False)
    report = {
        "status": "failed",
        "scope": "real EngineArgs first-construction host configuration only",
        "model_constructed": False,
        "device_tensor_or_collective_executed": False,
        "full_model_admission_executed": False,
        "pd_consumer_requested": args.pd_consumer,
        "pd_runtime_constructed": False,
        "explicit_v2_before": os.environ.get("VLLM_USE_V2_MODEL_RUNNER"),
    }
    os.environ["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    try:
        run(args, report)
    except BaseException:
        report["error"] = traceback.format_exc()
        raise
    finally:
        (args.output_dir / "result.json").write_text(
            json.dumps(report, indent=2, sort_keys=True) + "\n", "utf-8"
        )


if __name__ == "__main__":
    main()
