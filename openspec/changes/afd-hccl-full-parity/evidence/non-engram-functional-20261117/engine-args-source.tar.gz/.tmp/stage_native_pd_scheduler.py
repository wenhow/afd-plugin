"""Freeze public native A execute/sample/cancel/fallback with the F daemon."""

import argparse
import hashlib
import importlib.util
import io
import json
import shlex
import subprocess
import tarfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = "openspec/changes/afd-hccl-v2-microbatch/evidence/a3-forward-counts-20261109/run_a3_forward_counts.py"
IDENTITY = "openspec/changes/afd-hccl-full-parity/evidence/eager-configuration-source-identity-20261113.json"
HELPER = "openspec/changes/afd-hccl-v2-graph/evidence/a3-native-manager-20261109/run_a3_graph_manager.py"
PROBE = "tests/npu/hccl_native_attention_pd_probe.py"
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-native-pd-scheduler-20261114"
BASELINE = "openspec/changes/afd-hccl-full-parity/evidence/a3-native-pd-transfer-20261114/transfer-004/source.tar.gz"
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
DRIVER = ".tmp/stage_native_pd_scheduler.py"
EXTRA_IDENTITY = ".tmp/native-pd-storage-extra-source-identity.json"
EXTRA_SOURCES = ("vllm_ascend/core/single_type_kv_cache_manager.py", "vllm_ascend/patch/platform/patch_kv_cache_coordinator.py", "vllm_ascend/patch/platform/patch_kv_cache_utils.py", "vllm_ascend/core/scheduler_profiling_chunk.py", "vllm_ascend/models/deepseek_v41/cache_config.py", "vllm_ascend/worker/v2/attn_utils.py", "vllm_ascend/patch/platform/patch_speculative_config.py", "vllm_ascend/ops/rope_dsv4.py", "vllm_ascend/worker/v2/kvpp.py", "vllm/model_executor/layers/logits_processor.py", "vllm/model_executor/layers/vocab_parallel_embedding.py")
ASCEND_COMMIT = "7e37e29a7803d6897a7113088e2b771f83205bc0"
VLLM_COMMIT = "ced6857afa0ea7b2e3f0846a62e1394e90f15607"
OVERLAYS = (PROBE, "tests/npu/hccl_native_attention_pd_scheduler_probe.py")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


parser = argparse.ArgumentParser()
parser.add_argument("--label")
parser.add_argument("--query-len", type=int, choices=(1,), default=1)
parser.add_argument("--axes", choices=("00000",), default="00000")
parser.add_argument("--remote-root", type=Path)
parser.add_argument("--cann-cache-identity", action="store_true")
args = parser.parse_args()
if args.remote_root:
    remote = args.remote_root
    snapshot, results = remote / "snapshot", remote / "results"
    snapshot.mkdir()
    results.mkdir()
    with tarfile.open(remote / "source.tar.gz") as stream:
        stream.extractall(snapshot, filter="data")
    manifest = json.loads((snapshot / "manifest.json").read_text())
    assert all(sha((snapshot / name).read_bytes()) == digest for name, digest in manifest.items())
    expected = json.loads((snapshot / IDENTITY).read_text())["source_expected"]
    expected.update(json.loads((snapshot / EXTRA_IDENTITY).read_text())["source_expected"])
    site = Path(VENV) / "lib/python3.12/site-packages"
    checks = {name: sha((site / name).read_bytes()) == digest for name, digest in expected.items()}
    (results / "source-check.json").write_text(json.dumps(checks, indent=2) + "\n")
    assert all(checks.values())
    base = load_module("q3_component_environment", snapshot / BASE)
    helper = load_module("q3_device_supervision", snapshot / HELPER)
    env = base.prepare_env(snapshot)
    env["ASCEND_RT_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
    toolchain_expected = {}
    if args.cann_cache_identity:
        original = Path(env["ASCEND_HOME_PATH"]).resolve(strict=True)
        assert b"Version=9.0.1" in (original / "share/info/runtime/version.info").read_bytes()
        mirror = remote / "cann-cache-identity"
        mirror.mkdir()
        architecture = "aarch64-linux"
        for entry in original.iterdir():
            if entry.name != architecture:
                (mirror / entry.name).symlink_to(entry.absolute(), target_is_directory=entry.is_dir())
        (mirror / architecture).mkdir()
        for entry in (original / architecture).iterdir():
            (mirror / architecture / entry.name).symlink_to(entry.absolute(), target_is_directory=entry.is_dir())
        metadata = sorted(set((original / "share/info").rglob("version.info")) | set((original / "share/info").rglob("*install.info")))
        version_files = {}
        for entry in metadata:
            relative = entry.relative_to(original).as_posix()
            raw = entry.read_bytes()
            target = results / "toolchain-metadata" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(raw)
            version_files[relative] = sha(raw)
            toolchain_expected[str(entry)] = sha(raw)
        manifest_bytes = (json.dumps({"original_home": str(original), "kind": "cache_identity_compatibility_manifest", "purpose": "Legacy Triton CANN cache identity for unchanged split-package CANN 9.0.1 metadata", "files": version_files}, sort_keys=True, indent=2) + "\n").encode()
        legacy = mirror / architecture / "ascend_toolkit_install.info"
        assert not legacy.exists() and not legacy.is_symlink()
        legacy.write_bytes(manifest_bytes)
        (results / "toolchain-cache-manifest.json").write_bytes(manifest_bytes)
        for relative in ("triton/backends/ascend/utils.py", "triton/backends/ascend/compiler.py", "triton/runtime/jit.py", "triton/compiler/compiler.py"):
            entry = site / relative
            toolchain_expected[str(entry)] = sha(entry.read_bytes())
            target = results / "toolchain-source" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(entry.read_bytes())
        for relative in ("tools/bisheng_compiler/bin/bisheng", "tools/bisheng_compiler/bin/ld.lld", "aarch64-linux/lib64/libascendcl.so"):
            entry = original / relative
            toolchain_expected[str(entry)] = sha(entry.read_bytes())
        env["ASCEND_HOME_PATH"] = str(mirror)
        env["TRITON_CACHE_DIR"] = str(remote / "triton-cache")
        preflight = subprocess.run([VENV + "/bin/python", "-B", "-c", "from triton.backends.ascend.utils import get_cann_version_file_hash;print(get_cann_version_file_hash())"], env=env, capture_output=True, timeout=30)
        (results / "toolchain-preflight.log").write_bytes(preflight.stdout + preflight.stderr)
        assert preflight.returncode == 0 and preflight.stdout.decode().strip().splitlines()[-1] == sha(manifest_bytes)
        (results / "toolchain-identity.json").write_text(json.dumps({"original_home": str(original), "mirror_home": str(mirror), "metadata_files": version_files, "expected": toolchain_expected, "cache_manifest_sha256": sha(manifest_bytes), "native_cache_identity_verified_without_device": True, "isolated_triton_cache": env["TRITON_CACHE_DIR"], "symlinks": {str(p.relative_to(mirror)): str(p.resolve()) for p in list(mirror.iterdir()) + list((mirror / architecture).iterdir()) if p.is_symlink()}}, indent=2) + "\n")
    versions = subprocess.run([VENV + "/bin/python", "-B", "-c", "import importlib.metadata as m,json,platform;print(json.dumps({'python':platform.python_version(),'packages':{k:m.version(k) for k in ['torch','torch-npu','vllm','vllm-ascend','fastapi','triton','triton-ascend']}},indent=2))"], env=env, capture_output=True, check=True, timeout=30)
    (results / "versions.json").write_bytes(versions.stdout)
    (results / "effective-env.json").write_text(json.dumps({key: env.get(key) for key in ("ASCEND_RT_VISIBLE_DEVICES", "VLLM_USE_V2_MODEL_RUNNER", "VLLM_PLUGINS", "LD_LIBRARY_PATH", "PYTHONPATH", "ASCEND_HOME_PATH", "ASCEND_OPP_PATH", "PATH", "TRITON_CACHE_DIR")}, indent=2) + "\n")
    dependency_preflight = subprocess.run([VENV + "/bin/python", "-B", str(snapshot / PROBE), "--output-dir", str(results / "dependency-before")], env=env, capture_output=True, timeout=30)
    (results / "mooncake-preflight.log").write_bytes(dependency_preflight.stdout + dependency_preflight.stderr)
    assert dependency_preflight.returncode == 0
    dependency_before = json.loads((results / "dependency-before/result.json").read_text())["dependencies"]
    assert dependency_before["single_distribution_owns_resolved_extension"]
    assert not dependency_before["engine_imported"]
    (results / "mooncake-identity.json").write_text(json.dumps(dependency_before, indent=2) + "\n")
    before = subprocess.run(["npu-smi", "info"], env=env, capture_output=True, check=True, timeout=30)
    (results / "before.log").write_bytes(before.stdout + before.stderr)
    assert before.stdout.count(b"No running processes found in NPU") == 8
    command = [VENV + "/bin/python", "-B", str(snapshot / PROBE), "--model", "/mnt/workspace/models/DeepSeek-V4.1-Flash", "--devices", "0,2", "--run-scheduler-transfer", "--timeout", "240", "--output-dir", str(results / "transfer")]
    owned, killed, timed_out = {}, [], False
    started = time.monotonic()
    with (results / "probe.log").open("wb") as output:
        process = subprocess.Popen(command, cwd=snapshot, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            helper.collect_owned_processes(process.pid, owned)
            if time.monotonic() - started > 340:
                timed_out = True
                killed = helper.kill_owned(owned)
                break
            time.sleep(0.25)
        process.wait(timeout=10)
    after = subprocess.run(["npu-smi", "info"], env=env, capture_output=True, timeout=30)
    (results / "after.log").write_bytes(after.stdout + after.stderr)
    dependency_postflight = subprocess.run([VENV + "/bin/python", "-B", str(snapshot / PROBE), "--output-dir", str(results / "dependency-after")], env=env, capture_output=True, timeout=30)
    (results / "mooncake-postflight.log").write_bytes(dependency_postflight.stdout + dependency_postflight.stderr)
    assert dependency_postflight.returncode == 0
    dependency_after = json.loads((results / "dependency-after/result.json").read_text())["dependencies"]
    (results / "mooncake-after.json").write_text(json.dumps(dependency_after, indent=2) + "\n")
    assert dependency_after == dependency_before
    after_checks = {name: sha((snapshot / name).read_bytes()) == digest for name, digest in manifest.items()}
    installed_after = {name: sha((site / name).read_bytes()) == digest for name, digest in expected.items()}
    if toolchain_expected:
        toolchain_after = {name: sha(Path(name).read_bytes()) == digest for name, digest in toolchain_expected.items()}
        (results / "toolchain-after.json").write_text(json.dumps(toolchain_after, indent=2) + "\n")
        assert all(toolchain_after.values())
    (results / "source-after.json").write_text(json.dumps({"snapshot": after_checks, "installed": installed_after}, indent=2) + "\n")
    (results / "owned.json").write_text(json.dumps({"processes": owned, "killed_pids": killed, "start_ticks_checked_before_kill": True}, indent=2) + "\n")
    path = results / "transfer/transfer-result.json"
    native = json.loads(path.read_text()) if path.exists() else {}
    success = process.returncode == 0 and not timed_out and not killed and native.get("success") is True and after.returncode == 0 and after.stdout.count(b"No running processes found in NPU") == 8 and all(after_checks.values()) and all(installed_after.values())
    summary = {"scope": "Native D Scheduler allocation, ActiveKV output update and first target admission with real TE page transfer; no model execute/DSpark/Graph/full-model acceptance", "command": command, "query_len": args.query_len, "axes": [int(enabled) for enabled in args.axes], "source_files_checked": len(checks), "source_files_match": all(checks.values()), "elapsed_seconds": time.monotonic() - started, "returncode": process.returncode, "timed_out": timed_out, "killed_owned_pids": killed, "idle_boards_before": 8, "idle_boards_after": after.stdout.count(b"No running processes found in NPU"), "success": success}
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))
    raise SystemExit(0 if success else 1)

if not args.label or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in args.label):
    parser.error("label required")
destination = ROOT / FAMILY / args.label
destination.mkdir(parents=True, exist_ok=False)
with tarfile.open(ROOT / BASELINE) as stream:
    contents = {entry.name: stream.extractfile(entry).read() for entry in stream if entry.isfile() and entry.name != "manifest.json"}
for name in (*OVERLAYS, DRIVER):
    contents[name] = (ROOT / name).read_bytes()
extra_expected = {}
for name in EXTRA_SOURCES:
    ascend_source = name.startswith("vllm_ascend/")
    source_repo = ROOT.parent / ("vllm-ascend" if ascend_source else "vllm")
    source_commit = ASCEND_COMMIT if ascend_source else VLLM_COMMIT
    raw = subprocess.check_output(["git", "-C", str(source_repo), "show", source_commit + ":" + name])
    extra_expected[name] = sha(raw)
contents[EXTRA_IDENTITY] = (json.dumps({"commits": {"vllm": VLLM_COMMIT, "vllm_ascend": ASCEND_COMMIT}, "source_expected": extra_expected}, indent=2) + "\n").encode()
manifest = {name: sha(raw) for name, raw in contents.items()}
contents["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:gz") as stream:
    for name, raw in contents.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(raw)
        stream.addfile(entry, io.BytesIO(raw))
payload = buffer.getvalue()
(destination / "source.tar.gz").write_bytes(payload)
base = load_module("q3_source_environment", ROOT / BASE)
remote = base.ssh("python3 -c " + shlex.quote("import tempfile;print(tempfile.mkdtemp(prefix='native-pd-scheduler-20261114-',dir=" + repr(PARENT) + "))")).decode().strip()
(destination / "identity.json").write_text(json.dumps({"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(), "remote": remote, "manifest": manifest, "archive_sha256": sha(payload), "scope": "Frozen transfer004 production143 unchanged plus native Scheduler component helper and explicit worker/probe overlays; paused MTP excluded"}, indent=2) + "\n", encoding="utf-8")
base.ssh("cat > " + shlex.quote(remote + "/source.tar.gz"), payload)
base.ssh("cat > " + shlex.quote(remote + "/stage_native_pd_scheduler.py"), Path(__file__).read_bytes())
command = "python3 -B " + shlex.quote(remote + "/stage_native_pd_scheduler.py") + " --remote-root " + shlex.quote(remote) + " --query-len " + str(args.query_len) + " --axes " + args.axes
if args.cann_cache_identity:
    command += " --cann-cache-identity"
run = subprocess.run(["ssh", "-F", base.SSH_CONFIG, "-o", "BatchMode=yes", base.SSH_HOST, command], capture_output=True, timeout=420)
(destination / "remote.log").write_bytes(run.stdout + run.stderr)
result = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
(destination / "results.tar.gz").write_bytes(result)
short = ROOT / ".tmp" / ("native-pd-scheduler-" + args.label)
short.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(result)) as stream:
    stream.extractall(short, filter="data")
(destination / "collection.json").write_text(json.dumps({"archive_sha256": sha(result), "returncode": run.returncode, "short_extraction": str(short)}, indent=2) + "\n", encoding="utf-8")
print(run.stdout.decode(errors="replace"))
print(run.stderr.decode(errors="replace"))
raise SystemExit(run.returncode)
