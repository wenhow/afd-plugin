"""Prepare or execute only normal A/F Worker factory + init_device in A3.

The local default requires --prepare-only. Explicit execution uploads the frozen
archive; it never refreshes production sources, installs packages, or loads a
model. Each role has independent stores, caches and a PID/start-tick boundary.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import os
import runpy
import shlex
import signal
import subprocess
import sys
import tarfile
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-text-normal-worker-20261116"
PARENT = FAMILY + "/prepared-green-002/source.tar.gz"
PARENT_SHA = "dc7706808ecaf19079c7253eea3910ff167c5215ba004022236a6a3fd0dd9364"
CPU_DRIVER = ".tmp/run_text_normal_worker_cpu_a3.py"
CPU_DRIVER_SHA = "de451cc4a415bfb0fa9102eae6829f27da36bbeb3670769f0fe348b34d5929eb"
DRIVER = ".tmp/run_text_normal_worker_device_a3.py"
ENVIRONMENT_RECORD = ".tmp/normal-worker-init-device-environment.json"
ENVIRONMENT_RECORD_SHA = (
    "c0d04190352a00139c662162211e419b9d829b3f4932f654dcbbf50c14c4184c"
)
PROBE = "tests/npu/dsv41_normal_worker_probe.py"
PROBE_SHA = "aaccc0a461376a8bbbda533e684f3e37d158db42e38dbd4d15bce6c04529be35"
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
MODEL = "/mnt/workspace/models/DeepSeek-V4.1-Flash"
REMOTE_PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
ACTIVE_ROOT = REMOTE_PARENT + "/dspark-7e-qli-20261116-feigmgju"
ACTIVE_RECORD_SHA = "98864facddbda0289a9cd6d304d05507f0d441b01f78569ec511c3dd31109a04"
PARENT_ROOT = REMOTE_PARENT + "/dspark-7e-draft-ops-20261114.ylI5MX"
PARENT_RECORD_SHA = "c5bfab43df090a2a215bd973d5cf4f37176ea0f23c89193f135954a558b63dd1"
SOURCE_FILES = 451
PRODUCTION_FILES = 146
ACTIVE_ARTIFACTS = 1068
TOOLCHAIN_ARTIFACTS = 1404
EXPECTED_IDLE_BOARDS = 8
ROLE_TIMEOUT_SECONDS = 240
SSH_TIMEOUT_SECONDS = 720
POLL_SECONDS = 0.2
REAP_SECONDS = 10


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepare_speculator_env(snapshot):
    # This new component uses the complete installed CANN 9.2 toolchain.
    # Its ATB product lives beside the toolkit and is pinned independently.
    inherited = os.environ.copy()
    for key in ("PATH", "LD_LIBRARY_PATH", "PYTHONPATH"):
        inherited[key] = ":".join(
            value
            for value in inherited.get(key, "").split(":")
            if value and not value.startswith("/mnt/workspace/code/.ascend/cann-")
        )
    for key in (
        "ASCEND_HOME_PATH",
        "ASCEND_OPP_PATH",
        "ASCEND_AICPU_PATH",
        "ASCEND_TOOLKIT_HOME",
        "TBE_IMPL_PATH",
        "ASCEND_CUSTOM_OPP_PATH",
    ):
        inherited.pop(key, None)
    inherited["ASCEND_SLOG_PRINT_TO_STDOUT"] = "0"
    script = """set -e
source /mnt/workspace/code/.ascend/cann-9.2.0/ascend-toolkit/set_env.sh >/dev/null
export LD_LIBRARY_PATH=/opt/buildtools/python-3.12.9/lib:\
/usr/local/Ascend/driver/lib64/driver:\
/usr/local/Ascend/driver/lib64/common:${LD_LIBRARY_PATH}
export PATH=/mnt/workspace/code/.venvs/afd-v030-dsv41-c0/bin:${PATH}
source /mnt/workspace/code/.ascend/cann-9.2.0/nnal/atb/set_env.sh >/dev/null
env -0
"""
    prepared = subprocess.run(
        ["bash", "-c", script],
        env=inherited,
        capture_output=True,
        timeout=30,
        check=True,
    )
    env = {
        key.decode(): value.decode()
        for field in prepared.stdout.split(b"\0")
        if field
        for key, value in [field.split(b"=", 1)]
    }
    assert Path(env["ASCEND_HOME_PATH"]).resolve() == Path(
        "/mnt/workspace/code/.ascend/cann-9.2.0/cann-9.2.0"
    )
    old_home = "/mnt/workspace/code/.ascend/cann-9.0.1/"
    for key in ("PATH", "LD_LIBRARY_PATH", "PYTHONPATH"):
        assert all(
            not value.startswith(old_home) for value in env.get(key, "").split(":")
        )
    env["PYTHONPATH"] = str(snapshot) + ":" + env.get("PYTHONPATH", "")
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    env["VLLM_PLUGINS"] = (
        "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,ascend_service_profiling"
    )
    return env


def prepare(args):
    cpu = load_module("normal_worker_cpu_packaging", ROOT / CPU_DRIVER)
    assert sha((ROOT / CPU_DRIVER).read_bytes()) == CPU_DRIVER_SHA
    raw = (ROOT / PARENT).read_bytes()
    assert sha(raw) == PARENT_SHA
    parent, _ = cpu.read_archive(raw)
    assert len(parent) == 449 and sha(parent[PROBE]) == PROBE_SHA
    assert sha(parent[CPU_DRIVER]) == CPU_DRIVER_SHA
    record_raw = (ROOT / ENVIRONMENT_RECORD).read_bytes()
    assert sha(record_raw) == ENVIRONMENT_RECORD_SHA
    record = json.loads(record_raw)
    assert len(record["active_artifacts"]) == ACTIVE_ARTIFACTS
    assert len(record["toolchain_artifacts"]) == TOOLCHAIN_ARTIFACTS
    files = {
        **parent,
        DRIVER: Path(__file__).read_bytes(),
        ENVIRONMENT_RECORD: record_raw,
    }
    assert len(files) == SOURCE_FILES
    assert all(files[name] == data for name, data in parent.items())
    production = [name for name in files if name.startswith("afd_plugin/")]
    assert len(production) == PRODUCTION_FILES
    python_files = [name for name in files if name.endswith(".py")]
    for name in python_files:
        compile(files[name], name, "exec")
    assert len(cpu.source_pins(files)) == 191
    archive = cpu.archive_bytes(files)
    frozen, manifest = cpu.read_archive(archive)
    assert frozen == files
    output = ROOT / FAMILY / args.label
    output.mkdir(parents=True, exist_ok=False)
    (output / "source.tar.gz").write_bytes(archive)
    (output / "runner.py").write_bytes(files[DRIVER])
    record = {
        "source_archive_sha256": sha(archive),
        "parent_archive_sha256": PARENT_SHA,
        "source_files": len(files),
        "production_files": len(production),
        "all_parent_members_byte_equal": True,
        "production_byte_equal_parent": True,
        "python_files_compiled": len(python_files),
        "native_source_identities": 191,
        "active_package_and_record_identities": ACTIVE_ARTIFACTS,
        "toolchain_atb_identities": TOOLCHAIN_ARTIFACTS,
        "driver_sha256": manifest[DRIVER],
        "environment_record_sha256": ENVIRONMENT_RECORD_SHA,
        "probe_sha256": PROBE_SHA,
        "added_to_parent": sorted(set(files) - set(parent)),
        "roles": [{"role": "attention", "device": 0}, {"role": "ffn", "device": 1}],
        "role_timeout_seconds": ROLE_TIMEOUT_SECONDS,
        "prepared_only": True,
        "ssh_executed": False,
        "device_executed": False,
        "scope": "Normal Worker init_device only; no load_model/KV/execute/sample",
    }
    (output / "preparation.json").write_text(
        json.dumps(record, indent=2) + "\n", "utf-8"
    )
    (output / "manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n", "utf-8"
    )
    print(json.dumps(record, indent=2))


def observe_owned(pid, owned):
    pending = [pid]
    while pending:
        current = pending.pop()
        with contextlib.suppress(FileNotFoundError, ProcessLookupError):
            fields = (
                Path(f"/proc/{current}/stat").read_text().rsplit(") ", 1)[1].split()
            )
            start_ticks = fields[19]
            if current in owned and owned[current] != start_ticks:
                raise RuntimeError("observed PID changed start time")
            owned[current] = start_ticks
            children = (
                Path(f"/proc/{current}/task/{current}/children").read_text().split()
            )
            pending.extend(map(int, children))


def live_owned(owned):
    live = []
    for pid, start_ticks in owned.items():
        with contextlib.suppress(FileNotFoundError, ProcessLookupError):
            fields = Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()
            if fields[19] == start_ticks and fields[0] != "Z":
                live.append(pid)
    return live


def kill_owned(owned):
    killed = []
    for pid in reversed(live_owned(owned)):
        # Recheck the original process identity immediately before each kill.
        with contextlib.suppress(FileNotFoundError, ProcessLookupError):
            fields = Path(f"/proc/{pid}/stat").read_text().rsplit(") ", 1)[1].split()
            if fields[19] == owned[pid]:
                os.kill(pid, signal.SIGKILL)
                killed.append(pid)
    return killed


def supervise_role(command, environment, snapshot, results, role):
    owned, killed, timed_out = {}, [], False
    started = time.monotonic()
    with (results / (role + ".log")).open("wb") as log:
        child = subprocess.Popen(
            command,
            cwd=snapshot,
            env=environment,
            stdout=log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
        try:
            observe_owned(child.pid, owned)
            while child.poll() is None:
                observe_owned(child.pid, owned)
                if time.monotonic() - started >= ROLE_TIMEOUT_SECONDS:
                    timed_out = True
                    killed.extend(kill_owned(owned))
                    break
                time.sleep(POLL_SECONDS)
            child.wait(timeout=REAP_SECONDS)
        finally:
            leftovers = live_owned(owned)
            if leftovers:
                killed.extend(kill_owned(owned))
            if child.poll() is None:
                child.wait(timeout=REAP_SECONDS)
    result = {
        "role": role,
        "command": command,
        "returncode": child.returncode,
        "timed_out": timed_out,
        "killed_owned_pids": sorted(set(killed)),
        "owned_pid_start_ticks": owned,
        "surviving_owned_pids": live_owned(owned),
        "elapsed_seconds": time.monotonic() - started,
    }
    path = results / role / "result.json"
    result["report"] = json.loads(path.read_text()) if path.is_file() else None
    (results / (role + "-supervision.json")).write_text(
        json.dumps(result, indent=2) + "\n", "utf-8"
    )
    return result


def native_child(args):
    # Instrument only outer import/module identities; keep the frozen probe
    # untouched and let its real Worker factory/init_device/shutdown run.
    root = args.remote_root
    snapshot, results = root / "snapshot", root / "results"
    report = {"probe_sha256": PROBE_SHA, "returncode": None}
    code = 1
    try:
        sys.argv = [
            str(snapshot / PROBE),
            "--run-worker",
            "--model",
            args.model,
            "--output-dir",
            str(results / args.role),
            "--role",
            args.role,
            "--device",
            str(args.device),
        ]
        try:
            runpy.run_path(str(snapshot / PROBE), run_name="__main__")
            code = 0
        except SystemExit as error:
            code = error.code
    finally:
        report["returncode"] = code
        report["modules"] = {
            name: {
                "path": str(Path(module.__file__).resolve()),
                "sha256": sha(Path(module.__file__).read_bytes()),
            }
            for name, module in tuple(sys.modules.items())
            if name in ("vllm_ascend", "torch_npu", "vllm", "vllm_ascend.vllm_ascend_C")
            and module.__file__ is not None
        }
        mapped = {}
        selected_roots = (
            ACTIVE_ROOT + "/package/",
            "/mnt/workspace/code/.ascend/cann-9.2.0/",
        )
        forbidden = []
        for line in Path("/proc/self/maps").read_text().splitlines():
            path = line.split()[-1]
            if "/cann-9.0.1/" in path or path.startswith(PARENT_ROOT + "/package/"):
                forbidden.append(path)
            if path.startswith(selected_roots) and ".so" in path:
                resolved = Path(path).resolve(strict=True)
                mapped[str(resolved)] = sha(resolved.read_bytes())
        report["mapped_native_libraries"] = mapped
        report["forbidden_parent_or_cann90_mappings"] = sorted(set(forbidden))
        (results / (args.role + "-native-runtime.json")).write_text(
            json.dumps(report, indent=2) + "\n", "utf-8"
        )
    return code


def selected_environment(snapshot, owned, record):
    env = prepare_speculator_env(snapshot)
    package = ACTIVE_ROOT + "/package"
    vendor = package + "/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
    for key in ("PYTHONPATH", "LD_LIBRARY_PATH", "PATH"):
        env[key] = ":".join(
            path
            for path in env.get(key, "").split(":")
            if path and not path.startswith((PARENT_ROOT, ACTIVE_ROOT))
        )
    env["PYTHONPATH"] = ":".join(
        (
            str(snapshot),
            package,
            *(path for path in env["PYTHONPATH"].split(":") if path != str(snapshot)),
        )
    )
    env["LD_LIBRARY_PATH"] = (
        vendor + "/op_api/lib:" + package + "/vllm_ascend:" + env["LD_LIBRARY_PATH"]
    )
    env["ASCEND_CUSTOM_OPP_PATH"] = vendor
    assert Path(env["ATB_HOME_PATH"]).resolve() == Path(record["paths"]["atb_home"])
    for key in ("PYTHONPATH", "LD_LIBRARY_PATH", "PATH", "ASCEND_CUSTOM_OPP_PATH"):
        assert all(not path.startswith(PARENT_ROOT) for path in env[key].split(":"))
    env["AFD_DSV41_DUMMY_QUALIFICATION"] = "1"
    env["AFD_DSV41_EAGER_QUALIFICATION"] = "0"
    env["AFD_ASYNC_CAM_LAYERED_GMM"] = "0"
    env["ASCEND_RT_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
    for key, name in (
        ("ASCEND_CACHE_PATH", "ascend-cache"),
        ("ASCEND_WORK_PATH", "ascend-work"),
        ("ASCEND_PROCESS_LOG_PATH", "ascend-logs"),
        ("TORCH_EXTENSIONS_DIR", "torch-extensions"),
        ("TRITON_CACHE_DIR", "triton-cache"),
        ("XDG_CACHE_HOME", "cache"),
    ):
        path = owned / name
        path.mkdir(parents=True, exist_ok=False)
        env[key] = str(path)
    return env


def run_remote(args):
    root = args.remote_root.resolve()
    cpu_path = Path(__file__).parent / "cpu_runner.py"
    assert sha(cpu_path.read_bytes()) == CPU_DRIVER_SHA
    cpu = load_module("normal_worker_cpu_capsule", cpu_path)
    raw = (root / "source.tar.gz").read_bytes()
    files, manifest = cpu.read_archive(raw)
    preparation = json.loads((root / "preparation.json").read_text())
    assert (
        sha(raw) == preparation["source_archive_sha256"] and len(files) == SOURCE_FILES
    )
    assert sha(files[PROBE]) == PROBE_SHA
    snapshot, results = root / "snapshot", root / "results"
    snapshot.mkdir()
    results.mkdir()
    for name, data in files.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    record_raw = files[ENVIRONMENT_RECORD]
    assert sha(record_raw) == ENVIRONMENT_RECORD_SHA
    record = json.loads(record_raw)
    site = Path(args.python).parent.parent / "lib/python3.12/site-packages"
    native191 = {
        str(site / name): digest for name, digest in cpu.source_pins(files).items()
    }
    active = record["active_artifacts"]
    toolchain = record["toolchain_artifacts"]
    parent_record = PARENT_ROOT + "/final-extension-result.json"
    expected = {**native191, **active, **toolchain, parent_record: PARENT_RECORD_SHA}
    assert len(active) == ACTIVE_ARTIFACTS and len(toolchain) == TOOLCHAIN_ARTIFACTS
    actual_before = {name: sha(Path(name).read_bytes()) for name in expected}
    (results / "readonly-before.json").write_text(
        json.dumps(actual_before, indent=2) + "\n"
    )
    if actual_before != expected:
        raise RuntimeError(
            "frozen installed/package/CANN/ATB identity changed before run"
        )
    active_record_raw = Path(ACTIVE_ROOT, "metadata-build-result.json").read_bytes()
    assert sha(active_record_raw) == ACTIVE_RECORD_SHA
    active_record = json.loads(active_record_raw)
    assert active_record == record["active_record"]
    assert active_record["status"] == "built-not-loaded"
    assert active_record["native_enable_aicpu"] is True
    assert active_record["all_parent_api_symbols_retained"] is True
    assert active_record["reused_same_cann92_extension_and_python"] is True
    package_files = {
        str(path): sha(path.read_bytes())
        for path in Path(ACTIVE_ROOT, "package").rglob("*")
        if path.is_file()
    }
    assert {
        **package_files,
        str(Path(ACTIVE_ROOT, "metadata-build-result.json")): ACTIVE_RECORD_SHA,
    } == active
    env = selected_environment(snapshot, root / "owned-preflight", record)
    before = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-before.log").write_bytes(before.stdout + before.stderr)
    idle_before = before.stdout.count(b"No running processes found in NPU")
    runs, error = [], None
    started = time.monotonic()
    try:
        if before.returncode != 0 or idle_before != EXPECTED_IDLE_BOARDS:
            raise RuntimeError("all eight boards must be idle before init_device")
        for role, device in (("attention", 0), ("ffn", 1)):
            role_env = selected_environment(snapshot, root / (role + "-owned"), record)
            selected = {
                name: role_env.get(name)
                for name in (
                    "PYTHONPATH",
                    "PATH",
                    "LD_LIBRARY_PATH",
                    "ASCEND_HOME_PATH",
                    "ATB_HOME_PATH",
                    "ASCEND_CUSTOM_OPP_PATH",
                    "ASCEND_RT_VISIBLE_DEVICES",
                    "AFD_DSV41_DUMMY_QUALIFICATION",
                    "AFD_DSV41_EAGER_QUALIFICATION",
                    "VLLM_USE_V2_MODEL_RUNNER",
                    "VLLM_PLUGINS",
                    "ASCEND_CACHE_PATH",
                    "ASCEND_WORK_PATH",
                    "ASCEND_PROCESS_LOG_PATH",
                    "TORCH_EXTENSIONS_DIR",
                    "TRITON_CACHE_DIR",
                    "XDG_CACHE_HOME",
                )
            }
            (results / (role + "-environment.json")).write_text(
                json.dumps(selected, indent=2) + "\n"
            )
            command = [
                args.python,
                "-B",
                str(snapshot / DRIVER),
                "--remote-root",
                str(root),
                "--native-child",
                "--role",
                role,
                "--device",
                str(device),
                "--model",
                args.model,
            ]
            run = supervise_role(command, role_env, snapshot, results, role)
            runtime_path = results / (role + "-native-runtime.json")
            run["runtime"] = (
                json.loads(runtime_path.read_text()) if runtime_path.is_file() else None
            )
            runs.append(run)
            if (
                run["timed_out"]
                or run["killed_owned_pids"]
                or run["surviving_owned_pids"]
            ):
                break
    except BaseException:
        error = traceback.format_exc()
    after = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-after.log").write_bytes(after.stdout + after.stderr)
    idle_after = after.stdout.count(b"No running processes found in NPU")
    actual_after = {name: sha(Path(name).read_bytes()) for name in expected}
    source_after = {name: sha((snapshot / name).read_bytes()) for name in manifest}
    (results / "readonly-after.json").write_text(
        json.dumps(actual_after, indent=2) + "\n"
    )
    (results / "source-after.json").write_text(
        json.dumps(source_after, indent=2) + "\n"
    )
    roles_ok = len(runs) == 2
    for run in runs:
        report = run["report"] or {}
        runtime = run["runtime"] or {}
        origin = runtime.get("modules", {}).get("vllm_ascend", {}).get("path", "")
        extension = (
            ACTIVE_ROOT + "/package/vllm_ascend/"
            "vllm_ascend_C.cpython-312-aarch64-linux-gnu.so"
        )
        expected_device = "npu:0" if run["role"] == "attention" else "npu:1"
        roles_ok = roles_ok and (
            run["returncode"] == 0
            and not run["timed_out"]
            and not run["killed_owned_pids"]
            and not run["surviving_owned_pids"]
            and report.get("success") is True
            and report.get("run_worker") is True
            and report.get("run_config") is False
            and report.get("native_worker_component_accepted") is True
            and report.get("normal_role_init_device_completed") is True
            and report.get("native_wrapper_factory_constructed_worker") is True
            and report.get("native_groups_destroyed") is True
            and report.get("actual_device") == expected_device
            and report.get("cleanup_failures") == []
            and report.get("model_loaded") is False
            and report.get("kv_allocated") is False
            and report.get("inference_executed") is False
            and origin.startswith(ACTIVE_ROOT + "/package/vllm_ascend/")
            and runtime.get("mapped_native_libraries", {}).get(extension)
            == record["expected_native_library_sha256"][extension]
            and runtime.get("forbidden_parent_or_cann90_mappings") == []
        )
    success = bool(
        error is None
        and roles_ok
        and before.returncode == after.returncode == 0
        and idle_before == idle_after == EXPECTED_IDLE_BOARDS
        and actual_before == actual_after == expected
        and source_after == manifest
    )
    summary = {
        "success": success,
        "runs": runs,
        "error": error,
        "source_archive_sha256": sha(raw),
        "source_files": len(manifest),
        "production_files": PRODUCTION_FILES,
        "production_byte_equal_host_green": True,
        "installed_source_identities": len(native191),
        "active_artifact_identities": len(active),
        "toolchain_atb_identities": len(toolchain),
        "readonly_unchanged": actual_before == actual_after == expected,
        "source_unchanged": source_after == manifest,
        "idle_boards_before": idle_before,
        "idle_boards_after": idle_after,
        "elapsed_seconds": time.monotonic() - started,
        "model_loaded": False,
        "kv_allocated": False,
        "inference_executed": False,
        "scope": (
            "Normal Worker factory/init_device only; "
            "no load/KV/execute/sample or paired HCCL"
        ),
    }
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", "utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if success else 1


def execute_prepared(args):
    prepared = args.execute_prepared.resolve()
    cpu = load_module("normal_worker_cpu_transport", ROOT / CPU_DRIVER)
    raw = (prepared / "source.tar.gz").read_bytes()
    files, _ = cpu.read_archive(raw)
    preparation = json.loads((prepared / "preparation.json").read_text())
    assert sha(raw) == preparation["source_archive_sha256"]
    base = load_module("normal_worker_device_ssh", ROOT / cpu.BASE)
    uploader = load_module("normal_worker_device_upload", ROOT / cpu.UPLOAD_HELPER)
    make_remote = (
        "import tempfile;print(tempfile.mkdtemp("
        "prefix='text-normal-worker-device-20261116-',dir=" + repr(REMOTE_PARENT) + "))"
    )
    remote = base.ssh("python3 -c " + shlex.quote(make_remote)).decode().strip()
    (prepared / "identity.json").write_text(
        json.dumps({"remote_root": remote, "archive_sha256": sha(raw)}, indent=2) + "\n"
    )
    uploader.upload_source(base, remote, raw, prepared)
    inputs = {
        "runner.py": files[DRIVER],
        "cpu_runner.py": files[CPU_DRIVER],
        "preparation.json": (prepared / "preparation.json").read_bytes(),
    }
    deliver = (
        "import json,pathlib,sys; root=pathlib.Path("
        + repr(remote)
        + "); inputs=json.loads(sys.stdin.buffer.read()); "
        "[(root/n).write_bytes(bytes.fromhex(raw)) for n,raw in inputs.items()]"
    )
    base.ssh(
        "python3 -c " + shlex.quote(deliver),
        json.dumps({n: raw.hex() for n, raw in inputs.items()}).encode(),
    )
    command = (
        "python3 "
        + shlex.quote(remote + "/runner.py")
        + " --remote-root "
        + shlex.quote(remote)
        + " --python "
        + shlex.quote(args.python)
        + " --model "
        + shlex.quote(args.model)
    )
    process = subprocess.run(
        [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=15",
            base.SSH_HOST,
            command,
        ],
        capture_output=True,
        timeout=SSH_TIMEOUT_SECONDS,
    )
    (prepared / "remote-output.log").write_bytes(process.stdout + process.stderr)
    results = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
    (prepared / "results.tar.gz").write_bytes(results)
    with tarfile.open(fileobj=io.BytesIO(results)) as stream:
        summary = json.load(stream.extractfile("results/summary.json"))
    (prepared / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", "utf-8"
    )
    print(json.dumps(summary, indent=2))
    return 0 if process.returncode == 0 and summary["success"] is True else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--remote-root", type=Path)
    modes.add_argument("--execute-prepared", type=Path)
    parser.add_argument("--label", default=None)
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--python", default=VENV + "/bin/python")
    parser.add_argument("--native-child", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--role", choices=("attention", "ffn"), help=argparse.SUPPRESS)
    parser.add_argument("--device", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.prepare_only and (
        not args.label
        or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.label)
    ):
        parser.error("--prepare-only requires a safe lowercase --label")
    if not args.prepare_only and args.label is not None:
        parser.error("--label belongs only to local preparation")
    if args.native_child and (
        args.remote_root is None or args.role is None or args.device not in (0, 1)
    ):
        parser.error("native children require remote root, role and device 0 or 1")
    if args.prepare_only:
        prepare(args)
        return 0
    if args.native_child:
        return native_child(args)
    if args.execute_prepared is not None:
        return execute_prepared(args)
    return run_remote(args)


if __name__ == "__main__":
    raise SystemExit(main())
