"""Freeze the native eager U2 cancel/replace component on decode003 bytes."""

import argparse
import ast
import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
FAMILY = (
    ROOT
    / "openspec/changes/afd-hccl-full-parity/evidence"
    / "a3-dspark-native-live-prefix-20261115"
)
PARENT_LABEL = "prepared-decode-003"
PARENT_SHA = "cd3aaa11d6343cbcae0e765a3f4855ae61e9e7fd6bf6d28af777e44f2bce8ca8"
OLD_EAGER = (
    ROOT
    / "openspec/changes/afd-hccl-full-parity/evidence"
    / "a3-dspark-native-live-eager-streams-20261115/prepared-001/source.tar.gz"
)
OLD_EAGER_SHA = "54f751b957afff9246b2c9cfaee6b912542065957395a7b47a4ab3191445db90"
DRIVER = ".tmp/stage_dspark_live_prefix.py"
RECIPE = ".tmp/prepare_ready_eager_lifecycle.py"
PROOF = ".tmp/ready-eager-lifecycle-validation.json"
EXPECTED_DRIVER_SHA = "68499359dbc1476a92a5ea432bb7fd7ce18052aa49482aedc97a5fd957a0e2aa"
EXPECTED_PARENT_DRIVER_SHA = (
    "6f844db9ed761ca7dcfb406e9cb36fed6d92d25c82a0087792f4a74745102bc8"
)
PARENT_SOURCE_COUNT = 434
SOURCE_COUNT = 444
PRODUCTION_COUNT = 145
INSTALLED_COUNT = 191
HELPERS = (
    "tests/npu/hccl_native_attention_pd_dspark_cross_layer_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_eager_ffn_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_eager_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_graph_ffn_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_graph_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_lifecycle_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_overlap_probe.py",
    "tests/npu/hccl_native_attention_pd_dspark_u2_probe.py",
)
PROBE_FLAGS = (
    "--target-u2",
    "--target-cancel-replace",
    "--eager-stream-overlap",
    "--target-logits-policy",
    "constant7",
)
IDENTITIES = (
    "openspec/changes/afd-hccl-full-parity/evidence/"
    "eager-configuration-source-identity-20261113.json",
    ".tmp/native-pd-storage-extra-source-identity.json",
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_archive(path, expected):
    raw = path.read_bytes()
    assert sha(raw) == expected
    with tarfile.open(fileobj=io.BytesIO(raw)) as stream:
        entries = [entry for entry in stream if entry.isfile()]
        assert len({entry.name for entry in entries}) == len(entries)
        files = {entry.name: stream.extractfile(entry).read() for entry in entries}
    manifest = json.loads(files.pop("manifest.json"))
    assert {name: sha(raw) for name, raw in files.items()} == manifest
    return files, manifest


def check_cli():
    common = ["--native-build-root", "unused-native-build"]
    decode = ["--mode", "decode", "--eager-u2-lifecycle"]
    rejected = "Eager U2 lifecycle requires decode/constant7"
    frozen = "Eager U2 lifecycle requires a frozen source archive"
    cases = (
        ("help", ["--help"], 0, "--eager-u2-lifecycle"),
        ("live-prefix", ["--eager-u2-lifecycle"], 2, rejected),
        (
            "reject-policy",
            decode + ["--target-logits-policy", "reject-second-verification-row"],
            2,
            rejected,
        ),
        ("continuation", decode + ["--continue-after-rejection"], 2, rejected),
        ("ready-query", decode + ["--observe-ready-frontier"], 2, rejected),
        ("local-assembly", decode, 2, frozen),
        ("local-prepare-only", decode + ["--prepare-only"], 2, frozen),
        (
            "remote-live-prefix",
            ["--eager-u2-lifecycle", "--remote-root", "must-not-exist"],
            2,
            rejected,
        ),
    )
    records = []
    with tempfile.TemporaryDirectory(prefix="dspark-eager-cli-") as directory:
        for name, flags, status, fragment in cases:
            command = [
                sys.executable,
                "-X",
                "utf8",
                "-S",
                "-B",
                str(ROOT / DRIVER),
                *common,
                *flags,
            ]
            returned = subprocess.run(
                command,
                cwd=directory,
                capture_output=True,
                timeout=10,
                check=False,
            )
            output = (returned.stdout + returned.stderr).decode("utf-8")
            assert returned.returncode == status and fragment in output, (name, output)
            assert not list(Path(directory).iterdir())
            records.append(
                {
                    "name": name,
                    "flags": common + flags,
                    "returncode": returned.returncode,
                    "stdout": returned.stdout.decode("utf-8"),
                    "stderr": returned.stderr.decode("utf-8"),
                    "working_directory_unchanged": True,
                }
            )
    return records


def check_outer_gate(raw):
    """Execute only this harness's JSON gate with explicitly synthetic inputs."""
    tree = ast.parse(raw)
    constants = [
        node
        for node in tree.body
        if isinstance(node, ast.Assign)
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id.startswith("LIFECYCLE_")
    ]
    gate = next(
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Assign)
        and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id == "eager_lifecycle_valid"
    )
    program = compile(
        ast.Module(body=constants + [gate], type_ignores=[]), DRIVER, "exec"
    )
    native = {
        "target_graph_requested": False,
        "target_u2_requested": True,
        "target_cancel_replace_requested": True,
        "eager_stream_overlap_requested": True,
        "graph_compute_overlap_requested": False,
        "graph_all_axes_requested": False,
        "graph_exchange_order_requested": "stage_serial",
        "observe_ready_frontier_requested": False,
    }
    protocol = {
        "native_dspark_eager_stream_lifecycle_component_accepted": True,
        "native_dspark_request_lifecycle_component_accepted": True,
        "physical_overlap_accepted": False,
        "performance_accepted": False,
        "distinct_destination_requests": 3,
        "request_slot_reuse_observed": True,
        "physical_block_reuse_guaranteed": False,
        "actual_request_count": 2,
        "actual_query_rows_per_request": 3,
    }
    consumer = {
        "two_request_native_decode_accepted": True,
        "native_dspark_request_lifecycle_accepted": True,
        "native_dspark_request_lifecycle": {"accepted": True},
        "target_eager_decode": {"accepted": True},
    }
    cases = [("complete-component-report", None, None, None, True)]
    cases.extend(
        (
            ("graph-enabled", "native", "target_graph_requested", True, False),
            ("u2-disabled", "native", "target_u2_requested", False, False),
            (
                "component-not-accepted",
                "protocol",
                "native_dspark_eager_stream_lifecycle_component_accepted",
                False,
                False,
            ),
            ("bool-request-count", "protocol", "actual_request_count", True, False),
            (
                "physical-overlap-claim",
                "protocol",
                "physical_overlap_accepted",
                True,
                False,
            ),
            (
                "request-lifecycle-not-accepted",
                "consumer",
                "native_dspark_request_lifecycle_accepted",
                False,
                False,
            ),
            ("missing-eager-observation", "consumer", "target_eager_decode", {}, False),
        )
    )
    records = []
    for name, group, key, value, expected in cases:
        scope = {
            "args": SimpleNamespace(eager_u2_lifecycle=True),
            "native": copy.deepcopy(native),
            "consumer_protocol": copy.deepcopy(protocol),
            "consumer": copy.deepcopy(consumer),
        }
        if group:
            scope[
                {"native": "native", "protocol": "consumer_protocol"}.get(group, group)
            ][key] = value
        exec(program, scope)
        assert scope["eager_lifecycle_valid"] is expected
        records.append({"name": name, "accepted": expected})
    scope = {
        "args": SimpleNamespace(eager_u2_lifecycle=False),
        "native": {},
        "consumer_protocol": {},
        "consumer": {},
    }
    exec(program, scope)
    assert scope["eager_lifecycle_valid"] is True
    records.append({"name": "non-requested-default", "accepted": True})
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", default="prepared-eager-lifecycle-001")
    args = parser.parse_args()
    assert args.output and all(
        char in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in args.output
    )
    output = FAMILY / args.output
    assert not output.exists()
    parent_path = FAMILY / PARENT_LABEL / "source.tar.gz"
    files, previous = read_archive(parent_path, PARENT_SHA)
    old_eager, _ = read_archive(OLD_EAGER, OLD_EAGER_SHA)
    assert len(previous) == PARENT_SOURCE_COUNT
    assert previous[DRIVER] == EXPECTED_PARENT_DRIVER_SHA
    driver = (ROOT / DRIVER).read_bytes()
    assert sha(driver) == EXPECTED_DRIVER_SHA
    old_tree, new_tree = ast.parse(files[DRIVER]), ast.parse(driver)
    old_success, new_success = (
        next(
            node.value
            for node in ast.walk(tree)
            if isinstance(node, ast.Assign)
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "success"
        )
        for tree in (old_tree, new_tree)
    )
    new_success.values = [
        value
        for value in new_success.values
        if not isinstance(value, ast.Name) or value.id != "eager_lifecycle_valid"
    ]
    assert ast.dump(new_success) == ast.dump(old_success)
    files[DRIVER] = driver
    helpers = {}
    for name in HELPERS:
        current = (ROOT / name).read_bytes()
        assert current == old_eager[name]
        assert name not in previous
        files[name] = current
        helpers[name] = {"sha256": sha(current), "same_as_old_eager_archive": True}
    assert {name for name in previous if sha(files[name]) != previous[name]} == {DRIVER}
    compile(driver, DRIVER, "exec")
    for name in HELPERS:
        compile(files[name], name, "exec")
    cli = check_cli()
    gate = check_outer_gate(driver)
    proof = {
        "scope": "Stdlib harness CLI/JSON checks; no NPU, TE or native execution",
        "parent_archive_sha256": PARENT_SHA,
        "old_eager_archive_sha256": OLD_EAGER_SHA,
        "driver_sha256": sha(driver),
        "driver_parent_sha256": previous[DRIVER],
        "new_helper_identity": helpers,
        "probe_flags": list(PROBE_FLAGS),
        "cli": cli,
        "outer_gate_synthetic_json": gate,
        "device_test_executed": False,
        "ssh_executed": False,
        "runtime_imports_executed": False,
        "all_original_exit_cleanup_and_identity_gates_retained": True,
    }
    files[PROOF] = (json.dumps(proof, indent=2) + "\n").encode()
    files[RECIPE] = Path(__file__).read_bytes()
    manifest = {name: sha(raw) for name, raw in files.items()}
    assert len(manifest) == SOURCE_COUNT
    production = {
        name: digest
        for name, digest in manifest.items()
        if name.startswith("afd_plugin/") and name.endswith(".py")
    }
    assert len(production) == PRODUCTION_COUNT
    assert all(previous[name] == digest for name, digest in production.items())
    identities = {}
    for name in IDENTITIES:
        assert manifest[name] == previous[name]
        identities.update(json.loads(files[name])["source_expected"])
    assert len(identities) == INSTALLED_COUNT
    files["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
    buffer = io.BytesIO()
    with (
        gzip.GzipFile(fileobj=buffer, mode="wb", filename="", mtime=0) as compressed,
        tarfile.open(fileobj=compressed, mode="w") as stream,
    ):
        for name, raw in sorted(files.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw)
            stream.addfile(item, io.BytesIO(raw))
    archive = buffer.getvalue()
    preparation = json.loads((FAMILY / PARENT_LABEL / "preparation.json").read_bytes())
    preparation.update(
        archive_sha256=sha(archive),
        parent_archive_sha256=PARENT_SHA,
        parent_preparation=PARENT_LABEL,
        source_files=len(manifest),
        production_files=len(production),
        production_unchanged_from_decode003=True,
        driver_sha256=sha(driver),
        recipe_sha256=sha(files[RECIPE]),
        installed_sources_to_check=len(identities),
        installed_identity_inputs_unchanged_from_decode003=True,
        new_helpers=helpers,
        old_eager_archive_sha256=OLD_EAGER_SHA,
        eager_u2_lifecycle_supported=True,
        mode="decode",
        target_logits_policy="constant7",
        continue_after_rejection_requested=False,
        observe_ready_frontier_requested=False,
        eager_u2_lifecycle_requested=True,
        target_graph_requested=False,
        target_u2_requested=True,
        target_cancel_replace_requested=True,
        eager_stream_overlap_requested=True,
        graph_compute_overlap_requested=False,
        graph_all_axes_requested=False,
        graph_exchange_order_requested="stage_serial",
        physical_overlap_accepted=False,
        performance_accepted=False,
        device_test_executed=False,
        reason="Native eager U2 lifecycle: cancel A, finish B and load/execute C",
        scope=(
            "Prepared controlled target/FFN native N2/PD eager U2 component; "
            "physical overlap, performance, full model/Worker/serving pending"
        ),
    )
    output.mkdir()
    (output / "source.tar.gz").write_bytes(archive)
    (output / "preparation.json").write_text(json.dumps(preparation, indent=2) + "\n")
    (output / "source-review.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps(preparation, indent=2))


if __name__ == "__main__":
    main()
