"""Freeze or run the normal-Worker qualification CPU/EngineArgs capsule.

Preparation is local and stdlib-only. --execute-prepared is the explicit SSH
entry for the supervising root agent; it uploads the already frozen archive.
--remote-root runs CPU checks only, never --run-worker or model execution.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import importlib.util
import io
import json
import runpy
import shlex
import subprocess
import sys
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
EVIDENCE = "openspec/changes/afd-hccl-full-parity/evidence"
FAMILY = EVIDENCE + "/a3-text-normal-worker-20261116"
PARENT = (
    EVIDENCE
    + "/a3-text-u2-config-admission-20261116/engine-args-pd-green-001/source.tar.gz"
)
PARENT_SHA = "af0c18647dc8f25bb42a901ae40a74bb0f796f75ceef23dc6259ca50964cebdd"
PARENT_FEATURE_SHA = "943aec35a56dfd9e7256c3b33620937b5988ac6a30f6ffc1a6d1382362ed0897"
FEATURE = "afd_plugin/compat/npu/feature_validation.py"
TEST = "tests/unit/compat/npu/test_feature_validation.py"
FAKE = "tests/unit/fakes/vllm_config.py"
PROBE = "tests/npu/dsv41_normal_worker_probe.py"
DRIVER = ".tmp/run_text_normal_worker_cpu_a3.py"
BASE = (
    "openspec/changes/afd-hccl-v2-microbatch/evidence/"
    "a3-forward-counts-20261109/run_a3_forward_counts.py"
)
UPLOAD_HELPER = ".tmp/run_dspark_u2_admission_cpu_a3.py"
PINS = (
    EVIDENCE + "/eager-configuration-source-identity-20261113.json",
    ".tmp/native-pd-storage-extra-source-identity.json",
)
OVERLAY_IDENTITIES = (
    (FEATURE, "a8f2f49151a387fb2122231e06cad50582f93e68c1de827402e7db4ed37f2c5c"),
    (TEST, "fe1327e436d305c4d9769f5bb721230203d9b985831c4a799df58965f1a5e3f2"),
    (FAKE, "bac4abe8f54fb6e2608adb900dfdf1867e9c4f3fd0f68b658d6658e390a88529"),
    (PROBE, "aaccc0a461376a8bbbda533e684f3e37d158db42e38dbd4d15bce6c04529be35"),
)
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
REMOTE_PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
MODEL = "/mnt/workspace/models/DeepSeek-V4.1-Flash"
PARENT_FILES = 447
SOURCE_FILES = 449
PRODUCTION_FILES = 146
INSTALLED_IDENTITIES = 191
PYTEST_TIMEOUT_SECONDS = 180
CONFIG_TIMEOUT_SECONDS = 90
SSH_TIMEOUT_SECONDS = 460
MAX_TAR_BYTES = 32 * 1024 * 1024


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read_archive(raw: bytes) -> tuple[dict[str, bytes], dict[str, str]]:
    if len(raw) > MAX_TAR_BYTES:
        raise ValueError("source archive exceeds the bounded capsule size")
    files = {}
    total = 0
    with tarfile.open(fileobj=io.BytesIO(raw), mode="r:gz") as stream:
        for entry in stream:
            path = PurePosixPath(entry.name)
            if (
                not entry.isfile()
                or path.is_absolute()
                or str(path) != entry.name
                or ".." in path.parts
                or "\\" in entry.name
                or ":" in entry.name
                or entry.name in files
            ):
                raise ValueError("noncanonical, duplicate or non-file archive member")
            total += entry.size
            if total > MAX_TAR_BYTES:
                raise ValueError("expanded source archive exceeds the bounded size")
            files[entry.name] = stream.extractfile(entry).read()
    manifest = json.loads(files.pop("manifest.json"))
    if {name: sha(content) for name, content in files.items()} != manifest:
        raise ValueError("source archive does not match its exact manifest")
    return files, manifest


def archive_bytes(files: dict[str, bytes]) -> bytes:
    manifest = {name: sha(raw) for name, raw in sorted(files.items())}
    members = {
        **files,
        "manifest.json": (json.dumps(manifest, indent=2) + "\n").encode(),
    }
    output = io.BytesIO()
    with (
        gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as compressed,
        tarfile.open(fileobj=compressed, mode="w") as stream,
    ):
        for name, raw in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size = len(raw)
            item.mode = 0o644
            stream.addfile(item, io.BytesIO(raw))
    return output.getvalue()


def source_pins(files: dict[str, bytes]) -> dict[str, str]:
    expected = {}
    for name in PINS:
        for path, digest in json.loads(files[name])["source_expected"].items():
            if path in expected and expected[path] != digest:
                raise ValueError("conflicting installed native source pins")
            expected[path] = digest
    if len(expected) != INSTALLED_IDENTITIES:
        raise ValueError("installed source identity count changed")
    return expected


def prepare(args: argparse.Namespace) -> None:
    parent_raw = (ROOT / PARENT).read_bytes()
    assert sha(parent_raw) == PARENT_SHA
    parent, parent_manifest = read_archive(parent_raw)
    assert len(parent) == PARENT_FILES
    assert sha(parent[FEATURE]) == PARENT_FEATURE_SHA
    files = dict(parent)
    for name, digest in OVERLAY_IDENTITIES:
        raw = (ROOT / name).read_bytes()
        assert sha(raw) == digest, name
        if name != FEATURE or args.green:
            files[name] = raw
    files[DRIVER] = Path(__file__).read_bytes()
    assert len(files) == SOURCE_FILES
    production = {name for name in files if name.startswith("afd_plugin/")}
    assert len(production) == PRODUCTION_FILES
    assert all(files[name] == parent[name] for name in production if name != FEATURE)
    assert args.green or files[FEATURE] == parent[FEATURE]
    python_files = [name for name in files if name.endswith(".py")]
    for name in python_files:
        compile(files[name], name, "exec")
    pins = source_pins(files)
    for name in PINS:
        assert files[name] == parent[name]
    archive = archive_bytes(files)
    frozen, manifest = read_archive(archive)
    assert frozen == files
    output = ROOT / FAMILY / args.label
    output.mkdir(parents=True, exist_ok=False)
    (output / "source.tar.gz").write_bytes(archive)
    (output / "runner.py").write_bytes(files[DRIVER])
    expected = {
        "green": args.green,
        "source_archive_sha256": sha(archive),
        "parent_archive_sha256": PARENT_SHA,
        "source_files": len(files),
        "production_files": len(production),
        "other_production_byte_equal_parent": len(production) - 1,
        "python_files_compiled": len(python_files),
        "installed_source_identities": len(pins),
        "installed_pin_inputs_unchanged": True,
        "feature_sha256": manifest[FEATURE],
        "changed_from_parent": sorted(
            name for name in parent if files[name] != parent[name]
        ),
        "added_to_parent": sorted(set(files) - set(parent)),
        "source_manifest_sha256": sha((json.dumps(manifest, indent=2) + "\n").encode()),
        "overlay_sha256": {name: manifest[name] for name, _ in OVERLAY_IDENTITIES},
        "driver_sha256": manifest[DRIVER],
        "test_selection": [TEST],
        "engine_args_roles": ["attention", "ffn"],
        "native_tests_executed": False,
        "ssh_executed": False,
        "npu_executed": False,
        "scope": (
            "Preparation only; same final tests/fake/probe; no worker init or inference"
        ),
    }
    (output / "preparation.json").write_text(
        json.dumps(expected, indent=2) + "\n", "utf-8"
    )
    (output / "proof.json").write_text(
        json.dumps(
            {
                "manifest": manifest,
                "native191": pins,
                "parent_manifest": parent_manifest,
            },
            indent=2,
        )
        + "\n",
        "utf-8",
    )
    print(json.dumps(expected, indent=2))


def native_child(args: argparse.Namespace) -> int:
    # This branch is reached only by the remote driver's explicit native venv.
    import torch
    import torch_npu  # noqa: F401

    root = args.remote_root
    snapshot, results = root / "snapshot", root / "results"
    before = torch.npu.is_initialized()
    code = 1
    try:
        if args.native_child == "pytest":
            import pytest

            code = int(
                pytest.main(
                    [
                        TEST,
                        "-o",
                        "addopts=",
                        "-q",
                        "-ra",
                        "--tb=short",
                        "-p",
                        "no:cacheprovider",
                        "--disable-warnings",
                        "--junitxml=" + str(results / "junit.xml"),
                    ]
                )
            )
        else:
            sys.argv = [
                str(snapshot / PROBE),
                "--run-config",
                "--model",
                args.model,
                "--output-dir",
                str(results / args.role),
                "--role",
                args.role,
            ]
            try:
                runpy.run_path(str(snapshot / PROBE), run_name="__main__")
                code = 0
            except SystemExit as error:
                code = error.code
    finally:
        after = torch.npu.is_initialized()
        label = "pytest" if args.native_child == "pytest" else args.role
        (results / (label + "-native-state.json")).write_text(
            json.dumps(
                {
                    "npu_initialized_before": before,
                    "npu_initialized_after": after,
                    "returncode": code,
                },
                indent=2,
            )
            + "\n",
            "utf-8",
        )
    return code if code else int(before or after)


def run_child(
    command: list[str],
    *,
    snapshot: Path,
    environment: dict[str, str],
    timeout: int,
    log: Path,
) -> dict:
    timed_out = False
    try:
        process = subprocess.run(
            command, cwd=snapshot, env=environment, capture_output=True, timeout=timeout
        )
        code, raw = process.returncode, process.stdout + process.stderr
    except subprocess.TimeoutExpired as error:
        code, timed_out = None, True
        raw = (error.stdout or b"") + (error.stderr or b"")
    log.write_bytes(raw)
    return {"command": command, "returncode": code, "timed_out": timed_out}


def run_remote(args: argparse.Namespace) -> int:
    root = args.remote_root.resolve()
    archive = (root / "source.tar.gz").read_bytes()
    files, manifest = read_archive(archive)
    assert len(files) == SOURCE_FILES
    preparation = json.loads((root / "preparation.json").read_text())
    assert sha(archive) == preparation["source_archive_sha256"]
    assert manifest[FEATURE] == (
        dict(OVERLAY_IDENTITIES)[FEATURE]
        if preparation["green"]
        else PARENT_FEATURE_SHA
    )
    snapshot, results = root / "snapshot", root / "results"
    snapshot.mkdir()
    results.mkdir()
    for name, raw in files.items():
        destination = snapshot / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(raw)
    (snapshot / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    expected = source_pins(files)
    # A venv's python can be a symlink to the base interpreter. Keep the
    # requested venv path when locating its installed dependency identities.
    site = Path(args.python).parent.parent / "lib/python3.12/site-packages"

    def installed_hashes():
        return {name: sha((site / name).read_bytes()) for name in expected}

    before = installed_hashes()
    (results / "native-before.json").write_text(json.dumps(before, indent=2) + "\n")
    assert before == expected
    spec = importlib.util.spec_from_file_location(
        "normal_worker_cpu_environment", snapshot / BASE
    )
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    environment = base.prepare_env(snapshot)
    environment["AFD_DSV41_DUMMY_QUALIFICATION"] = "1"
    environment["AFD_DSV41_EAGER_QUALIFICATION"] = "0"
    environment["AFD_ASYNC_CAM_LAYERED_GMM"] = "0"
    environment["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    common = [
        args.python,
        "-B",
        str(snapshot / DRIVER),
        "--remote-root",
        str(root),
        "--model",
        args.model,
    ]
    pytest_run = run_child(
        [*common, "--native-child", "pytest"],
        snapshot=snapshot,
        environment=environment,
        timeout=PYTEST_TIMEOUT_SECONDS,
        log=results / "pytest.log",
    )
    cases = []
    junit = {"tests": 0, "failures": 0, "errors": 0, "skipped": 0}
    if (results / "junit.xml").is_file():
        for case in ET.parse(results / "junit.xml").iter("testcase"):
            junit["tests"] += 1
            failed = case.find("failure") is not None
            cases.append({"name": case.attrib["name"], "failed": failed})
            for name, tag in (
                ("failures", "failure"),
                ("errors", "error"),
                ("skipped", "skipped"),
            ):
                junit[name] += case.find(tag) is not None
    roles = []
    for role in ("attention", "ffn"):
        run = run_child(
            [*common, "--native-child", "config", "--role", role],
            snapshot=snapshot,
            environment=environment,
            timeout=CONFIG_TIMEOUT_SECONDS,
            log=results / (role + ".log"),
        )
        path = results / role / "result.json"
        run.update(
            role=role, report=json.loads(path.read_text()) if path.is_file() else None
        )
        roles.append(run)
    states = {}
    for label in ("pytest", "attention", "ffn"):
        path = results / (label + "-native-state.json")
        states[label] = json.loads(path.read_text()) if path.is_file() else None
    after = installed_hashes()
    snapshot_after = {name: sha((snapshot / name).read_bytes()) for name in manifest}
    (results / "native-after.json").write_text(json.dumps(after, indent=2) + "\n")
    (results / "source-after.json").write_text(
        json.dumps(snapshot_after, indent=2) + "\n"
    )
    identities_ok = before == after == expected and snapshot_after == manifest
    host_only = all(
        state is not None
        and state["npu_initialized_before"] is False
        and state["npu_initialized_after"] is False
        for state in states.values()
    )
    zero_skips = junit["tests"] > 0 and junit["skipped"] == junit["errors"] == 0
    no_timeout = not any(run["timed_out"] for run in [pytest_run, *roles])
    green = preparation["green"]
    if green:
        pytest_ok = pytest_run["returncode"] == 0 and junit["failures"] == 0
        roles_ok = all(
            run["returncode"] == 0
            and run["report"] is not None
            and run["report"]["success"] is True
            and run["report"].get("dummy_qualification_accepted") is True
            and run["report"]["run_config"] is True
            and run["report"]["run_worker"] is False
            and run["report"]["inference_executed"] is False
            for run in roles
        )
    else:
        failures = [case["name"] for case in cases if case["failed"]]
        positive_failures = [
            name
            for name in failures
            if name.startswith(
                "test_v41_dummy_qualification_preserves_normal_worker_config["
            )
        ]
        pytest_ok = (
            pytest_run["returncode"] == 1
            and len(positive_failures) == 8
            and failures
            and all(
                name.startswith(
                    (
                        "test_v41_dummy_",
                        "test_v41_qualification_candidates_are_mutually_exclusive",
                    )
                )
                for name in failures
            )
        )
        roles_ok = all(
            run["returncode"] == 1
            and run["report"] is not None
            and run["report"]["success"] is False
            and "DeepSeek V4.1 NPU AFD is not available"
            in run["report"].get("traceback", "")
            and run["report"].get("configuration", {}).get("load_format") == "dummy"
            for run in roles
        )
    accepted = bool(
        identities_ok
        and host_only
        and zero_skips
        and no_timeout
        and pytest_ok
        and roles_ok
    )
    summary = {
        "green": green,
        "validation_passed": accepted,
        "expected_red_rejection_observed": accepted if not green else False,
        "native_gate_tests_passed": accepted if green else False,
        "source_archive_sha256": sha(archive),
        "source_files": len(manifest),
        "production_files": sum(name.startswith("afd_plugin/") for name in manifest),
        "installed_source_identities": len(expected),
        "identities_unchanged": identities_ok,
        "junit": junit,
        "zero_skips": zero_skips,
        "pytest": pytest_run,
        "engine_args_runs": roles,
        "native_state": states,
        "npu_initialized_before_after_false": host_only,
        "timed_out": not no_timeout,
        "worker_init_executed": False,
        "model_loaded": False,
        "inference_executed": False,
        "scope": (
            "Real native CPU gate and two first EngineArgs constructions; "
            "no Worker init or NPU execution"
        ),
    }
    (results / "summary.json").write_text(json.dumps(summary, indent=2) + "\n", "utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if accepted else 1


def execute_prepared(args: argparse.Namespace) -> int:
    prepared = args.execute_prepared.resolve()
    raw = (prepared / "source.tar.gz").read_bytes()
    files, _ = read_archive(raw)
    record = json.loads((prepared / "preparation.json").read_text())
    assert sha(raw) == record["source_archive_sha256"]
    for label, path in (
        ("normal_worker_upload", ROOT / UPLOAD_HELPER),
        ("normal_worker_ssh", ROOT / BASE),
    ):
        spec = importlib.util.spec_from_file_location(label, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        if label == "normal_worker_upload":
            uploader = module
        else:
            base = module
    # Freeze the transport helpers used by this explicit execution separately;
    # the runtime capsule itself is never rebuilt from current live source.
    (prepared / "execute-transport-sources.json").write_text(
        json.dumps(
            {
                UPLOAD_HELPER: sha((ROOT / UPLOAD_HELPER).read_bytes()),
                BASE: sha((ROOT / BASE).read_bytes()),
            },
            indent=2,
        )
        + "\n"
    )
    make_remote = (
        "import tempfile;print(tempfile.mkdtemp("
        "prefix='text-normal-worker-20261116-',dir=" + repr(REMOTE_PARENT) + "))"
    )
    remote = base.ssh("python3 -c " + shlex.quote(make_remote)).decode().strip()
    (prepared / "identity.json").write_text(
        json.dumps({"remote_root": remote, "source_archive_sha256": sha(raw)}, indent=2)
        + "\n"
    )
    uploader.upload_source(base, remote, raw, prepared)
    inputs = {
        "runner.py": files[DRIVER],
        "preparation.json": (prepared / "preparation.json").read_bytes(),
    }
    script = (
        "import json,pathlib,sys; root=pathlib.Path("
        + repr(remote)
        + "); inputs=json.loads(sys.stdin.buffer.read()); "
        "[(root/name).write_bytes(bytes.fromhex(data)) "
        "for name,data in inputs.items()]"
    )
    base.ssh(
        "python3 -c " + shlex.quote(script),
        json.dumps({name: data.hex() for name, data in inputs.items()}).encode(),
    )
    command = (
        "python3 "
        + shlex.quote(remote + "/runner.py")
        + " --remote-root "
        + shlex.quote(remote)
        + " --model "
        + shlex.quote(args.model)
        + " --python "
        + shlex.quote(args.python)
    )
    completed = subprocess.run(
        [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=15",
            base.SSH_HOST,
            command,
        ],
        capture_output=True,
        timeout=SSH_TIMEOUT_SECONDS,
    )
    (prepared / "remote-output.log").write_bytes(completed.stdout + completed.stderr)
    result = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
    (prepared / "results.tar.gz").write_bytes(result)
    with tarfile.open(fileobj=io.BytesIO(result)) as stream:
        summary = json.load(stream.extractfile("results/summary.json"))
    (prepared / "summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", "utf-8"
    )
    print(json.dumps(summary, indent=2))
    return (
        0 if completed.returncode == 0 and summary["validation_passed"] is True else 1
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--remote-root", type=Path)
    modes.add_argument("--execute-prepared", type=Path)
    parser.add_argument("--label")
    parser.add_argument("--green", action="store_true")
    parser.add_argument("--model", default=MODEL)
    parser.add_argument("--python", default=VENV + "/bin/python")
    parser.add_argument(
        "--native-child", choices=("pytest", "config"), help=argparse.SUPPRESS
    )
    parser.add_argument("--role", choices=("attention", "ffn"), help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.prepare_only and (
        not args.label
        or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.label)
    ):
        parser.error("--prepare-only requires a lowercase safe --label")
    if not args.prepare_only and (args.label is not None or args.green):
        parser.error("--label/--green belong only to local --prepare-only")
    if args.native_child and (
        args.remote_root is None
        or (args.native_child == "config" and args.role is None)
    ):
        parser.error(
            "native children require --remote-root and config children require --role"
        )
    if args.native_child:
        return native_child(args)
    if args.prepare_only:
        prepare(args)
        return 0
    if args.execute_prepared is not None:
        return execute_prepared(args)
    return run_remote(args)


if __name__ == "__main__":
    raise SystemExit(main())
