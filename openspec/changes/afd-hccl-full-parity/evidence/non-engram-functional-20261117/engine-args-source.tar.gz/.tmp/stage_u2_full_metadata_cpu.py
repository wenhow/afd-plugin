"""Freeze native V4.1 compressed-cache metadata at the U2 prepare seam."""

import argparse
import hashlib
import importlib.util
import io
import json
import shlex
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = "openspec/changes/afd-hccl-v2-microbatch/evidence/a3-forward-counts-20261109/run_a3_forward_counts.py"
IDENTITY = "openspec/changes/afd-hccl-full-parity/evidence/eager-configuration-source-identity-20261113.json"
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-u2-full-metadata-cpu-20261114"
BASELINE = "openspec/changes/afd-hccl-full-parity/evidence/a3-pd-consumer-graph-cpu-20261114/whole-001/source.tar.gz"
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
DRIVER = ".tmp/stage_u2_full_metadata_cpu.py"
CONFIG_TESTS = ("tests/unit/v1/worker/npu/test_hccl_v41_ubatch_runner.py",)
CONFIG_FIXTURE = "tests/unit/fakes/hccl_v41_ubatch.py"
COMPONENT_TESTS = (
    "tests/unit/fakes/kv_connector.py",
    "tests/unit/v1/worker/npu/test_attention_model_runner_v2.py",
    "tests/unit/fakes/kv_layout_connector.py",
    "tests/unit/fakes/scheduler.py",
)
PRODUCTION = ("afd_plugin/v1/worker/npu/ubatch_runner.py",)
WHOLE_MODULES = (
    "tests/unit/v1/worker/npu/test_attention_model_runner_v2.py",
    "tests/unit/compat/npu/test_dspark_pd.py",
    "tests/unit/compat/npu/test_kv_layout_connector.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_staged.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_stage_state.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_graph.py",
    "tests/unit/v1/worker/npu/test_hccl_v41_ubatch_runner.py",
    "tests/unit/v1/worker/npu/test_hccl_v41_execution.py",
    "tests/unit/v1/worker/npu/test_attention_worker.py",
    "tests/unit/v1/worker/npu/test_hccl_v41_graph_coordinator.py",
    "tests/unit/compat/npu/test_runtime_config.py",
    "tests/unit/connectors/npu/test_hccl_staged.py",
    "tests/unit/v1/worker/test_npu_model_runner_v2.py",
    "tests/unit/v1/worker/test_npu_ubatch_outputs.py",
)
SIGNATURE = "tests/unit/compat/patches/test_signatures.py::test_scoped_patch_preserves_upstream_signature"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_environment(root):
    spec = importlib.util.spec_from_file_location("pd_graph_source_environment", root / BASE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


parser = argparse.ArgumentParser()
parser.add_argument("--label")
parser.add_argument("--baseline")
parser.add_argument("--green", action="store_true")
parser.add_argument("--component", action="store_true")
parser.add_argument("--suite", choices=("config", "execution", "whole"), default="config")
parser.add_argument("--remote-root", type=Path)
args = parser.parse_args()
if args.remote_root:
    remote = args.remote_root
    snapshot, results = remote / "snapshot", remote / "results"
    snapshot.mkdir()
    results.mkdir()
    with tarfile.open(remote / "source.tar.gz") as stream:
        stream.extractall(snapshot, filter="data")
    manifest = json.loads((snapshot / "manifest.json").read_text())
    assert all(sha((snapshot / name).read_bytes()) == digest for name, digest in manifest.items())
    expected = json.loads((snapshot / IDENTITY).read_text())["source_expected"]
    site = Path(VENV) / "lib/python3.12/site-packages"
    checks = {name: sha((site / name).read_bytes()) == digest for name, digest in expected.items()}
    (results / "source-check.json").write_text(json.dumps(checks, indent=2) + "\n")
    assert all(checks.values())
    if args.suite == "whole":
        modules = (*WHOLE_MODULES, *(SIGNATURE + "[" + hook + "]" for hook in (
            "pd-native-source-retirement", "pd-scheduler-new-request", "dspark-pd-sampling", "attention-shutdown")))
    elif args.suite == "config":
        modules = CONFIG_TESTS
    else:
        modules = (COMPONENT_TESTS[1],)
    command = [VENV + "/bin/python", "-B", "-m", "pytest", *modules, "-q", "-ra",
               "--disable-warnings", "--junitxml=" + str(results / "junit.xml")]
    if args.suite != "whole":
        command.extend(["-k", "u2_compressed_metadata_keeps_native_full_graph_bounds"])
    run = subprocess.run(command, env=load_environment(snapshot).prepare_env(snapshot),
                         cwd=snapshot, capture_output=True, timeout=180)
    (results / "pytest.log").write_bytes(run.stdout + run.stderr)
    (results / "summary.json").write_text(json.dumps({
        "scope": "Real native V4.1 compressed metadata through U2 prepare on CPU; no NPU, capture/replay, or model qualification",
        "suite": args.suite, "command": command, "returncode": run.returncode,
        "source_files_checked": len(checks), "source_files_match": all(checks.values()),
    }, indent=2) + "\n")
    print(run.stdout.decode(errors="replace"))
    print(run.stderr.decode(errors="replace"))
    raise SystemExit(run.returncode)

for label in (args.label, args.baseline):
    if label is not None and (not label or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in label)):
        parser.error("invalid label")
if not args.label:
    parser.error("label required")
destination = ROOT / FAMILY / args.label
destination.mkdir(parents=True, exist_ok=False)
previous = ROOT / (FAMILY + "/" + args.baseline + "/source.tar.gz" if args.baseline else BASELINE)
with tarfile.open(previous) as stream:
    contents = {entry.name: stream.extractfile(entry).read() for entry in stream
                if entry.isfile() and entry.name != "manifest.json"}
overlays = PRODUCTION if args.green else COMPONENT_TESTS if args.component else (*CONFIG_TESTS, CONFIG_FIXTURE)
for name in overlays:
    contents[name] = (ROOT / name).read_bytes()
contents[DRIVER] = Path(__file__).read_bytes()
manifest = {name: sha(raw) for name, raw in contents.items()}
contents["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:gz") as stream:
    for name, raw in contents.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(raw)
        stream.addfile(entry, io.BytesIO(raw))
payload = buffer.getvalue()
(destination / "source.tar.gz").write_bytes(payload)
base = load_environment(ROOT)
remote = base.ssh("python3 -c " + shlex.quote(
    "import tempfile;print(tempfile.mkdtemp(prefix='u2-full-metadata-cpu-20261114-',dir=" + repr(PARENT) + "))"
)).decode().strip()
(destination / "identity.json").write_text(json.dumps({
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
    "remote": remote, "archive_sha256": sha(payload), "manifest": manifest,
    "baseline": str(previous.relative_to(ROOT)), "overlays": list(overlays),
    "scope": "Frozen PDGraph whole001 source closure and explicit metadata overlays; paused local MTP excluded",
}, indent=2) + "\n", encoding="utf-8")
base.ssh("cat > " + shlex.quote(remote + "/source.tar.gz"), payload)
base.ssh("cat > " + shlex.quote(remote + "/stage_u2_full_metadata_cpu.py"), Path(__file__).read_bytes())
command = "python3 -B " + shlex.quote(remote + "/stage_u2_full_metadata_cpu.py") + " --remote-root " + shlex.quote(remote) + " --suite " + args.suite
run = subprocess.run(["ssh", "-F", base.SSH_CONFIG, "-o", "BatchMode=yes", base.SSH_HOST, command], capture_output=True, timeout=240)
(destination / "remote.log").write_bytes(run.stdout + run.stderr)
result = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
(destination / "results.tar.gz").write_bytes(result)
short = ROOT / ".tmp" / ("pdgraph-" + args.label)
short.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(result)) as stream:
    stream.extractall(short, filter="data")
(destination / "collection.json").write_text(json.dumps({
    "archive_sha256": sha(result), "returncode": run.returncode, "short_extraction": str(short),
}, indent=2) + "\n", encoding="utf-8")
print(run.stdout.decode(errors="replace"))
print(run.stderr.decode(errors="replace"))
raise SystemExit(run.returncode)
