"""Prepare or explicitly run the normal native C2 Scheduler successor.

Local preparation preserves all 455 accepted C2 sources and 146 production
modules. Only this driver, the execute probe and an explicit successor native
environment descriptor are added. Runtime retains the actual native Scheduler,
model, Attention, HC, compressed KV, remote MoE and sampler. No output IDs are
fixed; no native-baseline parity is claimed.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
import json
import os
import shlex
import struct
import subprocess
import sys
import tarfile
import time
import traceback
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
FAMILY = "openspec/changes/afd-hccl-full-parity/evidence/a3-text-normal-worker-20261116"
PARENT = FAMILY + "/prepared-c2-001/source.tar.gz"
PARENT_SHA = "bc6a9191897736e07a917309cbda97d6f6dc5c2c591fd5539f9404cae243b51a"
PREREQUISITES = (
    ("host-cpu-001", "host_cpu_accepted"),
    ("device-001", "native_c2_kv_component_accepted"),
)
DEVICE_DRIVER = ".tmp/run_text_normal_worker_device_a3.py"
DEVICE_DRIVER_SHA = "7e1261d24850df592f8160602f6433c825f1d070e8e456dbc8a3c291b3add60b"
CPU_DRIVER = ".tmp/run_text_normal_worker_cpu_a3.py"
DRIVER = ".tmp/run_text_normal_execute_a3.py"
PROBE = "tests/npu/dsv41_normal_execute_probe.py"
ENVIRONMENT_RECORD = ".tmp/normal-execute-environment.json"
PRODUCTION_FILES = 146
PARENT_SOURCE_FILES = 455
SOURCE_FILES = 458
INSTALLED_IDENTITIES = 197
ADDITIONAL_NATIVE_PINS = (
    (
        "vllm/v1/worker/worker_base.py",
        "4a1a5266b912fe97991d8dc89d92b923990da9f6cb4b817d00d52e9c0d26dd7c",
    ),
    (
        "vllm/multimodal/encoder_budget.py",
        "f27dcb17d35701eb78b226db91f6779344dec3055de3d452ea34f9ec46355987",
    ),
    (
        "vllm/models/deepseek_v41/common/mm_preprocess.py",
        "91f66f0c84f55709c10f16127b486a8af0e5f291efe08b46d617830eed3e8cab",
    ),
    (
        "vllm/multimodal/processing/context.py",
        "29abda6ef64c1feb339bbce2e7d0bceda8fbfc59388f0703198f8d7307733875",
    ),
    (
        "vllm/tokenizers/registry.py",
        "077f11649db9c6e086eeb60f9dd81ed5667cadd83a29e66a0870c1ed5b1680a5",
    ),
    (
        "vllm/config/multimodal.py",
        "271911aee151f17f092228cecee82af0713e9a47340ffdf66834ca7638a50d22",
    ),
)
DEFAULT_PAIR_TIMEOUT_SECONDS = 360
SSH_TIMEOUT_SECONDS = 780
POLL_SECONDS = 0.2
REAP_SECONDS = 10
DEFAULT_AFD_PORT = 30010
ATTENTION_KV_BUDGET_BYTES = 8 * 1024 * 1024
ATTENTION_CACHE_LAYERS = 6
PROMPT_TOKEN_IDS = (11, 12, 13, 14)
REQUEST_ID = "normal-c2-first-request"
REQUIRED_CUSTOM_SYMBOLS = (
    "aclnnVllmAscendQuantLightningIndexerV2",
    "aclnnVllmAscendQuantLightningIndexerV2GetWorkspaceSize",
)
DIRECT_LIBRARY_RELATIVE_PATHS = (
    "vllm_ascend/lib/libvllm_ascend_kernels.so",
    "vllm_ascend/libvllm_ascend_kernels.so",
)
EXTENSION_RELATIVE_PATH = "vllm_ascend/vllm_ascend_C.cpython-312-aarch64-linux-gnu.so"
ASCEND_REVISION = "7e37e29a7803d6897a7113088e2b771f83205bc0"


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", "utf-8")


def validate_environment_record(record, previous, previous_sha):
    # Preparation validates a completed descriptor's immutable relationships.
    # Only runtime checks the actual remote bytes, before importing the model.
    assert record["previous_environment_record_sha256"] == previous_sha
    assert record["toolchain_artifacts"] == previous["toolchain_artifacts"]
    assert len(record["selected_ops"]) == 11
    assert set(record["selected_ops"]) == (
        set(previous["active_record"]["selected_ops"]) | {"quant_lightning_indexer_v2"}
    )
    paths, old_paths = record["paths"], previous["paths"]
    for key in (
        "python",
        "cann_setup",
        "cann_home",
        "atb_setup",
        "atb_home",
        "parent_root",
    ):
        assert paths[key] == old_paths[key], key
    assert paths["previous_active_root"] == old_paths["active_root"]
    assert paths["parent_record"] == old_paths["parent_record"]
    for key in (
        "python",
        "cann_setup",
        "cann_home",
        "atb_setup",
        "atb_home",
        "parent_root",
        "previous_active_root",
        "active_root",
        "active_package",
        "active_vendor",
        "active_record",
    ):
        value = paths[key]
        path = PurePosixPath(value)
        assert path.is_absolute() and path.as_posix() == value
        assert ".." not in path.parts and not any(c in value for c in "\\\n\r\0:")
    active = PurePosixPath(paths["active_root"])
    assert active not in (
        PurePosixPath(paths["parent_root"]),
        PurePosixPath(paths["previous_active_root"]),
    )
    for key in ("parent_root", "previous_active_root"):
        assert not active.is_relative_to(PurePosixPath(paths[key]))
        assert not PurePosixPath(paths[key]).is_relative_to(active)
    assert paths["active_package"] == str(active / "package")
    assert paths["active_vendor"] == str(
        active / "package/vllm_ascend/_cann_ops_custom/vendors/custom_transformer"
    )
    assert PurePosixPath(paths["active_record"]).is_relative_to(active)
    assert record["parent_record_sha256"] == previous["parent_record_sha256"]
    artifacts = record["active_artifacts"]
    assert (
        artifacts
        and artifacts[paths["active_record"]] == record["active_record_sha256"]
    )
    for name, digest in artifacts.items():
        path = PurePosixPath(name)
        assert path.as_posix() == name and ".." not in path.parts
        assert path.is_relative_to(active)
        assert len(digest) == 64 and all(c in "0123456789abcdef" for c in digest)
    old_package = PurePosixPath(old_paths["active_package"])
    for name, digest in previous["active_artifacts"].items():
        path = PurePosixPath(name)
        if path.is_relative_to(old_package):
            relative = path.relative_to(old_package)
            if "_cann_ops_custom" not in relative.parts:
                new_name = str(PurePosixPath(paths["active_package"]) / relative)
                assert artifacts[new_name] == digest
    libraries = record["expected_native_library_sha256"]
    assert libraries and all(
        artifacts[name] == digest for name, digest in libraries.items()
    )
    direct_sha = record["expected_direct_library_sha256"]
    for relative in DIRECT_LIBRARY_RELATIVE_PATHS:
        name = str(PurePosixPath(paths["active_package"]) / relative)
        old_name = str(PurePosixPath(old_paths["active_package"]) / relative)
        assert artifacts[name] == libraries[name] == direct_sha
        assert direct_sha == previous["expected_native_library_sha256"][old_name]
    extension = str(PurePosixPath(paths["active_package"]) / EXTENSION_RELATIVE_PATH)
    old_extension = str(
        PurePosixPath(old_paths["active_package"]) / EXTENSION_RELATIVE_PATH
    )
    assert (
        libraries[extension]
        == previous["expected_native_library_sha256"][old_extension]
    )
    evidence = record["required_custom_symbols_evidence"]
    assert tuple(evidence["required_symbols"]) == REQUIRED_CUSTOM_SYMBOLS
    assert evidence["missing_symbols"] == []
    evidence_path = PurePosixPath(evidence["path"])
    assert evidence_path.as_posix() == evidence["path"]
    assert evidence_path.is_relative_to(active) and ".." not in evidence_path.parts
    digest = evidence["sha256"]
    assert len(digest) == 64 and all(c in "0123456789abcdef" for c in digest)
    if evidence["path"] in artifacts:
        assert artifacts[evidence["path"]] == digest
    assert record["build_completed"] is True
    assert record["runtime_extension_loaded"] is False


def selected_environment(snapshot, owned, record):
    # Same complete CANN9.2/ATB startup as the accepted C2 capsule, with explicit
    # successor paths. No imported module globals or old records are rewritten.
    paths = record["paths"]
    excluded = (
        paths["parent_root"],
        paths["previous_active_root"],
        paths["active_root"],
    )
    inherited = os.environ.copy()
    for key in ("PATH", "LD_LIBRARY_PATH", "PYTHONPATH"):
        inherited[key] = ":".join(
            value
            for value in inherited.get(key, "").split(":")
            if value
            and not value.startswith(("/mnt/workspace/code/.ascend/cann-", *excluded))
        )
    for key in (
        "ASCEND_HOME_PATH",
        "ASCEND_OPP_PATH",
        "ASCEND_AICPU_PATH",
        "ASCEND_TOOLKIT_HOME",
        "TBE_IMPL_PATH",
        "ASCEND_CUSTOM_OPP_PATH",
    ):
        inherited.pop(key, None)
    inherited["ASCEND_SLOG_PRINT_TO_STDOUT"] = "0"
    script = (
        "set -e\nsource " + shlex.quote(paths["cann_setup"]) + " >/dev/null\n"
        "export LD_LIBRARY_PATH=/opt/buildtools/python-3.12.9/lib:"
        "/usr/local/Ascend/driver/lib64/driver:"
        "/usr/local/Ascend/driver/lib64/common:${LD_LIBRARY_PATH}\n"
        "export PATH="
        + shlex.quote(str(PurePosixPath(paths["python"]).parent))
        + ":${PATH}\nsource "
        + shlex.quote(paths["atb_setup"])
        + " >/dev/null\nenv -0\n"
    )
    prepared = subprocess.run(
        ["bash", "-c", script],
        env=inherited,
        capture_output=True,
        timeout=30,
        check=True,
    )
    env = {
        key.decode(): value.decode()
        for field in prepared.stdout.split(b"\0")
        if field
        for key, value in [field.split(b"=", 1)]
    }
    assert Path(env["ASCEND_HOME_PATH"]).resolve() == Path(paths["cann_home"])
    assert Path(env["ATB_HOME_PATH"]).resolve() == Path(paths["atb_home"])
    for key in ("PYTHONPATH", "LD_LIBRARY_PATH", "PATH"):
        env[key] = ":".join(
            value
            for value in env.get(key, "").split(":")
            if value and not value.startswith(excluded)
        )
        assert all("/cann-9.0.1/" not in value for value in env[key].split(":"))
    env["PYTHONPATH"] = ":".join(
        (
            str(snapshot),
            paths["active_package"],
            *(
                value
                for value in env["PYTHONPATH"].split(":")
                if value != str(snapshot)
            ),
        )
    )
    env["LD_LIBRARY_PATH"] = (
        paths["active_vendor"]
        + "/op_api/lib:"
        + paths["active_package"]
        + "/vllm_ascend:"
        + env["LD_LIBRARY_PATH"]
    )
    env["ASCEND_CUSTOM_OPP_PATH"] = paths["active_vendor"]
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["VLLM_USE_V2_MODEL_RUNNER"] = "1"
    env["VLLM_PLUGINS"] = (
        "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,"
        "ascend_service_profiling"
    )
    for key in ("PYTHONPATH", "LD_LIBRARY_PATH", "PATH", "ASCEND_CUSTOM_OPP_PATH"):
        assert all(not value.startswith(excluded[:2]) for value in env[key].split(":"))
    env["AFD_DSV41_DUMMY_QUALIFICATION"] = "1"
    env["AFD_DSV41_EAGER_QUALIFICATION"] = "0"
    env["AFD_ASYNC_CAM_LAYERED_GMM"] = "0"
    # Diagnostic successor: locate the actual asynchronous metadata failure.
    # This changes launch synchronization only, never native operator inputs.
    env["ASCEND_LAUNCH_BLOCKING"] = "1"
    # Keep the native inputs after the unsuccessful 004 query-length trial.
    # The probe now observes tensor descriptors and the actual runtime context.
    env["AFD_DSV41_METADATA_QUERY_LENGTH_DIAGNOSTIC"] = "0"
    env["ASCEND_RT_VISIBLE_DEVICES"] = "0,1,2,3,4,5,6,7"
    for key, name in (
        ("ASCEND_CACHE_PATH", "ascend-cache"),
        ("ASCEND_WORK_PATH", "ascend-work"),
        ("ASCEND_PROCESS_LOG_PATH", "ascend-logs"),
        ("TORCH_EXTENSIONS_DIR", "torch-extensions"),
        ("TRITON_CACHE_DIR", "triton-cache"),
        ("XDG_CACHE_HOME", "cache"),
        ("TMPDIR", "tmp"),
    ):
        path = owned / name
        path.mkdir(parents=True, exist_ok=False)
        env[key] = str(path)
    return env


def verify_native_environment_files(record):
    # These are immutable build artifacts and actual nm output, not a kernel
    # execution check. Run this before starting either model process.
    paths = record["paths"]
    build_raw = Path(paths["active_record"]).read_bytes()
    assert sha(build_raw) == record["active_record_sha256"]
    build = json.loads(build_raw)
    assert build["status"] == "built-not-loaded"
    assert build["source_commit"] == ASCEND_REVISION
    assert Path(paths["active_record"]).parent == Path(paths["active_root"])
    assert build["active_parent_root"] == paths["previous_active_root"]
    assert build["parent_root"] == paths["parent_root"]
    assert build["selected_ops"] == record["selected_ops"]
    assert build["all_parent_api_symbols_retained"] is True
    assert build["reused_same_cann92_extension_and_python"] is True
    assert build["readonly_unchanged"] is True
    assert build["runtime_extension_loaded"] is False
    assert build["native_operations_accepted"] is False
    actual_package = {
        str(PurePosixPath(paths["active_root"]) / name): item["sha256"]
        for name, item in build["artifacts"].items()
    }
    assert actual_package == {
        name: digest
        for name, digest in record["active_artifacts"].items()
        if name != paths["active_record"]
    }
    evidence = record["required_custom_symbols_evidence"]
    exported = build["exported_symbols"]
    for key in ("path", "sha256", "required_symbols", "missing_symbols"):
        assert exported[key] == evidence[key]
    assert all(
        exported["observed_symbols"][name] is True for name in REQUIRED_CUSTOM_SYMBOLS
    )
    symbols_raw = Path(evidence["path"]).read_bytes()
    assert sha(symbols_raw) == evidence["sha256"]
    symbols = {
        line.split()[-1]
        for line in symbols_raw.decode("utf-8").splitlines()
        if line.split()
    }
    assert set(REQUIRED_CUSTOM_SYMBOLS) <= symbols
    kernels = build["native_qli_opp_outputs"]
    assert kernels["logical_op"] == "VllmAscendQuantLightningIndexerV2"
    assert kernels["soc"] == "ascend910_93"
    assert (
        type(kernels["kernel_object_count"]) is int
        and kernels["kernel_object_count"] > 0
    )
    assert kernels["kernel_executed"] is False
    assert kernels["artifacts"] and all(
        record["active_artifacts"][str(PurePosixPath(paths["active_root"]) / name)]
        == item["sha256"]
        for name, item in kernels["artifacts"].items()
    )
    return {
        "build_record_sha256": sha(build_raw),
        "required_custom_symbols": list(REQUIRED_CUSTOM_SYMBOLS),
        "symbol_evidence_sha256": sha(symbols_raw),
        "native_kernel_object_count": kernels["kernel_object_count"],
        "native_build_artifacts_verified": True,
        "kernel_execution_verified_by_readiness_check": False,
    }


def prepare(args):
    parent_raw = (ROOT / PARENT).read_bytes()
    assert sha(parent_raw) == PARENT_SHA
    assert sha((ROOT / DEVICE_DRIVER).read_bytes()) == DEVICE_DRIVER_SHA
    device = load_module("normal_execute_device_capsule", ROOT / DEVICE_DRIVER)
    cpu = load_module("normal_execute_cpu_capsule", ROOT / CPU_DRIVER)
    parent, _ = cpu.read_archive(parent_raw)
    assert len(parent) == PARENT_SOURCE_FILES
    assert sha(parent[DEVICE_DRIVER]) == DEVICE_DRIVER_SHA
    previous_raw = parent[device.ENVIRONMENT_RECORD]
    assert sha(previous_raw) == device.ENVIRONMENT_RECORD_SHA
    record_raw = args.environment_record.read_bytes()
    record = json.loads(record_raw)
    validate_environment_record(record, json.loads(previous_raw), sha(previous_raw))
    prerequisites = {}
    prerequisite_raw = {}
    for label, accepted_field in PREREQUISITES:
        raw = (ROOT / PARENT).parent.joinpath(label, "summary.json").read_bytes()
        summary = json.loads(raw)
        assert summary["success"] is True and summary[accepted_field] is True
        assert summary["source_archive_sha256"] == PARENT_SHA
        prerequisites[label] = {"sha256": sha(raw), "accepted_field": accepted_field}
        prerequisite_raw[label] = raw
    files = {
        **parent,
        DRIVER: Path(__file__).read_bytes(),
        PROBE: (ROOT / PROBE).read_bytes(),
        ENVIRONMENT_RECORD: record_raw,
    }
    assert len(files) == SOURCE_FILES
    assert all(files[name] == raw for name, raw in parent.items())
    assert sorted(set(files) - set(parent)) == sorted(
        (DRIVER, PROBE, ENVIRONMENT_RECORD)
    )
    production = [name for name in files if name.startswith("afd_plugin/")]
    assert len(production) == PRODUCTION_FILES
    assert all(files[name] == parent[name] for name in production)
    python_files = [name for name in files if name.endswith(".py")]
    for name in python_files:
        compile(files[name], name, "exec")
    pins = cpu.source_pins(files)
    assert pins == cpu.source_pins(parent) and len(pins) == 191
    assert not set(pins).intersection(dict(ADDITIONAL_NATIVE_PINS))
    assert len({**pins, **dict(ADDITIONAL_NATIVE_PINS)}) == INSTALLED_IDENTITIES
    archive = cpu.archive_bytes(files)
    frozen, manifest = cpu.read_archive(archive)
    assert frozen == files
    output = ROOT / FAMILY / args.label
    output.mkdir(parents=True, exist_ok=False)
    (output / "source.tar.gz").write_bytes(archive)
    (output / "runner.py").write_bytes(files[DRIVER])
    for label, raw in prerequisite_raw.items():
        (output / ("parent-" + label + "-summary.json")).write_bytes(raw)
    write_json(output / "manifest.json", manifest)
    record = {
        "source_archive_sha256": sha(archive),
        "parent_archive_sha256": PARENT_SHA,
        "parent_archive_path": PARENT,
        "source_files": len(files),
        "production_files": len(production),
        "python_files_compiled": len(python_files),
        "parent_source_files": PARENT_SOURCE_FILES,
        "all_parent_members_byte_equal": True,
        "changed_parent_members": [],
        "production_byte_equal_c2_parent": True,
        "production_parent_equal_count": PRODUCTION_FILES,
        "production_changes": {},
        "parent_acceptance_prerequisites": prerequisites,
        "native_pin_inputs_byte_equal_parent": True,
        "native_source_identities": INSTALLED_IDENTITIES,
        "parent_native_source_identities": len(pins),
        "additional_native_source_pins": dict(ADDITIONAL_NATIVE_PINS),
        "environment_record_sha256": sha(record_raw),
        "previous_environment_record_sha256": sha(previous_raw),
        "active_artifact_identities": len(record["active_artifacts"]),
        "toolchain_atb_identities": len(record["toolchain_artifacts"]),
        "added_to_parent": [DRIVER, PROBE, ENVIRONMENT_RECORD],
        "driver_sha256": manifest[DRIVER],
        "probe_sha256": manifest[PROBE],
        "roles": [{"role": "attention", "device": 0}, {"role": "ffn", "device": 1}],
        "pair_timeout_seconds": args.timeout,
        "afd_port": args.afd_port,
        "prepared_only": True,
        "ssh_executed": False,
        "device_executed": False,
        "native_normal_c2_execute_component_accepted": False,
        "inference_executed": False,
        "full_checkpoint_accepted": False,
        "numerical_equivalence_accepted": False,
        "scope": (
            "normal native Scheduler prefill4/decode1/sample2/empty retirement; "
            "no fixed output IDs or native parity"
        ),
        "native_forward_operator_symbol_evidence_locked": True,
        "native_forward_operator_execution_verified": False,
        "execution_diagnostics": {
            "ASCEND_LAUNCH_BLOCKING": "1",
            "metadata_inputs_observed": True,
            "optional_query_lengths_supplied": False,
            "native_inputs_changed": False,
            "metadata_descriptors_and_context_observed": True,
            "performance_measurement": False,
        },
    }
    write_json(output / "preparation.json", record)
    write_json(
        output / "source-proof.json",
        {
            "parent_source_archive_sha256": PARENT_SHA,
            "source_archive_sha256": sha(archive),
            "unchanged_parent_members": len(parent),
            "changed_parent_members": {},
            "added_members": {
                name: manifest[name] for name in (DRIVER, PROBE, ENVIRONMENT_RECORD)
            },
            "production_all_parent_equal": True,
            "python_compiled": python_files,
            "parent_native_pin_inputs_unchanged": True,
            "additional_native_source_pins": dict(ADDITIONAL_NATIVE_PINS),
            "ssh_executed": False,
            "device_executed": False,
        },
    )
    print(json.dumps(record, indent=2))


def verify_pair_messages(reports, snapshot):
    # Execute the real stdlib codec leaf; canonical bytes are observations after
    # the actual calls. This does not claim raw socket or device-kernel tracing.
    codec = load_module(
        "normal_execute_control_codec",
        snapshot / "afd_plugin/connectors/npu/hccl_protocol.py",
    )
    expected_caps = codec.HcclCapabilities(512, 4096, 16, (0, 1, 2), 1, 0)
    expected_types = (
        "HELLO",
        "HELLO",
        "FORWARD",
        "ACCEPT",
        "COMPLETE",
        "FORWARD",
        "ACCEPT",
        "COMPLETE",
        "STOP",
        "STOP_ACK",
    )
    directions = (
        "send_returned",
        "receive_returned",
        "send_returned",
        "receive_returned",
        "receive_returned",
        "send_returned",
        "receive_returned",
        "receive_returned",
        "send_returned",
        "receive_returned",
    )
    payloads, transactions = {}, []
    for role, peer in (("attention", 0), ("ffn", 1)):
        records = reports[role]["pair_control_messages"]
        assert len(records) == len(expected_types)
        payloads[role] = []
        for index, entry in enumerate(records):
            assert type(entry["ordinal"]) is int and entry["ordinal"] == index
            assert (
                type(entry["peer_pair_rank"]) is int and entry["peer_pair_rank"] == peer
            )
            direction = directions[index]
            if role == "ffn":
                direction = (
                    "receive_returned"
                    if direction == "send_returned"
                    else "send_returned"
                )
            assert entry["role"] == role and entry["direction"] == direction
            message = codec.decode_hccl_control_message(
                json.dumps(entry["encoded_message"], separators=(",", ":")).encode()
            )
            canonical = codec.encode_hccl_control_message(message)
            assert sha(canonical) == entry["sha256"]
            assert message.kind.value == expected_types[index]
            if index < 2:
                assert message.capabilities == expected_caps
                assert message.role.value == ("attention" if index == 0 else "ffn")
            elif index in (2, 5):
                plan = message.plan
                rows = 4 if index == 2 else 1
                assert plan.layer_indices == (0, 1, 2)
                assert plan.valid_tokens == plan.padded_tokens == rows
                assert plan.mode == "target" and plan.stage_idx == 0
                if role == "attention":
                    transactions.append(plan.transaction_id)
            elif index in (3, 4, 6, 7):
                assert (
                    message.transaction_id
                    == records[2 if index < 5 else 5]["encoded_message"]["plan"][
                        "transaction_id"
                    ]
                )
            payloads[role].append(canonical)
    assert payloads["attention"] == payloads["ffn"]
    assert len(transactions) == len(set(transactions)) == 2
    return {
        "canonical_messages_per_role": 10,
        "hello_and_peer_stop_ack_verified": True,
        "forward_transactions": 2,
        "transaction_ids": transactions,
        "raw_socket_bytes_observed": False,
    }


def verify_execution(reports, results, protocol):
    attention = reports["attention"]
    detail = attention["scheduler"]
    output_ids = detail["actual_output_ids"]
    assert len(output_ids) == 2 and all(
        type(value) is int and 0 <= value < 4096 for value in output_ids
    )
    assert detail["prompt"] == list(PROMPT_TOKEN_IDS) and detail["max_tokens"] == 2
    assert detail["skip_tokenizer_init"] is True
    assert (
        detail["model_is_multimodal"] is True and detail["language_model_only"] is True
    )
    assert len(detail["steps"]) == 2
    for ordinal, entry in enumerate(detail["steps"]):
        ids = list(PROMPT_TOKEN_IDS) if ordinal == 0 else output_ids[:1]
        positions = [0, 1, 2, 3] if ordinal == 0 else [4]
        assert entry["input_ids"] == ids and entry["positions"] == positions
        assert entry["computed_before_schedule"] == (0 if ordinal == 0 else 4)
        assert entry["computed_after_update"] == 4 + ordinal
        assert entry["sampled_token_ids"] == [[output_ids[ordinal]]]
        assert (
            entry["worker_history"]
            == list(PROMPT_TOKEN_IDS) + output_ids[: ordinal + 1]
        )
        step = entry["schedule"]
        assert step["total_num_scheduled_tokens"] == len(ids)
        assert step["num_scheduled_tokens"] == {REQUEST_ID: len(ids)}
        assert step["new_request_ids"] == ([REQUEST_ID] if ordinal == 0 else [])
        assert step["cached_request_ids"] == ([] if ordinal == 0 else [REQUEST_ID])
        hidden = entry["hidden"]
        raw = (results / "attention" / hidden["raw_file"]).read_bytes()
        assert sha(raw) == hidden["sha256"] and len(raw) == hidden["bytes"]
        assert hidden["finite"] is True and hidden["shape"] == [len(ids), 512]
    assert detail["request_status"] == "FINISHED_LENGTH_CAPPED"
    assert (
        detail["worker_request_retired"] is True and detail["scheduler_empty"] is True
    )
    assert detail["empty_output_executed"] is True
    assert detail["retirement"]["finished_req_ids"] == [REQUEST_ID]
    assert detail["retirement"]["total_num_scheduled_tokens"] == 0
    tensor_shapes = {
        "hidden": ("torch.bfloat16", 2),
        "router": ("torch.float32", 4),
        "ids": ("torch.int32", 4),
        "output": ("torch.bfloat16", 2),
    }
    pairs = {}
    for role in ("attention", "ffn"):
        entries = reports[role]["layer_payloads"]
        assert len(entries) == 12
        pairs[role] = []
        for ordinal, entry in enumerate(entries):
            parent_index, local = divmod(ordinal, 6)
            layer, output = divmod(local, 2)
            kind = "output" if output else "inputs"
            rows = 4 if parent_index == 0 else 1
            assert entry["ordinal"] == ordinal and entry["role"] == role
            assert entry["transaction_id"] == protocol["transaction_ids"][parent_index]
            assert entry["layer"] == layer and entry["kind"] == kind
            assert set(entry["tensors"]) == (
                {"output"} if output else {"hidden", "router", "ids"}
            )
            hashes = {}
            for name, tensor in entry["tensors"].items():
                dtype, width = tensor_shapes[name]
                shape = [rows] if name == "ids" else [rows, 512]
                raw = (results / role / tensor["raw_file"]).read_bytes()
                assert tensor["dtype"] == dtype and tensor["shape"] == shape
                assert tensor["finite"] is True and tensor["device"].startswith("npu:")
                assert type(tensor["data_ptr"]) is int and tensor["data_ptr"] > 0
                assert (
                    len(raw)
                    == tensor["bytes"]
                    == rows * (1 if name == "ids" else 512) * width
                )
                assert sha(raw) == tensor["sha256"]
                if name == "ids":
                    assert list(struct.unpack("<" + "i" * rows, raw)) == (
                        list(PROMPT_TOKEN_IDS) if parent_index == 0 else output_ids[:1]
                    )
                hashes[name] = tensor["sha256"]
            if not output:
                assert (
                    entry["tensors"]["hidden"]["data_ptr"]
                    != entry["tensors"]["router"]["data_ptr"]
                )
            pairs[role].append(hashes)
    assert pairs["attention"] == pairs["ffn"]
    return {
        "forward_parents": 2,
        "layer_exchanges": 6,
        "payload_cross_peer_bytes_verified": True,
        "actual_output_ids": output_ids,
        "empty_retirement_verified": True,
        "native_numerical_parity_verified": False,
    }


def supervise_pair(args, device, snapshot, results, record):
    started = time.monotonic()
    processes, logs, owned = {}, {}, {}
    error, timed_out, killed = None, False, []
    try:
        for role, ordinal in (("attention", 0), ("ffn", 1)):
            env = selected_environment(
                snapshot, args.remote_root / (role + "-owned"), record
            )
            write_json(results / (role + "-environment.json"), env)
            command = [
                args.python,
                "-B",
                str(snapshot / PROBE),
                "--run",
                "--role",
                role,
                "--model",
                args.model,
                "--output-dir",
                str(results / role),
                "--device",
                str(ordinal),
                "--afd-port",
                str(args.afd_port),
                "--timeout",
                str(args.timeout),
            ]
            logs[role] = (results / (role + ".log")).open("wb")
            processes[role] = subprocess.Popen(
                command,
                cwd=snapshot,
                env=env,
                stdout=logs[role],
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
            owned[role] = {}
            device.observe_owned(processes[role].pid, owned[role])
        while any(child.poll() is None for child in processes.values()):
            for role, child in processes.items():
                if child.poll() is None:
                    device.observe_owned(child.pid, owned[role])
                elif child.returncode != 0:
                    raise RuntimeError(f"{role} exited with {child.returncode}")
            if time.monotonic() - started >= args.timeout:
                timed_out = True
                raise TimeoutError("normal A/F paired C2 execution timed out")
            time.sleep(POLL_SECONDS)
        for role, child in processes.items():
            if child.returncode != 0:
                raise RuntimeError(f"{role} exited with {child.returncode}")
    except BaseException:
        error = traceback.format_exc()
    finally:
        for role in processes:
            killed.extend(device.kill_owned(owned[role]))
        for role, child in processes.items():
            child.wait(timeout=REAP_SECONDS)
            logs[role].close()
    runs = []
    for role, child in processes.items():
        path = results / role / "result.json"
        runs.append(
            {
                "role": role,
                "pid": child.pid,
                "returncode": child.returncode,
                "owned_pid_start_ticks": owned[role],
                "surviving_owned_pids": device.live_owned(owned[role]),
                "report": json.loads(path.read_text()) if path.is_file() else None,
            }
        )
    return {
        "runs": runs,
        "timed_out": timed_out,
        "killed_owned_pids": sorted(set(killed)),
        "error": error,
        "elapsed_seconds": time.monotonic() - started,
    }


def run_remote(args):
    root = args.remote_root.resolve()
    device = load_module("normal_model_device_runner", root / "device_runner.py")
    assert sha((root / "device_runner.py").read_bytes()) == DEVICE_DRIVER_SHA
    cpu = load_module("normal_model_cpu_runner", root / "cpu_runner.py")
    raw = (root / "source.tar.gz").read_bytes()
    files, manifest = cpu.read_archive(raw)
    preparation = json.loads((root / "preparation.json").read_text())
    assert sha(raw) == preparation["source_archive_sha256"]
    assert len(files) == SOURCE_FILES
    assert manifest[PROBE] == preparation["probe_sha256"]
    assert manifest[DRIVER] == sha(Path(__file__).read_bytes())
    assert (args.timeout, args.afd_port) == (
        preparation["pair_timeout_seconds"],
        preparation["afd_port"],
    )
    assert preparation["production_byte_equal_c2_parent"] is True
    snapshot, results = root / "snapshot", root / "results"
    snapshot.mkdir()
    results.mkdir()
    for name, data in files.items():
        target = snapshot / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    previous_raw = files[device.ENVIRONMENT_RECORD]
    assert sha(previous_raw) == device.ENVIRONMENT_RECORD_SHA
    previous = json.loads(previous_raw)
    record_raw = files[ENVIRONMENT_RECORD]
    assert sha(record_raw) == preparation["environment_record_sha256"]
    record = json.loads(record_raw)
    validate_environment_record(record, previous, sha(previous_raw))
    paths = record["paths"]
    assert args.python == paths["python"]
    site = Path(args.python).parent.parent / "lib/python3.12/site-packages"
    native = {
        str(site / name): digest
        for name, digest in {
            **cpu.source_pins(files),
            **dict(ADDITIONAL_NATIVE_PINS),
        }.items()
    }
    assert len(native) == INSTALLED_IDENTITIES
    assert len(record["active_artifacts"]) == preparation["active_artifact_identities"]
    assert len(record["toolchain_artifacts"]) == preparation["toolchain_atb_identities"]
    evidence = record["required_custom_symbols_evidence"]
    expected = {
        **native,
        **record["active_artifacts"],
        **previous["active_artifacts"],
        **record["toolchain_artifacts"],
        str(PurePosixPath(paths["parent_root"]) / paths["parent_record"]): record[
            "parent_record_sha256"
        ],
        evidence["path"]: evidence["sha256"],
    }
    actual_before = {name: sha(Path(name).read_bytes()) for name in expected}
    write_json(results / "readonly-before.json", actual_before)
    if actual_before != expected:
        raise RuntimeError("frozen native/package/CANN/ATB identity changed before run")
    native_readiness = verify_native_environment_files(record)
    write_json(results / "native-build-readiness.json", native_readiness)
    package = Path(paths["active_package"])
    active_record_path = paths["active_record"]
    assert {
        **{str(p): sha(p.read_bytes()) for p in package.rglob("*") if p.is_file()},
        active_record_path: sha(Path(active_record_path).read_bytes()),
    } == record["active_artifacts"]
    env = selected_environment(snapshot, root / "owned-preflight", record)
    before = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-before.log").write_bytes(before.stdout + before.stderr)
    idle_before = before.stdout.count(b"No running processes found in NPU")
    pair, error, protocol, execution = {}, None, None, None
    started = time.monotonic()
    try:
        if before.returncode != 0 or idle_before != device.EXPECTED_IDLE_BOARDS:
            raise RuntimeError("all eight boards must be idle before model loading")
        pair = supervise_pair(args, device, snapshot, results, record)
        if pair["error"] is None:
            reports = {run["role"]: run["report"] for run in pair["runs"]}
            protocol = verify_pair_messages(reports, snapshot)
            execution = verify_execution(reports, results, protocol)
    except BaseException:
        error = traceback.format_exc()
    after = subprocess.run(
        ["npu-smi", "info"], env=env, capture_output=True, timeout=30
    )
    (results / "npu-after.log").write_bytes(after.stdout + after.stderr)
    idle_after = after.stdout.count(b"No running processes found in NPU")
    actual_after = {name: sha(Path(name).read_bytes()) for name in expected}
    source_after = {name: sha((snapshot / name).read_bytes()) for name in manifest}
    write_json(results / "readonly-after.json", actual_after)
    write_json(results / "source-after.json", source_after)
    roles_ok = len(pair.get("runs", [])) == 2
    extension = str(PurePosixPath(paths["active_package"]) / EXTENSION_RELATIVE_PATH)
    for run in pair.get("runs", []):
        role, report = run["role"], run["report"] or {}
        runtime = report.get("runtime", {})
        origin = runtime.get("modules", {}).get("vllm_ascend", {}).get("path", "")
        mapped = runtime.get("mapped_native_libraries", {})
        roles_ok = roles_ok and (
            run["returncode"] == 0
            and not run["surviving_owned_pids"]
            and report.get("success") is True
            and report.get("run") is True
            and report.get("native_model_load_component_accepted") is True
            and report.get("normal_role_init_device_completed") is True
            and report.get("normal_load_model_returned") is True
            and report.get("normal_connector_hello_completed") is True
            and report.get("model_loaded") is True
            and report.get("initialize_attention_kv_requested")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("attention_kv_initialized")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("native_attention_kv_component_accepted")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("native_c2_kv_component_accepted")
            is (args.initialize_attention_kv and role == "attention")
            and report.get("pure_swa_patch_installed") is False
            and report.get("compress_ratios") == [0, 0, 2]
            and report.get("candidate_source_layer") == 20
            and report.get("configuration", {})
            .get("native_geometry", {})
            .get("num_layers")
            == 3
            and report.get("inference_executed") is True
            and report.get("loaded_parameters_unchanged") is True
            and report.get("loaded_parameters_after_execution")
            == report["loaded_model"]["parameters"]
            and report.get("native_scheduler_prefill_decode_retirement_accepted")
            is (role == "attention")
            and report.get("numerical_equivalence_accepted") is False
            and report.get("full_checkpoint_accepted") is False
            and report.get("native_groups_destroyed") is True
            and report.get("cleanup_failures") == []
            and report.get("actual_device")
            == ("npu:0" if role == "attention" else "npu:1")
            and report.get("loaded_model", {}).get("parameter_count", 0) > 0
            and report.get("loaded_model", {}).get("parameter_bytes", 0) > 0
            and origin.startswith(paths["active_package"] + "/vllm_ascend/")
            and mapped.get(extension)
            == record["expected_native_library_sha256"][extension]
            and any(
                mapped.get(str(PurePosixPath(paths["active_package"]) / relative))
                == record["expected_direct_library_sha256"]
                for relative in DIRECT_LIBRARY_RELATIVE_PATHS
            )
            and not any(
                paths["parent_root"] in name
                or paths["previous_active_root"] in name
                or "/cann-9.0.1/" in name
                for name in mapped
            )
        )
        if role == "ffn":
            roles_ok = roles_ok and (
                report.get("ffn_empty_cache_initialized") is True
                and report.get("ffn_public_poll_observed_peer_stop_and_owner_exit")
                is True
            )
        else:
            roles_ok = roles_ok and report.get("ffn_empty_cache_initialized") is False
            if args.initialize_attention_kv:
                kv = report.get("attention_kv", {})
                storages = kv.get("underlying_storages", {})
                roles_ok = roles_ok and (
                    kv.get("native_initialize_from_config_returned") is True
                    and kv.get("budget_bytes") == ATTENTION_KV_BUDGET_BYTES
                    and 0 < kv.get("actual_storage_bytes", 0) <= kv["budget_bytes"]
                    and len(kv.get("bindings", {})) == ATTENTION_CACHE_LAYERS
                    and kv.get("native_tuple_aliases_verified") is True
                    and len(kv.get("source_tuple", {}).get("state", [])) == 1
                    and len(kv.get("source_tuple", {}).get("swa", [])) == 3
                    and len(storages) == 1
                    and all(
                        entry["bytes"] > 0
                        and (results / role / entry["raw_file"]).stat().st_size
                        == entry["bytes"]
                        and sha((results / role / entry["raw_file"]).read_bytes())
                        == entry["sha256"]
                        for entry in storages.values()
                    )
                    and kv.get("loaded_parameters_unchanged") is True
                    and kv.get("loaded_parameters_after")
                    == report["loaded_model"]["parameters"]
                    and kv.get("initial_kv_contents_verified") is False
                    and kv.get("memory_profile_executed") is False
                    and kv.get("model_warmup_executed") is False
                    and kv.get("scheduler_created") is False
                    and kv.get("fresh_block_zeroer_executed") is False
                )
    success = bool(
        error is None
        and pair.get("error") is None
        and roles_ok
        and not pair.get("timed_out", True)
        and not pair.get("killed_owned_pids", [None])
        and protocol is not None
        and execution is not None
        and before.returncode == after.returncode == 0
        and idle_before == idle_after == device.EXPECTED_IDLE_BOARDS
        and actual_before == actual_after == expected
        and source_after == manifest
    )
    attention_report = next(
        (
            run["report"] or {}
            for run in pair.get("runs", [])
            if run["role"] == "attention"
        ),
        {},
    )
    summary = {
        "success": success,
        "native_model_load_component_accepted": success,
        "pair_supervision": pair,
        "protocol": protocol,
        "execution": execution,
        "native_normal_c2_execute_component_accepted": success,
        "error": error,
        "source_archive_sha256": sha(raw),
        "source_files": len(files),
        "production_files": PRODUCTION_FILES,
        "production_byte_equal_c2_parent": True,
        "production_parent_equal_count": PRODUCTION_FILES,
        "production_changes": preparation["production_changes"],
        "pure_swa_patch_installed": False,
        "installed_source_identities": len(native),
        "environment_record_sha256": sha(record_raw),
        "active_root": paths["active_root"],
        "active_artifact_identities": len(record["active_artifacts"]),
        "previous_active_artifact_identities": len(previous["active_artifacts"]),
        "toolchain_atb_identities": len(record["toolchain_artifacts"]),
        "required_custom_symbols_evidence": evidence,
        "native_build_readiness": native_readiness,
        "readonly_unchanged": actual_before == actual_after == expected,
        "source_unchanged": source_after == manifest,
        "idle_boards_before": idle_before,
        "idle_boards_after": idle_after,
        "elapsed_seconds": time.monotonic() - started,
        "initialize_attention_kv_requested": args.initialize_attention_kv,
        "attention_kv_initialized": attention_report.get("attention_kv_initialized")
        is True,
        "native_attention_kv_component_accepted": bool(
            success and args.initialize_attention_kv
        ),
        "native_c2_kv_component_accepted": bool(
            success and args.initialize_attention_kv
        ),
        "inference_executed": attention_report.get("inference_executed") is True,
        "execution_diagnostics": {
            "ASCEND_LAUNCH_BLOCKING": "1",
            "optional_query_lengths_supplied": False,
            "native_inputs_changed": False,
            "metadata_descriptors_and_context_observed": True,
            "performance_measurement": False,
        },
        "full_checkpoint_accepted": False,
        "numerical_equivalence_accepted": False,
    }
    write_json(results / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if success else 1


def execute_prepared(args):
    prepared = args.execute_prepared.resolve()
    device = load_module("normal_model_device_upload", ROOT / DEVICE_DRIVER)
    assert sha((ROOT / DEVICE_DRIVER).read_bytes()) == DEVICE_DRIVER_SHA
    cpu = load_module("normal_model_cpu_upload", ROOT / CPU_DRIVER)
    raw = (prepared / "source.tar.gz").read_bytes()
    files, _ = cpu.read_archive(raw)
    preparation = json.loads((prepared / "preparation.json").read_text())
    assert sha(raw) == preparation["source_archive_sha256"]
    assert len(files) == SOURCE_FILES
    assert sha(files[DRIVER]) == sha(Path(__file__).read_bytes())
    previous_raw = files[device.ENVIRONMENT_RECORD]
    assert sha(previous_raw) == device.ENVIRONMENT_RECORD_SHA
    record_raw = files[ENVIRONMENT_RECORD]
    assert sha(record_raw) == preparation["environment_record_sha256"]
    validate_environment_record(
        json.loads(record_raw), json.loads(previous_raw), sha(previous_raw)
    )
    for label, accepted_field in PREREQUISITES:
        parent_raw = (prepared / ("parent-" + label + "-summary.json")).read_bytes()
        parent_summary = json.loads(parent_raw)
        assert (
            sha(parent_raw)
            == preparation["parent_acceptance_prerequisites"][label]["sha256"]
        )
        assert (
            parent_summary["success"] is True and parent_summary[accepted_field] is True
        )
        assert parent_summary["source_archive_sha256"] == PARENT_SHA
    execution = prepared / (args.execution_label or "execute-001")
    execution.mkdir(exist_ok=False)
    base = load_module("normal_model_ssh", ROOT / cpu.BASE)
    uploader = load_module("normal_model_chunk_upload", ROOT / cpu.UPLOAD_HELPER)
    create = (
        "import tempfile;print(tempfile.mkdtemp("
        "prefix='text-normal-execute-20261117-',dir="
        + repr(device.REMOTE_PARENT)
        + "))"
    )
    remote = base.ssh("python3 -c " + shlex.quote(create)).decode().strip()
    write_json(
        execution / "identity.json", {"remote_root": remote, "archive_sha256": sha(raw)}
    )
    uploader.upload_source(base, remote, raw, execution)
    inputs = {
        "runner.py": files[DRIVER],
        "device_runner.py": files[DEVICE_DRIVER],
        "cpu_runner.py": files[CPU_DRIVER],
        "preparation.json": (prepared / "preparation.json").read_bytes(),
    }
    deliver = (
        "import json,pathlib,sys;root=pathlib.Path("
        + repr(remote)
        + ");inputs=json.loads(sys.stdin.buffer.read());"
        "[(root/n).write_bytes(bytes.fromhex(raw)) for n,raw in inputs.items()]"
    )
    base.ssh(
        "python3 -c " + shlex.quote(deliver),
        json.dumps({n: raw.hex() for n, raw in inputs.items()}).encode(),
    )
    command_args = [
        "python3",
        remote + "/runner.py",
        "--remote-root",
        remote,
        "--python",
        args.python,
        "--model",
        args.model,
        "--timeout",
        str(preparation["pair_timeout_seconds"]),
        "--afd-port",
        str(preparation["afd_port"]),
    ]
    command = shlex.join(command_args)
    process = subprocess.run(
        [
            "ssh",
            "-F",
            base.SSH_CONFIG,
            "-o",
            "BatchMode=yes",
            "-o",
            "ConnectTimeout=15",
            base.SSH_HOST,
            command,
        ],
        capture_output=True,
        timeout=SSH_TIMEOUT_SECONDS,
    )
    (execution / "remote-output.log").write_bytes(process.stdout + process.stderr)
    results_raw = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
    (execution / "results.tar.gz").write_bytes(results_raw)
    with tarfile.open(fileobj=io.BytesIO(results_raw)) as stream:
        summary = json.load(stream.extractfile("results/summary.json"))
    write_json(execution / "summary.json", summary)
    print(json.dumps(summary, indent=2))
    return 0 if process.returncode == 0 and summary["success"] is True else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--prepare-only", action="store_true")
    modes.add_argument("--remote-root", type=Path)
    modes.add_argument("--execute-prepared", type=Path)
    parser.add_argument("--label")
    parser.add_argument("--environment-record", type=Path)
    parser.add_argument("--execution-label")
    parser.add_argument("--model", default="/mnt/workspace/models/DeepSeek-V4.1-Flash")
    parser.add_argument(
        "--python", default="/mnt/workspace/code/.venvs/afd-v030-dsv41-c0/bin/python"
    )
    parser.add_argument("--timeout", type=int, default=DEFAULT_PAIR_TIMEOUT_SECONDS)
    parser.add_argument("--afd-port", type=int, default=DEFAULT_AFD_PORT)
    args = parser.parse_args()
    if args.timeout <= 0 or not 0 < args.afd_port < 65536:
        parser.error("positive timeout and port in 1..65535 required")
    if args.prepare_only and (
        not args.label
        or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-" for c in args.label)
    ):
        parser.error("--prepare-only requires a safe lowercase --label")
    if not args.prepare_only and args.label is not None:
        parser.error("--label belongs only to preparation")
    if args.prepare_only and args.environment_record is None:
        parser.error("--prepare-only requires an explicit --environment-record")
    if not args.prepare_only and args.environment_record is not None:
        parser.error("--environment-record belongs only to preparation")
    if args.execution_label is not None and (
        args.execute_prepared is None
        or not args.execution_label
        or any(
            c not in "abcdefghijklmnopqrstuvwxyz0123456789-"
            for c in args.execution_label
        )
    ):
        parser.error(
            "--execution-label requires --execute-prepared and a safe lowercase label"
        )
    args.initialize_attention_kv = True
    if args.prepare_only:
        prepare(args)
        return 0
    if args.execute_prepared is not None:
        return execute_prepared(args)
    return run_remote(args)


if __name__ == "__main__":
    raise SystemExit(main())
