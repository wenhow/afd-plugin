"""Collect an existing live-prefix attempt without starting another worker."""

import argparse
import hashlib
import importlib.util
import io
import json
import shlex
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
FAMILY = (
    ROOT / "openspec/changes/afd-hccl-full-parity/evidence/"
    "a3-dspark-native-live-prefix-20261115"
)
BASE = (
    ROOT / "openspec/changes/afd-hccl-v2-microbatch/evidence/"
    "a3-forward-counts-20261109/run_a3_forward_counts.py"
)
REMOTE_PARENT = PurePosixPath("/mnt/workspace/tmp/afd-c0-20261104.hVgsIf")


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--label", required=True)
    args = parser.parse_args()
    if not args.label or any(
        value not in "abcdefghijklmnopqrstuvwxyz0123456789-" for value in args.label
    ):
        parser.error("a bounded existing attempt label is required")
    destination = FAMILY / args.label
    identity = json.loads((destination / "identity.json").read_text())
    remote = PurePosixPath(identity["remote"])
    assert remote.parent == REMOTE_PARENT
    assert remote.name.startswith("dspark-native-live-prefix-20261115-")
    archive_path = destination / "results.tar.gz"
    assert not archive_path.exists(), "Never replace original collected results"
    assert not (destination / "collection.json").exists()
    source = (destination / "source.tar.gz").read_bytes()
    assert sha(source) == identity["archive_sha256"]
    mode = identity.get("mode", "live-prefix")
    assert mode in ("live-prefix", "decode")
    spec = importlib.util.spec_from_file_location("live_prefix_collect_base", BASE)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    metadata_script = """import hashlib,json,os,pathlib
root=pathlib.Path(REMOTE)
recorded={}
outer_owned=root/'results/owned.json'
inner_owned=root/'results'/MODE/'ownership.json'
if outer_owned.is_file():
    recorded.update({pid:int(identity['start_ticks']) for pid,identity in
        json.loads(outer_owned.read_text())['processes'].items()})
if inner_owned.is_file():
    recorded.update({pid:int(ticks) for pid,ticks in
        json.loads(inner_owned.read_text())['owned_pid_start_ticks'].items()})
active=[]
for process in pathlib.Path('/proc').iterdir():
    if not process.name.isdigit() or int(process.name)==os.getpid():
        continue
    try:
        arguments=(process/'cmdline').read_bytes().split(b'\\0')
        stat=(process/'stat').read_text()
        fields=stat[stat.rfind(')')+2:].split()
        ticks=int(fields[19])
        if fields[0]=='Z':
            continue
        # Exact path arguments only: the query script itself contains the path.
        exact_path=any(argument.startswith(str(root).encode()+b'/')
            for argument in arguments)
        recorded_owner=recorded.get(process.name)==ticks
        if exact_path or recorded_owner:
            active.append({'pid':int(process.name),'start_ticks':ticks,
                'exact_path_argument':exact_path,'recorded_owner':recorded_owner})
    except (FileNotFoundError,PermissionError,ProcessLookupError):
        continue
p=root/'results/summary.json'
q=root/'results'/MODE/'summary.json'
print(json.dumps({'outer_summary':json.loads(p.read_text()) if p.is_file() else None,
    'inner_summary':json.loads(q.read_text()) if q.is_file() else None,
    'supervision_launch':json.loads((root/'supervision-launch.json').read_text())
        if (root/'supervision-launch.json').is_file() else None,
    'source_archive_sha256':hashlib.sha256((root/'source.tar.gz').read_bytes()).hexdigest(),
    'active_attempt_processes':active,
    'scope':'Existing attempt only; no launch or current hardware/cleanup acceptance'}))
""".replace("REMOTE", repr(str(remote))).replace("MODE", repr(mode))
    observation = base.ssh("python3 -c " + shlex.quote(metadata_script))
    observed = json.loads(observation)
    assert observed["source_archive_sha256"] == identity["archive_sha256"]
    assert not observed["active_attempt_processes"], (
        "Existing attempt still has active processes; "
        "inspect ownership before collection"
    )
    result = base.ssh("tar -czf - -C " + shlex.quote(str(remote)) + " results")
    short = ROOT / ".tmp" / ("dspark-native-live-prefix-" + args.label)
    assert not short.exists()
    with tarfile.open(fileobj=io.BytesIO(result)) as stream:
        members = stream.getmembers()
        assert all(
            member.name == "results" or member.name.startswith("results/")
            for member in members
        )
        stream.extractall(short, filter="data")
    archive_path.write_bytes(result)
    transport_path = destination / "transport.json"
    original_transport = (
        json.loads(transport_path.read_text()) if transport_path.is_file() else None
    )
    report = {
        "archive_sha256": sha(result),
        "short_extraction": str(short),
        "collection_method": "read-only reconnect; no worker relaunched",
        "original_ssh_returncode": (
            original_transport["returncode"] if original_transport else 255
        ),
        "original_transport": original_transport,
        "original_runtime_exit_unverified": observed["outer_summary"] is None,
        "observed_existing_summaries": observed,
    }
    (destination / "collection.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as error:
        print("SSH collection unavailable; existing attempt left unchanged")
        raise SystemExit(error.returncode) from error
