"""Freeze CPU contract tests for STOP polling and profiler owner completion."""

import argparse
import hashlib
import importlib.util
import io
import json
import shlex
import subprocess
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = "openspec/changes/afd-hccl-v2-microbatch/evidence/a3-forward-counts-20261109/run_a3_forward_counts.py"
IDENTITY = "openspec/changes/afd-hccl-full-parity/evidence/eager-configuration-source-identity-20261113.json"
RUNS = "openspec/changes/afd-hccl-full-parity/evidence/a3-pd-consumer-u2-cpu-20261114"
VENV = "/mnt/workspace/code/.venvs/afd-v030-dsv41-c0"
PARENT = "/mnt/workspace/tmp/afd-c0-20261104.hVgsIf"
OVERLAYS = ("afd_plugin/compat/npu/profiler_control.py", "afd_plugin/compat/patches/engine_core.py", "afd_plugin/v1/worker/npu/attention_model_runner_v2.py", "afd_plugin/v1/worker/npu/ffn_model_runner.py", "afd_plugin/v1/worker/npu/ffn_worker.py", "afd_plugin/distributed/hccl_plan.py", "afd_plugin/connectors/npu/hccl_staged.py", "afd_plugin/v1/worker/npu/hccl_v41_eager_bootstrap.py", "afd_plugin/connectors/npu/p2p_hccl.py")
MODULES = (
    "tests/unit/v1/worker/npu/test_attention_model_runner_v2.py",
    "tests/unit/compat/npu/test_dspark_pd.py",
    "tests/unit/compat/npu/test_kv_layout_connector.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_staged.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_stage_state.py",
    "tests/unit/model_executor/models/npu/test_deepseek_v41_graph.py",
    "tests/unit/v1/worker/npu/test_hccl_v41_ubatch_runner.py",
    "tests/unit/v1/worker/npu/test_hccl_v41_execution.py",
)
NEW_FIXTURES = (
    "tests/unit/fakes/deepseek_v41.py",
    "tests/unit/fakes/dspark_pd.py",
    "tests/unit/fakes/kv_connector.py",
    "tests/unit/fakes/kv_layout_connector.py",
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_base(root):
    spec = importlib.util.spec_from_file_location("profiler_poll_cpu_base", root / BASE)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


parser = argparse.ArgumentParser()
parser.add_argument("--label")
parser.add_argument("--red", action="store_true", help="unused, retained staging compatibility")
parser.add_argument("--whole-modules", action="store_true")
parser.add_argument("--green", action="store_true")
parser.add_argument("--baseline")
parser.add_argument("--frontier-cases", action="store_true")
parser.add_argument("--latest-tests", action="store_true")
parser.add_argument("--combined", action="store_true")
parser.add_argument("--p-u2", action="store_true")
parser.add_argument("--remote-root", type=Path)
args = parser.parse_args()
if args.remote_root:
    remote = args.remote_root
    snapshot, results = remote / "snapshot", remote / "results"
    snapshot.mkdir()
    results.mkdir()
    with tarfile.open(remote / "source.tar.gz") as stream:
        stream.extractall(snapshot, filter="data")
    manifest = json.loads((snapshot / "manifest.json").read_text())
    assert all(sha((snapshot / name).read_bytes()) == digest for name, digest in manifest.items())
    expected = json.loads((snapshot / IDENTITY).read_text())["source_expected"]
    site = Path(VENV) / "lib/python3.12/site-packages"
    checks = {name: sha((site / name).read_bytes()) == digest for name, digest in expected.items()}
    (results / "source-check.json").write_text(json.dumps(checks, indent=2) + "\n")
    assert all(checks.values())
    env = load_base(snapshot).prepare_env(snapshot)
    signature = "tests/unit/compat/patches/test_signatures.py::test_scoped_patch_preserves_upstream_signature"
    modules = (*MODULES, "tests/unit/compat/npu/test_runtime_config.py", *(signature + "[" + hook + "]" for hook in ("pd-native-source-retirement", "pd-scheduler-new-request", "dspark-pd-sampling"))) if args.whole_modules else (MODULES[0],)
    command = [VENV + "/bin/python", "-B", "-m", "pytest", *modules,
        "-q", "-ra", "--disable-warnings", "--junitxml=" + str(results / "junit.xml")]
    if not args.whole_modules:
        command.extend(["-k", "native_pd_u2"])
    run = subprocess.run(command, env=env, cwd=snapshot, capture_output=True, timeout=180)
    (results / "pytest.log").write_bytes(run.stdout + run.stderr)
    (results / "summary.json").write_text(json.dumps({"scope": "Native PD D handoff to same-owner eager U2 target/sample/proposal with declared CPU arithmetic; no NPU/HCCL or full-model acceptance",
        "command": command, "returncode": run.returncode, "source_files_checked": len(checks),
        "source_files_match": all(checks.values()), "red": args.red}, indent=2) + "\n")
    print(run.stdout.decode(errors="replace"))
    print(run.stderr.decode(errors="replace"))
    raise SystemExit(run.returncode)

if not args.label or any(char not in "abcdefghijklmnopqrstuvwxyz0123456789-" for char in args.label):
    parser.error("valid label required")
destination = ROOT / RUNS / args.label
destination.mkdir(parents=True, exist_ok=False)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
contents = {}
previous = ROOT / "openspec/changes/afd-hccl-full-parity/evidence/a3-p-report-gloo-cpu-20261114/cpu-002/source.tar.gz"
with tarfile.open(previous) as stream:
    for member in stream:
        if member.isfile() and member.name != "manifest.json":
            contents[member.name] = stream.extractfile(member).read()
for name in ("afd_plugin/compat/npu/runtime_config.py", "tests/unit/compat/npu/test_runtime_config.py", "tests/unit/fakes/kv_connector.py", "tests/unit/v1/worker/npu/test_attention_model_runner_v2.py"):
    contents[name] = (ROOT / name).read_bytes()
contents[".tmp/stage_pd_consumer_u2_cpu.py"] = Path(__file__).read_bytes()
manifest = {name: sha(data) for name, data in contents.items()}
contents["manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w:gz") as stream:
    for name, data in contents.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        stream.addfile(member, io.BytesIO(data))
payload = buffer.getvalue()
(destination / "source.tar.gz").write_bytes(payload)
base = load_base(ROOT)
remote = base.ssh("python3 -c " + shlex.quote("import tempfile;print(tempfile.mkdtemp(prefix='pd-consumer-u2-cpu-20261114-',dir=" + repr(PARENT) + "))")).decode().strip()
(destination / "identity.json").write_text(json.dumps({"head": head, "remote": remote, "red": args.red,
    "archive_sha256": sha(payload), "manifest": manifest,
    "scope": "Gloo cpu002 frozen 143 runtime with only runtime_config D/U2 eligibility overlay and three explicitly frozen test/fixture files; prior local MTP changes preserved and excluded"}, indent=2) + "\n", encoding="utf-8")
base.ssh("cat > " + shlex.quote(remote + "/source.tar.gz"), payload)
base.ssh("cat > " + shlex.quote(remote + "/stage_pd_consumer_u2_cpu.py"), Path(__file__).read_bytes())
command = "python3 -B " + shlex.quote(remote + "/stage_pd_consumer_u2_cpu.py") + " --remote-root " + shlex.quote(remote)
if args.whole_modules:
    command += " --whole-modules"
if args.frontier_cases:
    command += " --frontier-cases"
if args.combined:
    command += " --combined"
if args.p_u2:
    command += " --p-u2"
run = subprocess.run(["ssh", "-F", base.SSH_CONFIG, "-o", "BatchMode=yes", base.SSH_HOST, command], capture_output=True, timeout=240)
(destination / "remote.log").write_bytes(run.stdout + run.stderr)
result = base.ssh("tar -czf - -C " + shlex.quote(remote) + " results")
(destination / "results.tar.gz").write_bytes(result)
short = ROOT / ".tmp" / ("pdu2-" + args.label)
short.mkdir(exist_ok=False)
with tarfile.open(fileobj=io.BytesIO(result)) as stream:
    stream.extractall(short, filter="data")
(destination / "collection.json").write_text(json.dumps({"archive_sha256": sha(result), "returncode": run.returncode,
    "short_extraction": str(short)}, indent=2) + "\n", encoding="utf-8")
print(run.stdout.decode(errors="replace"))
print(run.stderr.decode(errors="replace"))
raise SystemExit(run.returncode)
