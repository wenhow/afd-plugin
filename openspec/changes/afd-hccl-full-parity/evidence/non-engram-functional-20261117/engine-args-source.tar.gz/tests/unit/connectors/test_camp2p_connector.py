# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project

from __future__ import annotations

import sys
from types import ModuleType, SimpleNamespace

import pytest

from tests.unit.fakes.afd_config import camp2p_config as _afd_config
from tests.unit.fakes.vllm_config import camp2p_config as _vllm_config

pytest.importorskip("torch")
pytest.importorskip("vllm")
pytest.importorskip("torch_npu")

from afd_plugin.config import AFDConfig
from afd_plugin.connectors import (
    AFDConnectorFactory,
    AFDTransferContext,
    AFDTransferMetadata,
    AFDTransferState,
)
from afd_plugin.connectors.metadata import AFDControlPayload, AFDDPMetadata
from afd_plugin.connectors.npu import camp2p as camp2p_module
from afd_plugin.connectors.npu.camp2p import (
    CAMP2pAFDConnector,
    CAMP2PExtraInfo,
    CAMP2PTransferState,
    build_camp2p_topology,
)
from tests.unit.fakes.dp_metadata import DPMetadata as _FakeDPMetadata


def test_camp2p_factory_creates_connector():
    connector = AFDConnectorFactory.create_connector(
        0,
        0,
        _vllm_config(extra_config={"core_num": 12}),
        _afd_config(role="attention"),
    )

    assert isinstance(connector, CAMP2pAFDConnector)
    assert not connector.is_initialized
    assert connector.max_num_reqs == 8
    assert connector.extra_info.core_num == 12


@pytest.mark.parametrize(
    "attention_size,ffn_size,counts,physical",
    [
        (2, 1, [4, 2], [4, 4]),
        (4, 2, [4, 1, 2, 3], [4, 3, 4, 3]),
        (4, 2, [4, 2], [4, 4, 4, 4]),  # Expand DP counts to TP peers first.
        (2, 2, [4, 2], [4, 2]),
    ],
)
def test_camp2p_stage_wire_counts_preserve_attention_payload(
    monkeypatch, attention_size, ffn_size, counts, physical
):
    import torch

    connector = CAMP2pAFDConnector(
        0,
        0,
        _vllm_config(num_ubatches=2),
        AFDConfig(
            connector="CAMP2pAFDConnector",
            role="attention",
            num_attention_ranks=attention_size,
            num_ffn_ranks=ffn_size,
        ),
        0,
    )
    payload = AFDControlPayload(
        {stage: AFDDPMetadata(torch.tensor(counts)) for stage in range(2)},
        False,
        False,
    )
    connector.p2p_pg = "control-group"
    sent = []
    monkeypatch.setattr(
        camp2p_module,
        "send_control_payload",
        lambda payload, **kwargs: sent.append(payload),
    )
    connector.control_plane.update_state_from_dp_metadata(payload)
    connector.control_plane.send_dp_metadata_list(payload)
    for stage in range(2):
        assert (
            payload.dp_metadata_list[stage].num_tokens_across_dp_cpu.tolist() == counts
        )
        assert (
            connector.dp_metadata_list[stage].num_tokens_across_dp_cpu.tolist()
            == physical
        )
        assert (
            sent[0].dp_metadata_list[stage].num_tokens_across_dp_cpu.tolist()
            == physical
        )


@pytest.mark.parametrize("with_input_ids", [False, True])
def test_camp2p_opaque_send_uses_current_stage_padding(monkeypatch, with_input_ids):
    import torch

    connector = CAMP2pAFDConnector(
        0,
        0,
        _vllm_config(num_ubatches=2),
        AFDConfig(
            connector="CAMP2pAFDConnector",
            role="attention",
            num_attention_ranks=2,
            num_ffn_ranks=1,
        ),
        0,
    )
    methods = {}
    monkeypatch.setattr(camp2p_module, "_CAMP2P_CUSTOM_OPS_REGISTERED", False)
    monkeypatch.setattr(
        camp2p_module,
        "direct_register_custom_op",
        lambda **kwargs: methods.update({kwargs["op_name"]: kwargs["op_func"]}),
    )
    camp2p_module._register_camp2p_custom_ops()
    contexts = [
        SimpleNamespace(
            ubatch_idx=stage,
            additional_kwargs={"afd_metadata": SimpleNamespace(connector=connector)},
        )
        for stage in range(2)
    ]
    current = contexts[0]
    monkeypatch.setattr(camp2p_module, "get_forward_context", lambda: current)
    sent = []

    def native_send(*args):
        sent.append(args)
        return None, None, None, torch.tensor([1]), None

    monkeypatch.setattr(
        torch.ops.afd_ascend,
        "a2e",
        native_send,
        raising=False,
    )
    received_refs = []

    def native_recv(*args):
        received_refs.append(args[0])
        return args[0]

    monkeypatch.setattr(
        torch.ops.afd_ascend,
        "e2a",
        native_recv,
        raising=False,
    )

    # Invoke the same opaque runtime functions after changing the live metadata,
    # as a model graph traced during an unsplit profile must do without retracing.
    connector.control_plane.update_state_from_dp_metadata(
        AFDControlPayload({0: AFDDPMetadata(torch.tensor([4, 4]))}, False, True)
    )
    connector.control_plane.update_state_from_dp_metadata(
        AFDControlPayload(
            {
                0: AFDDPMetadata(torch.tensor([4, 2])),
                1: AFDDPMetadata(torch.tensor([1, 3])),
            },
            False,
            False,
        )
    )
    for stage, real, physical in [(0, 4, 4), (1, 1, 3)]:
        current = contexts[stage]
        hidden = torch.arange(real * 16, dtype=torch.float32).reshape(real, 16)
        ids, scales = (
            camp2p_module.prepare_token_id_transfer(
                torch.arange(real), topk=2, expected_tokens=real
            )
            if with_input_ids
            else (None, None)
        )
        methods["afd_camp2p_send_attn_output"](
            hidden,
            "stage0",
            "stage1",
            "",
            real,
            16,
            2,
            1,
            2,
            1,
            8,
            int(with_input_ids),
            ids,
            scales,
        )
        wire = sent[-1][0]
        assert wire.shape == (physical, 16)
        assert sent[-1][3] == physical
        assert torch.equal(wire[:real], hidden)
        assert torch.count_nonzero(wire[real:]) == 0
        if with_input_ids:
            assert torch.equal(sent[-1][1][:real], ids)
            assert sent[-1][1].shape == (physical, 2)
            assert sent[-1][2].shape == (physical, 2)
        methods["afd_camp2p_recv_ffn_output"](
            hidden,
            "stage0",
            "stage1",
            "",
            real,
            16,
            2,
            1,
            2,
            1,
            8,
        )
        assert received_refs[-1] is hidden
    assert contexts[0].cam_afdtransfer_state is not contexts[1].cam_afdtransfer_state


def test_camp2p_topology_matches_original_rank_layout():
    attn0 = build_camp2p_topology(_afd_config(role="attention"), 0)
    attn1 = build_camp2p_topology(_afd_config(role="attention"), 1)
    attn2 = build_camp2p_topology(_afd_config(role="attention"), 2)
    ffn1 = build_camp2p_topology(_afd_config(role="ffn"), 1)

    assert (attn0.world_rank, attn0.p2p_rank, attn0.dp_metadata_destinations) == (
        2,
        2,
        (0,),
    )
    assert (attn1.world_rank, attn1.p2p_rank, attn1.dp_metadata_destinations) == (
        3,
        3,
        (1,),
    )
    assert not attn2.participates_in_p2p_group
    assert (ffn1.world_rank, ffn1.p2p_rank) == (1, 1)


def _init_ffn_connector(rank, vllm_config):
    connector = CAMP2pAFDConnector(
        rank,
        rank,
        vllm_config,
        _afd_config(role="ffn"),
        rank,
    )
    connector._initialized = True
    connector.hccl_comm_name = "hccl0"
    connector.hccl_comm_name2 = "hccl1"
    connector.hccl_comm_name3 = ""
    connector.hccl_comm_name1 = "moe"
    return connector


def test_camp2p_recv_attn_output_uses_kernel_strided_af_grouping(monkeypatch):
    torch = pytest.importorskip("torch")

    monkeypatch.setattr(
        torch.ops.afd_ascend,
        "a2e",
        lambda *args: ("hidden", None, None, "atten-batch", "active-mask"),
        raising=False,
    )
    dp_metadata_list = {0: _FakeDPMetadata([2, 3, 5, 7])}
    rank0 = _init_ffn_connector(0, _vllm_config())
    rank1 = _init_ffn_connector(1, _vllm_config())
    rank0.dp_metadata_list = dp_metadata_list
    rank1.dp_metadata_list = dp_metadata_list

    context0 = rank0.recv_attn_output(ubatch_idx=0, layer_idx=3).context
    context1 = rank1.recv_attn_output(ubatch_idx=0, layer_idx=3).context

    assert context0.metadata.seq_lens == [7]
    assert context1.metadata.seq_lens == [10]
    assert isinstance(context0.states, CAMP2PTransferState)
    assert isinstance(context0.states, AFDTransferState)
    assert context0.states.batch_size == 7
    assert context0.states.h == 16
    assert context0.states.k == 2


def test_camp2p_recv_attn_output_drives_the_operator_ids_mode(monkeypatch):
    """Requesting ids must reach the operator, not stay a connector-local flag.

    The ``a2e`` operator only writes its ids slot in the ids mode, and the
    sending rank selects that mode independently. A receiving rank that reads the
    slot in the other mode would install uninitialised device memory as token
    ids, which a token-keyed router turns into an out-of-range table read. The
    ids that arrive are model-specific tensors, so they travel on the payload
    rather than in the backend transfer state.
    """

    torch = pytest.importorskip("torch")

    calls: list[tuple] = []

    def fake_a2e(*args):
        calls.append(args)
        tokens, topk = args[3], args[5]
        ids = torch.arange(tokens * topk, dtype=torch.int32).reshape(tokens, topk)
        return ("hidden", ids, None, "atten-batch", "active-mask")

    monkeypatch.setattr(torch.ops.afd_ascend, "a2e", fake_a2e, raising=False)
    connector = _init_ffn_connector(0, _vllm_config())
    connector.dp_metadata_list = {0: _FakeDPMetadata([2, 3, 5, 7])}

    with_ids = connector.recv_attn_output(
        ubatch_idx=0,
        layer_idx=0,
        recv_input_ids=True,
    )
    without_ids = connector.recv_attn_output(
        ubatch_idx=0,
        layer_idx=0,
        recv_input_ids=False,
    )

    assert calls[0][-1] == 1
    assert with_ids.input_ids.tolist() == [0, 2, 4, 6, 8, 10, 12]
    assert calls[1][-1] == 0
    assert without_ids.input_ids is None


def test_camp2p_extra_info_rejects_unknown_mix_placement():
    with pytest.raises(ValueError, match="unknown CAMP2P connector_extra_config"):
        CAMP2PExtraInfo.from_mapping({"mix_placement": True})


def test_camp2p_extra_info_validates_values():
    with pytest.raises(ValueError, match="core_num must be positive"):
        CAMP2PExtraInfo.from_mapping({"core_num": 0})
    with pytest.raises(TypeError, match="core_num must be an integer"):
        CAMP2PExtraInfo.from_mapping({"core_num": 8.5})


def test_camp2p_extra_info_coerces_integer_bool_values():
    assert (
        CAMP2PExtraInfo.from_mapping(
            {"compute_gate_on_attention": 1},
        ).compute_gate_on_attention
        is True
    )
    assert (
        CAMP2PExtraInfo.from_mapping(
            {"compute_gate_on_attention": 0},
        ).compute_gate_on_attention
        is False
    )


def test_camp2p_connector_uses_role_specific_core_num(monkeypatch):
    torch = pytest.importorskip("torch")

    monkeypatch.setattr(
        torch.ops.afd_ascend,
        "a2e",
        lambda *args: ("hidden", None, None, "atten-batch", "active-mask"),
        raising=False,
    )
    connector = _init_ffn_connector(
        0,
        _vllm_config(
            n_shared_experts=3,
            extra_config={
                "core_num": 8,
                "ffn_core_num": 13,
            },
        ),
    )
    connector.dp_metadata_list = {0: _FakeDPMetadata([2, 3, 5, 7])}

    states = connector.recv_attn_output(ubatch_idx=0, layer_idx=3).context.states

    assert states.k == 2
    assert states.batch_size == 7
    # The ffn_core_num override applies because this is an FFN-role connector.
    assert states.aiv_num == 13


def test_camp2p_init_scopes_fresh_options_to_each_hccl_group(monkeypatch):
    calls = []
    option_calls = []

    monkeypatch.setitem(sys.modules, "torch_npu", ModuleType("torch_npu"))
    monkeypatch.setattr(camp2p_module, "ensure_cam_p2p_ops_available", lambda: None)
    monkeypatch.setattr(camp2p_module, "_register_camp2p_custom_ops", lambda: None)

    def fake_init_afd_process_group(**kwargs):
        calls.append(kwargs)
        backend = SimpleNamespace(
            get_hccl_comm_name=lambda rank: f"hccl:{kwargs['group_name']}:{rank}",
        )
        return SimpleNamespace(
            group_name=kwargs["group_name"],
            _get_backend=lambda device: backend,
        )

    monkeypatch.setattr(
        camp2p_module,
        "init_afd_process_group",
        fake_init_afd_process_group,
    )

    def fake_create_hccl_process_group_options(hccl_buffer_size_mb):
        option_calls.append(hccl_buffer_size_mb)
        return object()

    monkeypatch.setattr(
        camp2p_module,
        "create_hccl_process_group_options",
        fake_create_hccl_process_group_options,
    )
    connector = CAMP2pAFDConnector(
        0,
        0,
        _vllm_config(
            num_ubatches=2,
            extra_config={"hccl_buffer_size": 2048},
        ),
        _afd_config(role="ffn"),
        0,
    )

    connector.init_afd_connector()

    assert [call["group_name"] for call in calls] == ["afd", "afd1", "afd_moe", "p2p"]
    assert option_calls == [2048, 2048, 2048]
    hccl_options = [call["pg_options"] for call in calls[:3]]
    assert len({id(options) for options in hccl_options}) == 3
    assert "pg_options" not in calls[3]
    assert connector.hccl_comm_name_list == ["hccl:afd:0", "hccl:afd1:0"]
    assert connector.hccl_comm_name == "hccl:afd:0"
    assert connector.hccl_comm_name2 == "hccl:afd1:0"
    assert (
        camp2p_module._get_group_ep(
            0,
            connector.hccl_comm_name,
            connector.hccl_comm_name2,
            "",
        )
        == "hccl:afd:0"
    )
    assert (
        camp2p_module._get_group_ep(
            1,
            connector.hccl_comm_name,
            connector.hccl_comm_name2,
            "",
        )
        == "hccl:afd1:0"
    )


def test_camp2p_send_attn_custom_op_receives_all_hccl_names(monkeypatch):
    torch = pytest.importorskip("torch")

    captured = {}
    connector = CAMP2pAFDConnector(
        0,
        0,
        _vllm_config(num_ubatches=2),
        _afd_config(role="attention"),
        0,
    )
    connector._initialized = True
    connector.hccl_comm_name = "hccl0"
    connector.hccl_comm_name2 = "hccl1"
    connector.hccl_comm_name3 = ""
    hidden_states = torch.empty((3, 16))
    metadata = AFDTransferMetadata.create_attention_metadata(
        layer_idx=0,
        stage_idx=1,
        seq_len=3,
    )
    context = AFDTransferContext(metadata=metadata)

    # The connector stows the CAMP2P transfer state and ubatch index on the
    # forward context; capture that instead of a dedicated helper.
    forward_context = SimpleNamespace()
    monkeypatch.setattr(camp2p_module, "get_forward_context", lambda: forward_context)

    def fake_send_attn_output(*args):
        captured["args"] = args
        return args[0]

    monkeypatch.setattr(
        torch.ops.vllm,
        "afd_camp2p_send_attn_output",
        fake_send_attn_output,
        raising=False,
    )

    output = connector.send_attn_output(hidden_states, context)

    assert output is None
    assert forward_context.ubatch_idx == 1
    assert captured["args"][1:4] == ("hccl0", "hccl1", "")
    assert captured["args"][4] == 3
    assert forward_context.cam_afdtransfer_state.batch_size == 3


def test_camp2p_init_fails_cleanly_without_ascend_runtime(monkeypatch):
    connector = CAMP2pAFDConnector(
        0,
        0,
        _vllm_config(),
        _afd_config(role="attention"),
        0,
    )

    def _raise_missing_ops():
        raise RuntimeError(
            "CAMP2P Ascend custom ops are not available. Build the package with "
            "Ascend ops enabled in a torch-npu/CANN environment.",
        )

    # Force the "ascend runtime missing" path so the test is deterministic on
    # real NPU hosts too: otherwise init proceeds into init_afd_process_group
    # and blocks forever on the HCCL rendezvous waiting for absent peers.
    monkeypatch.setattr(
        camp2p_module,
        "ensure_cam_p2p_ops_available",
        _raise_missing_ops,
    )

    with pytest.raises(RuntimeError, match="AFD Ascend custom ops|torch-npu"):
        connector.init_afd_connector()
