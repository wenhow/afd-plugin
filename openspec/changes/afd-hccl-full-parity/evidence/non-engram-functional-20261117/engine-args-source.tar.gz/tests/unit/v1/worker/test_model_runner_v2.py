# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project

"""Unit tests for AFD CUDA GPU ModelRunnerV2 support."""

from __future__ import annotations

from contextlib import nullcontext
from types import MethodType, SimpleNamespace

import pytest

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")

from torch import device as torch_device  # noqa: E402
from vllm.config import CUDAGraphMode  # noqa: E402
from vllm.forward_context import (  # noqa: E402
    BatchDescriptor,
    ForwardContext,
    override_forward_context,
)
from vllm.v1.worker import gpu_model_runner as native_v1  # noqa: E402
from vllm.v1.worker.gpu import cudagraph_utils, dp_utils  # noqa: E402
from vllm.v1.worker.gpu import model_runner as native_v2  # noqa: E402
from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector  # noqa: E402
from vllm.v1.worker.gpu.ubatch_utils import UBatchState  # noqa: E402
from vllm.v1.worker.ubatch_utils import UBatchSlice  # noqa: E402

from afd_plugin.model_executor.models import (  # noqa: E402
    forward_context as afd_forward_context,
)
from afd_plugin.model_executor.models.model_utils import (  # noqa: E402
    get_afd_model_config,
)
from afd_plugin.v1.worker import (  # noqa: E402
    attention_model_runner_v2 as v2_runner_module,
)
from afd_plugin.v1.worker import (  # noqa: E402
    attention_worker,
    ffn_worker,
)
from afd_plugin.v1.worker import (  # noqa: E402
    ffn_routed_experts_model_runner as routed_runner_module,
)
from afd_plugin.v1.worker.attention_model_runner_v2 import (  # noqa: E402
    AFDAttentionModelRunnerV2,
)
from afd_plugin.v1.worker.ffn_worker import AFDFFNWorker  # noqa: E402
from afd_plugin.validation import (  # noqa: E402
    validate_gpu_model_runner_v2_config,
    validate_npu_model_runner_v2_config,
)
from tests.unit.fakes.connector import (  # noqa: E402
    FakeRoutedConnector,
)
from tests.unit.fakes.platform import stub_platform_forward_context  # noqa: E402
from tests.unit.fakes.profiler import StepProfiler as _StepProfiler  # noqa: E402

TEST_MODEL_MAX_LEN = 163840
TEST_HIDDEN_SIZE = 2048
TEST_CUDAGRAPH_CAPTURE_SIZE = 8


@pytest.fixture(autouse=True)
def cpu_platform_forward_context(monkeypatch):
    # Native KV helper contexts still execute their real creation/provider
    # lifecycle; accelerator-only additional kwargs require device groups.
    stub_platform_forward_context(monkeypatch)


class _RecordingConnector:
    def __init__(self, events: list[str]):
        self.events = events
        self.control_plane = self
        self.closed = False

    def update_state_from_dp_metadata(self, payload):
        self.events.append("control_update")
        self.last_payload = payload

    def send_dp_metadata_list(self, payload):
        self.events.append("control_send")
        self.last_payload = payload

    def send_attn_output(self, hidden_states, context, **kwargs):
        self.events.append("data")

    def close(self):
        self.closed = True
        self.events.append("close")


class _RunnerRecorder:
    instances: list[tuple[SimpleNamespace, torch_device]] = []

    def __init__(self, vllm_config, device):
        type(self).instances.append((vllm_config, device))


class _NativeRunnerSentinel:
    instances = 0

    def __init__(self, vllm_config, device):
        type(self).instances += 1


def _v2_config(
    *,
    role: str = "attention",
    architecture: str = "DeepseekV2ForCausalLM",
    use_v2: bool = True,
    num_attention_ranks: int = 1,
    num_ffn_ranks: int = 1,
    data_parallel_size: int = 1,
    tensor_parallel_size: int = 1,
    prefill_context_parallel_size: int = 1,
    enforce_eager: bool = True,
    cudagraph_mode: CUDAGraphMode = CUDAGraphMode.NONE,
    cudagraph_capture_sizes: list[int] | None = None,
    max_cudagraph_capture_size: int = 0,
):
    hf_config = SimpleNamespace(
        architectures=[architecture],
        model_type="deepseek_v2",
        hidden_size=TEST_HIDDEN_SIZE,
    )
    model_config = SimpleNamespace(
        hf_config=hf_config,
        runner_type="generate",
        is_moe=True,
        is_encoder_decoder=False,
        is_multimodal_model=False,
        enforce_eager=enforce_eager,
        enable_prompt_embeds=False,
        enable_return_routed_experts=False,
        quantization=None,
        quantization_config=None,
        max_model_len=TEST_MODEL_MAX_LEN,
        dtype=torch.bfloat16,
        get_hidden_size=lambda: TEST_HIDDEN_SIZE,
    )
    parallel_config = SimpleNamespace(
        data_parallel_size=data_parallel_size,
        data_parallel_rank=0,
        data_parallel_rank_local=0,
        data_parallel_index=0,
        data_parallel_backend="mp",
        distributed_executor_backend="mp",
        nnodes_within_dp=1,
        assigned_physical_gpu_ids=None,
        tensor_parallel_size=tensor_parallel_size,
        pipeline_parallel_size=1,
        prefill_context_parallel_size=prefill_context_parallel_size,
        decode_context_parallel_size=1,
        enable_expert_parallel=True,
        enable_elastic_ep=False,
        enable_eplb=False,
        use_sequence_parallel_moe=False,
        is_moe_model=True,
        enable_dbo=False,
        use_ubatching=False,
        num_ubatches=1,
    )
    compilation_config = SimpleNamespace(
        mode=None,
        cudagraph_mode=cudagraph_mode,
        cudagraph_capture_sizes=cudagraph_capture_sizes or [],
        max_cudagraph_capture_size=max_cudagraph_capture_size,
        compile_sizes=[],
        compile_ranges_endpoints=[model_config.max_model_len],
        pass_config=SimpleNamespace(
            enable_sp=False,
        ),
    )
    return SimpleNamespace(
        use_v2_model_runner=use_v2,
        additional_config={
            "afd": {
                "role": role,
                "connector": "P2pNcclAFDConnector",
                "num_attention_ranks": num_attention_ranks,
                "num_ffn_ranks": num_ffn_ranks,
                "compute_gate_on_attention": False,
            },
        },
        model_config=model_config,
        parallel_config=parallel_config,
        compilation_config=compilation_config,
        cache_config=SimpleNamespace(enable_prefix_caching=False),
        kernel_config=SimpleNamespace(moe_backend="auto"),
        scheduler_config=SimpleNamespace(
            enable_chunked_prefill=False,
            async_scheduling=False,
            max_num_batched_tokens=TEST_MODEL_MAX_LEN,
            max_num_seqs=TEST_CUDAGRAPH_CAPTURE_SIZE,
        ),
        lora_config=None,
        speculative_config=None,
        num_speculative_tokens=0,
        diffusion_config=None,
        quant_config=None,
    )


def _runner_for_metadata(
    events: list[str],
    *,
    data_parallel_size: int = 1,
    data_parallel_rank: int = 0,
):
    runner = object.__new__(AFDAttentionModelRunnerV2)
    runner.vllm_config = _v2_config(
        num_attention_ranks=data_parallel_size,
        num_ffn_ranks=data_parallel_size,
        data_parallel_size=data_parallel_size,
    )
    runner.vllm_config.parallel_config.data_parallel_rank = data_parallel_rank
    runner.connector = _RecordingConnector(events)
    runner._is_warmup = False
    runner._afd_is_graph_capturing = False
    runner._afd_is_graph_replaying = False
    runner._afd_pending_metadata = None
    runner._afd_suppress_metadata_send = False
    runner._afd_transaction_counter = 0
    runner.ubatch_runner = None
    runner.prof = _StepProfiler()
    runner.cudagraph_manager = SimpleNamespace(run_fullgraph=lambda _desc: None)
    return runner


def _scheduler_output(num_tokens: int):
    return SimpleNamespace(total_num_scheduled_tokens=num_tokens)


def _no_graph_model_manager():
    manager = object.__new__(cudagraph_utils.ModelCudaGraphManager)
    manager._graphs_captured = False
    manager._candidates = {}
    manager._lora_dispatch_map = {}
    manager._max_lora_case = 0
    return manager


def _fake_worker_init(worker):
    worker.device = torch.device("cpu")
    if worker.use_v2_model_runner:
        from vllm.v1.worker.gpu import model_runner as imported_module
    else:
        from vllm.v1.worker import gpu_model_runner as imported_module

    worker.model_runner = imported_module.GPUModelRunner(
        worker.vllm_config,
        worker.device,
    )


def _construct_like_native_worker(worker):
    if worker.use_v2_model_runner:
        from vllm.v1.worker.gpu import model_runner as imported_module
    else:
        from vllm.v1.worker import gpu_model_runner as imported_module

    return imported_module.GPUModelRunner(
        worker.vllm_config,
        worker.device,
    )


def _prepare_worker(worker_cls, config, *, use_v2):
    worker = object.__new__(worker_cls)
    worker.rank = 0
    worker.local_rank = 0
    worker.vllm_config = config
    worker.model_config = config.model_config
    worker.use_v2_model_runner = use_v2
    worker.device_config = SimpleNamespace(device_type="cuda")
    return worker


def test_v2_fullgraph_replay_hook_restores_manager_instance_after_success():
    events: list[str] = []
    runner = _runner_for_metadata(events)
    descriptor = SimpleNamespace(num_tokens=8, num_ubatches=1)

    def native_replay(self, desc):
        events.append("native_replay")
        return desc.num_tokens

    native_bound_replay = MethodType(native_replay, runner.cudagraph_manager)
    runner.cudagraph_manager.run_fullgraph = native_bound_replay
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph

    with v2_runner_module._use_afd_fullgraph_replay_hook(runner, 3):
        assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
        assert runner.cudagraph_manager.run_fullgraph(descriptor) == 8

    assert runner.cudagraph_manager.__dict__["run_fullgraph"] is native_bound_replay
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    assert events == ["control_update", "control_send", "native_replay"]


def test_v2_fullgraph_replay_hook_removes_temporary_instance_override():
    class Manager:
        def run_fullgraph(self, desc):
            return desc.num_tokens

    runner = _runner_for_metadata([])
    runner.cudagraph_manager = Manager()
    descriptor = SimpleNamespace(num_tokens=8, num_ubatches=1)
    assert "run_fullgraph" not in vars(runner.cudagraph_manager)

    with v2_runner_module._use_afd_fullgraph_replay_hook(runner, 3):
        assert runner.cudagraph_manager.run_fullgraph(descriptor) == 8

    assert "run_fullgraph" not in vars(runner.cudagraph_manager)


def test_v2_fullgraph_replay_hooks_on_two_managers_do_not_interfere():
    first_events: list[str] = []
    second_events: list[str] = []
    first = _runner_for_metadata(first_events)
    second = _runner_for_metadata(second_events)
    descriptor = SimpleNamespace(num_tokens=8, num_ubatches=1)

    def first_replay(_self, _desc):
        first_events.append("native_replay")

    def second_replay(_self, _desc):
        second_events.append("native_replay")

    first_original = MethodType(first_replay, first.cudagraph_manager)
    second_original = MethodType(second_replay, second.cudagraph_manager)
    first.cudagraph_manager.run_fullgraph = first_original
    second.cudagraph_manager.run_fullgraph = second_original

    with v2_runner_module._use_afd_fullgraph_replay_hook(first, 3):
        first_hook = first.cudagraph_manager.__dict__["run_fullgraph"]
        with v2_runner_module._use_afd_fullgraph_replay_hook(second, 5):
            assert first.cudagraph_manager.__dict__["run_fullgraph"] is first_hook
            first.cudagraph_manager.run_fullgraph(descriptor)
            second.cudagraph_manager.run_fullgraph(descriptor)
        assert second.cudagraph_manager.__dict__["run_fullgraph"] is second_original
        assert first.cudagraph_manager.__dict__["run_fullgraph"] is first_hook

    assert first.cudagraph_manager.__dict__["run_fullgraph"] is first_original
    assert second.cudagraph_manager.__dict__["run_fullgraph"] is second_original
    assert first_events == ["control_update", "control_send", "native_replay"]
    assert second_events == ["control_update", "control_send", "native_replay"]


def test_v2_fullgraph_replay_hook_rejects_same_manager_reentry():
    runner = _runner_for_metadata([])
    original = runner.cudagraph_manager.__dict__["run_fullgraph"]

    with v2_runner_module._use_afd_fullgraph_replay_hook(runner, 3):
        active_hook = runner.cudagraph_manager.__dict__["run_fullgraph"]
        with (
            pytest.raises(RuntimeError, match="already active"),
            v2_runner_module._use_afd_fullgraph_replay_hook(runner, 3),
        ):
            pass
        assert runner.cudagraph_manager.__dict__["run_fullgraph"] is active_hook

    assert runner.cudagraph_manager.__dict__["run_fullgraph"] is original


_OVERRIDE_ROOTS = {
    "par": ("parallel_config",),
    "comp": ("compilation_config",),
    "model": ("model_config",),
    "hf": ("model_config", "hf_config"),
    "sched": ("scheduler_config",),
}


def _validator_call(overrides):
    """Apply dotted-path overrides to ``_v2_config()`` for a validator call.

    ``afd.<key>`` edits the AFD dict; other roots are ``_OVERRIDE_ROOTS``
    aliases or plain config attributes. ``expected_role`` (default: the AFD
    role) and ``device_type`` are validator arguments, not config fields.
    """

    overrides = dict(overrides)
    call = {
        "device_type": overrides.pop("device_type", None),
        "expected_role": overrides.pop("expected_role", None),
    }
    config = _v2_config()
    afd = config.additional_config["afd"]
    for path, value in overrides.items():
        *parents, name = path.split(".")
        if parents == ["afd"]:
            afd[name] = value
            continue
        target = config
        if parents:
            parents = [*_OVERRIDE_ROOTS.get(parents[0], parents[:1]), *parents[1:]]
        for attr in parents:
            target = getattr(target, attr)
        if not hasattr(target, name):
            raise AttributeError(f"unknown validator override {path!r}")
        setattr(target, name, value)
    call["expected_role"] = call["expected_role"] or afd["role"]
    return config, call


def _err(match, exc_type=RuntimeError):
    return exc_type, match


def _expect(error):
    return nullcontext() if error is None else pytest.raises(error[0], match=error[1])


_GPU_GRAPH = {
    "model.enforce_eager": False,
    "comp.cudagraph_mode": CUDAGraphMode.FULL_DECODE_ONLY,
    "comp.cudagraph_capture_sizes": [TEST_CUDAGRAPH_CAPTURE_SIZE],
    "comp.max_cudagraph_capture_size": TEST_CUDAGRAPH_CAPTURE_SIZE,
}


@pytest.mark.parametrize(
    ("overrides", "error"),
    [
        pytest.param({}, None, id="accept-baseline"),
        pytest.param(
            {"afd.role": "ffn", "hf.architectures": ["AFDDeepseekV2ForCausalLM"]},
            None,
            id="accept-ffn-afd-prefixed-arch",
        ),
        pytest.param(
            {
                "hf.architectures": ["DeepseekV3ForCausalLM"],
                "afd.num_attention_ranks": 6,
                "afd.num_ffn_ranks": 3,
                "par.data_parallel_size": 2,
                "par.tensor_parallel_size": 3,
            },
            None,
            id="accept-attention-dp2-tp3",
        ),
        pytest.param(
            {
                "afd.role": "ffn",
                "hf.architectures": ["Qwen3MoeForCausalLM"],
                "afd.num_attention_ranks": 6,
                "afd.num_ffn_ranks": 3,
                "par.data_parallel_size": 3,
            },
            None,
            id="accept-ffn-ranks-use-ffn-count",
        ),
        pytest.param(
            {
                **_GPU_GRAPH,
                "hf.architectures": ["DeepseekV3ForCausalLM"],
                "hf.hidden_size": 5120,
                "afd.num_attention_ranks": 3,
                "afd.num_ffn_ranks": 3,
                "par.data_parallel_size": 3,
                "comp.cudagraph_capture_sizes": [4, 16],
                "comp.max_cudagraph_capture_size": 16,
                "comp.compile_sizes": [16],
                "comp.compile_ranges_endpoints": [16, TEST_MODEL_MAX_LEN],
                "sched.max_num_seqs": 16,
            },
            None,
            id="accept-full-decode-only-graph",
        ),
        pytest.param(
            {**_GPU_GRAPH, "comp.cudagraph_mode": CUDAGraphMode.FULL},
            _err("FULL_DECODE_ONLY"),
            id="reject-graph-mode-full",
        ),
        pytest.param(
            {"expected_role": "ffn"},
            _err("role mismatch", ValueError),
            id="reject-role-mismatch",
        ),
        pytest.param({"device_type": "npu"}, _err("requires CUDA"), id="reject-npu"),
        pytest.param(
            {"afd.connector": "CAMAsyncAFDConnector"},
            _err("P2pNcclAFDConnector"),
            id="reject-non-p2pnccl-connector",
        ),
        pytest.param(
            {"afd.num_attention_ranks": 2},
            _err("ranks must match DP"),
            id="reject-rank-mismatch",
        ),
        pytest.param({"par.enable_dbo": True}, _err("DBO"), id="reject-dbo-1ub"),
        pytest.param(
            {"par.use_ubatching": True}, _err("ubatching"), id="reject-ubatching-1ub"
        ),
        pytest.param(
            {"par.pipeline_parallel_size": 2}, _err("PP or CP"), id="reject-pp"
        ),
        pytest.param(
            {"par.prefill_context_parallel_size": 2}, _err("PP or CP"), id="reject-pcp"
        ),
        pytest.param(
            {"par.decode_context_parallel_size": 2}, _err("PP or CP"), id="reject-dcp"
        ),
        pytest.param(
            {"par.enable_elastic_ep": True}, _err("static expert"), id="reject-elastic"
        ),
        pytest.param(
            {"par.enable_eplb": True}, _err("static expert"), id="reject-eplb"
        ),
        pytest.param(
            {"par.use_sequence_parallel_moe": True},
            _err("static expert"),
            id="reject-sp-moe",
        ),
        pytest.param(
            {"par.enable_expert_parallel": False},
            _err("static expert"),
            id="reject-no-expert-parallel",
        ),
        pytest.param(
            {"comp.pass_config.enable_sp": True},
            _err("static expert"),
            id="reject-pass-sp",
        ),
        pytest.param(
            {"hf.architectures": ["UnsupportedForCausalLM"]},
            _err("registered AFD model"),
            id="reject-unregistered-model",
        ),
    ],
)
def test_gpu_v2_validator_outcome(overrides, error):
    config, call = _validator_call(overrides)
    with _expect(error):
        validate_gpu_model_runner_v2_config(
            config,
            expected_role=call["expected_role"],
            device_type=call["device_type"] or "cuda",
        )


@pytest.mark.parametrize("local_ubatching", [False, True])
def test_npu_async_v2_constructor_validates_before_native_and_connector_init(
    monkeypatch, local_ubatching
):
    pytest.importorskip("vllm_ascend")
    from afd_plugin.v1.worker.npu import attention_model_runner_v2 as module

    config = _v2_config()
    config.model_config.hf_text_config = config.model_config.hf_config
    config.model_config.use_mla = True
    config.parallel_config.num_ubatches = 2
    config.parallel_config.use_ubatching = local_ubatching
    config.parallel_config.dbo_decode_token_threshold = 2
    config.parallel_config.dbo_prefill_token_threshold = 2
    config.additional_config["afd"].update(
        connector="CAMAsyncAFDConnector",
        async_dp=True,
        compute_gate_on_attention=True,
    )
    events = []

    def native_init(self, vllm_config, device):
        events.append("native")
        self.vllm_config = vllm_config

    connector = SimpleNamespace(control_plane=None)

    def create_connector(*args):
        events.append("connector")
        return connector

    monkeypatch.setattr(module.NPUModelRunnerV2, "__init__", native_init)
    monkeypatch.setattr(module, "_resolve_world_ranks", lambda: (0, 0))
    monkeypatch.setattr(module, "create_npu_runtime_connector", create_connector)
    monkeypatch.setattr(
        module, "create_deferred_afd_npu_profiler", lambda _role, **kwargs: None
    )
    runner = module.AFDNPUAttentionModelRunnerV2(
        config, SimpleNamespace(type="npu", index=0)
    )
    assert runner.connector is connector
    assert events == ["native", "connector"]


_NPU_SYNC = {"afd.connector": "CAMP2pAFDConnector"}
_NPU_ASYNC = {
    "afd.connector": "CAMAsyncAFDConnector",
    "afd.async_dp": True,
    "afd.compute_gate_on_attention": True,
}
_NPU_DBO = {
    **_NPU_SYNC,
    "afd.num_attention_ranks": 2,
    "par.data_parallel_size": 2,
    "par.enable_dbo": True,
    "par.use_ubatching": True,
    "par.num_ubatches": 2,
}
_NPU_GRAPH = {
    **_NPU_SYNC,
    "model.enforce_eager": False,
    "comp.cudagraph_capture_sizes": [TEST_CUDAGRAPH_CAPTURE_SIZE],
    "comp.max_cudagraph_capture_size": TEST_CUDAGRAPH_CAPTURE_SIZE,
}


@pytest.mark.parametrize(
    ("overrides", "error"),
    [
        pytest.param(_NPU_ASYNC, None, id="accept-async-cam"),
        pytest.param(
            {
                **_NPU_ASYNC,
                "afd.num_attention_ranks": 4,
                "par.data_parallel_size": 2,
                "par.tensor_parallel_size": 2,
                "par.use_sequence_parallel_moe": True,
                "comp.pass_config.enable_sp": True,
            },
            None,
            id="accept-async-cam-dp2-tp2-sp",
        ),
        # Model construction, rather than a backend-wide guard, owns effective
        # SP. DeepSeek V2's negative construction regression is kept separately.
        pytest.param(
            {**_NPU_SYNC, "par.use_sequence_parallel_moe": True},
            None,
            id="accept-sync-sp-moe-deferred",
        ),
        pytest.param(
            {**_NPU_SYNC, "comp.pass_config.enable_sp": True},
            None,
            id="accept-sync-pass-sp-deferred",
        ),
        pytest.param(_NPU_DBO, None, id="accept-dbo-eager-dp2"),
        pytest.param(
            {
                **_NPU_DBO,
                "model.enforce_eager": False,
                "comp.cudagraph_mode": CUDAGraphMode.FULL_DECODE_ONLY,
            },
            None,
            id="accept-dbo-graph-dp2",
        ),
        pytest.param(
            {**_NPU_GRAPH, "comp.cudagraph_mode": CUDAGraphMode.FULL},
            None,
            id="accept-acl-graph-full",
        ),
        pytest.param(
            {**_NPU_GRAPH, "comp.cudagraph_mode": CUDAGraphMode.FULL_DECODE_ONLY},
            None,
            id="accept-acl-graph-full-decode-only",
        ),
        pytest.param(
            {**_NPU_DBO, "par.data_parallel_size": 1, "afd.num_attention_ranks": 1},
            _err("DBO requires Attention DP > 1"),
            id="reject-dbo-dp1",
        ),
        pytest.param(
            {**_NPU_DBO, "par.num_ubatches": 3},
            _err("DBO requires exactly two ubatches"),
            id="reject-dbo-three-ubatches",
        ),
        pytest.param(
            {**_NPU_DBO, "speculative_config": object()},
            _err("DBO does not support speculative"),
            id="reject-dbo-speculative",
        ),
        pytest.param(
            {**_NPU_GRAPH, "comp.cudagraph_mode": CUDAGraphMode.FULL_AND_PIECEWISE},
            _err("ACL graph modes FULL"),
            id="reject-acl-graph-full-and-piecewise",
        ),
        pytest.param(
            {**_NPU_ASYNC, "afd.async_dp": False},
            _err("async DP"),
            id="reject-async-cam-sync-dp",
        ),
        pytest.param(
            {**_NPU_ASYNC, "afd.compute_gate_on_attention": False},
            _err("compute_gate_on_attention"),
            id="reject-async-cam-ffn-gate",
        ),
        pytest.param(
            {**_NPU_ASYNC, "model.enforce_eager": False},
            _err("eager"),
            id="reject-async-cam-graph",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.pipeline_parallel_size": 2},
            _err("PP or CP"),
            id="reject-async-cam-pp",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.prefill_context_parallel_size": 2},
            _err("PP or CP"),
            id="reject-async-cam-pcp",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.decode_context_parallel_size": 2},
            _err("PP or CP"),
            id="reject-async-cam-dcp",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.enable_dbo": True},
            _err("DBO"),
            id="reject-async-cam-dbo-1ub",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.use_ubatching": True},
            _err("DBO"),
            id="reject-async-cam-ubatching-1ub",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.enable_elastic_ep": True},
            _err("static expert"),
            id="reject-async-cam-elastic",
        ),
        pytest.param(
            {**_NPU_ASYNC, "par.enable_eplb": True},
            _err("static expert"),
            id="reject-async-cam-eplb",
        ),
    ],
)
def test_npu_v2_validator_outcome(overrides, error):
    config, call = _validator_call(overrides)
    with _expect(error):
        validate_npu_model_runner_v2_config(
            config,
            expected_role=call["expected_role"],
            device_type=call["device_type"] or "npu",
        )


def test_v2_metadata_provider_has_complete_transaction_and_dp_dependencies():
    runner = _runner_for_metadata([])

    first = runner.build_afd_metadata(None, 7)
    second = runner.build_afd_metadata(None, 7)

    assert first.transaction_id == "afd-0"
    assert second.transaction_id == "afd-1"
    assert first.tokens_lens == [7]
    assert first.tokens_unpadded_lens == [7]
    assert runner.build_capture_dp_metadata(9).num_tokens_across_dp_cpu.tolist() == [9]


def _capture_descriptor(num_reqs: int, num_tokens: int, num_ubatches: int = 1):
    return SimpleNamespace(
        cg_mode=CUDAGraphMode.FULL,
        num_ubatches=num_ubatches,
        num_reqs=num_reqs,
        num_tokens=num_tokens,
    )


@pytest.mark.parametrize("real_tokens, expected", [(7, [4, 3]), (3, [3, 0])])
def test_mrv2_stage_sidecars_preserve_native_slices_and_isolate_mutation(
    real_tokens, expected
):
    runner = _runner_for_metadata([])
    # The second request straddles the token boundary, as in native MRV2.
    slices = [
        UBatchSlice(slice(0, 2), slice(0, 4)),
        UBatchSlice(slice(1, 3), slice(4, 8)),
    ]
    native_attention_metadata = [{"layer": object()} for _ in slices]
    native_slot_mappings = [object() for _ in slices]
    contexts = [
        SimpleNamespace(
            additional_kwargs={"platform_key": f"stage-{stage_idx}"},
            attn_metadata=native_attention_metadata[stage_idx],
            slot_mapping=native_slot_mappings[stage_idx],
        )
        for stage_idx in range(len(slices))
    ]
    runner.install_mrv2_ubatch_metadata(slices, contexts, real_tokens)
    stages = [c.additional_kwargs["afd_metadata"] for c in contexts]
    assert [m.stage_idx for m in stages] == [0, 1]
    assert [m.tokens_start_loc for m in stages] == [[0], [4]]
    assert [m.requests_start_loc for m in stages] == [[0], [1]]
    assert [m.tokens_lens for m in stages] == [[4], [4]]
    assert [m.tokens_unpadded_lens for m in stages] == [[n] for n in expected]
    assert all(m.num_stages == 2 for m in stages)
    assert stages[0].transaction_id == stages[1].transaction_id
    assert all(m.connector is runner.connector for m in stages)
    for stage_idx, context in enumerate(contexts):
        assert context.attn_metadata is native_attention_metadata[stage_idx]
        assert context.slot_mapping is native_slot_mappings[stage_idx]
        assert context.additional_kwargs["platform_key"] == f"stage-{stage_idx}"
    stages[0].tokens_lens[0] = 99
    assert stages[1].tokens_lens == [4]
    assert runner._afd_pending_metadata.tokens_lens == [4, 4]


@pytest.mark.parametrize("graph", [False, True])
@pytest.mark.parametrize("dp_size", [1, 2])
def test_mrv2_prepare_sends_one_complete_payload_and_restores_instance(graph, dp_size):
    events: list[str] = []
    runner = _runner_for_metadata(events, data_parallel_size=dp_size)
    slices = [
        UBatchSlice(slice(0, 2), slice(0, 4)),
        UBatchSlice(slice(2, 4), slice(4, 8)),
    ]
    contexts = [SimpleNamespace(additional_kwargs={}) for _ in slices]
    prepared = UBatchState(slices, contexts)
    calls = []

    class NativeUBatch:
        def prepare(self, *args):
            calls.append(args)
            return prepared

    runner.ubatch_runner = NativeUBatch()
    batch = SimpleNamespace(num_tokens=5, num_tokens_after_padding=8, num_reqs=4)
    mode = CUDAGraphMode.FULL if graph else CUDAGraphMode.NONE
    with v2_runner_module._use_afd_ubatch_preparation(runner):
        assert runner.ubatch_runner.prepare(batch, (), None, mode) is prepared
        if graph:
            with v2_runner_module._use_afd_fullgraph_replay_hook(runner, 5):
                runner.cudagraph_manager.run_fullgraph(_capture_descriptor(4, 8, 2))
    assert "prepare" not in vars(runner.ubatch_runner)
    assert calls == [(batch, (), None, mode, False)]
    assert events == ["control_update", "control_send"]
    payload = runner.connector.last_payload
    assert payload.is_graph_replaying is graph
    assert list(payload.dp_metadata_list) == [0, 1]
    assert [
        m.num_tokens_across_dp_cpu.tolist() for m in payload.dp_metadata_list.values()
    ] == [[4] * dp_size, [4] * dp_size]


def test_mrv2_capture_tracker_distinguishes_equal_size_stage_layouts():
    tracker = v2_runner_module._AFDCaptureEventTracker(
        [_capture_descriptor(4, 8), _capture_descriptor(4, 8, 2)]
    )
    assert tracker.consume(4, 8)[1] is True
    assert tracker.consume(4, 8)[1] is False
    assert tracker.consume(4, 8, 2)[1] is True
    assert tracker.consume(4, 8, 2)[1] is False
    tracker.assert_complete()
    wrong = v2_runner_module._AFDCaptureEventTracker([_capture_descriptor(4, 8, 2)])
    with pytest.raises(RuntimeError, match="descriptor/order drift"):
        wrong.consume(4, 8)


@pytest.mark.parametrize("fail_control", [False, True])
@pytest.mark.parametrize("dp_size", [1, 2])
def test_mrv2_ubatch_capture_events_and_exception_restore(fail_control, dp_size):
    events: list[str] = []
    runner = _runner_for_metadata(events, data_parallel_size=dp_size)
    slices = [
        UBatchSlice(slice(0, 2), slice(0, 4)),
        UBatchSlice(slice(2, 4), slice(4, 8)),
    ]
    batch = SimpleNamespace(num_tokens=8, num_tokens_after_padding=8, num_reqs=4)
    payloads = []

    class CaptureConnector(_RecordingConnector):
        def send_dp_metadata_list(self, payload):
            payloads.append(payload)
            if fail_control:
                raise RuntimeError("control failed")
            super().send_dp_metadata_list(payload)

    def native_prepare(*args):
        return UBatchState(
            slices, [SimpleNamespace(additional_kwargs={}) for _ in slices]
        )

    runner.connector = CaptureConnector(events)
    runner.ubatch_runner = SimpleNamespace(prepare=native_prepare)
    tracker = v2_runner_module._AFDCaptureEventTracker([_capture_descriptor(4, 8, 2)])

    def capture():
        with v2_runner_module._use_afd_ubatch_preparation(runner, tracker):
            for _ in (True, False):
                runner.ubatch_runner.prepare(batch, (), None, CUDAGraphMode.FULL, True)

    if fail_control:
        with pytest.raises(RuntimeError, match="control failed"):
            capture()
    else:
        capture()
        tracker.assert_complete()
        assert [
            (p.is_warmup, p.is_graph_capturing, p.is_graph_replaying) for p in payloads
        ] == [(True, False, False), (False, True, False)]
        assert all(
            metadata.num_tokens_across_dp_cpu.tolist() == [4] * dp_size
            for payload in payloads
            for metadata in payload.dp_metadata_list.values()
        )
        assert events == ["control_update", "control_send"] * 2
    assert runner.ubatch_runner.prepare is native_prepare


@pytest.mark.parametrize(
    ("data_parallel_size", "expected_dp_counts"),
    [
        (1, [[8], [8], [16], [16]]),
        (2, [[8, 8], [8, 8], [16, 16], [16, 16]]),
    ],
    ids=["dp1", "dp2"],
)
def test_v2_capture_publishes_two_descriptor_events_outside_graph_body(
    monkeypatch,
    data_parallel_size,
    expected_dp_counts,
):
    events: list[str] = []
    runner = _runner_for_metadata(
        events,
        data_parallel_size=data_parallel_size,
    )
    descriptors = [_capture_descriptor(1, 8), _capture_descriptor(2, 16)]
    runner.cudagraph_manager = SimpleNamespace(
        _capture_descs={CUDAGraphMode.FULL: descriptors},
        _max_full_descs_to_capture=None,
    )
    in_graph_body = False
    payloads = []
    captured_metadata = []
    prepare_calls = []

    class CaptureConnector(_RecordingConnector):
        def update_state_from_dp_metadata(self, payload):
            assert not in_graph_body
            super().update_state_from_dp_metadata(payload)

        def send_dp_metadata_list(self, payload):
            assert not in_graph_body
            payloads.append(payload)
            super().send_dp_metadata_list(payload)

    runner.connector = CaptureConnector(events)

    def original_prepare(num_reqs, num_tokens, *args, **kwargs):
        prepare_calls.append((num_reqs, num_tokens))
        return f"attention-state-{len(prepare_calls)}"

    original_create = afd_forward_context.forward_context_module.create_forward_context

    def native_create_forward_context():
        return ForwardContext(
            no_compile_layers={},
            attn_metadata={},
            slot_mapping={},
            additional_kwargs={},
            ubatch_slices=None,
            dp_metadata=None,
            batch_descriptor=None,
            cudagraph_runtime_mode=CUDAGraphMode.FULL,
        )

    def native_capture(self, *, profile_only=False):
        nonlocal in_graph_body
        for desc in descriptors:
            for _ in (True, False):
                state = cudagraph_utils.prepare_inputs_to_capture(
                    desc.num_reqs,
                    desc.num_tokens,
                    None,
                    None,
                    None,
                    [],
                    None,
                    True,
                )
                assert state == f"attention-state-{len(prepare_calls)}"
                events.append("graph_enter")
                in_graph_body = True
                context = (
                    afd_forward_context.forward_context_module.create_forward_context()
                )
                captured_metadata.append(
                    context.additional_kwargs["afd_metadata"].clone(),
                )
                in_graph_body = False
                events.append("graph_exit")
        return 23

    monkeypatch.setattr(
        cudagraph_utils,
        "prepare_inputs_to_capture",
        original_prepare,
    )
    monkeypatch.setattr(
        afd_forward_context.forward_context_module,
        "create_forward_context",
        native_create_forward_context,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "capture_model", native_capture)

    assert AFDAttentionModelRunnerV2.capture_model(runner) == 23

    assert prepare_calls == [(1, 8), (1, 8), (2, 16), (2, 16)]
    assert [(p.is_warmup, p.is_graph_capturing) for p in payloads] == [
        (True, False),
        (False, True),
        (True, False),
        (False, True),
    ]
    assert [
        p.dp_metadata_list[0].num_tokens_across_dp_cpu.tolist() for p in payloads
    ] == expected_dp_counts
    assert [m.tokens_lens for m in captured_metadata] == [[8], [8], [16], [16]]
    assert [m.tokens_unpadded_lens for m in captured_metadata] == [
        [8],
        [8],
        [16],
        [16],
    ]
    assert events == [
        "control_update",
        "control_send",
        "graph_enter",
        "graph_exit",
        "control_update",
        "control_send",
        "graph_enter",
        "graph_exit",
        "control_update",
        "control_send",
        "graph_enter",
        "graph_exit",
        "control_update",
        "control_send",
        "graph_enter",
        "graph_exit",
    ]
    assert cudagraph_utils.prepare_inputs_to_capture is original_prepare
    assert (
        afd_forward_context.forward_context_module.create_forward_context
        is native_create_forward_context
    )
    assert native_create_forward_context is not original_create


@pytest.mark.parametrize("failure", ["prepare", "control", "forward"])
def test_v2_capture_restores_symbol_and_sidecars_on_failure(monkeypatch, failure):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    descriptor = _capture_descriptor(1, 8)
    runner.cudagraph_manager = SimpleNamespace(
        _capture_descs={CUDAGraphMode.FULL: [descriptor]},
        _max_full_descs_to_capture=None,
    )
    previous_metadata = object()
    runner._afd_pending_metadata = previous_metadata
    runner._afd_suppress_metadata_send = False
    runner._is_warmup = False
    runner._afd_is_graph_capturing = False

    def original_prepare(*args, **kwargs):
        if failure == "prepare":
            raise RuntimeError("prepare failed")
        return "attention-state"

    if failure == "control":

        def fail_control(payload):
            raise RuntimeError("control failed")

        runner.connector.send_dp_metadata_list = fail_control

    def native_create_forward_context():
        return ForwardContext(
            no_compile_layers={},
            attn_metadata={},
            slot_mapping={},
            additional_kwargs={},
            ubatch_slices=None,
            dp_metadata=None,
            batch_descriptor=None,
            cudagraph_runtime_mode=CUDAGraphMode.FULL,
        )

    def native_capture(self, *, profile_only=False):
        cudagraph_utils.prepare_inputs_to_capture(
            descriptor.num_reqs,
            descriptor.num_tokens,
            None,
            None,
            None,
            [],
            None,
            True,
        )
        afd_forward_context.forward_context_module.create_forward_context()
        if failure == "forward":
            raise RuntimeError("forward failed")
        return 1

    monkeypatch.setattr(
        cudagraph_utils,
        "prepare_inputs_to_capture",
        original_prepare,
    )
    monkeypatch.setattr(
        afd_forward_context.forward_context_module,
        "create_forward_context",
        native_create_forward_context,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "capture_model", native_capture)

    with pytest.raises(RuntimeError, match=f"{failure} failed"):
        AFDAttentionModelRunnerV2.capture_model(runner)

    assert cudagraph_utils.prepare_inputs_to_capture is original_prepare
    assert runner._afd_pending_metadata is previous_metadata
    assert runner._afd_suppress_metadata_send is False
    assert runner._is_warmup is False
    assert runner._afd_is_graph_capturing is False


@pytest.mark.parametrize(
    ("drift", "expected_prepare_count"),
    [
        ("descriptor", 0),
        ("missing", 3),
        ("extra", 5),
        ("order", 2),
        ("shape", 1),
    ],
)
def test_v2_capture_source_drift_fails_loud_and_restores(
    monkeypatch,
    drift,
    expected_prepare_count,
):
    runner = _runner_for_metadata([])
    descriptors = [_capture_descriptor(1, 8), _capture_descriptor(2, 16)]
    if drift == "descriptor":
        descriptors[0].cg_mode = CUDAGraphMode.PIECEWISE
    runner.cudagraph_manager = SimpleNamespace(
        _capture_descs={CUDAGraphMode.FULL: descriptors},
        _max_full_descs_to_capture=None,
    )
    calls = [(1, 8), (1, 8), (2, 16), (2, 16)]
    if drift == "missing":
        calls.pop()
    elif drift == "extra":
        calls.append((2, 16))
    elif drift == "order":
        calls[1], calls[2] = calls[2], calls[1]
    elif drift == "shape":
        calls[0] = (1, 9)
    original_calls = []

    def original_prepare(num_reqs, num_tokens, *args, **kwargs):
        original_calls.append((num_reqs, num_tokens))
        return "attention-state"

    def native_capture(self, *, profile_only=False):
        for num_reqs, num_tokens in calls:
            cudagraph_utils.prepare_inputs_to_capture(
                num_reqs,
                num_tokens,
                None,
                None,
                None,
                [],
                None,
                True,
            )
        return 1

    monkeypatch.setattr(
        cudagraph_utils,
        "prepare_inputs_to_capture",
        original_prepare,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "capture_model", native_capture)

    with pytest.raises(RuntimeError, match="descriptor|call count|extra"):
        AFDAttentionModelRunnerV2.capture_model(runner)

    assert cudagraph_utils.prepare_inputs_to_capture is original_prepare
    assert original_calls == calls[:expected_prepare_count]


def test_v2_capture_profile_only_truncates_tracker_and_forwards_flag(monkeypatch):
    """Mirror the 0.30.0 memory-profiling capture: the manager truncates the
    FULL descriptor list to ``_max_full_descs_to_capture`` and the AFD wrapper
    must forward ``profile_only`` while pairing exactly the captured subset."""
    events: list[str] = []
    runner = _runner_for_metadata(events)
    descriptors = [
        _capture_descriptor(1, 8),
        _capture_descriptor(2, 16),
        _capture_descriptor(3, 32),
    ]
    runner.cudagraph_manager = SimpleNamespace(
        _capture_descs={CUDAGraphMode.FULL: descriptors},
        _max_full_descs_to_capture=2,
    )
    forwarded_profile_only = []
    prepare_calls = []

    def original_prepare(num_reqs, num_tokens, *args, **kwargs):
        prepare_calls.append((num_reqs, num_tokens))
        return "attention-state"

    def native_capture(self, *, profile_only=False):
        forwarded_profile_only.append(profile_only)
        # Native capture() truncates FULL descs the same way before pairing.
        for desc in descriptors[: self.cudagraph_manager._max_full_descs_to_capture]:
            for _ in (True, False):
                cudagraph_utils.prepare_inputs_to_capture(
                    desc.num_reqs,
                    desc.num_tokens,
                    None,
                    None,
                    None,
                    [],
                    None,
                    True,
                )
        return 42

    monkeypatch.setattr(
        cudagraph_utils,
        "prepare_inputs_to_capture",
        original_prepare,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "capture_model", native_capture)

    assert AFDAttentionModelRunnerV2.capture_model(runner, profile_only=True) == 42

    assert forwarded_profile_only == [True]
    assert prepare_calls == [(1, 8), (1, 8), (2, 16), (2, 16)]
    assert cudagraph_utils.prepare_inputs_to_capture is original_prepare


def test_v2_capture_profile_only_rejects_partial_event_stream(monkeypatch):
    """Without truncation the third descriptor's events never arrive, so the
    wrapper must fail loudly instead of silently skipping AFD payloads."""
    events: list[str] = []
    runner = _runner_for_metadata(events)
    descriptors = [_capture_descriptor(1, 8), _capture_descriptor(2, 16)]
    runner.cudagraph_manager = SimpleNamespace(
        _capture_descs={CUDAGraphMode.FULL: descriptors},
        _max_full_descs_to_capture=None,
    )

    def original_prepare(num_reqs, num_tokens, *args, **kwargs):
        return "attention-state"

    def native_capture(self, *, profile_only=False):
        # Simulates a capture that stops after the first descriptor.
        for _ in (True, False):
            cudagraph_utils.prepare_inputs_to_capture(
                descriptors[0].num_reqs,
                descriptors[0].num_tokens,
                None,
                None,
                None,
                [],
                None,
                True,
            )
        return 0

    monkeypatch.setattr(
        cudagraph_utils,
        "prepare_inputs_to_capture",
        original_prepare,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "capture_model", native_capture)

    with pytest.raises(RuntimeError, match="call count"):
        AFDAttentionModelRunnerV2.capture_model(runner, profile_only=True)

    assert cudagraph_utils.prepare_inputs_to_capture is original_prepare


@pytest.mark.parametrize(
    ("data_parallel_rank", "real_tokens"),
    [(0, 3), (1, 1)],
    ids=["rank0-real3", "rank1-idle-real1"],
)
def test_v2_dp2_repeated_fullgraph_replay_sends_local_real_and_padded_tokens(
    monkeypatch,
    data_parallel_rank,
    real_tokens,
):
    events: list[str] = []
    runner = _runner_for_metadata(
        events,
        data_parallel_size=2,
        data_parallel_rank=data_parallel_rank,
    )
    runner.vllm_config.compilation_config.cudagraph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY
    )
    manager = SimpleNamespace()
    runner.cudagraph_manager = manager
    descriptor = SimpleNamespace(num_tokens=8, num_ubatches=1)
    payloads = []
    metadata_seen = []
    replay_returns: list[str] = []

    class ReplayConnector(_RecordingConnector):
        def send_dp_metadata_list(self, payload):
            payloads.append(payload)
            super().send_dp_metadata_list(payload)

    runner.connector = ReplayConnector(events)

    def native_replay(self, desc):
        metadata = runner._afd_pending_metadata
        metadata_seen.append(
            (list(metadata.tokens_lens), list(metadata.tokens_unpadded_lens)),
        )
        events.append("native_replay")
        return f"replay-{len(metadata_seen)}"

    def native_execute(self, *args, **kwargs):
        assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
        for _ in range(2):
            replay_returns.append(manager.run_fullgraph(descriptor))
        return "native-result"

    native_bound_replay = MethodType(native_replay, manager)
    manager.run_fullgraph = native_bound_replay
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert (
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(real_tokens),
        )
        == "native-result"
    )

    assert replay_returns == ["replay-1", "replay-2"]
    assert metadata_seen == [
        ([8], [real_tokens]),
        ([8], [real_tokens]),
    ]
    assert [(p.is_warmup, p.is_graph_capturing) for p in payloads] == [
        (False, False),
        (False, False),
    ]
    assert [
        p.dp_metadata_list[0].num_tokens_across_dp_cpu.tolist() for p in payloads
    ] == [[8, 8], [8, 8]]
    assert events == [
        "control_update",
        "control_send",
        "native_replay",
        "control_update",
        "control_send",
        "native_replay",
    ]
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    assert manager.__dict__["run_fullgraph"] is native_bound_replay
    assert runner._afd_pending_metadata is None


def test_v2_dp2_zero_work_without_native_replay_sends_no_control(monkeypatch):
    events: list[str] = []
    runner = _runner_for_metadata(
        events,
        data_parallel_size=2,
        data_parallel_rank=1,
    )
    runner.vllm_config.compilation_config.cudagraph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY
    )
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph

    def native_execute(self, *args, **kwargs):
        return "idle-result"

    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert (
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(0),
        )
        == "idle-result"
    )
    assert events == []
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    assert runner._afd_pending_metadata is None


def test_v2_replay_exception_restores_manager_and_sidecars(monkeypatch):
    runner = _runner_for_metadata([])
    runner.vllm_config.compilation_config.cudagraph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY
    )
    manager = SimpleNamespace()
    runner.cudagraph_manager = manager
    descriptor = SimpleNamespace(num_tokens=8, num_ubatches=1)
    previous_metadata = object()
    runner._afd_pending_metadata = previous_metadata

    def native_replay(self, desc):
        raise RuntimeError("replay failed")

    def native_execute(self, *args, **kwargs):
        return manager.run_fullgraph(descriptor)

    native_bound_replay = MethodType(native_replay, manager)
    manager.run_fullgraph = native_bound_replay
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph
    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    with pytest.raises(RuntimeError, match="replay failed"):
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(3),
        )

    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    assert manager.__dict__["run_fullgraph"] is native_bound_replay
    assert runner._afd_pending_metadata is previous_metadata
    assert runner._afd_suppress_metadata_send is False
    assert runner._is_warmup is False
    assert runner._afd_is_graph_capturing is False


def test_v2_graph_miss_uses_provider_once_without_replay_control(monkeypatch):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    runner.vllm_config.compilation_config.cudagraph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY
    )

    def unexpected_replay(_desc):
        pytest.fail("graph miss must not replay a captured graph")

    monkeypatch.setattr(runner.cudagraph_manager, "run_fullgraph", unexpected_replay)
    context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=3),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )

    def original_create_forward_context():
        return context

    def native_execute(self, *args, **kwargs):
        native_context = (
            afd_forward_context.forward_context_module.create_forward_context()
        )
        native_context.additional_kwargs["afd_metadata"].connector.send_attn_output(
            None,
            None,
        )
        return "eager-result"

    monkeypatch.setattr(
        afd_forward_context.forward_context_module,
        "create_forward_context",
        original_create_forward_context,
    )
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph
    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert (
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(3),
        )
        == "eager-result"
    )
    assert events == ["control_update", "control_send", "data"]
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay


def test_v2_eager_execute_does_not_replace_fullgraph_replay(monkeypatch):
    runner = _runner_for_metadata([])
    replay_symbol_during_execute = []

    def native_replay(self, desc):
        return None

    def native_execute(self, *args, **kwargs):
        replay_symbol_during_execute.append(
            cudagraph_utils.CudaGraphManager.run_fullgraph,
        )
        return "eager-result"

    monkeypatch.setattr(
        cudagraph_utils.CudaGraphManager,
        "run_fullgraph",
        native_replay,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert (
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(3),
        )
        == "eager-result"
    )
    assert replay_symbol_during_execute == [native_replay]
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is native_replay


def test_v2_profile_before_graph_manager_uses_provider_without_replay_hook(
    monkeypatch,
):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    runner.vllm_config.compilation_config.cudagraph_mode = (
        CUDAGraphMode.FULL_DECODE_ONLY
    )
    runner.cudagraph_manager = None
    context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=7),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )
    forward_context_module = afd_forward_context.forward_context_module

    def original_create_forward_context():
        return context

    monkeypatch.setattr(
        forward_context_module,
        "create_forward_context",
        original_create_forward_context,
    )

    def unexpected_replay_hook(*_args, **_kwargs):
        raise AssertionError("profile execution must not install the replay hook")

    monkeypatch.setattr(
        v2_runner_module,
        "_use_afd_fullgraph_replay_hook",
        unexpected_replay_hook,
    )
    class_replay = cudagraph_utils.CudaGraphManager.run_fullgraph
    execute_calls = []

    def native_execute(self, *args, **kwargs):
        execute_calls.append(kwargs)
        assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
        native_context = forward_context_module.create_forward_context()
        native_context.additional_kwargs["afd_metadata"].connector.send_attn_output(
            None,
            None,
        )
        return "profile-result"

    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert (
        AFDAttentionModelRunnerV2.execute_model(
            runner,
            _scheduler_output(7),
            is_profile=True,
        )
        == "profile-result"
    )

    assert execute_calls == [
        {
            "dummy_run": False,
            "skip_attn_for_dummy_run": False,
            "is_profile": True,
            "context_len": 0,
            "valid_dummy_state_slots": False,
        },
    ]
    assert events == ["control_update", "control_send", "data"]
    assert cudagraph_utils.CudaGraphManager.run_fullgraph is class_replay
    assert runner._afd_pending_metadata is None
    assert runner._afd_suppress_metadata_send is False
    assert runner._is_warmup is False
    assert runner._afd_is_graph_capturing is False
    assert (
        forward_context_module.create_forward_context is original_create_forward_context
    )


@pytest.mark.parametrize("need_eager", [False, True])
def test_dp1_native_token_seams_preserve_real_token_count(need_eager):
    cudagraph_manager = None if need_eager else _no_graph_model_manager()
    descriptor, dp_metadata = dp_utils.dispatch_cg_and_sync_dp(
        cudagraph_manager=cudagraph_manager,
        num_reqs=2,
        num_tokens=7,
        uniform_token_count=None,
        dp_size=1,
        dp_rank=0,
        need_eager=need_eager,
    )
    assert dp_metadata is None
    assert descriptor.cg_mode is CUDAGraphMode.NONE
    assert descriptor.num_tokens == 7


def test_dp1_ordinary_native_path_binds_unpadded_afd_metadata():
    manager = _no_graph_model_manager()
    descriptor, dp_metadata = dp_utils.dispatch_cg_and_sync_dp(
        cudagraph_manager=manager,
        num_reqs=2,
        num_tokens=7,
        uniform_token_count=None,
        dp_size=1,
        dp_rank=0,
        need_eager=False,
    )
    assert dp_metadata is None

    runner = _runner_for_metadata([])
    context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=descriptor.num_tokens),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )
    runner.install_afd_metadata_on_forward_context(context)
    metadata = context.additional_kwargs["afd_metadata"]
    assert metadata.tokens_lens == [7]
    assert metadata.tokens_unpadded_lens == [7]
    payload = runner.connector.last_payload
    assert payload.dp_metadata_list[0].num_tokens_across_dp_cpu.tolist() == [7]


@pytest.mark.parametrize(
    ("is_profile", "skip_attn"),
    [(False, False), (True, True)],
)
def test_native_v2_dummy_profile_thin_path_uses_afd_execute_wrapper(
    monkeypatch,
    is_profile,
    skip_attn,
):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    runner.max_num_reqs = 2
    runner.lora_config = None
    runner.is_first_pp_rank = True
    runner.is_last_pp_rank = False

    class KVConnector:
        def set_disabled(self, disabled):
            self.disabled = disabled

    runner.kv_connector = KVConnector()
    context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=7),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )

    def original_create_forward_context():
        return context

    forward_context_module = afd_forward_context.forward_context_module
    monkeypatch.setattr(
        forward_context_module,
        "create_forward_context",
        original_create_forward_context,
    )
    execute_calls: list[tuple[bool, bool, bool]] = []

    def native_execute(
        self,
        scheduler_output,
        intermediate_tensors=None,
        dummy_run=False,
        skip_attn_for_dummy_run=False,
        is_profile=False,
        context_len=0,
        valid_dummy_state_slots=False,
    ):
        execute_calls.append(
            (dummy_run, skip_attn_for_dummy_run, is_profile),
        )
        native_context = forward_context_module.create_forward_context()
        native_context.additional_kwargs["afd_metadata"].connector.send_attn_output(
            None,
            None,
        )

    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    assert AFDAttentionModelRunnerV2._dummy_run(
        runner,
        7,
        skip_attn=skip_attn,
        is_profile=is_profile,
        skip_eplb=True,
    ) == (None, None)

    assert execute_calls == [(True, skip_attn, is_profile)]
    assert events == ["control_update", "control_send", "data"]
    assert runner._afd_pending_metadata is None
    assert runner.kv_connector.disabled is False
    assert (
        forward_context_module.create_forward_context is original_create_forward_context
    )


@pytest.mark.parametrize("raise_in_native", [False, True])
def test_v2_provider_orders_control_before_data_and_always_restores(
    monkeypatch,
    raise_in_native,
):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=7),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )

    def original_create_forward_context():
        return context

    forward_context_module = afd_forward_context.forward_context_module
    monkeypatch.setattr(
        forward_context_module,
        "create_forward_context",
        original_create_forward_context,
    )

    def native_execute(self, *args, **kwargs):
        native_context = forward_context_module.create_forward_context()
        native_context.additional_kwargs["afd_metadata"].connector.send_attn_output(
            None,
            None,
        )
        if raise_in_native:
            raise RuntimeError("native execute failed")
        return "native-result"

    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    if raise_in_native:
        with pytest.raises(RuntimeError, match="native execute failed"):
            AFDAttentionModelRunnerV2.execute_model(runner, _scheduler_output(7))
    else:
        assert (
            AFDAttentionModelRunnerV2.execute_model(
                runner,
                _scheduler_output(7),
            )
            == "native-result"
        )

    assert events == ["control_update", "control_send", "data"]
    assert runner._afd_pending_metadata is None
    assert (
        forward_context_module.create_forward_context is original_create_forward_context
    )
    assert runner.prof.steps == 1


def _active_native_kv_connector(runner, loaded_contexts):
    # Exercise native KV-only context creation with a device-free transport.
    # These are the only compilation fields read by create_forward_context.
    runner.vllm_config.compilation_config.fast_moe_cold_start = False
    runner.vllm_config.compilation_config.static_forward_context = {}
    connector = object.__new__(ActiveKVConnector)
    connector.vllm_config = runner.vllm_config
    connector._disabled = False
    connector._pending_load_kwargs = None
    connector.kv_connector = SimpleNamespace(
        handle_preemptions=lambda _metadata: None,
        bind_connector_metadata=lambda _metadata: None,
        start_load_kv=lambda context, **_kwargs: loaded_contexts.append(context),
        finish_forward=lambda: None,
        wait_for_save=lambda: None,
        get_transfer_results=lambda _finished: SimpleNamespace(
            finished_sending=set(),
            finished_recving={"kv-only"},
            failed_recving=set(),
        ),
        get_block_ids_with_load_errors=set,
        get_kv_connector_stats=lambda: None,
        get_kv_connector_kv_cache_events=lambda: None,
        build_connector_worker_meta=lambda: None,
        clear_connector_metadata=lambda: None,
    )
    return connector


@pytest.mark.parametrize("has_sync_kv_loads", [False, True])
def test_v2_idle_native_kv_helper_context_does_not_publish_afd_control(
    has_sync_kv_loads,
):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    loaded_contexts: list[ForwardContext] = []
    connector = _active_native_kv_connector(runner, loaded_contexts)
    scheduler_output = SimpleNamespace(
        total_num_scheduled_tokens=0,
        kv_connector_metadata=object(),
        has_sync_kv_loads=has_sync_kv_loads,
        finished_req_ids=set(),
    )

    with (
        afd_forward_context.use_afd_metadata_provider(
            runner.install_afd_metadata_on_forward_context
        ),
        override_forward_context(None),
    ):
        output = connector.no_forward(scheduler_output)

    assert output.kv_connector_output.finished_recving == {"kv-only"}
    assert len(loaded_contexts) == 1
    context = loaded_contexts[0]
    assert context.attn_metadata is None
    assert context.batch_descriptor is None
    assert context.ubatch_slices is None
    assert "afd_metadata" not in context.additional_kwargs
    assert events == []
    assert runner._afd_pending_metadata is None
    assert runner._afd_transaction_counter == 0


def test_v2_eager_native_kv_helper_context_preserves_pending_afd_transaction():
    events: list[str] = []
    runner = _runner_for_metadata(events)
    model_context = ForwardContext(
        no_compile_layers={},
        attn_metadata={},
        slot_mapping={},
        additional_kwargs={},
        dp_metadata=None,
        ubatch_slices=None,
        batch_descriptor=BatchDescriptor(num_tokens=7),
        cudagraph_runtime_mode=CUDAGraphMode.NONE,
    )
    runner.install_afd_metadata_on_forward_context(model_context)
    pending_metadata = runner._afd_pending_metadata
    loaded_contexts: list[ForwardContext] = []
    connector = _active_native_kv_connector(runner, loaded_contexts)
    scheduler_output = SimpleNamespace(
        total_num_scheduled_tokens=7,
        kv_connector_metadata=object(),
        has_sync_kv_loads=False,
        finished_req_ids=set(),
    )

    with afd_forward_context.use_afd_metadata_provider(
        runner.install_afd_metadata_on_forward_context
    ):
        with override_forward_context(model_context):
            connector.pre_forward(scheduler_output)
            connector.finish_forward()
        # Native eager execution starts asynchronous KV loading after leaving
        # the model context, while the AFD execute_model provider is still live.
        with override_forward_context(None):
            output = connector.post_forward(scheduler_output.finished_req_ids)

    assert output.finished_recving == {"kv-only"}
    assert len(loaded_contexts) == 1
    context = loaded_contexts[0]
    assert context.attn_metadata is None
    assert context.batch_descriptor is None
    assert "afd_metadata" not in context.additional_kwargs
    assert events == ["control_update", "control_send"]
    assert runner._afd_pending_metadata is pending_metadata
    assert runner._afd_transaction_counter == 1
    assert runner._afd_suppress_metadata_send is False


def test_v2_repeated_execute_reinstalls_provider_and_advances_transactions(
    monkeypatch,
):
    events: list[str] = []
    runner = _runner_for_metadata(events)
    contexts: list[ForwardContext] = []
    transaction_ids: list[str] = []

    def original_create_forward_context():
        context = ForwardContext(
            no_compile_layers={},
            attn_metadata={},
            slot_mapping={},
            additional_kwargs={},
            dp_metadata=None,
            ubatch_slices=None,
            batch_descriptor=BatchDescriptor(num_tokens=7),
            cudagraph_runtime_mode=CUDAGraphMode.NONE,
        )
        contexts.append(context)
        return context

    forward_context_module = afd_forward_context.forward_context_module
    monkeypatch.setattr(
        forward_context_module,
        "create_forward_context",
        original_create_forward_context,
    )

    def native_execute(self, *args, **kwargs):
        context = forward_context_module.create_forward_context()
        metadata = context.additional_kwargs["afd_metadata"]
        transaction_ids.append(metadata.transaction_id)
        metadata.connector.send_attn_output(None, None)
        return "native-result"

    monkeypatch.setattr(native_v2.GPUModelRunner, "execute_model", native_execute)

    for _ in range(2):
        assert (
            AFDAttentionModelRunnerV2.execute_model(
                runner,
                _scheduler_output(7),
            )
            == "native-result"
        )
        assert runner._afd_pending_metadata is None
        assert (
            forward_context_module.create_forward_context
            is original_create_forward_context
        )

    assert len(contexts) == 2
    assert transaction_ids == ["afd-0", "afd-1"]
    assert events == [
        "control_update",
        "control_send",
        "data",
        "control_update",
        "control_send",
        "data",
    ]
    assert runner.prof.steps == 2


@pytest.mark.parametrize("failure", ["profiler", "native", "connector"])
def test_v2_shutdown_runs_all_cleanup_layers_when_each_layer_fails(
    monkeypatch,
    failure,
):
    events: list[str] = []
    runner = object.__new__(AFDAttentionModelRunnerV2)
    runner.prof = _StepProfiler()
    runner._afd_pending_metadata = object()
    runner.connector = _RecordingConnector(events)

    def stop_profiler(profiler):
        events.append("profiler")
        if failure == "profiler":
            raise RuntimeError("profiler failed")

    def native_shutdown(self):
        events.append("native")
        if failure == "native":
            raise RuntimeError("native failed")

    def close_connector():
        events.append("connector")
        if failure == "connector":
            raise RuntimeError("connector failed")

    monkeypatch.setattr(runner.connector, "close", close_connector)
    monkeypatch.setattr(
        "afd_plugin.v1.worker.attention_model_runner_v2.stop_afd_gpu_profiler",
        stop_profiler,
    )
    monkeypatch.setattr(native_v2.GPUModelRunner, "shutdown", native_shutdown)

    with pytest.raises(RuntimeError, match=failure):
        AFDAttentionModelRunnerV2.shutdown(runner)

    assert events == ["profiler", "native", "connector"]
    assert runner._afd_pending_metadata is None


def _patch_v2_constructor_dependencies(monkeypatch, connector):
    config = _v2_config()

    monkeypatch.setattr(
        (
            "afd_plugin.v1.worker.attention_model_runner_v2."
            "validate_gpu_model_runner_v2_config"
        ),
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        "afd_plugin.v1.worker.attention_model_runner_v2._resolve_world_ranks",
        lambda: (0, 0),
    )
    monkeypatch.setattr(
        (
            "afd_plugin.v1.worker.attention_model_runner_v2."
            "AFDConnectorFactory.create_connector"
        ),
        lambda *args, **kwargs: connector,
    )
    return config


def test_v2_load_model_initializes_connector_after_native_load(monkeypatch):
    events: list[str] = []

    class Connector:
        is_initialized = False

        def init_afd_connector(self):
            events.append("connector_init")
            self.is_initialized = True

    def native_load(self, load_dummy_weights=False, *args, **kwargs):
        events.append(f"native_load:{load_dummy_weights}")

    runner = object.__new__(AFDAttentionModelRunnerV2)
    runner.connector = Connector()
    monkeypatch.setattr(native_v2.GPUModelRunner, "load_model", native_load)

    runner.load_model(load_dummy_weights=True)

    assert events == ["native_load:True", "connector_init"]
    assert runner.connector.is_initialized


def test_v2_load_model_reports_moe_layers_to_routed_connector(monkeypatch):
    """An ``AFDRoutedExpertsConnector`` receives the MoE layers Attention
    dispatches, which every rank checks against the FFN's.

    Why: dispatch and combine run once per MoE layer on every rank.
    """
    connector = FakeRoutedConnector()
    runner = object.__new__(AFDAttentionModelRunnerV2)
    runner.connector = connector
    runner.model = SimpleNamespace(get_experts_layer_indices=lambda: [1, 3])
    monkeypatch.setattr(
        native_v2.GPUModelRunner, "load_model", lambda self, *args, **kwargs: None
    )
    monkeypatch.setattr(AFDAttentionModelRunnerV2, "get_model", lambda self: self.model)

    runner.load_model()

    assert connector.init_kwargs == {
        "moe_layer_indices": (1, 3),
        "local_experts": None,
    }


def test_v2_constructor_rejects_missing_control_plane_and_cleans_native(
    monkeypatch,
):
    events: list[str] = []

    class Connector:
        control_plane = None

        def close(self):
            events.append("connector")

    def native_init(self, vllm_config, device):
        events.append("native_init")
        self.vllm_config = vllm_config

    def native_shutdown(self):
        events.append("native_shutdown")

    monkeypatch.setattr(native_v2.GPUModelRunner, "__init__", native_init)
    monkeypatch.setattr(native_v2.GPUModelRunner, "shutdown", native_shutdown)
    config = _patch_v2_constructor_dependencies(monkeypatch, Connector())

    with pytest.raises(RuntimeError, match="control-plane"):
        AFDAttentionModelRunnerV2(config, torch.device("cpu"))

    assert events == ["native_init", "connector", "native_shutdown"]


def test_v2_constructor_defers_connector_initialization(monkeypatch):
    events: list[str] = []

    class Connector:
        control_plane = object()

        def close(self):
            events.append("connector")

    def native_init(self, vllm_config, device):
        events.append("native_init")
        self.vllm_config = vllm_config

    monkeypatch.setattr(native_v2.GPUModelRunner, "__init__", native_init)
    monkeypatch.setattr(
        native_v2.GPUModelRunner,
        "shutdown",
        lambda self: events.append("native_shutdown"),
    )
    monkeypatch.setattr(
        "afd_plugin.v1.worker.attention_model_runner_v2.create_afd_gpu_profiler",
        lambda role: _StepProfiler(),
    )
    connector = Connector()
    config = _patch_v2_constructor_dependencies(monkeypatch, connector)

    runner = AFDAttentionModelRunnerV2(config, torch.device("cpu"))

    assert runner.connector is connector
    assert events == ["native_init"]


@pytest.mark.parametrize(
    ("worker_module", "worker_cls", "runner_name", "native_module"),
    [
        (
            attention_worker,
            attention_worker.AFDAttentionWorker,
            "AFDAttentionModelRunnerV2",
            native_v2,
        ),
        (ffn_worker, AFDFFNWorker, "GPUFFNModelRunner", native_v2),
    ],
)
def test_v2_worker_directly_constructs_one_plugin_runner(
    monkeypatch,
    worker_module,
    worker_cls,
    runner_name,
    native_module,
):
    config = _v2_config(role="ffn" if worker_cls is AFDFFNWorker else "attention")
    worker = _prepare_worker(worker_cls, config, use_v2=True)
    _RunnerRecorder.instances.clear()
    _NativeRunnerSentinel.instances = 0

    monkeypatch.setattr(worker_module, runner_name, _RunnerRecorder)
    monkeypatch.setattr(native_module, "GPUModelRunner", _NativeRunnerSentinel)

    def unexpected_v1_construction(*_args, **_kwargs):
        pytest.fail("AFD GPU startup constructed native ModelRunnerV1")

    monkeypatch.setattr(native_v1, "GPUModelRunner", unexpected_v1_construction)
    monkeypatch.setattr(worker_module.Worker, "init_device", _fake_worker_init)
    monkeypatch.setattr(
        worker_module,
        "assert_compatible_afd_stack",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(worker_module.torch.accelerator, "empty_cache", lambda: None)

    worker.init_device()

    assert len(_RunnerRecorder.instances) == 1
    assert _NativeRunnerSentinel.instances == 0
    assert native_module.GPUModelRunner is _NativeRunnerSentinel
    assert worker.model_runner.__class__ is _RunnerRecorder
    assert worker.model_config is worker.vllm_config.model_config
    assert worker.model_config.hf_config.architectures == [
        "AFDDeepseekV2ForCausalLM",
    ]
    _construct_like_native_worker(worker)
    assert _NativeRunnerSentinel.instances == 1


@pytest.mark.parametrize(
    ("worker_module", "worker_cls", "runner_name"),
    [
        (
            attention_worker,
            attention_worker.AFDAttentionWorker,
            "AFDAttentionModelRunnerV2",
        ),
        (ffn_worker, AFDFFNWorker, "GPUFFNModelRunner"),
    ],
)
def test_gpu_workers_reject_v1_before_native_or_plugin_runner_construction(
    monkeypatch, worker_module, worker_cls, runner_name
):
    config = _v2_config(
        role="ffn" if worker_cls is AFDFFNWorker else "attention",
        use_v2=False,
    )
    worker = _prepare_worker(worker_cls, config, use_v2=False)
    original_model_config = worker.model_config

    def unexpected_construction(*_args, **_kwargs):
        pytest.fail("V1 configuration reached worker/runner initialization")

    monkeypatch.setattr(worker_module, runner_name, unexpected_construction)
    monkeypatch.setattr(native_v1, "GPUModelRunner", unexpected_construction)
    monkeypatch.setattr(native_v2, "GPUModelRunner", unexpected_construction)
    monkeypatch.setattr(worker_module.Worker, "init_device", unexpected_construction)
    monkeypatch.setattr(
        worker_module,
        "assert_compatible_afd_stack",
        lambda *args, **kwargs: None,
    )

    with pytest.raises(RuntimeError, match="requires ModelRunnerV2"):
        worker.init_device()

    assert worker.model_config is original_model_config
    assert config.model_config.hf_config.architectures == ["DeepseekV2ForCausalLM"]


@pytest.mark.parametrize(
    ("worker_module", "worker_cls", "runner_name"),
    [
        (
            attention_worker,
            attention_worker.AFDAttentionWorker,
            "AFDAttentionModelRunnerV2",
        ),
        (ffn_worker, AFDFFNWorker, "GPUFFNModelRunner"),
    ],
)
def test_worker_runner_substitution_restores_on_constructor_exception(
    monkeypatch,
    worker_module,
    worker_cls,
    runner_name,
):
    config = _v2_config(role="ffn" if worker_cls is AFDFFNWorker else "attention")
    worker = _prepare_worker(worker_cls, config, use_v2=True)
    _RunnerRecorder.instances.clear()
    _NativeRunnerSentinel.instances = 0

    native_module = native_v2

    def raising_worker_init(current_worker):
        current_worker.device = torch.device("cpu")
        from vllm.v1.worker.gpu import model_runner as imported_module

        imported_module.GPUModelRunner(
            current_worker.vllm_config,
            current_worker.device,
        )
        raise RuntimeError("runner construction failed")

    monkeypatch.setattr(worker_module, runner_name, _RunnerRecorder)
    monkeypatch.setattr(native_module, "GPUModelRunner", _NativeRunnerSentinel)
    monkeypatch.setattr(worker_module.Worker, "init_device", raising_worker_init)
    monkeypatch.setattr(
        worker_module,
        "assert_compatible_afd_stack",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(worker_module.torch.accelerator, "empty_cache", lambda: None)

    with pytest.raises(RuntimeError, match="runner construction failed"):
        worker.init_device()

    assert len(_RunnerRecorder.instances) == 1
    assert _NativeRunnerSentinel.instances == 0
    assert native_module.GPUModelRunner is _NativeRunnerSentinel
    _construct_like_native_worker(worker)
    assert _NativeRunnerSentinel.instances == 1


def test_ffn_worker_selects_routed_runner_for_routed_connector(monkeypatch):
    """An ``AFDRoutedExpertsConnector`` gets the routed-experts runner, and
    vLLM's MoE backend is pinned to one that keeps the expert layout.

    Why: the routed runner runs the experts itself, from vLLM's layout.
    """
    config = _v2_config(role="ffn")
    worker = _prepare_worker(AFDFFNWorker, config, use_v2=True)
    _RunnerRecorder.instances.clear()
    monkeypatch.setattr(
        ffn_worker.AFDConnectorFactory,
        "get_connector_class",
        lambda name: FakeRoutedConnector,
    )
    monkeypatch.setattr(
        routed_runner_module, "GPUFFNRoutedExpertsModelRunner", _RunnerRecorder
    )
    monkeypatch.setattr(native_v2, "GPUModelRunner", _NativeRunnerSentinel)
    monkeypatch.setattr(ffn_worker.Worker, "init_device", _fake_worker_init)
    monkeypatch.setattr(
        ffn_worker, "assert_compatible_afd_stack", lambda *args, **kwargs: None
    )
    monkeypatch.setattr(ffn_worker.torch.accelerator, "empty_cache", lambda: None)

    worker.init_device()

    assert worker.model_runner.__class__ is _RunnerRecorder
    assert native_v2.GPUModelRunner is _NativeRunnerSentinel
    assert config.kernel_config.moe_backend == "triton"


def _deepep_m2n_v2_config(**kwargs):
    config = _v2_config(architecture="Qwen3MoeForCausalLM", **kwargs)
    config.additional_config["afd"]["connector"] = "DeepEPM2NAFDConnector"
    config.additional_config["afd"]["compute_gate_on_attention"] = True
    return config


@pytest.mark.parametrize("tp_size", [1, 2])
def test_v2_validator_accepts_deepep_m2n_attention_tp(tp_size):
    """DeepEP M2N accepts Attention TP > 1.

    Why: each Attention TP rank dispatches its own slice of the tokens, and
    the worker derives the TP rank from the worker rank before vLLM's
    process groups exist.
    """
    validate_gpu_model_runner_v2_config(
        _deepep_m2n_v2_config(
            tensor_parallel_size=tp_size, num_attention_ranks=tp_size
        ),
        expected_role="attention",
        device_type="cuda",
    )


def test_v2_validator_rejects_deepep_m2n_ffn_tp():
    """DeepEP M2N FFN ranks must run TP = 1.

    Why: DeepEP routes each token to the one FFN rank that owns the whole
    expert; FFN experts are not TP-sharded.
    """
    config = _deepep_m2n_v2_config(role="ffn", tensor_parallel_size=2, num_ffn_ranks=2)
    with pytest.raises(RuntimeError, match="requires FFN tensor_parallel_size=1"):
        validate_gpu_model_runner_v2_config(
            config,
            expected_role="ffn",
            device_type="cuda",
        )


@pytest.mark.parametrize("role", ["attention", "ffn"])
def test_v2_validator_requires_gate_on_attention_for_deepep_m2n(role):
    """DeepEP M2N without compute_gate_on_attention fails at validation.

    Why: the connector routes on Attention, so a run without the gate there
    cannot dispatch; failing here names the setting instead of failing later
    in the connector handshake.
    """
    config = _deepep_m2n_v2_config(role=role)
    config.additional_config["afd"]["compute_gate_on_attention"] = False
    with pytest.raises(RuntimeError, match="requires compute_gate_on_attention=true"):
        validate_gpu_model_runner_v2_config(
            config,
            expected_role=role,
            device_type="cuda",
        )


@pytest.mark.parametrize("use_v2", [False, True])
def test_non_afd_model_config_and_native_runner_identity_are_unchanged(
    monkeypatch,
    use_v2,
):
    model_config = SimpleNamespace(
        hf_config=SimpleNamespace(architectures=["OtherForCausalLM"]),
    )

    assert get_afd_model_config(model_config, device_type="cuda") is model_config

    native_module = native_v2 if use_v2 else native_v1
    _NativeRunnerSentinel.instances = 0
    monkeypatch.setattr(native_module, "GPUModelRunner", _NativeRunnerSentinel)
    worker = SimpleNamespace(
        use_v2_model_runner=use_v2,
        vllm_config=SimpleNamespace(model_config=model_config),
        device=torch.device("cpu"),
    )
    _construct_like_native_worker(worker)

    assert _NativeRunnerSentinel.instances == 1
    assert native_module.GPUModelRunner is _NativeRunnerSentinel
