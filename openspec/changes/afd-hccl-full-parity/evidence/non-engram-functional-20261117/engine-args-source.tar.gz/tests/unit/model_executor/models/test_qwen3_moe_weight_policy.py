# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project

from __future__ import annotations

from types import SimpleNamespace
from typing import TYPE_CHECKING

import pytest

if TYPE_CHECKING:
    from torch import Tensor

torch = pytest.importorskip("torch")
pytest.importorskip("vllm")

from afd_plugin.config import DEEPEP_M2N_CONNECTOR, AFDConfig  # noqa: E402
from afd_plugin.model_executor.models import qwen3_moe as adapter  # noqa: E402
from tests.unit.fakes.weights import OneShotWeights as _OneShotWeights  # noqa: E402

ATTENTION_ROLE = frozenset(("attention",))
FFN_ROLE = frozenset(("ffn",))
BOTH_ROLES = frozenset(("attention", "ffn"))
WEIGHT_ROLE_CASES = (
    ("embedding", "model.embed_tokens.weight", BOTH_ROLES),
    ("final-norm", "model.norm.weight", BOTH_ROLES),
    ("lm-head", "lm_head.weight", BOTH_ROLES),
    (
        "attention-q-projection",
        "model.layers.0.self_attn.q_proj.weight",
        ATTENTION_ROLE,
    ),
    (
        "attention-k-scale",
        "model.layers.0.self_attn.attn.k_scale",
        ATTENTION_ROLE,
    ),
    (
        "input-layernorm",
        "model.layers.0.input_layernorm.weight",
        ATTENTION_ROLE,
    ),
    (
        "post-attention-layernorm",
        "model.layers.0.post_attention_layernorm.weight",
        ATTENTION_ROLE,
    ),
    ("moe-gate", "model.layers.0.mlp.gate.weight", FFN_ROLE),
    (
        "moe-expert-projection",
        "model.layers.0.mlp.experts.0.gate_proj.weight",
        FFN_ROLE,
    ),
    (
        "moe-expert-scale",
        "model.layers.0.mlp.experts.0.gate_proj.weight_scale_inv",
        FFN_ROLE,
    ),
    (
        "shared-expert-projection",
        "model.layers.0.mlp.shared_expert.gate_proj.weight",
        FFN_ROLE,
    ),
    (
        "shared-expert-gate",
        "model.layers.0.mlp.shared_expert_gate.weight",
        FFN_ROLE,
    ),
    (
        "dense-gate-projection",
        "model.layers.3.mlp.gate_proj.weight",
        FFN_ROLE,
    ),
)


# With gate-on-Attention (DeepEP M2N) only the MoE gate changes owner.
GATE_ON_ATTENTION_ROLE_CASES = (
    ("moe-gate", "model.layers.0.mlp.gate.weight", BOTH_ROLES),
    (
        "moe-expert-projection",
        "model.layers.0.mlp.experts.0.gate_proj.weight",
        FFN_ROLE,
    ),
    (
        "shared-expert-gate",
        "model.layers.0.mlp.shared_expert_gate.weight",
        FFN_ROLE,
    ),
    (
        "dense-gate-projection",
        "model.layers.3.mlp.gate_proj.weight",
        FFN_ROLE,
    ),
    (
        "attention-q-projection",
        "model.layers.0.self_attn.q_proj.weight",
        ATTENTION_ROLE,
    ),
    ("embedding", "model.embed_tokens.weight", BOTH_ROLES),
)


@pytest.mark.parametrize(
    ("checkpoint_name", "roles"),
    [case[1:] for case in WEIGHT_ROLE_CASES],
    ids=[case[0] for case in WEIGHT_ROLE_CASES],
)
def test_weight_role_policy(
    checkpoint_name: str,
    roles: frozenset[str],
) -> None:
    assert adapter._checkpoint_weight_roles(checkpoint_name) == roles


@pytest.mark.parametrize(
    ("checkpoint_name", "roles"),
    [case[1:] for case in GATE_ON_ATTENTION_ROLE_CASES],
    ids=[case[0] for case in GATE_ON_ATTENTION_ROLE_CASES],
)
def test_gate_on_attention_weight_role_policy(
    checkpoint_name: str,
    roles: frozenset[str],
) -> None:
    """The MoE gate loads on both roles; everything else keeps its owner.

    Why: Attention routes with the gate, and the FFN's native MoE block still
    owns a gate parameter that vLLM's strict loader requires to be loaded.
    """
    assert (
        adapter._checkpoint_weight_roles(
            checkpoint_name,
            routes_on_attention=True,
        )
        == roles
    )


@pytest.mark.parametrize(
    ("role", "uses_deepep_m2n", "expected_names"),
    [
        (
            "attention",
            False,
            [
                "model.embed_tokens.weight",
                "model.layers.0.self_attn.q_proj.weight",
                "model.layers.0.input_layernorm.weight",
                "lm_head.weight",
            ],
        ),
        (
            "ffn",
            False,
            [
                "model.embed_tokens.weight",
                "model.layers.0.mlp.gate.weight",
                "model.layers.0.mlp.experts.0.down_proj.weight",
                "lm_head.weight",
            ],
        ),
        (
            "attention",
            True,
            [
                "model.embed_tokens.weight",
                "model.layers.0.self_attn.q_proj.weight",
                "model.layers.0.input_layernorm.weight",
                "model.layers.0.mlp.gate.weight",
                "lm_head.weight",
            ],
        ),
        (
            "ffn",
            True,
            [
                "model.embed_tokens.weight",
                "model.layers.0.mlp.gate.weight",
                "model.layers.0.mlp.experts.0.down_proj.weight",
                "lm_head.weight",
            ],
        ),
    ],
)
def test_load_weights_filters_once_and_delegates_to_native_loader(
    monkeypatch: pytest.MonkeyPatch,
    role: str,
    uses_deepep_m2n: bool,
    expected_names: list[str],
) -> None:
    names = [
        "model.embed_tokens.weight",
        "model.layers.0.self_attn.q_proj.weight",
        "model.layers.0.input_layernorm.weight",
        "model.layers.0.mlp.gate.weight",
        "model.layers.0.mlp.experts.0.down_proj.weight",
        "lm_head.weight",
    ]
    weights = _OneShotWeights(names)
    seen: list[tuple[str, Tensor]] = []
    native_result = {"native.loaded_params"}

    def fake_native_loader(self, filtered_weights):
        assert iter(filtered_weights) is filtered_weights
        seen.extend(filtered_weights)
        return native_result

    monkeypatch.setattr(
        adapter.native.Qwen3MoeForCausalLM,
        "load_weights",
        fake_native_loader,
    )
    model = object.__new__(adapter.AFDQwen3MoeForCausalLM)
    object.__setattr__(model, "afd_role", role)
    # The gate follows the connector: only DeepEP M2N routes on Attention.
    object.__setattr__(
        model,
        "afd_config",
        AFDConfig(
            role=role,
            connector=DEEPEP_M2N_CONNECTOR,
            compute_gate_on_attention=True,
        )
        if uses_deepep_m2n
        else AFDConfig(role=role),
    )

    result = model.load_weights(weights)

    assert result is native_result
    assert [name for name, _tensor in seen] == expected_names
    assert [tensor for _name, tensor in seen] == [
        weights.items[names.index(name)][1] for name in expected_names
    ]
    assert weights.iterations == 1


def test_native_loader_and_mapping_remain_native_owned() -> None:
    assert "forward" not in adapter.AFDQwen3MoeModel.__dict__
    assert "load_weights" not in adapter.AFDQwen3MoeModel.__dict__
    assert (
        adapter.AFDQwen3MoeModel.hf_to_vllm_mapper
        is adapter.native.Qwen3MoeModel.hf_to_vllm_mapper
    )
    assert (
        adapter.AFDQwen3MoeForCausalLM.hf_to_vllm_mapper
        is adapter.native.Qwen3MoeForCausalLM.hf_to_vllm_mapper
    )


def test_model_reports_config_driven_moe_layer_indices() -> None:
    model = object.__new__(adapter.AFDQwen3MoeModel)
    object.__setattr__(
        model,
        "config",
        SimpleNamespace(
            decoder_sparse_step=2,
            mlp_only_layers=[3],
            num_experts=8,
            num_hidden_layers=6,
        ),
    )

    assert model.get_experts_layer_indices() == (1, 5)
