# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Two-process CPU Gloo check of the native P sampling/report frontier.

Launch each scenario in a fresh torchrun process group. Native target/sample,
DSpark proposal, registered prefix projection, and the production report owner
run over the existing declared CPU arithmetic/cache leaves. This is not native
vLLM TP initialization, sharded-model inference, NPU/HCCL or full PD serving.
The caller must supervise torchrun with an outer deadline; Gloo has its own
bounded operation timeout. Destroying Gloo does not retire a failed KV owner.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import os
import sys
import traceback
from dataclasses import asdict, dataclass
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from torch.distributed import ProcessGroup

WORLD_SIZE = 2
GROUP_TIMEOUT_SECONDS = 20
MAX_GROUP_TIMEOUT_SECONDS = 60
FAILURE_RANK = 1
FAILURE_MESSAGE = "controlled native P draft Attention failure on rank 1"
SOURCE_PATHS = (
    "tests/npu/dsv41_pd_report_probe.py",
    "tests/unit/fakes/kv_connector.py",
    "tests/unit/fakes/dspark_pd.py",
    "tests/unit/fakes/deepseek_v41.py",
    "tests/unit/fakes/dspark_speculator.py",
    "tests/unit/fakes/kv_layout_connector.py",
    "afd_plugin/v1/worker/npu/attention_model_runner_v2.py",
    "afd_plugin/compat/npu/dspark_pd.py",
    "afd_plugin/compat/npu/kv_layout_connector.py",
    "afd_plugin/compat/npu/runtime_config.py",
)


@dataclass(frozen=True)
class GlooTpCoordinator:
    """Only the actual CPU group fields consumed by the report owner.

    This does not pretend to implement vLLM's complete GroupCoordinator.
    """

    world_size: int
    rank_in_group: int
    cpu_group: ProcessGroup


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--scenario", choices=("success", "draft-failure"), required=True
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--group-timeout", type=int, default=GROUP_TIMEOUT_SECONDS)
    args = parser.parse_args()
    if not 0 < args.group_timeout <= MAX_GROUP_TIMEOUT_SECONDS:
        parser.error("group timeout must be positive and at most 60 seconds")
    return args


def file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def source_snapshot(root: Path) -> dict[str, dict[str, str]]:
    return {
        relative: {
            "path": str((root / relative).resolve()),
            "sha256": file_sha256(root / relative),
        }
        for relative in SOURCE_PATHS
    }


def scheduler_contract(scheduled, *, include_generation: bool):
    """Compare actual input/allocator declarations without changing them."""
    sources = []
    for source in scheduled.kv_connector_metadata.dspark_sources:
        record = asdict(source)
        if not include_generation:
            del record["source_generation"]
        sources.append(record)
    return {
        "new_requests": [
            {
                "request_id": item.req_id,
                "prompt_token_ids": item.prompt_token_ids,
                "prefill_token_ids": item.prefill_token_ids,
                "block_ids": item.block_ids,
                "num_computed_tokens": item.num_computed_tokens,
                "max_tokens": item.sampling_params.max_tokens,
                "temperature": item.sampling_params.temperature,
            }
            for item in scheduled.scheduled_new_reqs
        ],
        "num_scheduled_tokens": scheduled.num_scheduled_tokens,
        "total_num_scheduled_tokens": scheduled.total_num_scheduled_tokens,
        "finished_req_ids": sorted(scheduled.finished_req_ids),
        "sources": sources,
    }


def run_worker(args, report: dict) -> None:
    # Worker isolation: the CLI/help path imports neither torch nor runtime
    # packages. The existing CPU fixture closure intentionally needs pytest.
    import pytest
    import torch
    import torch.distributed as dist

    from afd_plugin.compat.npu.dspark_pd import (
        DsparkPdWriteReport,
        read_lease_from_payload,
    )
    from tests.unit.fakes.deepseek_v41 import PD_CPU_TARGET_TOKEN
    from tests.unit.fakes.kv_connector import make_native_pd_prefill_owner_case

    rank = int(os.environ["RANK"])
    size = int(os.environ["WORLD_SIZE"])
    local_rank = int(os.environ["LOCAL_RANK"])
    if size != WORLD_SIZE or not 0 <= rank < size or local_rank != rank:
        raise ValueError("run with two local torchrun ranks in a fresh process group")
    report.update(rank=rank, world_size=size, local_rank=local_rank, pid=os.getpid())
    root = Path(__file__).resolve().parents[2]
    report["sources_before"] = source_snapshot(root)
    report["torch_version"] = torch.__version__
    initialized = False
    primary_error = None
    try:
        dist.init_process_group(
            backend="gloo",
            timeout=timedelta(seconds=args.group_timeout),
        )
        initialized = True
        group = dist.group.WORLD
        if group is None or dist.get_backend(group) != "gloo":
            raise RuntimeError("the report group must be the actual Gloo process group")
        coordinator = GlooTpCoordinator(size, rank, group)
        report["group"] = {
            "backend": dist.get_backend(group),
            "rank": dist.get_rank(group),
            "world_size": dist.get_world_size(group),
            "timeout_seconds": args.group_timeout,
        }
        with pytest.MonkeyPatch.context() as patch:

            def share_scheduler(local):
                # The source is rank zero's original SchedulerOutput, including
                # actual build_connector_meta generation/schema/allocations.
                # Independent rank allocations must agree before any worker
                # model/storage binding; do not rewrite a received source.
                payload = [local if rank == 0 else None]
                dist.broadcast_object_list(payload, src=0, group=group)
                incoming = payload[0]
                if type(incoming) is not type(local):
                    raise TypeError(
                        "broadcast did not preserve the native scheduler type"
                    )
                local_contract = scheduler_contract(local, include_generation=False)
                incoming_contract = scheduler_contract(
                    incoming, include_generation=False
                )
                if local_contract != incoming_contract:
                    raise ValueError(
                        "independent P allocations/schema/inputs differ from rank zero"
                    )
                local_identity = scheduler_contract(local, include_generation=True)
                shared_identity = scheduler_contract(incoming, include_generation=True)
                report["scheduler"] = {
                    "local_allocator_contract_matches_rank_zero": True,
                    "rank_zero_original_object": incoming is local
                    if rank == 0
                    else None,
                    "local_before_broadcast": local_identity,
                    "received_from_rank_zero": shared_identity,
                }
                write_json(
                    args.output_dir / f"rank-{rank}-scheduler.json", report["scheduler"]
                )
                return incoming

            case = make_native_pd_prefill_owner_case(
                patch,
                tp_size=size,
                tp_rank=rank,
                tp_group=coordinator,
                share_scheduler=share_scheduler,
            )
            owner, prefix = case.owner, case.prefix
            consumer = owner.dspark_pd_consumer
            report["actual_source_bindings"] = {
                name: {
                    "path": inspect.getfile(inspect.unwrap(binding)),
                    "sha256": file_sha256(
                        Path(inspect.getfile(inspect.unwrap(binding)))
                    ),
                    "qualname": binding.__qualname__,
                }
                for name, binding in (
                    ("sample_tokens", type(owner).sample_tokens),
                    ("agree_batch", consumer.agree_batch),
                    ("consume_prefill", type(consumer).consume_prefill),
                    ("all_gather_object", dist.all_gather_object),
                )
            }
            if (
                owner.vllm_config is not prefix.config
                or consumer.vllm_config is not owner.vllm_config
                or owner.vllm_config.parallel_config.tensor_parallel_size != size
                or consumer.tp_rank != rank
                or consumer.tp_size != size
                or consumer.binding.target_model is not owner.model
            ):
                raise AssertionError(
                    "one immutable P/TP2 owner must bind its actual model"
                )
            retained_model = owner.model
            retained_caches = tuple(prefix.caches.values())
            report["ready_before_execute"] = case.producer.request_ready(case.query)
            if report["ready_before_execute"]["ok"]:
                raise AssertionError("Ready preceded native target execution")
            if owner.execute_model(case.scheduler) is not None:
                raise AssertionError("native V2 target must retain its sampling state")
            state = owner.execute_model_state
            report["native_parent"] = {
                "request_ids": state.input_batch.req_ids,
                "query_start_loc": state.input_batch.query_start_loc_np.tolist(),
                "scheduled_tokens": state.input_batch.num_scheduled_tokens.tolist(),
                "auxiliary_layers": len(state.aux_hidden_states),
            }
            report["ready_after_execute"] = case.producer.request_ready(case.query)
            if report["ready_after_execute"]["ok"]:
                raise AssertionError("Ready preceded native sampling/proposal")
            case.observations.enabled = True
            cause = RuntimeError(FAILURE_MESSAGE)
            hook = None
            if args.scenario == "draft-failure" and rank == FAILURE_RANK:

                def fail_attention(module, inputs):
                    raise cause

                layer = next(iter(owner.speculator.model.model.layers.values()))
                hook = layer.self_attn.register_forward_pre_hook(fail_attention)

            actual_all_gather_object = dist.all_gather_object
            exchanges = []

            def observed_all_gather_object(object_list, obj, group=None):
                # Transparent observation of the real collective, preserving
                # the production owner's exact input and returned objects.
                actual_all_gather_object(object_list, obj, group=group)
                if isinstance(obj, DsparkPdWriteReport):
                    exchange = {
                        "local_report": asdict(obj),
                        "gathered_reports": [asdict(item) for item in object_list],
                    }
                    exchanges.append(exchange)
                    write_json(args.output_dir / f"rank-{rank}-reports.json", exchanges)

            try:
                with patch.context() as collective_patch:
                    collective_patch.setattr(
                        dist, "all_gather_object", observed_all_gather_object
                    )
                    try:
                        output = owner.sample_tokens(None)
                    except Exception as exc:
                        report["sample_exception"] = {
                            "type": type(exc).__name__,
                            "message": str(exc),
                            "is_local_original_cause": exc is cause,
                        }
                        if args.scenario != "draft-failure":
                            raise
                        if rank == FAILURE_RANK:
                            if exc is not cause:
                                raise AssertionError(
                                    "native draft cause was replaced"
                                ) from exc
                        elif (
                            type(exc) is not RuntimeError
                            or str(exc)
                            != "DSpark prompt projection TP agreement failed"
                        ):
                            raise AssertionError(
                                "successful peer missed the TP failure"
                            ) from exc
                    else:
                        if args.scenario != "success":
                            raise AssertionError("a failed TP report published success")
                        report["sample_output"] = output.get_output().sampled_token_ids
                        if report["sample_output"] != [[PD_CPU_TARGET_TOKEN]] * len(
                            case.requests
                        ):
                            raise AssertionError(
                                "native sampling missed the CPU target logits"
                            )
            finally:
                if hook is not None:
                    hook.remove()
            if len(exchanges) != 1:
                raise AssertionError(
                    "each P sample frontier must finish one real report exchange"
                )
            reports = exchanges[0]["gathered_reports"]
            if [item["source_tp_rank"] for item in reports] != list(range(size)):
                raise AssertionError("real Gloo reports lost their actual source ranks")
            if any(item["tp_size"] != size for item in reports):
                raise AssertionError(
                    "report geometry differs from the frozen TP2 owner"
                )
            report["proposal_ready_observations"] = case.observations.replies
            if any(reply["ok"] for reply in case.observations.replies):
                raise AssertionError(
                    "Ready became visible during native proposal writes"
                )
            ready = case.producer.request_ready(case.query)
            report["ready_after_sample"] = ready
            report["consumer_terminal"] = consumer.terminal
            if args.scenario == "success":
                if not case.observations.replies:
                    raise AssertionError(
                        "the successful native draft did not write its CPU cache"
                    )
                if any(item["error"] is not None for item in reports):
                    raise AssertionError(
                        "success scenario contains a failed actual report"
                    )
                if consumer.terminal or not ready["ok"]:
                    raise AssertionError(
                        "successful TP report did not publish actual Ready"
                    )
                lease = read_lease_from_payload(ready["lease"])
                if lease.ready != prefix.expected_ready:
                    raise AssertionError(
                        "Ready differs from this rank's registered prefix"
                    )
                if case.producer.complete_read(lease) != b"ACK":
                    raise AssertionError(
                        "actual typed DONE did not acknowledge the lease"
                    )
                report["ready_after_done"] = case.producer.request_ready(case.query)
                if report["ready_after_done"]["ok"]:
                    raise AssertionError("completed Ready was revived")
            else:
                if (
                    reports[0]["error"] is not None
                    or reports[FAILURE_RANK]["error"]
                    != f"RuntimeError: {FAILURE_MESSAGE}"
                    or not consumer.terminal
                    or ready["ok"]
                ):
                    raise AssertionError(
                        "the actual mixed TP report did not fail closed"
                    )
                refused = {}
                for name, operation in (
                    ("sample", lambda: owner.sample_tokens(None)),
                    ("execute", lambda: owner.execute_model(case.scheduler)),
                    ("shutdown", owner.prepare_shutdown),
                ):
                    try:
                        operation()
                    except RuntimeError as exc:
                        expected = (
                            "pending native sampling"
                            if name == "shutdown"
                            else "terminal"
                        )
                        if expected not in str(exc):
                            raise
                        refused[name] = str(exc)
                    else:
                        raise AssertionError(f"failed owner accepted {name}")
                report["refused_after_failure"] = refused
                if case.producer.request_ready(case.query)["ok"]:
                    raise AssertionError("a failed owner retry revived Ready")
            if owner.model is not retained_model or any(
                actual is not original
                for actual, original in zip(
                    prefix.caches.values(), retained_caches, strict=True
                )
            ):
                raise AssertionError(
                    "report handling replaced the retained model/KV owner"
                )
            report["model_and_registered_kv_references_retained"] = True
            report["checks_passed"] = True
    except BaseException as exc:
        primary_error = exc
        raise
    finally:
        if initialized:
            try:
                dist.destroy_process_group()
                report["gloo_destroy_returned"] = True
            except BaseException as exc:
                report["gloo_destroy_error"] = {
                    "type": type(exc).__name__,
                    "message": str(exc),
                }
                if primary_error is None:
                    raise
        report["sources_after"] = source_snapshot(root)
        report["sources_unchanged"] = (
            report["sources_before"] == report["sources_after"]
        )
        if primary_error is None and not report["sources_unchanged"]:
            raise AssertionError("probe source bytes changed during execution")


def main() -> int:
    args = parse_args()
    args.output_dir = args.output_dir.resolve()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rank_label = os.environ.get("RANK", "unassigned")
    output_path = args.output_dir / f"rank-{rank_label}.json"
    if output_path.exists():
        raise FileExistsError("use a fresh output directory for each torchrun scenario")
    root = Path(__file__).resolve().parents[2]
    sys.path.insert(0, str(root))
    report = {
        "schema_version": 1,
        "scenario": args.scenario,
        "success": False,
        "validation_kind": "two-process CPU Gloo final P report component",
        "scope": {
            "native_sample_and_proposal_with_declared_cpu_leaves": True,
            "production_final_tp_report": True,
            "native_vllm_tp_initialization": False,
            "tp_sharded_model_arithmetic": False,
            "npu_acceptance": False,
            "hccl_acceptance": False,
            "full_model_acceptance": False,
            "performance": False,
            "model_or_kv_cleanup": False,
            "failed_owner_recovery": False,
        },
    }
    try:
        run_worker(args, report)
        report["success"] = bool(
            report["checks_passed"]
            and report["gloo_destroy_returned"]
            and report["sources_unchanged"]
        )
    except BaseException as exc:
        report["failure"] = {
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": traceback.format_exc(),
        }
    write_json(output_path, report)
    print(json.dumps({"rank": rank_label, "success": report["success"]}), flush=True)
    return 0 if report["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
