# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Observe native P entering-layer aux states without installing a speculator.

Only supervised NPU workers import runtime dependencies. The actual V4.1 model
creates these tensors and GPUModelRunner retains them in ExecuteModelState;
this helper records and checks them without replacing forward or sampling.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import torch
    from vllm.v1.worker.gpu.model_runner import ExecuteModelState
    from vllm_ascend.worker.v2.model_runner import NPUModelRunner

TARGET_AUX_LAYER_IDS = (1, 2)


@dataclass(frozen=True)
class NativePdAuxSnapshot:
    state: ExecuteModelState
    tensors: tuple[torch.Tensor, ...]
    contents: tuple[bytes, ...]
    coordinates: dict


def batch_coordinates(state: ExecuteModelState) -> dict:
    """Freeze real parent coordinates before native sampling advances requests."""
    batch = state.input_batch
    return {
        "request_ids": list(batch.req_ids),
        "num_reqs": batch.num_reqs,
        "num_valid_tokens": batch.num_tokens,
        "num_tokens_after_padding": batch.num_tokens_after_padding,
        "input_ids": batch.input_ids.cpu().tolist(),
        "positions": batch.positions.cpu().tolist(),
        "query_start_loc": batch.query_start_loc.cpu().tolist(),
        "query_start_loc_np": batch.query_start_loc_np.tolist(),
        "num_computed_tokens": batch.num_computed_tokens_np.tolist(),
        "prefill_lengths": batch.prefill_len_np.tolist(),
        "logits_indices": batch.logits_indices.cpu().tolist(),
    }


def observe_native_pd_aux(
    state: ExecuteModelState,
    expected_aux: tuple[torch.Tensor, ...],
    *,
    source_request_id: str,
    input_ids: list[int],
    positions: list[int],
    output_dir: Path,
    report: dict,
) -> NativePdAuxSnapshot:
    # Native tensors, CPU oracle values and byte snapshots are checked only in
    # the supervised worker; no fake output is supplied to ModelRunner.
    import torch

    detail = report["native_pd_producer"]["auxiliary_states"] = {
        "passed": False,
        "checkpoint_layer_ids": list(TARGET_AUX_LAYER_IDS),
        "model_layer_indices": [value - 1 for value in TARGET_AUX_LAYER_IDS],
        "layer_id_api": "model.set_aux_hidden_state_layers",
        "native_semantics": "residual stream mean over HC axis before target layer",
        "speculative_config_is_none": True,
        "speculator_is_none": True,
        "DSpark_projection_executed": False,
        "draft_or_scatter_executed": False,
        "native_model_or_sampler_replaced": False,
        "execute_model_state_identity": id(state),
        "input_batch_identity": id(state.input_batch),
    }
    coords = batch_coordinates(state)
    detail["batch_before_sample"] = coords
    assert coords["request_ids"] == [source_request_id]
    assert coords["num_reqs"] == 1
    assert (
        coords["num_valid_tokens"]
        == coords["num_tokens_after_padding"]
        == len(input_ids)
    )
    assert coords["input_ids"] == input_ids and coords["positions"] == positions
    assert (
        coords["query_start_loc"]
        == coords["query_start_loc_np"]
        == [
            0,
            len(input_ids),
        ]
    )
    assert coords["num_computed_tokens"] == [0]
    assert coords["prefill_lengths"] == [len(input_ids)]
    assert coords["logits_indices"] == [len(input_ids) - 1]
    actual_aux = state.aux_hidden_states
    assert actual_aux is not None
    assert len(actual_aux) == len(expected_aux) == len(TARGET_AUX_LAYER_IDS)
    records, contents = [], []
    for layer_id, actual, expected in zip(
        TARGET_AUX_LAYER_IDS, actual_aux, expected_aux, strict=True
    ):
        assert actual.dtype == expected.dtype == torch.bfloat16
        assert actual.device == state.hidden_states.device
        assert actual.shape == expected.shape == state.hidden_states.shape
        assert torch.isfinite(actual).all().item()
        assert not torch.equal(actual, state.hidden_states)
        cpu = actual.cpu()
        raw = cpu.contiguous().view(torch.uint8).numpy().tobytes()
        expected_raw = expected.contiguous().view(torch.uint8).numpy().tobytes()
        path = f"producer-aux-layer-{layer_id}.bin"
        (output_dir / path).write_bytes(raw)
        records.append(
            {
                "checkpoint_layer_id": layer_id,
                "model_layer_index": layer_id - 1,
                "data_ptr": actual.data_ptr(),
                "shape": list(actual.shape),
                "stride": list(actual.stride()),
                "dtype": str(actual.dtype),
                "device": str(actual.device),
                "values": cpu.float().tolist(),
                "expected_values": expected.float().tolist(),
                "path": path,
                "sha256": hashlib.sha256(raw).hexdigest(),
                "expected_sha256": hashlib.sha256(expected_raw).hexdigest(),
            }
        )
        detail["layers"] = records
        assert raw == expected_raw
        torch.testing.assert_close(cpu, expected, rtol=0, atol=0)
        contents.append(raw)
    assert not torch.equal(actual_aux[0], actual_aux[1])
    detail["order_distinguishable"] = True
    detail["distinct_from_final_hidden"] = True
    return NativePdAuxSnapshot(state, tuple(actual_aux), tuple(contents), coords)


def verify_native_pd_aux_after_sample(
    owner: NPUModelRunner, snapshot: NativePdAuxSnapshot, *, report: dict
) -> None:
    # Retain the original state instead of manufacturing another execution
    # state after sample_tokens has cleared the runner's native pending state.
    import torch

    detail = report["native_pd_producer"]["auxiliary_states"]
    assert owner.execute_model_state is None
    assert owner.vllm_config.speculative_config is None and owner.speculator is None
    assert snapshot.state.input_batch is not None
    assert id(snapshot.state) == detail["execute_model_state_identity"]
    assert id(snapshot.state.input_batch) == detail["input_batch_identity"]
    coords = batch_coordinates(snapshot.state)
    detail["batch_after_sample"] = coords
    assert coords == snapshot.coordinates
    after = []
    for index, (tensor, expected_raw) in enumerate(
        zip(snapshot.tensors, snapshot.contents, strict=True)
    ):
        assert snapshot.state.aux_hidden_states[index] is tensor
        raw = tensor.cpu().contiguous().view(torch.uint8).numpy().tobytes()
        after.append(
            {"data_ptr": tensor.data_ptr(), "sha256": hashlib.sha256(raw).hexdigest()}
        )
        assert tensor.data_ptr() == detail["layers"][index]["data_ptr"]
        assert raw == expected_raw
    detail["after_sample"] = after
    detail["original_state_aux_preserved"] = True
    detail["native_sample_cleared_owner_pending_state"] = True
    detail["passed"] = True
