# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Bounded real-NPU HCCL stage/peer probe using controlled arithmetic, no MoE.

Run on idle devices after activating the pinned CANN and Python environment.
Each process retains a separate native vLLM TP group; only the transport-owned
groups are closed before the final native collective is checked.
"""

from __future__ import annotations

import argparse
import json
import os
import signal
import socket
import subprocess
import sys
import tempfile
import time
import traceback
from datetime import timedelta
from functools import partial
from pathlib import Path

HIDDEN_SIZE = 16
VOCAB_SIZE = 4_096
CAPACITY = 32
LAYERS = (0, 2)
CHECKPOINT = "/mnt/workspace/models/DeepSeek-V4.1-Flash"
ROUTER_DELTA = 0.00031
ROUTER_DELTA_SCALE = 4_096
GROUP_TIMEOUT_SECONDS = 45
TOTAL_TIMEOUT_SECONDS = 240
REAP_TIMEOUT_SECONDS = 10
PORT_ATTEMPTS = 20
MAX_TCP_PORT = 65_535
TOPOLOGIES = ("1a1f", "2a1f", "1a2f", "2a2f-tp1", "2a2f-tp2")


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--topology", choices=TOPOLOGIES, default="1a1f")
    parser.add_argument("--model", default=CHECKPOINT, help="local model config path")
    parser.add_argument(
        "--devices", default="0,2,4,6", help="FFN ranks, then Attention ranks"
    )
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--timeout", type=int, default=TOTAL_TIMEOUT_SECONDS)
    parser.add_argument(
        "--local-counts-service",
        action="store_true",
        help="collect real Attention local counts and use the FFN v3 service entry",
    )
    parser.add_argument(
        "--eager-pipeline-version",
        type=int,
        choices=(0, 1),
        default=0,
        help="select an explicit HELLO eager family; v1 also performs matched warmup",
    )
    rejection = parser.add_mutually_exclusive_group()
    rejection.add_argument(
        "--reject-eager-pipeline",
        choices=("ffn", "attention"),
        help="set only role rank0 to eager family0; all other ranks select family1",
    )
    rejection.add_argument(
        "--reject-hidden-size",
        action="store_true",
        help="expect a mismatched FFN0 HELLO to reject every rank",
    )
    rejection.add_argument(
        "--reject-plan-digest",
        action="store_true",
        help="inject a bad FFN0 ACCEPT digest on the real Gloo domain (2a1f)",
    )
    parser.add_argument("--role", choices=("attention", "ffn"), help=argparse.SUPPRESS)
    parser.add_argument("--role-rank", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    attention, ffn, tp = {
        "1a1f": (1, 1, 1),
        "2a1f": (2, 1, 1),
        "1a2f": (1, 2, 1),
        "2a2f-tp1": (2, 2, 1),
        "2a2f-tp2": (2, 2, 2),
    }[args.topology]
    args.attention_size, args.ffn_size, args.tp_size = attention, ffn, tp
    if args.local_counts_service and (
        args.topology not in ("1a1f", "2a2f-tp2")
        or args.reject_hidden_size
        or args.reject_plan_digest
        or args.reject_eager_pipeline
    ):
        parser.error("--local-counts-service requires an equal TP1/TP2 positive case")
    if args.reject_plan_digest and args.topology != "2a1f":
        parser.error("--reject-plan-digest is scoped to the 2a1f drain case")
    if (
        args.eager_pipeline_version or args.reject_eager_pipeline
    ) and args.topology not in ("1a1f", "2a2f-tp2"):
        parser.error("eager family v1 requires paired TP1/TP2")
    try:
        devices = tuple(map(int, args.devices.split(",")))
    except ValueError:
        parser.error("--devices requires comma-separated integer NPU IDs")
    if len(devices) < attention + ffn or len(set(devices)) != len(devices):
        parser.error("--devices requires enough distinct NPUs for the topology")
    args.devices = devices[: attention + ffn]
    if min(args.devices) < 0 or not 0 < args.timeout <= TOTAL_TIMEOUT_SECONDS:
        parser.error("invalid device index or timeout")
    if args.role and (
        args.role_rank is None or args.port is None or args.output_dir is None
    ):
        parser.error("worker invocation requires role rank, port and output directory")
    return args


def build_config(tp_size, model_path):
    # Worker isolation: the supervisor does not import torch/vLLM or touch NPU.
    from vllm.config import CompilationMode, CUDAGraphMode, ModelConfig, VllmConfig
    from vllm.config.device import DeviceConfig
    from vllm.config.load import LoadConfig
    from vllm.config.parallel import ParallelConfig

    config = VllmConfig(
        model_config=ModelConfig(
            model=model_path,
            dtype="bfloat16",
            trust_remote_code=True,
            enforce_eager=True,
            max_model_len=128,
            skip_tokenizer_init=True,
            language_model_only=True,
        ),
        parallel_config=ParallelConfig(tensor_parallel_size=tp_size),
        device_config=DeviceConfig(device="cpu"),
        load_config=LoadConfig(load_format="dummy"),
    )
    config.device_config = DeviceConfig(device="npu")
    config.quant_config = config.engram_config = config.speculative_config = None
    config.compilation_config.mode = CompilationMode.NONE
    config.compilation_config.cudagraph_mode = CUDAGraphMode.NONE
    config.compilation_config.use_inductor_graph_partition = False
    return config


def build_plans(args):
    from afd_plugin.distributed.hccl import HcclStageLayout
    from afd_plugin.distributed.hccl_plan import HcclParentPlan

    def counts(first, following):
        return tuple(
            first if rank // args.tp_size == 0 else following
            for rank in range(args.attention_size)
        )

    zero = (0,) * args.attention_size

    def stage(index, valid, padded):
        return HcclStageLayout(index, valid, padded, args.ffn_size, args.tp_size)

    return (
        HcclParentPlan("u1-one", LAYERS, (stage(0, counts(1, 1), counts(1, 1)),)),
        HcclParentPlan(
            "u2-mixed",
            LAYERS,
            (
                stage(0, counts(0, 3), counts(0, 4)),
                stage(1, counts(1, 0), counts(2, 2)),
            ),
        ),
        HcclParentPlan(
            "u2-empty-stage",
            LAYERS,
            (stage(0, zero, zero), stage(1, counts(5, 1), counts(6, 2))),
        ),
        HcclParentPlan(
            "u2-empty", LAYERS, (stage(0, zero, zero), stage(1, zero, zero))
        ),
        HcclParentPlan(
            "u2-dummy",
            LAYERS,
            (stage(0, zero, counts(4, 2)), stage(1, zero, counts(2, 2))),
            "dummy",
        ),
        HcclParentPlan(
            "u2-repeat",
            LAYERS,
            (
                stage(0, counts(3, 1), counts(4, 2)),
                stage(1, counts(1, 3), counts(2, 4)),
            ),
        ),
    )


def make_attention_inputs(torch, args, stage, attention_rank, layer_idx):
    padded = stage.attention_padded_tokens[attention_rank]
    valid = stage.attention_valid_tokens[attention_rank]
    dp_rank = attention_rank // args.tp_size
    values = torch.arange(padded * HIDDEN_SIZE, dtype=torch.float32)
    hidden = (values.reshape(padded, HIDDEN_SIZE) / 64 + dp_rank).bfloat16()
    fp32 = hidden.float() + ROUTER_DELTA
    ids = (
        torch.arange(padded, dtype=torch.int32)
        + 100
        + dp_rank * 100
        + stage.stage_idx * 20
        + layer_idx * 3
    )
    ids[valid:] = 0
    return hidden, fp32, ids


def local_output(hidden, fp32, ids, ffn_rank, tp_size, layer_idx, stage_idx):
    return (
        (fp32 - hidden.float()) * ROUTER_DELTA_SCALE
        + ids[:, None].float()
        + (ffn_rank // tp_size) / 8
        + layer_idx / 8
        + stage_idx / 16
    ).bfloat16()


def expected_ffn_inputs(torch, args, stage, ffn_rank, layer_idx):
    pieces = [[], [], []]
    for peer in stage.for_ffn(ffn_rank):
        attention_rank = peer.attention_world_rank - args.ffn_size
        source = make_attention_inputs(torch, args, stage, attention_rank, layer_idx)
        for index, (tensor, shape) in enumerate(
            zip(
                source,
                (
                    (peer.padded_tokens, HIDDEN_SIZE),
                    (peer.padded_tokens, HIDDEN_SIZE),
                    (peer.padded_tokens,),
                ),
                strict=True,
            )
        ):
            chunk = torch.zeros(shape, dtype=tensor.dtype)
            available = min(
                peer.padded_tokens, max(0, tensor.shape[0] - peer.attention_offset)
            )
            chunk[:available] = tensor[
                peer.attention_offset : peer.attention_offset + available
            ]
            pieces[index].append(chunk)
    return tuple(torch.cat(parts, dim=0) for parts in pieces)


def expected_attention_output(torch, args, stage, attention_rank, layer_idx):
    source = make_attention_inputs(torch, args, stage, attention_rank, layer_idx)
    padded = stage.attention_padded_tokens[attention_rank]
    expected = torch.zeros((padded, HIDDEN_SIZE), dtype=torch.bfloat16)
    for peer in stage.for_attention(attention_rank):
        start = peer.attention_offset
        stop = min(start + peer.padded_tokens, padded)
        if start >= stop:
            continue
        output = local_output(
            *(tensor[start:stop] for tensor in source),
            peer.ffn_world_rank,
            args.tp_size,
            layer_idx,
            stage.stage_idx,
        )
        expected[start:stop] = (output.float() * args.tp_size).bfloat16()
    return expected


def expect_rejection(report, label, error_type, operation):
    """Exercise a public pre-I/O boundary and retain the actual rejection."""
    try:
        operation()
    except error_type as exc:
        report["rejections"].append(
            {"label": label, "type": type(exc).__name__, "message": str(exc)}
        )
    else:
        raise AssertionError(f"{label} unexpectedly succeeded")


def local_count_cases():
    # These are rank-local extents of the controlled input tensors, not plans.
    # Native TP peers own replicated tokens, so their local counts agree.
    return (
        ("counts-u1-first", (1,), (2,)),
        ("counts-u2-first", (0, 3), (0, 4)),
        ("counts-u1-fallback", (3,), (4,)),
        ("counts-u2-second", (1, 0), (2, 2)),
        ("counts-empty", (0, 0), (0, 0)),
    )


def run_local_counts_service(torch, dist, args, transport, config, report):
    # This component probe deliberately supplies a weightless runner shell.
    # Its actual service method and context execute; production construction,
    # native MoE and model admission are outside this controlled-arithmetic case.
    from vllm.distributed import get_tp_group
    from vllm.forward_context import get_forward_context
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.ascend_forward_context import (
        set_mc2_mask,
        set_mc2_tokens_capacity,
    )

    from afd_plugin.distributed.hccl_plan import HcclLocalForward
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner

    device = f"npu:{args.devices[transport.world_rank]}"
    config.parallel_config.rank = args.role_rank
    init_ascend_config(config)
    report["scope"] = "real local-count HCCL and FFN service; controlled arithmetic"
    report["ffn_runner_constructor_called"] = False
    report["local_counts_version"] = 1
    if args.role == "ffn":

        class ControlledArithmetic(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.exchanges = []
                self.plans = {}

            def compute_ffn_output(
                self,
                hidden_states,
                layer_idx,
                *,
                input_ids,
                hidden_states_fp32,
                already_sequence_parallel,
            ):
                plan = transport.plan
                assert plan is not None
                context = get_forward_context()
                metadata = context.additional_kwargs["afd_metadata"]
                stage = plan.stages[metadata.stage_idx]
                expected = expected_ffn_inputs(
                    torch, args, stage, args.role_rank, layer_idx
                )
                for actual, reference in zip(
                    (hidden_states, hidden_states_fp32, input_ids),
                    expected,
                    strict=True,
                ):
                    torch.testing.assert_close(actual.cpu(), reference, rtol=0, atol=0)
                peers = stage.for_ffn(args.role_rank)
                rows = sum(peer.padded_tokens for peer in peers)
                assert metadata.transaction_id == plan.transaction_id
                assert metadata.tokens_lens == [rows]
                assert metadata.tokens_unpadded_lens == [
                    sum(peer.valid_tokens for peer in peers)
                ]
                assert metadata.num_stages == len(plan.stages)
                assert context.additional_kwargs["model_instance"] is self
                assert context.additional_kwargs["num_tokens"] == rows
                assert torch.equal(context.input_ids, input_ids)
                assert not already_sequence_parallel
                output = local_output(
                    hidden_states,
                    hidden_states_fp32,
                    input_ids,
                    args.role_rank,
                    args.tp_size,
                    layer_idx,
                    stage.stage_idx,
                )
                dist.all_reduce(output, group=get_tp_group().device_group)
                self.plans[plan.transaction_id] = plan
                self.exchanges.append((plan.transaction_id, layer_idx, stage.stage_idx))
                return output

        runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
        runner.vllm_config = config
        runner.connector = transport
        runner.model = ControlledArithmetic()
        set_mc2_tokens_capacity(config, config.scheduler_config.max_num_seqs, 1)
        set_mc2_mask(config, device)
        for transaction_id, valid, padded in local_count_cases():
            assert runner.execute_hccl_v41_step(transport) is True
            expected_steps = [
                (transaction_id, layer, stage_idx)
                for layer in LAYERS
                for stage_idx, rows in enumerate(padded)
                if rows
            ]
            actual_steps = [
                entry for entry in runner.model.exchanges if entry[0] == transaction_id
            ]
            assert actual_steps == expected_steps
            plan = runner.model.plans.get(transaction_id)
            report["transactions"].append(
                {
                    "transaction_id": transaction_id,
                    "service_completed": True,
                    "plan_digest": None if plan is None else plan.digest,
                    "verified_layer_stages": [
                        list(entry[1:]) for entry in actual_steps
                    ],
                    "stage_count": len(valid),
                    "whole_empty_without_compute": not any(padded),
                }
            )
        assert runner.execute_hccl_v41_step(transport) is False
        report["ffn_service_stop_returned_false"] = True
    else:
        for transaction_id, valid, padded in local_count_cases():
            local = HcclLocalForward("target", valid, padded)
            plan = transport.submit_forward(
                local,
                transaction_id=transaction_id if transport.is_coordinator else None,
            )
            assert plan is not None and plan.transaction_id == transaction_id
            assert plan.layer_indices == LAYERS and plan.mode == local.mode
            assert len(plan.stages) == len(local.valid_tokens)
            for stage_idx, stage in enumerate(plan.stages):
                assert (
                    stage.attention_valid_tokens
                    == (valid[stage_idx],) * args.attention_size
                )
                assert (
                    stage.attention_padded_tokens
                    == (padded[stage_idx],) * args.attention_size
                )
            exchanges = []
            for layer_idx in LAYERS:
                for stage in plan.stages:
                    if not any(stage.attention_padded_tokens):
                        continue
                    source = make_attention_inputs(
                        torch, args, stage, args.role_rank, layer_idx
                    )
                    native = tuple(tensor.to(device) for tensor in source)
                    transport.send_layer_inputs(layer_idx, stage.stage_idx, *native)
                    output = transport.receive_layer_output(layer_idx, stage.stage_idx)
                    torch.testing.assert_close(
                        output.cpu(),
                        expected_attention_output(
                            torch, args, stage, args.role_rank, layer_idx
                        ),
                        rtol=0,
                        atol=0,
                    )
                    exchanges.append([layer_idx, stage.stage_idx])
            transport.finish_forward()
            report["transactions"].append(
                {
                    "transaction_id": plan.transaction_id,
                    "plan_digest": plan.digest,
                    "local_valid": local.valid_tokens,
                    "local_padded": local.padded_tokens,
                    "verified_layer_stages": exchanges,
                    "stages": [
                        {
                            "stage_idx": stage.stage_idx,
                            "valid": stage.attention_valid_tokens,
                            "padded": stage.attention_padded_tokens,
                        }
                        for stage in plan.stages
                    ],
                }
            )
        transport.stop_attention()
        report["all_attention_stop_completed"] = True
    report["stop_acknowledged"] = True


def run_rank(args):
    # Runtime imports are intentionally local to the isolated worker process.
    import torch
    import torch.distributed as dist
    import vllm_ascend.ops  # noqa: F401
    from vllm.config import set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )
    from vllm.platforms import current_platform
    from vllm.plugins import load_general_plugins
    from vllm_ascend.utils import adapt_patch

    from afd_plugin.connectors.npu.hccl_staged_transport import HcclStagedTransport
    from afd_plugin.distributed.hccl_plan import (
        MAX_CONTROL_MESSAGE_BYTES,
        HcclPlanCapabilities,
        HcclPlanMessage,
        decode_hccl_plan_message,
        encode_hccl_plan_message,
    )

    started = time.monotonic()
    world_rank = args.role_rank + (args.ffn_size if args.role == "attention" else 0)
    device = args.devices[world_rank]
    tp_rank = args.role_rank % args.tp_size
    native_group_idx = args.role_rank // args.tp_size
    if args.role == "attention":
        native_group_idx += args.ffn_size // args.tp_size
    report = {
        "role": args.role,
        "role_rank": args.role_rank,
        "world_rank": world_rank,
        "pid": os.getpid(),
        "device": device,
        "topology": args.topology,
        "native_tp_size": args.tp_size,
        "native_tp_rank": tp_rank,
        "native_moe_executed": False,
        "checkpoint_weights_loaded": False,
        "scope": "real multi-stage HCCL transport with controlled arithmetic",
        "transactions": [],
        "rejections": [],
        "success": False,
    }
    eager_version = (
        int(not (args.role == args.reject_eager_pipeline and args.role_rank == 0))
        if args.reject_eager_pipeline
        else args.eager_pipeline_version
    )
    report["eager_pipeline_version"] = eager_version
    report["created_plugin_group_backends"] = []
    report["control_messages"] = []

    class ObservedHandshakeTransport(HcclStagedTransport):
        """Record actual group creation and messages without changing their bytes."""

        def _create_group(self, backend, name):
            group = super()._create_group(backend, name)
            report["created_plugin_group_backends"].append(backend)
            return group

        def _send_control(self, destination, message):
            super()._send_control(destination, message)
            report["control_messages"].append(
                {"direction": "sent", "peer": destination, "kind": message.kind}
            )

        def _recv_control(self, source):
            message = super()._recv_control(source)
            report["control_messages"].append(
                {"direction": "received", "peer": source, "kind": message.kind}
            )
            return message

    result_path = args.output_dir / f"{args.role}-{args.role_rank}.json"
    transport = None

    def native_group_check():
        assert dist.get_world_size() == args.tp_size
        assert dist.get_rank() == tp_rank
        value = torch.tensor([tp_rank + 1], dtype=torch.float32, device=f"npu:{device}")
        dist.all_reduce(value, group=get_tp_group().device_group)
        assert value.item() == sum(range(1, args.tp_size + 1))
        return value.cpu().tolist()

    def receive_injected_control(rank):
        size = torch.empty(1, dtype=torch.int64, device="cpu")
        dist.recv(size, group_src=rank, group=transport.control_group)
        length = int(size.item())
        if not 0 < length <= MAX_CONTROL_MESSAGE_BYTES:
            raise ValueError("injected peer received an invalid control frame size")
        body = torch.empty(length, dtype=torch.uint8, device="cpu")
        dist.recv(body, group_src=rank, group=transport.control_group)
        return decode_hccl_plan_message(bytes(body.tolist()))

    def send_injected_control(rank, message):
        data = encode_hccl_plan_message(message)
        size = torch.tensor([len(data)], dtype=torch.int64, device="cpu")
        body = torch.tensor(list(data), dtype=torch.uint8, device="cpu")
        dist.send(size, group_dst=rank, group=transport.control_group)
        dist.send(body, group_dst=rank, group=transport.control_group)

    try:
        current_platform.pre_register_and_update()
        load_general_plugins()
        torch.npu.set_device(device)
        adapt_patch()
        config = build_config(args.tp_size, args.model)
        with set_current_vllm_config(config):
            native_port = args.port + 1 + native_group_idx
            init_distributed_environment(
                world_size=args.tp_size,
                rank=tp_rank,
                local_rank=device,
                distributed_init_method=f"tcp://127.0.0.1:{native_port}",
                backend="hccl",
                timeout=timedelta(seconds=GROUP_TIMEOUT_SECONDS),
            )
            initialize_model_parallel(
                tensor_model_parallel_size=args.tp_size, backend="hccl"
            )
            report["native_tp_before_transport"] = native_group_check()
            transport = ObservedHandshakeTransport(
                args.role,
                args.role_rank,
                HcclPlanCapabilities(
                    HIDDEN_SIZE
                    + int(
                        args.reject_hidden_size
                        and args.role == "ffn"
                        and args.role_rank == 0
                    ),
                    VOCAB_SIZE,
                    CAPACITY,
                    LAYERS,
                    args.attention_size,
                    args.ffn_size,
                    args.tp_size,
                    local_counts_version=int(args.local_counts_service),
                    eager_pipeline_version=eager_version,
                ),
                init_method=f"tcp://127.0.0.1:{args.port}",
                local_device=device,
                timeout_seconds=GROUP_TIMEOUT_SECONDS,
            )
            if args.reject_hidden_size or args.reject_eager_pipeline:
                rejection_field = (
                    "eager_pipeline_version"
                    if args.reject_eager_pipeline
                    else "hidden_size"
                )
                try:
                    transport.initialize()
                except (RuntimeError, ValueError) as exc:
                    if rejection_field not in str(exc):
                        raise
                    report["expected_rejection"] = {
                        "type": type(exc).__name__,
                        "message": str(exc),
                    }
                else:
                    raise AssertionError("mismatched HELLO unexpectedly initialized")
                assert transport.terminal and transport.closed
                assert not transport.initialized and not transport.data_groups
                assert not transport.eager_pipeline_warmed
                assert report["created_plugin_group_backends"] == ["gloo"]
                report["rejected_before_hccl_groups_and_warmup"] = True
            else:
                transport.initialize()
                if eager_version:
                    assert transport.negotiated_capabilities.eager_pipeline_version == 1
                    transport.warmup_eager_pipeline(
                        parent_stream=torch.npu.current_stream(device)
                    )
                    assert transport.eager_pipeline_warmed
                    report["matched_eager_warmup_executed"] = True
                report["native_tp_after_initialize"] = native_group_check()
                if args.local_counts_service:
                    run_local_counts_service(
                        torch, dist, args, transport, config, report
                    )
                elif args.reject_plan_digest:
                    first_plan = build_plans(args)[0]
                    if args.role == "ffn" and args.role_rank == 0:
                        forward = receive_injected_control(args.ffn_size)
                        if forward.kind != "FORWARD" or forward.plan != first_plan:
                            raise AssertionError(
                                "injected peer did not receive expected FORWARD"
                            )
                        send_injected_control(
                            args.ffn_size,
                            HcclPlanMessage(
                                "ACCEPT",
                                world_rank=0,
                                transaction_id=first_plan.transaction_id,
                                plan_digest="0" * 64,
                            ),
                        )
                        rejected = receive_injected_control(args.ffn_size)
                        if rejected.kind != "ERROR" or "digest" not in rejected.error:
                            raise AssertionError(
                                "injected peer did not receive digest ERROR"
                            )
                        report["expected_rejection"] = {
                            "type": "ERROR",
                            "message": rejected.error,
                        }
                    else:
                        try:
                            if transport.is_coordinator:
                                transport.begin_forward(first_plan)
                            else:
                                transport.receive_forward()
                        except (RuntimeError, ValueError) as exc:
                            if "digest" not in str(exc):
                                raise
                            report["expected_rejection"] = {
                                "type": type(exc).__name__,
                                "message": str(exc),
                            }
                        else:
                            raise AssertionError(
                                "mismatched ACCEPT unexpectedly succeeded"
                            )
                else:
                    for plan in build_plans(args):
                        if args.role == "attention" and args.role_rank == 0:
                            transport.begin_forward(plan)
                        else:
                            assert transport.receive_forward() == plan
                        if any(
                            any(stage.attention_padded_tokens) for stage in plan.stages
                        ):
                            expect_rejection(
                                report,
                                "early_complete",
                                RuntimeError,
                                transport.finish_forward,
                            )
                        if transport.is_coordinator:
                            expect_rejection(
                                report, "active_stop", RuntimeError, transport.stop
                            )
                        exchanges = []
                        for layer_idx in LAYERS:
                            for stage in plan.stages:
                                if not any(stage.attention_padded_tokens):
                                    continue
                                if args.role == "attention":
                                    source = make_attention_inputs(
                                        torch, args, stage, args.role_rank, layer_idx
                                    )
                                    expect_rejection(
                                        report,
                                        "receive_before_inputs",
                                        RuntimeError,
                                        partial(
                                            transport.receive_layer_output,
                                            layer_idx,
                                            stage.stage_idx,
                                        ),
                                    )
                                    native = tuple(
                                        tensor.to(f"npu:{device}") for tensor in source
                                    )
                                    expect_rejection(
                                        report,
                                        "wrong_stage",
                                        ValueError,
                                        partial(
                                            transport.send_layer_inputs,
                                            layer_idx,
                                            stage.stage_idx + 1,
                                            *native,
                                        ),
                                    )
                                    transport.send_layer_inputs(
                                        layer_idx,
                                        stage.stage_idx,
                                        *native,
                                    )
                                    output = transport.receive_layer_output(
                                        layer_idx, stage.stage_idx
                                    )
                                    expected = expected_attention_output(
                                        torch, args, stage, args.role_rank, layer_idx
                                    )
                                    torch.testing.assert_close(
                                        output.cpu(), expected, rtol=0, atol=0
                                    )
                                else:
                                    expect_rejection(
                                        report,
                                        "output_before_inputs",
                                        RuntimeError,
                                        partial(
                                            transport.send_layer_output,
                                            layer_idx,
                                            stage.stage_idx,
                                            torch.empty(
                                                (0, HIDDEN_SIZE),
                                                dtype=torch.bfloat16,
                                                device=f"npu:{device}",
                                            ),
                                        ),
                                    )
                                    received = transport.receive_layer(
                                        layer_idx, stage.stage_idx
                                    )
                                    expected = expected_ffn_inputs(
                                        torch, args, stage, args.role_rank, layer_idx
                                    )
                                    for actual, reference in zip(
                                        (
                                            received.hidden_states,
                                            received.hidden_states_fp32,
                                            received.input_ids,
                                        ),
                                        expected,
                                        strict=True,
                                    ):
                                        torch.testing.assert_close(
                                            actual.cpu(), reference, rtol=0, atol=0
                                        )
                                    output = local_output(
                                        received.hidden_states,
                                        received.hidden_states_fp32,
                                        received.input_ids,
                                        args.role_rank,
                                        args.tp_size,
                                        layer_idx,
                                        stage.stage_idx,
                                    )
                                    dist.all_reduce(
                                        output, group=get_tp_group().device_group
                                    )
                                    transport.send_layer_output(
                                        layer_idx, stage.stage_idx, output
                                    )
                                exchanges.append([layer_idx, stage.stage_idx])
                        transport.finish_forward()
                        if transport.is_coordinator:
                            expect_rejection(
                                report,
                                "completed_transaction_replay",
                                ValueError,
                                partial(transport.begin_forward, plan),
                            )
                        report["transactions"].append(
                            {
                                "transaction_id": plan.transaction_id,
                                "mode": plan.mode,
                                "plan_digest": plan.digest,
                                "verified_layer_stages": exchanges,
                                "stages": [
                                    {
                                        "stage_idx": stage.stage_idx,
                                        "valid": stage.attention_valid_tokens,
                                        "padded": stage.attention_padded_tokens,
                                    }
                                    for stage in plan.stages
                                ],
                            }
                        )
                    if args.role == "attention" and args.role_rank == 0:
                        transport.stop()
                    else:
                        assert transport.receive_forward() is None
                    report["stop_acknowledged"] = True
            transport.close()
            transport.close()
            report["native_tp_after_close"] = native_group_check()
            report["success"] = True
    except BaseException as exc:
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        traceback.print_exc()
    finally:
        result_path.write_text(json.dumps(report, indent=2) + "\n")
        try:
            if transport is not None:
                transport.close()
            destroy_model_parallel()
            destroy_distributed_environment()
            report["native_groups_destroyed"] = True
        except BaseException as exc:
            report["success"] = False
            report["cleanup_error"] = {"type": type(exc).__name__, "message": str(exc)}
            traceback.print_exc()
        report["elapsed_seconds"] = time.monotonic() - started
        result_path.write_text(json.dumps(report, indent=2) + "\n")
    return 0 if report["success"] else 1


def select_port_block(count):
    for _ in range(PORT_ATTEMPTS):
        listeners = []
        try:
            first = socket.socket()
            listeners.append(first)
            first.bind(("127.0.0.1", 0))
            port = first.getsockname()[1]
            if port + count - 1 > MAX_TCP_PORT:
                continue
            for offset in range(1, count):
                listener = socket.socket()
                listeners.append(listener)
                listener.bind(("127.0.0.1", port + offset))
            return port
        except OSError:
            continue
        finally:
            for listener in listeners:
                listener.close()
    raise RuntimeError("could not reserve a contiguous probe port block")


def run_parent(args):
    started = time.monotonic()
    args.output_dir = args.output_dir or Path(
        tempfile.mkdtemp(prefix="afd-stage-probe-")
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    port = select_port_block(1 + (args.attention_size + args.ffn_size) // args.tp_size)
    processes, logs = [], []
    summary = {
        "scope": "multi-stage transport component; no native MoE/model",
        "success": False,
    }
    deadline = started + args.timeout - REAP_TIMEOUT_SECONDS
    try:
        for role, count in (("ffn", args.ffn_size), ("attention", args.attention_size)):
            for rank in range(count):
                key = f"{role}-{rank}"
                log = (args.output_dir / (key + ".log")).open("w")
                logs.append(log)
                command = [
                    sys.executable,
                    "-B",
                    str(Path(__file__).resolve()),
                    "--topology",
                    args.topology,
                    "--model",
                    args.model,
                    "--role",
                    role,
                    "--role-rank",
                    str(rank),
                    "--port",
                    str(port),
                    "--devices",
                    ",".join(map(str, args.devices)),
                    "--output-dir",
                    str(args.output_dir),
                ]
                if args.reject_hidden_size:
                    command.append("--reject-hidden-size")
                if args.reject_plan_digest:
                    command.append("--reject-plan-digest")
                if args.local_counts_service:
                    command.append("--local-counts-service")
                command += [
                    "--eager-pipeline-version",
                    str(args.eager_pipeline_version),
                ]
                if args.reject_eager_pipeline:
                    command += ["--reject-eager-pipeline", args.reject_eager_pipeline]
                process = subprocess.Popen(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
                processes.append((key, process))
        for _, process in processes:
            process.wait(timeout=max(0.1, deadline - time.monotonic()))
    except subprocess.TimeoutExpired:
        summary["timed_out"] = True
    finally:
        summary["external_kills"] = []
        for key, process in processes:
            if process.poll() is None:
                summary["external_kills"].append(key)
                os.killpg(process.pid, signal.SIGKILL)
        for _, process in processes:
            process.wait(timeout=REAP_TIMEOUT_SECONDS)
        for log in logs:
            log.close()
        summary["ranks"] = {
            key: {
                "pid": process.pid,
                "exit_code": process.returncode,
                "result": json.loads((args.output_dir / (key + ".json")).read_text())
                if (args.output_dir / (key + ".json")).exists()
                else None,
            }
            for key, process in processes
        }
        summary["success"] = (
            bool(summary["ranks"])
            and not summary["external_kills"]
            and all(
                value["exit_code"] == 0
                and value["result"] is not None
                and value["result"]["success"]
                for value in summary["ranks"].values()
            )
        )
        summary["topology"] = args.topology
        summary["reject_hidden_size"] = args.reject_hidden_size
        summary["reject_plan_digest"] = args.reject_plan_digest
        summary["local_counts_service"] = args.local_counts_service
        summary["eager_pipeline_version"] = args.eager_pipeline_version
        summary["reject_eager_pipeline"] = args.reject_eager_pipeline
        summary["devices"] = args.devices
        summary["elapsed_seconds"] = time.monotonic() - started
        (args.output_dir / "result.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if summary["success"] else 1


if __name__ == "__main__":
    parsed = parse_args()
    raise SystemExit(run_rank(parsed) if parsed.role else run_parent(parsed))
