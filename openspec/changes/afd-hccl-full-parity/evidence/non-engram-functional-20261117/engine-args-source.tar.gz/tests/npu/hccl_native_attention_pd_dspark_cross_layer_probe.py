# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Observe original Graph pipeline scopes without adding device operations.

Host scope order is separate from HCCL device completion. This opt-in observer
retains no graph or tensor and does not execute Python on graph replay.
"""

from __future__ import annotations

from contextlib import contextmanager

TARGET_ACTIONS = (
    ("input", 0, 0),
    ("input", 0, 1),
    ("output", 0, 0),
    ("input", 1, 0),
    ("output", 0, 1),
    ("input", 1, 1),
    ("output", 1, 0),
    ("output", 1, 1),
)


@contextmanager
def observe_cross_layer_actions(report):
    """Wrap public scopes in this isolated process; preserve their real bodies."""
    import torch

    from afd_plugin.connectors.npu.hccl_graph_pipeline import (
        HcclGraphComputePipeline,
    )

    cls = HcclGraphComputePipeline
    original_run = cls.run
    methods = {
        "attention_send": (cls.attention_send, "input"),
        "attention_receive": (cls.attention_receive, "output"),
        "ffn_receive": (cls.ffn_receive, "input"),
        "ffn_send": (cls.ffn_send, "output"),
    }
    runs = report["graph_cross_layer_actions"] = []
    active = {}

    @contextmanager
    def observed_run(pipeline):
        assert pipeline.bank.exchange_order == "cross_layer_v1"
        assert pipeline.schedule is not None
        identity = id(pipeline)
        assert identity not in active
        record = {
            "ordinal": len(runs),
            "role": pipeline.bank.role,
            "key_digest": pipeline.bank.key.digest,
            "pipeline": identity,
            "bank": id(pipeline.bank),
            "schedule": id(pipeline.schedule),
            "exchange_order": pipeline.bank.exchange_order,
            "stage_rows": list(pipeline.bank.stage_rows),
            "phase": (
                "capture" if torch.npu.is_current_stream_capturing() else "warmup"
            ),
            "declared_actions": [
                [action.kind, action.layer_idx, action.stage_idx]
                for action in pipeline.schedule.actions
            ],
            "actions": [],
            "returned": False,
        }
        runs.append(record)
        active[identity] = record
        try:
            with original_run(pipeline):
                yield
            record["returned"] = True
        except BaseException as error:
            record["error_type"] = type(error).__name__
            raise
        finally:
            del active[identity]

    def wrap_action(original, kind):
        @contextmanager
        def observed(pipeline, layer_idx, stage_idx, **kwargs):
            record = active[id(pipeline)]
            fields = {"kind": kind, "layer": layer_idx, "stage": stage_idx}
            record["actions"].append(fields | {"boundary": "begin"})
            with original(pipeline, layer_idx, stage_idx, **kwargs):
                yield
            record["actions"].append(fields | {"boundary": "returned"})

        return observed

    try:
        cls.run = observed_run
        for name, (original, kind) in methods.items():
            setattr(cls, name, wrap_action(original, kind))
        yield
        assert not active
    finally:
        cls.run = original_run
        for name, (original, _) in methods.items():
            setattr(cls, name, original)


def verify_cross_layer_actions(records, entries, *, role):
    """Join actual host scopes with the retained U2 capture's schedule owner."""
    assert len(records) == 2
    assert [record["phase"] for record in records] == ["warmup", "capture"]
    u2_entries = [entry for entry in entries if entry["num_stages"] == 2]
    assert len(u2_entries) == 1
    entry = u2_entries[0]
    expected = [
        {"kind": kind, "layer": layer, "stage": stage, "boundary": boundary}
        for kind, layer, stage in TARGET_ACTIONS
        for boundary in ("begin", "returned")
    ]
    for ordinal, record in enumerate(records):
        assert type(record["ordinal"]) is int and record["ordinal"] == ordinal
        assert record["role"] == role
        assert record["key_digest"] == entry["key_digest"]
        assert record["exchange_order"] == "cross_layer_v1"
        assert record["stage_rows"] == [3, 3]
        assert record["returned"] is True and "error_type" not in record
        assert record["declared_actions"] == [list(action) for action in TARGET_ACTIONS]
        assert all(
            type(coordinate) is int
            for action in record["declared_actions"]
            for coordinate in action[1:]
        )
        assert record["actions"] == expected
        assert all(
            type(action[name]) is int
            for action in record["actions"]
            for name in ("layer", "stage")
        )
        assert all(
            type(record[name]) is int and record[name] > 0
            for name in ("pipeline", "bank", "schedule")
        )
        if record["phase"] == "capture":
            pipeline = entry["pipeline_storage"]
            assert record["pipeline"] == pipeline["pipeline"]
            assert record["bank"] == pipeline["bank"]
            assert record["schedule"] == pipeline["schedule"]["identity"]


def verify_cross_layer_lifecycle(attention, ffn):
    """Validate the original lifecycle and both roles' actual host action order."""
    from hccl_native_attention_pd_dspark_overlap_probe import (
        verify_graph_compute_lifecycle,
    )

    for report in (attention, ffn):
        assert report["graph_exchange_order_requested"] == "cross_layer_v1"
    assert (
        attention["native_live_owner"]["graph_exchange_order_requested"]
        == "cross_layer_v1"
    )
    service = ffn["native_ffn"]
    assert service["graph_exchange_order_requested"] == "cross_layer_v1"
    protocol = verify_graph_compute_lifecycle(
        attention, ffn, graph_all_axes=True, graph_exchange_order="cross_layer_v1"
    )
    entries = attention["target_graph_decode"]["storage_before"]["entries"]
    for entry in entries:
        assert entry["bank_exchange_order"] == (
            "stage_serial" if entry["num_stages"] == 1 else "cross_layer_v1"
        )
    captures = {entry["key"]: entry for entry in service["captured_entries"]}
    for entry in captures.values():
        assert entry["bank_exchange_order"] == (
            "stage_serial" if entry["num_ubatches"] == 1 else "cross_layer_v1"
        )
    for transaction in service["transactions"]:
        if transaction["phase"] in ("capture", "replay"):
            assert (
                transaction["bank_exchange_order"]
                == (captures[transaction["key"]]["bank_exchange_order"])
            )
    verify_cross_layer_actions(
        attention["graph_cross_layer_actions"], entries, role="attention"
    )
    peer_entries = [
        {
            "key_digest": entry["key"],
            "num_stages": entry["num_ubatches"],
            "pipeline_storage": entry["pipeline_storage"],
        }
        for entry in service["captured_entries"]
    ]
    verify_cross_layer_actions(
        ffn["graph_cross_layer_actions"], peer_entries, role="ffn"
    )
    return protocol | {
        "native_dspark_graph_cross_layer_lifecycle_component_accepted": True,
        "host_action_order_observed": True,
        "device_timeline_accepted": False,
    }
