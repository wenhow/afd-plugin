# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Legal eager PD primitives for a future native Attention handoff component.

The default command only inspects installed Mooncake metadata and binary bytes.
``--run-storage`` additionally materializes native V4.1 NPU KV storage. Explicit
``--run-transfer`` starts supervised independent P/D workers, each with native
TP1 groups and a real TransferEngine/ActiveKVConnector. It checks asynchronous
zero-work submission, attested page reads and native DONE with exact page bytes.
It does not execute a model or the DSpark Ready/read-lease protocol. There is no
simulated transfer-engine path.

``--run-scheduler-transfer`` additionally uses the native D scheduler for page
allocation, asynchronous completion and first-target admission. It stops before
model execution and preserves the separate transfer-only baseline.

``--run-model-transfer`` adds a third real F daemon and consumes the actual D
first-target schedule through native execute/sample and request retirement.
Its Attention/HC/FFN leaves are controlled, with positive finite BF16 page bytes.

``--target-graph`` captures on the idle registered D owner, receives two real
PD requests and executes their eager first target followed by Q1 FULL/U2 replay
with cumulative KV writes. It uses controlled arithmetic and does not qualify
checkpoint inference, SparseFA, DSpark or performance.

``--native-producer`` adds original-prompt P scheduling and controlled native
KV generation. Its actual EngineCoreOutput supplies D's transfer declaration;
hybrid truncation and DONE-delayed P block retirement remain native.

``--producer-aux`` additionally selects actual native entering-layer auxiliary
outputs on P without speculation or a draft model. It does not project DSpark KV.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.machinery
import importlib.metadata
import json
import os
import subprocess
import sys
import time
import traceback
import uuid
from contextlib import ExitStack
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import torch
    from vllm.config import VllmConfig
    from vllm.v1.core.sched.output import SchedulerOutput
    from vllm.v1.kv_cache_interface import KVCacheConfig
    from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )

    from afd_plugin.compat.npu.kv_layout import KVLayoutSnapshot

MOONCAKE_DISTRIBUTIONS = (
    "mooncake-transfer-engine-npu",
    "mooncake-transfer-engine-ascend",
    "mooncake-transfer-engine",
)
ATTESTED_CONNECTOR_MODULE = "afd_plugin.compat.npu.kv_layout_connector"
DEFAULT_HANDSHAKE_PORT = 23570
BLOCK_SIZE = 128
HEAD_SIZE = 16
INDEX_HEAD_SIZE = 8
LAYER_COUNT = 2
COMPRESS_RATIO = 2
STATE_RING_ROWS = 32
NUM_BLOCKS = 9
SOURCE_BLOCK = 1
DESTINATION_BLOCK = 2
DESTINATION_SENTINEL = 165
SOURCE_BYTE_MODULUS = 251
SOURCE_POOL_MULTIPLIER = 17
TOTAL_TIMEOUT_SECONDS = 240
SOURCE_RETENTION_TIMEOUT_SECONDS = 2 * TOTAL_TIMEOUT_SECONDS
GROUP_TIMEOUT_SECONDS = 45
POLL_SECONDS = 0.05


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inspect_mooncake_dependencies() -> dict:
    """Resolve distributions and extension bytes without importing Mooncake."""
    installed = []
    for name in MOONCAKE_DISTRIBUTIONS:
        try:
            distribution = importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:
            continue
        binaries = []
        for member in distribution.files or ():
            if not str(member).endswith(".so"):
                continue
            path = Path(distribution.locate_file(member)).resolve(strict=True)
            binaries.append(
                {
                    "path": str(path),
                    "size": path.stat().st_size,
                    "sha256": file_sha256(path),
                }
            )
        installed.append(
            {
                "name": distribution.metadata["Name"],
                "version": distribution.version,
                "root": str(Path(distribution.locate_file("")).resolve()),
                "binaries": sorted(binaries, key=lambda item: item["path"]),
            }
        )
    # PathFinder resolves the child against package search paths directly.
    # importlib.util.find_spec('mooncake.engine') would import its parent.
    package = importlib.machinery.PathFinder.find_spec("mooncake")
    extension = None
    if package is not None and package.submodule_search_locations is not None:
        extension = importlib.machinery.PathFinder.find_spec(
            "mooncake.engine", package.submodule_search_locations
        )
    engine = None
    if extension is not None and extension.origin is not None:
        path = Path(extension.origin).resolve(strict=True)
        engine = {
            "path": str(path),
            "size": path.stat().st_size,
            "sha256": file_sha256(path),
        }
    owns_extension = (
        len(installed) == 1
        and engine is not None
        and any(
            binary["path"] == engine["path"] and binary["sha256"] == engine["sha256"]
            for binary in installed[0]["binaries"]
        )
    )
    return {
        "distributions": installed,
        "engine_extension": engine,
        "single_distribution_owns_resolved_extension": owns_extension,
        "engine_imported": "mooncake.engine" in sys.modules,
        "engine_initialized": False,
        "npu_queried": False,
        "runtime_import_accepted": False,
        "transfer_accepted": False,
    }


def make_eager_pd_config(
    base: VllmConfig,
    *,
    role: Literal["kv_producer", "kv_consumer"],
    engine_id: str,
    handshake_port: int,
    host: str,
) -> VllmConfig:
    """Clone an unbound eager/Q1 target before any model/storage/worker exists.

    Existing speculation, transfer, Graph or ubatching is rejected; no unsupported
    original configuration is converted to an eligible consumer after binding.
    Production validation runs on the resulting independent role configuration.
    """
    # Lazy imports isolate the stdlib dependency/help command from runtime setup.
    from vllm.config.kv_transfer import KVTransferConfig

    from afd_plugin.compat.npu.runtime_config import (
        is_deepseek_v41_model,
        validate_deepseek_v41_pd,
    )

    if (
        not is_deepseek_v41_model(base)
        or base.kv_transfer_config is not None
        or base.speculative_config is not None
        or base.engram_config is not None
        or not base.model_config.enforce_eager
        or base.compilation_config.cudagraph_mode.name != "NONE"
        or base.compilation_config.mode.name != "NONE"
        or base.compilation_config.use_inductor_graph_partition
        or base.compilation_config.static_forward_context
        or base.parallel_config.use_ubatching
        or base.parallel_config.enable_dbo
        or base.parallel_config.tensor_parallel_size != 1
    ):
        raise ValueError("PD primitive requires an unbound eager/no-spec/TP1/U1 target")
    if role not in ("kv_producer", "kv_consumer"):
        raise ValueError("PD primitive requires a separate P or D role")
    if not engine_id or not host or not 0 < handshake_port < 65536:
        raise ValueError("PD primitive requires an explicit engine/host/port identity")
    config = copy.deepcopy(base)
    config.kv_transfer_config = KVTransferConfig(
        kv_connector="MooncakeHybridConnector",
        kv_connector_module_path=ATTESTED_CONNECTOR_MODULE,
        engine_id=engine_id,
        kv_buffer_device="npu",
        kv_role=role,
        kv_ip=host,
        kv_port=handshake_port,
        kv_connector_extra_config={
            "prefill": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
            "decode": {"tp_size": 1, "dp_size": 1, "pp_size": 1},
        },
    )
    validate_deepseek_v41_pd(config)
    return config


@dataclass(frozen=True)
class NativePdStorage:
    """Retain the actual config, native allocations, views and attested layout."""

    vllm_config: VllmConfig
    kv_cache_config: KVCacheConfig
    raw_tensors: dict[str, torch.Tensor]
    caches: dict[str, torch.Tensor | tuple[torch.Tensor, ...]]
    layout: KVLayoutSnapshot


def allocate_native_pd_storage(
    config: VllmConfig, device: torch.device
) -> NativePdStorage:
    """Use the locked V4.1 planner, aligned allocator and native view reshaper.

    Geometry is controlled metadata, not a checkpoint Attention implementation.
    All aliases/offsets/dtypes/scale planes are chosen by the actual native cache
    factories and materialization functions, then read back by the real collector.
    """
    import torch
    from vllm.config import set_current_vllm_config
    from vllm.v1.kv_cache_interface import CircularBufferSpec
    from vllm.v1.worker.utils import AttentionGroup
    from vllm_ascend.attention.dsa_v41 import DeepseekV41CacheBackend
    from vllm_ascend.models.deepseek_v41.cache_config import (
        get_deepseek_v41_kv_cache_config,
        get_deepseek_v41_pool_bytes_per_block,
        group_cache_specs,
        make_cache_groups,
        make_index_cache_spec,
        make_mla_cache_spec,
        make_swa_cache_spec,
    )
    from vllm_ascend.worker.v2.attn_utils import (
        _allocate_kv_cache,
        _reshape_kv_cache_v2,
    )

    from afd_plugin.compat.npu.kv_layout_native import (
        collect_deepseek_v41_kv_layout,
    )
    from afd_plugin.compat.npu.runtime_config import validate_deepseek_v41_pd

    validate_deepseek_v41_pd(config)
    if config.kv_transfer_config is None:
        raise ValueError("native PD storage requires an original PD role configuration")
    if device.type != "npu" or device.index is None:
        raise ValueError("PD storage requires an actual indexed NPU device")
    text = config.model_config.hf_text_config
    if (
        config.speculative_config is not None
        or config.engram_config is not None
        or config.compilation_config.mode.name != "NONE"
        or config.compilation_config.static_forward_context
        or text.num_hidden_layers != LAYER_COUNT
        or text.hidden_size != HEAD_SIZE
        or list(text.compress_ratios) != [COMPRESS_RATIO] * LAYER_COUNT
    ):
        raise ValueError("storage requires the declared unbound tiny eager PD metadata")
    specs = {}
    for index in range(LAYER_COUNT):
        prefix = f"model.layers.{index}.self_attn"
        specs[prefix + ".long_kv_cache"] = make_mla_cache_spec(
            block_size=BLOCK_SIZE,
            head_size=HEAD_SIZE,
            compress_ratio=COMPRESS_RATIO,
        )
        specs[prefix + ".indexer.k_cache"] = make_index_cache_spec(
            block_size=BLOCK_SIZE,
            head_size=INDEX_HEAD_SIZE,
            compress_ratio=COMPRESS_RATIO,
        )
        specs[prefix + ".compressor.state_cache"] = CircularBufferSpec(
            block_size=STATE_RING_ROWS,
            num_kv_heads=1,
            head_size=HEAD_SIZE,
            dtype=torch.bfloat16,
        )
        specs[prefix + ".swa_cache"] = make_swa_cache_spec(
            block_size=BLOCK_SIZE,
            window_size=text.sliding_window,
            head_size=HEAD_SIZE,
            dtype=torch.bfloat16,
            cache_dtype=config.cache_config.cache_dtype,
        )
    groups = make_cache_groups(group_cache_specs(specs))
    pool_bytes = get_deepseek_v41_pool_bytes_per_block(groups)
    kv_config = get_deepseek_v41_kv_cache_config(
        config, groups, available_memory=NUM_BLOCKS * pool_bytes
    )
    if kv_config.num_blocks != NUM_BLOCKS:
        raise ValueError("native cache override changed the bounded component capacity")
    attention_groups = []
    for group_index, group in enumerate(groups):
        for name in group.layer_names:
            attention_groups.append(
                AttentionGroup(
                    backend=DeepseekV41CacheBackend,
                    layer_names=[name],
                    kv_cache_spec=group.kv_cache_spec.kv_cache_specs[name],
                    kv_cache_group_id=group_index,
                )
            )
    with set_current_vllm_config(config):
        raw = _allocate_kv_cache(kv_config, shared_layers={}, device=device)
        caches = _reshape_kv_cache_v2(
            attn_groups=attention_groups,
            kv_cache_raw_tensors=raw,
            cache_dtype=config.cache_config.cache_dtype,
            kernel_block_sizes=[group.kv_cache_spec.block_size for group in groups],
            shared_kv_cache_layers={},
            kv_cache_config=kv_config,
        )
    layout = collect_deepseek_v41_kv_layout(kv_config, caches)
    assert layout.device_type == "npu" and layout.num_blocks == NUM_BLOCKS
    return NativePdStorage(config, kv_config, raw, caches, layout)


def bind_native_pd_storage(
    config: VllmConfig, storage: NativePdStorage
) -> ActiveKVConnector:
    """Initialize the real native singleton/factory and register actual KV views.

    Call only in a supervised fresh worker with native model-parallel groups.
    Failure retains the native engine/worker/storage for process supervision;
    there is no fabricated success or unconditional cleanup in this helper.
    """
    from vllm.distributed.kv_transfer import (
        ensure_kv_transfer_initialized,
        has_kv_transfer_group,
    )
    from vllm.v1.worker.gpu.kv_connector import (
        ActiveKVConnector,
        get_kv_connector,
    )

    from afd_plugin.compat.npu.kv_layout_connector import MooncakeHybridConnector
    from afd_plugin.compat.npu.runtime_config import validate_deepseek_v41_pd

    if config is not storage.vllm_config:
        raise ValueError("PD storage must bind its original role configuration")
    if has_kv_transfer_group():
        raise RuntimeError("PD component requires a fresh native KV singleton")
    validate_deepseek_v41_pd(config)
    ensure_kv_transfer_initialized(config, storage.kv_cache_config)
    active = get_kv_connector(config, storage.caches)
    assert isinstance(active, ActiveKVConnector)
    assert isinstance(active.kv_connector, MooncakeHybridConnector)
    return active


def make_pd_idle_step(metadata: MooncakeConnectorMetadata) -> SchedulerOutput:
    """Build genuine zero-work caller input for ActiveKV/native owner polling."""
    from vllm.v1.core.sched.output import SchedulerOutput

    output = SchedulerOutput.make_empty()
    output.kv_connector_metadata = metadata
    # Retain native async default: no fake synchronous-load fast path.
    assert output.has_sync_kv_loads is False
    return output


def prepare_component_config(args: argparse.Namespace) -> VllmConfig:
    """Create all controlled role metadata before storage/model registration."""
    from hccl_staged_probe import build_config

    base = build_config(1, args.model)
    base.cache_config.block_size = BLOCK_SIZE
    base.cache_config.enable_prefix_caching = False
    base.cache_config.num_gpu_blocks_override = None
    base.scheduler_config.disable_hybrid_kv_cache_manager = False
    text = base.model_config.hf_text_config
    text.hidden_size = HEAD_SIZE
    text.num_hidden_layers = LAYER_COUNT
    text.compress_ratios = [COMPRESS_RATIO] * LAYER_COUNT
    text.sliding_window = BLOCK_SIZE
    base.model_config.hf_config = text
    if args.run_model_transfer and (args.role != "kv_producer" or args.native_producer):
        from hccl_native_attention_pd_model_probe import configure_pd_model_component

        configure_pd_model_component(
            base, role="ffn" if args.role == "ffn" else "attention", port=args.afd_port
        )
        if args.native_producer and args.role == "kv_producer":
            base.additional_config = {}
    if args.role == "ffn":
        if args.target_graph:
            from hccl_native_attention_pd_graph_probe import configure_pd_target_graph

            configure_pd_target_graph(base)
        return base
    config = make_eager_pd_config(
        base,
        role=args.role,
        engine_id=args.engine_id,
        handshake_port=args.handshake_port,
        host=args.host,
    )
    if args.target_graph and args.role == "kv_consumer":
        from hccl_native_attention_pd_graph_probe import configure_pd_target_graph

        configure_pd_target_graph(config)
    return config


def run_storage(args: argparse.Namespace) -> dict:
    """Explicit device-only smoke of prerequisites, without a transfer engine."""
    import torch
    from vllm.platforms import current_platform

    # Same real platform setup as EngineArgs, before model/config construction.
    current_platform.pre_register_and_update()
    import vllm_ascend.ops  # noqa: F401
    from vllm_ascend.ascend_config import init_ascend_config

    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    config = prepare_component_config(args)
    text = config.model_config.hf_text_config
    init_ascend_config(config)
    storage = allocate_native_pd_storage(config, device)
    torch.npu.synchronize(device)
    return {
        "role": config.kv_transfer_config.kv_role,
        "engine_id": config.kv_transfer_config.engine_id,
        "device": str(device),
        "original_checkpoint": str(Path(args.model).resolve()),
        "component_layers": LAYER_COUNT,
        "component_hidden_size": HEAD_SIZE,
        "component_compress_ratios": list(text.compress_ratios),
        "layout": json.loads(storage.layout.to_json()),
        "native_aligned_allocator_executed": True,
        "native_view_reshaper_executed": True,
        "native_layout_collector_executed": True,
        "transfer_engine_initialized": False,
        "memory_registered": False,
        "active_kv_connector_constructed": False,
        "native_attention_owner_executed": False,
        "production_u1_requested": args.production_u1,
        "pd_handoff_accepted": False,
        "graph_pd_accepted": False,
        "full_model_accepted": False,
        "performance_accepted": False,
    }


def write_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def await_peer_record(path: Path, *, run_id: str, deadline: float) -> dict:
    """Wait on supervisor-owned caller coordination, outside the PD protocol."""
    while not path.exists():
        if time.monotonic() >= deadline:
            raise TimeoutError(f"timed out waiting for peer record {path.name}")
        time.sleep(POLL_SECONDS)
    record = json.loads(path.read_text(encoding="utf-8"))
    if record["run_id"] != run_id:
        raise ValueError("peer record belongs to a different component run")
    return record


def source_page_bytes(pool_index: int, size: int) -> bytes:
    """Independent host oracle for controlled physical bytes, including padding."""
    offset = SOURCE_POOL_MULTIPLIER * (pool_index + 1)
    return bytes((index + offset) % SOURCE_BYTE_MODULUS for index in range(size))


def snapshot_pages(
    storage: NativePdStorage, output_dir: Path, *, label: str
) -> list[dict]:
    """Save every full physical allocation, preserving independent page aliases."""
    result = []
    for index, descriptor in enumerate(storage.kv_cache_config.kv_cache_tensors):
        raw = storage.raw_tensors[descriptor.layers[0]]
        assert raw.is_contiguous() and raw.numel() == descriptor.size
        contents = raw.detach().cpu().numpy().tobytes()
        path = output_dir / f"{label}-pool-{index}.bin"
        path.write_bytes(contents)
        result.append(
            {
                "path": path.name,
                "sha256": file_sha256(path),
                "size": len(contents),
                "data_ptr": raw.data_ptr(),
                "block_stride": descriptor.block_stride,
                "layers": list(descriptor.layers),
            }
        )
    return result


def transfer_source_page_bytes(args, pool_index, size, block_stride):
    if args.run_model_transfer:
        from hccl_native_attention_pd_model_probe import model_source_page_bytes

        return model_source_page_bytes(pool_index, size, block_stride=block_stride)
    return source_page_bytes(pool_index, size)


def run_model_ffn_worker(args, config, device, deadline, result_path):
    import torch
    from hccl_native_attention_pd_model_probe import (
        create_pd_model_connector,
        run_pd_ffn_service,
    )
    from vllm.config import set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )

    report = {
        "run_id": args.run_id,
        "role": args.role,
        "pid": os.getpid(),
        "device": str(device),
        "success": False,
        "native_groups_destroyed": False,
    }
    try:
        with set_current_vllm_config(config):
            init_distributed_environment(
                world_size=1,
                rank=0,
                local_rank=device.index,
                distributed_init_method=f"tcp://127.0.0.1:{args.native_port}",
                backend="hccl",
                timeout=timedelta(seconds=GROUP_TIMEOUT_SECONDS),
            )
            initialize_model_parallel(tensor_model_parallel_size=1, backend="hccl")
            assert get_tp_group().world_size == 1
            connector = create_pd_model_connector(
                config,
                device,
                production_u1=args.production_u1,
                target_graph=args.target_graph,
                report=report,
            )
            # Management-created MC2 masks are shared with the daemon. Native
            # startup creates them outside InferenceMode, before the thread.
            run_pd_ffn_service(
                config,
                device,
                connector,
                report,
                deadline=deadline,
                production_u1=args.production_u1,
                target_graph=args.target_graph,
            )
            value = torch.tensor([SOURCE_POOL_MULTIPLIER], device=device)
            get_tp_group().all_reduce(value)
            assert value.item() == SOURCE_POOL_MULTIPLIER
            report["native_tp_after_service"] = True
            destroy_model_parallel()
            destroy_distributed_environment()
            report["native_groups_destroyed"] = report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        write_json(result_path, report)


def run_transfer_worker(args: argparse.Namespace) -> None:
    # Worker isolation: importing the parent/help path never initializes NPU/TE.
    import msgspec
    import torch
    import torch.distributed as dist
    from vllm import envs
    from vllm.config import set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.platforms import current_platform
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )

    current_platform.pre_register_and_update()
    import vllm_ascend.ops  # noqa: F401

    if args.run_model_transfer:
        from vllm.plugins import load_general_plugins
        from vllm_ascend.utils import adapt_patch

        load_general_plugins()
        adapt_patch()

    from afd_plugin.compat.npu.kv_layout import compare_kv_layouts, layout_from_json
    from afd_plugin.compat.npu.kv_layout_connector import (
        AttestedMooncakeAgentMetadata,
    )

    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    config = prepare_component_config(args)
    if args.run_model_transfer and args.role != "kv_producer":
        from afd_plugin.compat.patches.npu.ascend_config import (
            init_ascend_config as init_afd_ascend_config,
        )

        init_afd_ascend_config(config)
    else:
        init_ascend_config(config)
    result_path = args.output_dir / f"{args.role}.json"
    deadline = time.monotonic() + args.timeout
    if args.role == "ffn":
        run_model_ffn_worker(args, config, device, deadline, result_path)
        return
    report = {
        "run_id": args.run_id,
        "role": args.role,
        "pid": os.getpid(),
        "device": str(device),
        "success": False,
        "native_groups_destroyed": False,
        "native_tp_size": 1,
        "independent_native_world_size": 1,
        "source_retention_timeout_seconds": envs.VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT,
        "public_zero_work_steps": [],
        "native_attention_owner_executed": False,
        "typed_dspark_ready_lease_executed": False,
        "request_cancellation_executed": False,
        "model_kv_cleanup_verified": False,
        "thread_retirement_verified": False,
        "graph_pd_accepted": False,
        "full_model_accepted": False,
        "performance_accepted": False,
        "configuration": {
            "kv_role": config.kv_transfer_config.kv_role,
            "kv_connector": config.kv_transfer_config.kv_connector,
            "kv_connector_module_path": (
                config.kv_transfer_config.kv_connector_module_path
            ),
            "engine_id": config.kv_transfer_config.engine_id,
            "enforce_eager": config.model_config.enforce_eager,
            "cudagraph_mode": config.compilation_config.cudagraph_mode.name,
            "compilation_mode": config.compilation_config.mode.name,
            "speculative_config_is_none": config.speculative_config is None,
            "engram_config_is_none": config.engram_config is None,
            "use_ubatching": config.parallel_config.use_ubatching,
            "native_tp_size": config.parallel_config.tensor_parallel_size,
            "disable_hybrid_kv_cache_manager": (
                config.scheduler_config.disable_hybrid_kv_cache_manager
            ),
            "component_layers": config.model_config.hf_text_config.num_hidden_layers,
            "component_hidden_size": config.model_config.hf_text_config.hidden_size,
        },
    }
    source_request_id = args.run_id + "-source"
    destination_request_id = args.run_id + "-destination"
    source_ids, destination_ids = {source_request_id}, {destination_request_id}
    if args.run_request_reuse:
        source_ids.add(args.run_id + "-source-b")
        destination_ids.add(args.run_id + "-destination-b")
    if args.target_graph:
        from hccl_native_attention_pd_graph_lifecycle_probe import graph_request_ids

        graph_sources, graph_destinations = graph_request_ids(args.run_id)
        source_ids, destination_ids = set(graph_sources), set(graph_destinations)
    scheduler_handoff = model_owner = model_connector = None
    assert args.timeout < envs.VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT

    def native_tp_check() -> dict:
        value = torch.tensor([SOURCE_POOL_MULTIPLIER], device=device)
        dist.all_reduce(value, group=get_tp_group().device_group)
        assert value.item() == SOURCE_POOL_MULTIPLIER
        assert dist.get_world_size() == get_tp_group().world_size == 1
        return {"rank": dist.get_rank(), "world_size": dist.get_world_size()}

    def zero_step(active, metadata) -> tuple[set[str], set[str]]:
        step = make_pd_idle_step(metadata)
        returned = active.no_forward(step)
        output = returned.kv_connector_output
        # The native output factory elides an empty KVConnectorOutput while an
        # asynchronous load is still pending. Preserve that public observation;
        # only a later real completion can satisfy the transfer contract.
        sent = set(() if output is None else output.finished_sending or ())
        received = set(() if output is None else output.finished_recving or ())
        failed = set(() if output is None else output.failed_recving or ())
        invalid = set(() if output is None else output.invalid_block_ids or ())
        report["public_zero_work_steps"].append(
            {
                "has_sync_kv_loads": step.has_sync_kv_loads,
                "total_num_scheduled_tokens": step.total_num_scheduled_tokens,
                "submitted_request_ids": sorted(metadata.requests),
                "kv_connector_output_present": output is not None,
                "finished_sending": sorted(sent),
                "finished_recving": sorted(received),
                "failed_recving": sorted(failed),
                "invalid_block_ids": sorted(invalid),
            }
        )
        assert not failed and not invalid
        assert sent.issubset(source_ids)
        assert received.issubset(destination_ids)
        return sent, received

    try:
        with set_current_vllm_config(config):
            init_distributed_environment(
                world_size=1,
                rank=0,
                local_rank=args.device,
                distributed_init_method=f"tcp://127.0.0.1:{args.native_port}",
                backend="hccl",
                timeout=timedelta(seconds=GROUP_TIMEOUT_SECONDS),
            )
            initialize_model_parallel(tensor_model_parallel_size=1, backend="hccl")
            report["native_tp_before_transfer"] = native_tp_check()
            if args.run_model_transfer and args.role == "kv_consumer":
                from hccl_native_attention_pd_model_probe import (
                    create_pd_model_connector,
                )

                model_connector = create_pd_model_connector(
                    config,
                    device,
                    production_u1=args.production_u1,
                    target_graph=args.target_graph,
                    report=report,
                )
            storage = allocate_native_pd_storage(config, device)
            for index, descriptor in enumerate(
                storage.kv_cache_config.kv_cache_tensors
            ):
                raw = storage.raw_tensors[descriptor.layers[0]]
                data = (
                    transfer_source_page_bytes(
                        args, index, descriptor.size, descriptor.block_stride
                    )
                    if args.role == "kv_producer"
                    else bytes([DESTINATION_SENTINEL]) * descriptor.size
                )
                host_tensor = torch.frombuffer(bytearray(data), dtype=torch.int8)
                raw.copy_(host_tensor.to(device))
            torch.npu.synchronize(device)
            report["before"] = snapshot_pages(
                storage, args.output_dir, label=args.role + "-before"
            )
            report["layout"] = json.loads(storage.layout.to_json())
            active = bind_native_pd_storage(config, storage)
            report["native_active_kv_connector_registered"] = True
            report["actual_connector_type"] = (
                type(active.kv_connector).__module__
                + "."
                + type(active.kv_connector).__qualname__
            )
            handshake = active.kv_connector.get_handshake_metadata()
            assert isinstance(handshake, AttestedMooncakeAgentMetadata)
            handshake_path = args.output_dir / f"{args.role}-handshake.msgpack"
            handshake_path.write_bytes(msgspec.msgpack.encode(handshake))
            report["handshake"] = {
                "path": handshake_path.name,
                "sha256": file_sha256(handshake_path),
                "engine_id": handshake.engine_id,
                "host": handshake.local_ip,
                "port": config.kv_transfer_config.kv_port,
                "runtime_id": handshake.runtime_id,
            }
            report["request_mapping"] = {
                "source_request_id": source_request_id,
                "destination_request_id": destination_request_id,
                "source_block": SOURCE_BLOCK,
                "destination_block": (
                    None
                    if args.run_scheduler_transfer or args.run_model_transfer
                    else DESTINATION_BLOCK
                ),
                "num_groups": len(storage.kv_cache_config.kv_cache_groups),
            }
            if args.target_graph:
                from hccl_native_attention_pd_graph_lifecycle_probe import (
                    GRAPH_SOURCE_BLOCKS,
                )

                report["request_mapping"] = {
                    "source_request_ids": graph_sources,
                    "destination_request_ids": graph_destinations,
                    "source_blocks": GRAPH_SOURCE_BLOCKS,
                    "num_groups": len(storage.kv_cache_config.kv_cache_groups),
                    "destination_blocks_chosen_by_native_scheduler": True,
                }
            if args.role == "kv_producer":
                if args.native_producer:
                    from hccl_native_attention_pd_producer_probe import (
                        run_native_pd_producer,
                    )

                    scheduler_handoff = run_native_pd_producer(
                        args, config, storage, active, report, deadline
                    )
                    model_owner = scheduler_handoff.owner
                elif args.target_graph:
                    from hccl_native_attention_pd_graph_lifecycle_probe import (
                        register_graph_sources,
                    )

                    register_graph_sources(args, active, report, deadline, zero_step)
                else:
                    metadata = MooncakeConnectorMetadata()
                    metadata.reqs_in_batch.add(source_request_id)
                    metadata.requests_to_send[source_request_id] = time.time()
                    sent, received = zero_step(active, metadata)
                    assert not sent and not received
                    write_json(
                        args.output_dir / "producer-ready.json",
                        {"run_id": args.run_id, **report["handshake"]},
                    )
                    while source_request_id not in sent:
                        if time.monotonic() >= deadline:
                            raise TimeoutError("producer did not observe native DONE")
                        time.sleep(POLL_SECONDS)
                        sent, received = zero_step(active, MooncakeConnectorMetadata())
                        assert not received
                    report["native_done_observed"] = True
                    if args.run_request_reuse:
                        from hccl_native_attention_pd_reuse_probe import (
                            REPLACEMENT_SOURCE_BLOCK,
                        )

                        retired = await_peer_record(
                            args.output_dir / "consumer-reuse-retired.json",
                            run_id=args.run_id,
                            deadline=deadline,
                        )
                        assert retired["request_id"] == destination_request_id
                        assert retired["status"] == "FINISHED_ABORTED"
                        assert retired["native_empty_execute_retired"]
                        replacement_id = args.run_id + "-source-b"
                        metadata = MooncakeConnectorMetadata()
                        metadata.reqs_in_batch.add(replacement_id)
                        metadata.requests_to_send[replacement_id] = time.time()
                        sent, received = zero_step(active, metadata)
                        assert not sent and not received
                        write_json(
                            args.output_dir / "producer-reuse-ready.json",
                            {
                                "run_id": args.run_id,
                                **report["handshake"],
                                "request_id": replacement_id,
                                "source_block": REPLACEMENT_SOURCE_BLOCK,
                            },
                        )
                        while replacement_id not in sent:
                            if time.monotonic() >= deadline:
                                raise TimeoutError(
                                    "replacement source did not observe DONE"
                                )
                            time.sleep(POLL_SECONDS)
                            sent, received = zero_step(
                                active, MooncakeConnectorMetadata()
                            )
                            assert not received and source_request_id not in sent
                        report["replacement_native_done_observed"] = True
                    await_peer_record(
                        args.output_dir / "consumer-verified.json",
                        run_id=args.run_id,
                        deadline=deadline,
                    )
            else:
                peer = await_peer_record(
                    args.output_dir / "producer-ready.json",
                    run_id=args.run_id,
                    deadline=deadline,
                )
                peer_path = args.output_dir / peer["path"]
                assert file_sha256(peer_path) == peer["sha256"]
                source = msgspec.msgpack.decode(
                    peer_path.read_bytes(), type=AttestedMooncakeAgentMetadata
                )
                assert source.engine_id == peer["engine_id"]
                assert source.local_ip == peer["host"]
                source_layout = layout_from_json(source.afd_kv_layout.decode("utf-8"))
                comparison = compare_kv_layouts(source_layout, storage.layout)
                assert comparison.compatible, comparison.differences
                report["source_layout_compatible"] = True
                if args.target_graph:
                    from hccl_native_attention_pd_graph_lifecycle_probe import (
                        run_pd_graph_handoff,
                    )

                    scheduler_handoff = run_pd_graph_handoff(
                        args,
                        config,
                        storage,
                        active,
                        model_connector,
                        source,
                        peer,
                        report,
                        deadline,
                    )
                    report["scheduler_group_block_pairs"] = (
                        scheduler_handoff.group_block_pairs
                    )
                elif args.run_scheduler_transfer or args.run_model_transfer:
                    from hccl_native_attention_pd_scheduler_probe import (
                        run_scheduler_handoff,
                    )

                    scheduling_options = {}
                    if args.native_producer:
                        assert peer["original_prompt_token_ids"] == [11, 12, 13, 14, 15]
                        assert peer["computed_prefix_tokens"] == 4
                        scheduling_options["source_transfer_params"] = peer[
                            "source_transfer_params"
                        ]
                        report["native_producer_envelope_consumed"] = True
                        report["native_producer_pages"] = peer["source_pages"]
                    if args.run_request_reuse:
                        from hccl_native_attention_pd_reuse_probe import (
                            INITIAL_REQUEST_MAX_TOKENS,
                        )

                        scheduling_options["max_tokens"] = INITIAL_REQUEST_MAX_TOKENS
                    with ExitStack() as native_context:
                        if args.cancel_before_load:
                            from hccl_native_attention_pd_model_probe import (
                                build_pd_attention_owner,
                            )
                            from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

                            native_context.enter_context(torch.inference_mode())
                            native_context.enter_context(torch_cuda_wrapper())
                            model_owner, _ = build_pd_attention_owner(
                                config,
                                storage,
                                active,
                                model_connector,
                                device,
                                report,
                                production_u1=True,
                            )
                            scheduling_options.update(
                                cancel_before_load=True,
                                execute_empty=model_owner.execute_model,
                            )
                        scheduler_handoff = run_scheduler_handoff(
                            config,
                            storage,
                            active,
                            source_metadata=source,
                            source_port=peer["port"],
                            source_request_id=source_request_id,
                            destination_request_id=destination_request_id,
                            deadline=deadline,
                            report=report,
                            **scheduling_options,
                        )
                    report["scheduler_group_block_pairs"] = (
                        scheduler_handoff.group_block_pairs
                    )
                else:
                    metadata = MooncakeConnectorMetadata()
                    metadata.reqs_in_batch.add(destination_request_id)
                    group_count = len(storage.kv_cache_config.kv_cache_groups)
                    metadata.add_new_req(
                        request_id=destination_request_id,
                        local_block_ids=tuple(
                            [DESTINATION_BLOCK] for _ in range(group_count)
                        ),
                        num_external_tokens=BLOCK_SIZE,
                        kv_transfer_params={
                            "remote_block_ids": tuple(
                                [SOURCE_BLOCK] for _ in range(group_count)
                            ),
                            "remote_engine_id": source.engine_id,
                            "remote_request_id": source_request_id,
                            "remote_host": source.local_ip,
                            "remote_port": peer["port"],
                            "remote_ptp_size": 1,
                            "remote_pcp_size": 1,
                            "num_prompt_blocks": 1,
                        },
                    )
                    sent, received = zero_step(active, metadata)
                    assert not sent
                    while destination_request_id not in received:
                        if time.monotonic() >= deadline:
                            raise TimeoutError(
                                "consumer did not observe completed read"
                            )
                        time.sleep(POLL_SECONDS)
                        sent, received = zero_step(active, MooncakeConnectorMetadata())
                        assert not sent
                report["native_read_finished_observed"] = True
            torch.npu.synchronize(device)
            report["after"] = snapshot_pages(
                storage, args.output_dir, label=args.role + "-after"
            )
            for index, descriptor in enumerate(
                storage.kv_cache_config.kv_cache_tensors
            ):
                actual = (args.output_dir / report["after"][index]["path"]).read_bytes()
                source = transfer_source_page_bytes(
                    args, index, descriptor.size, descriptor.block_stride
                )
                if args.native_producer:
                    generated_pages = (
                        report["native_pd_producer"]["generated_pages"]
                        if args.role == "kv_producer"
                        else report["native_producer_pages"]
                    )
                    source_record = generated_pages[index]
                    source = (args.output_dir / source_record["path"]).read_bytes()
                    assert hashlib.sha256(source).hexdigest() == source_record["sha256"]
                if args.role == "kv_producer":
                    expected = source
                else:
                    expected = bytearray([DESTINATION_SENTINEL]) * descriptor.size
                    stride = descriptor.block_stride
                    copies = {DESTINATION_BLOCK: SOURCE_BLOCK}
                    if scheduler_handoff is not None:
                        copies = {}
                        for group_index, group in enumerate(
                            storage.kv_cache_config.kv_cache_groups
                        ):
                            if not set(group.layer_names).intersection(
                                descriptor.layers
                            ):
                                continue
                            for (
                                source_block,
                                destination_block,
                            ) in scheduler_handoff.group_block_pairs[group_index]:
                                assert 0 <= source_block < NUM_BLOCKS
                                assert 0 <= destination_block < NUM_BLOCKS
                                if destination_block in copies:
                                    assert copies[destination_block] == source_block
                                copies[destination_block] = source_block
                        assert copies
                    for destination_block, source_block in copies.items():
                        expected[
                            destination_block * stride : (destination_block + 1)
                            * stride
                        ] = source[source_block * stride : (source_block + 1) * stride]
                    report["after"][index]["expected_block_copies"] = sorted(
                        (source_block, destination_block)
                        for destination_block, source_block in copies.items()
                    )
                assert actual == expected
                assert (
                    report["before"][index]["data_ptr"]
                    == report["after"][index]["data_ptr"]
                )
                report["after"][index]["expected_sha256"] = hashlib.sha256(
                    expected
                ).hexdigest()
            report["all_physical_bytes_match_independent_oracle"] = True
            if args.run_model_transfer and args.role == "kv_producer":
                for entry in report["after"]:
                    raw = (args.output_dir / entry["path"]).read_bytes()
                    stride = entry["block_stride"]
                    entry["physical_page_sha256"] = [
                        hashlib.sha256(raw[offset : offset + stride]).hexdigest()
                        for offset in range(0, len(raw), stride)
                    ]
                    if not args.native_producer:
                        assert len(set(entry["physical_page_sha256"])) == NUM_BLOCKS
            if args.run_model_transfer and args.role == "kv_consumer":
                from hccl_native_attention_pd_model_probe import (
                    execute_pd_target,
                    record_pd_cancelled_target,
                )
                from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

                # Native V2 initialization installs the Ascend CUDA API wrapper
                # used by sampling/AsyncOutput as well as graph management.
                if args.target_graph:
                    from hccl_native_attention_pd_graph_lifecycle_probe import (
                        run_pd_graph_targets,
                    )

                    model_owner = scheduler_handoff.owner
                    run_pd_graph_targets(
                        scheduler_handoff,
                        storage,
                        report,
                        args.output_dir,
                        cancel_after_first_replay=args.graph_cancel,
                    )
                elif args.cancel_before_load:
                    record_pd_cancelled_target(model_owner, scheduler_handoff, report)
                else:
                    with torch.inference_mode(), torch_cuda_wrapper():
                        model_owner = execute_pd_target(
                            config,
                            storage,
                            active,
                            scheduler_handoff,
                            model_connector,
                            device,
                            report,
                            production_u1=args.production_u1,
                            cancel_after_sample=args.run_request_reuse,
                        )
                report["after_model"] = snapshot_pages(
                    storage, args.output_dir, label="kv_consumer-after-model"
                )
                for transferred, consumed in zip(
                    report["after"], report["after_model"], strict=True
                ):
                    if not args.target_graph:
                        assert transferred["sha256"] == consumed["sha256"]
                    assert transferred["data_ptr"] == consumed["data_ptr"]
                report["physical_pages_unchanged_after_model"] = not args.target_graph
                if args.run_request_reuse:
                    from hccl_native_attention_pd_reuse_probe import run_pd_replacement

                    scheduler_handoff = run_pd_replacement(
                        args,
                        config,
                        storage,
                        active,
                        scheduler_handoff,
                        model_owner,
                        model_connector,
                        report,
                        deadline,
                    )
                model_owner.prepare_shutdown()
                report["native_attention_peer_stop_returned"] = True
            ensure_kv_transfer_shutdown()
            report["native_singleton_shutdown_returned"] = True
            if scheduler_handoff is not None:
                scheduler_handoff.scheduler.shutdown()
                report["native_scheduler_shutdown_returned"] = True
            if args.role == "kv_consumer":
                receiver = active.kv_connector.connector_worker.kv_recv_thread
                report["consumer_receiver_retired"] = receiver.retired
                report["consumer_receiver_alive_after_shutdown"] = receiver.is_alive()
                assert receiver.retired and not receiver.is_alive()
                report["thread_retirement_verified"] = True
                # Keep P listening until the final real DONE/ACK has returned
                # and the receiver/executor have retired; this is caller sync.
                write_json(
                    args.output_dir / "consumer-verified.json",
                    {
                        "run_id": args.run_id,
                        "all_physical_bytes_verified": True,
                        "consumer_receiver_retired": True,
                    },
                )
            if model_owner is not None:
                model_owner.shutdown()
                report["native_attention_runner_shutdown_returned"] = True
            # Storage/active are retained through process exit. Even a native
            # runner shutdown here does not establish full Worker/model cleanup.
            report["native_tp_after_transfer"] = native_tp_check()
            destroy_model_parallel()
            destroy_distributed_environment()
            report["native_groups_destroyed"] = True
            report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        write_json(result_path, report)


def supervise_transfer(args: argparse.Namespace) -> dict:
    """Own both worker process trees with PID/start identity and a total bound."""
    from hccl_eager_backend_probe import kill_owned, observe_owned
    from hccl_staged_probe import select_port_block

    ports = select_port_block(6 if args.run_model_transfer else 4)
    run_id = uuid.uuid4().hex
    children, owned = {}, {}
    started = time.monotonic()
    report = {
        "run_id": run_id,
        "success": False,
        "timed_out": False,
        "forced_killed_pids": [],
        "devices": list(args.devices),
        "model_owner_executed": False,
        "graph_pd_accepted": False,
        "typed_dspark_ready_lease_accepted": False,
        "full_model_accepted": False,
        "performance_accepted": False,
    }
    try:
        with ExitStack() as stack:
            roles = (
                ("kv_producer", "kv_consumer", "ffn")
                if args.run_model_transfer
                else ("kv_producer", "kv_consumer")
            )
            for index, role in enumerate(roles):
                log = stack.enter_context((args.output_dir / f"{role}.log").open("wb"))
                command = [
                    sys.executable,
                    "-B",
                    str(Path(__file__).resolve()),
                    "--run-model-transfer"
                    if args.run_model_transfer
                    else "--run-scheduler-transfer"
                    if args.run_scheduler_transfer
                    else "--run-transfer",
                    "--worker",
                    "--run-id",
                    run_id,
                    "--role",
                    role,
                    "--device",
                    str(args.devices[index]),
                    "--model",
                    args.model,
                    "--output-dir",
                    str(args.output_dir),
                    "--timeout",
                    str(args.timeout),
                    "--native-port",
                    str(ports + index),
                    "--handshake-port",
                    str(ports + (3 if args.run_model_transfer else 2) + index),
                    "--engine-id",
                    run_id + "-" + role,
                    "--host",
                    args.host,
                ]
                if args.run_model_transfer:
                    command.extend(
                        [
                            "--afd-port",
                            str(ports + 5),
                            "--devices",
                            ",".join(map(str, args.devices)),
                        ]
                    )
                if args.production_u1:
                    command.append("--production-u1")
                if args.run_request_reuse:
                    command.append("--run-request-reuse")
                if args.cancel_before_load:
                    command.append("--cancel-before-load")
                if args.target_graph:
                    command.append("--target-graph")
                if args.graph_cancel:
                    command.append("--graph-cancel")
                if args.native_producer:
                    command.append("--native-producer")
                if args.producer_aux:
                    command.append("--producer-aux")
                children[role] = subprocess.Popen(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    env=os.environ
                    | {
                        "VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT": str(
                            SOURCE_RETENTION_TIMEOUT_SECONDS
                        )
                    },
                )
            while any(child.poll() is None for child in children.values()):
                for child in children.values():
                    if child.poll() is None:
                        observe_owned(child.pid, owned)
                write_json(
                    args.output_dir / "ownership.json",
                    {
                        "supervisor_pid": os.getpid(),
                        "worker_pids": {
                            role: child.pid for role, child in children.items()
                        },
                        "owned_pid_start_ticks": {
                            str(pid): ticks for pid, ticks in owned.items()
                        },
                    },
                )
                failed = {
                    role: child.returncode
                    for role, child in children.items()
                    if child.poll() is not None and child.returncode != 0
                }
                if failed:
                    raise RuntimeError(f"PD worker failed: {failed}")
                if time.monotonic() - started >= args.timeout:
                    report["timed_out"] = True
                    raise TimeoutError("supervised PD transfer exceeded total bound")
                time.sleep(POLL_SECONDS)
            report["returncodes"] = {
                role: child.returncode for role, child in children.items()
            }
            report["workers"] = {
                role: json.loads(
                    (args.output_dir / f"{role}.json").read_text(encoding="utf-8")
                )
                for role in children
            }
            assert all(code == 0 for code in report["returncodes"].values())
            assert all(
                worker["run_id"] == run_id and worker["success"]
                for worker in report["workers"].values()
            )
            if args.run_model_transfer:
                model_detail = (
                    "native_pd_graph" if args.target_graph else "native_pd_model"
                )
                assert report["workers"]["kv_consumer"][model_detail]["passed"]
                assert report["workers"]["ffn"]["native_pd_ffn"][
                    "native_daemon_retired"
                ]
                report["model_owner_executed"] = True
                if args.native_producer:
                    assert report["workers"]["kv_producer"]["native_pd_producer"][
                        "passed"
                    ]
                    assert report["workers"]["kv_consumer"][
                        "native_producer_envelope_consumed"
                    ]
                    report["native_producer_chain_executed"] = True
                    if args.producer_aux:
                        assert report["workers"]["kv_producer"]["native_pd_producer"][
                            "auxiliary_states"
                        ]["passed"]
                        report["native_producer_aux_observed"] = True
            report["success"] = True
    except BaseException as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        report["traceback"] = traceback.format_exc()
        if not isinstance(error, Exception):
            raise
    finally:
        for child in children.values():
            if child.poll() is None:
                observe_owned(child.pid, owned)
        if any(child.poll() is None for child in children.values()):
            report["forced_killed_pids"] = kill_owned(owned)
        for child in children.values():
            child.wait(timeout=GROUP_TIMEOUT_SECONDS)
        report["returncodes"] = {
            role: child.returncode for role, child in children.items()
        }
        report["elapsed_seconds"] = time.monotonic() - started
        write_json(args.output_dir / "transfer-result.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    operation = parser.add_mutually_exclusive_group()
    operation.add_argument("--run-storage", action="store_true")
    operation.add_argument("--run-transfer", action="store_true")
    operation.add_argument("--run-scheduler-transfer", action="store_true")
    operation.add_argument("--run-model-transfer", action="store_true")
    parser.add_argument(
        "--production-u1",
        action="store_true",
        help="use the normal eager/U1 factory and production RemoteMoE protocol",
    )
    parser.add_argument("--model")
    parser.add_argument(
        "--run-request-reuse",
        action="store_true",
        help="cancel the sampled first request and reuse its owner for a new PD prefix",
    )
    parser.add_argument(
        "--cancel-before-load",
        action="store_true",
        help="cancel A while waiting for remote KV, before submitting its real read",
    )
    parser.add_argument(
        "--target-graph",
        action="store_true",
        help="two real PD requests followed by native target Graph/U2 and KV writes",
    )
    parser.add_argument(
        "--native-producer",
        action="store_true",
        help="generate P KV with native execution and export its real envelope",
    )
    parser.add_argument(
        "--producer-aux",
        action="store_true",
        help="observe native entering-layer P aux outputs without a draft model",
    )
    parser.add_argument(
        "--graph-cancel",
        action="store_true",
        help="cancel one PD request after replay, then replay its surviving peer",
    )
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--devices", default="0,2")
    parser.add_argument("--timeout", type=float, default=TOTAL_TIMEOUT_SECONDS)
    parser.add_argument(
        "--role", choices=("kv_producer", "kv_consumer", "ffn"), default="kv_consumer"
    )
    parser.add_argument("--engine-id", default="controlled-native-pd-storage")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--handshake-port", type=int, default=DEFAULT_HANDSHAKE_PORT)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--run-id", help=argparse.SUPPRESS)
    parser.add_argument("--native-port", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--afd-port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.production_u1 and not args.run_model_transfer:
        parser.error("--production-u1 requires --run-model-transfer")
    if args.run_request_reuse and not (args.run_model_transfer and args.production_u1):
        parser.error(
            "--run-request-reuse requires --run-model-transfer --production-u1"
        )
    if args.cancel_before_load and not args.run_request_reuse:
        parser.error("--cancel-before-load requires --run-request-reuse")
    if args.target_graph and (
        not args.run_model_transfer or args.production_u1 or args.run_request_reuse
    ):
        parser.error("--target-graph requires standalone --run-model-transfer")
    if args.graph_cancel and not args.target_graph:
        parser.error("--graph-cancel requires --target-graph")
    if args.native_producer and (
        not (args.run_model_transfer and args.production_u1)
        or args.target_graph
        or args.run_request_reuse
    ):
        parser.error(
            "--native-producer requires standalone --run-model-transfer --production-u1"
        )
    if args.producer_aux and not args.native_producer:
        parser.error("--producer-aux requires --native-producer")
    transfer_requested = (
        args.run_transfer or args.run_scheduler_transfer or args.run_model_transfer
    )
    if (args.run_storage or transfer_requested) and not args.model:
        parser.error("device operations require --model")
    try:
        args.devices = tuple(int(value) for value in args.devices.split(","))
    except ValueError:
        parser.error("--devices requires two distinct nonnegative indices")
    device_count = 3 if args.run_model_transfer else 2
    if (
        len(args.devices) != device_count
        or len(set(args.devices)) != device_count
        or min(args.devices) < 0
    ):
        parser.error(f"--devices requires {device_count} distinct nonnegative indices")
    if args.role == "ffn" and not (args.worker and args.run_model_transfer):
        parser.error("F role requires an isolated model-transfer worker")
    if (
        args.worker
        and args.run_model_transfer
        and (args.afd_port is None or not 0 < args.afd_port < 65536)
    ):
        parser.error("model-transfer worker requires an explicit valid AFD port")
    if args.device < 0 or not 0 < args.handshake_port < 65536:
        parser.error("invalid device or handshake port")
    if not 0 < args.timeout <= TOTAL_TIMEOUT_SECONDS:
        parser.error("invalid bounded timeout")
    if args.worker and (
        not transfer_requested or not args.run_id or args.native_port is None
    ):
        parser.error("isolated worker requires transfer/run identity/native port")
    if (
        transfer_requested
        and not args.worker
        and args.output_dir.exists()
        and any(args.output_dir.iterdir())
    ):
        parser.error("transfer requires a fresh empty output directory")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.worker:
        try:
            run_transfer_worker(args)
            return 0
        except BaseException:
            error = traceback.format_exc()
            print(error, flush=True)
            path = args.output_dir / f"{args.role}.json"
            if not path.exists():
                write_json(
                    path,
                    {
                        "run_id": args.run_id,
                        "role": args.role,
                        "success": False,
                        "traceback": error,
                    },
                )
            return 1
    report = {
        "schema_version": 1,
        "success": False,
        "mode": (
            "model-transfer"
            if args.run_model_transfer
            else "scheduler-transfer"
            if args.run_scheduler_transfer
            else "transfer"
            if args.run_transfer
            else "storage"
            if args.run_storage
            else "dependency-preflight"
        ),
        "source": {
            "path": str(Path(__file__).resolve()),
            "sha256": file_sha256(Path(__file__)),
        },
        "production_u1_requested": args.production_u1,
        "pd_handoff_accepted": False,
        "graph_pd_accepted": False,
        "full_model_accepted": False,
    }
    try:
        report["dependencies"] = inspect_mooncake_dependencies()
        if not report["dependencies"]["single_distribution_owns_resolved_extension"]:
            raise RuntimeError(
                "require exactly one Mooncake distribution owning engine.so"
            )
        if args.run_storage:
            report["storage"] = run_storage(args)
        if transfer_requested:
            report["transfer"] = supervise_transfer(args)
            if not report["transfer"]["success"]:
                raise RuntimeError(
                    "actual PD transfer component failed; see raw workers"
                )
            report["physical_page_transfer_verified"] = True
        report["success"] = True
    except Exception as error:
        report["error"] = {"type": type(error).__name__, "message": str(error)}
        report["traceback"] = traceback.format_exc()
    (args.output_dir / "result.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return 0 if report["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
