# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Run the native DSpark context writer with bounded loaded projection weights.

The auxiliary inputs must come from the separately archived native P probe.
Only --run imports runtime packages. This constructor-free component executes
native linear/RMSNorm/RoPE/scatter/fence and native cache materialization; it
does not instantiate a Speculator, publish Ready, or execute a draft decoder.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
import sys
import traceback
from contextlib import contextmanager
from datetime import timedelta
from pathlib import Path

from dsv41_dspark_projection_ops_probe import (
    artifact,
    bf16_bytes,
    bf16_word,
    digest,
    float32,
    inspect_metadata,
    loaded_custom_libraries,
    round_bf16,
    write_report,
)

HIDDEN_SIZE = 16
AUX_LAYER_IDS = (1, 2)
PROMPT_ROWS = 4
DRAFT_LAYERS = 2
BLOCK_SIZE = 128
NUM_BLOCKS = 9
DRAFT_BLOCK_ID = 5
COMPRESS_RATIO = 2
INDEX_HEAD_SIZE = 8
STATE_RING_ROWS = 32
NORM_EPSILON = 1e-6
ROPE_BASE = 10000
MAX_POSITIONS = 64
BF16_BYTES = 2
MAX_PROJECTED_BF16_ULPS = 2
GROUP_TIMEOUT_SECONDS = 45


def bf16_float(word: int) -> float:
    return struct.unpack("<f", struct.pack("<I", word << 16))[0]


def decode_rows(raw: bytes) -> list[list[float]]:
    if len(raw) != PROMPT_ROWS * HIDDEN_SIZE * BF16_BYTES:
        raise ValueError("native aux artifact must contain four BF16 rows of width 16")
    values = [bf16_float(word[0]) for word in struct.iter_unpack("<H", raw)]
    if not all(math.isfinite(value) for value in values):
        raise ValueError("native auxiliary inputs must be finite")
    return [
        values[start : start + HIDDEN_SIZE]
        for start in range(0, len(values), HIDDEN_SIZE)
    ]


def projection_weights() -> dict[str, list[list[float]] | list[float]]:
    """Declare exact BF16 weights before any native model is materialized."""
    main = [[0.0] * (HIDDEN_SIZE * len(AUX_LAYER_IDS)) for _ in range(HIDDEN_SIZE)]
    for channel, row in enumerate(main):
        row[channel] = 0.5
        row[HIDDEN_SIZE + (channel + 1) % HIDDEN_SIZE] = 0.25
    weights = {
        "model.main_proj.weight": main,
        "model.main_norm.weight": [1.0] * HIDDEN_SIZE,
    }
    for layer in range(DRAFT_LAYERS):
        matrix = [[0.0] * HIDDEN_SIZE for _ in range(HIDDEN_SIZE)]
        for channel, row in enumerate(matrix):
            row[(channel * 3 + layer + 1) % HIDDEN_SIZE] = (
                -0.5 if (channel + layer) % 2 else 0.5
            )
        prefix = f"model.layers.{DRAFT_LAYERS + layer}.self_attn"
        weights[prefix + ".wkv.weight"] = matrix
        weights[prefix + ".kv_norm.weight"] = [1.0] * HIDDEN_SIZE
    return weights


def reference_projection(
    aux: tuple[bytes, bytes], weights: dict
) -> list[list[list[float]]]:
    """Scalar FP32/BF16 boundaries, independent of Torch and native functions."""
    layers = [decode_rows(raw) for raw in aux]

    def linear(row, matrix):
        result = []
        for channels in matrix:
            total = 0.0
            for value, weight in zip(row, channels, strict=True):
                total = float32(total + float32(value * weight))
            result.append(round_bf16(total))
        return result

    def normalize(row):
        squares = 0.0
        for value in row:
            squares = float32(squares + float32(value * value))
        variance = float32(float32(squares / HIDDEN_SIZE) + NORM_EPSILON)
        scale = float32(1 / math.sqrt(variance))
        return [round_bf16(float32(value * scale)) for value in row]

    contexts = [
        normalize(linear(first + second, weights["model.main_proj.weight"]))
        for first, second in zip(*layers, strict=True)
    ]
    projected = []
    for layer in range(DRAFT_LAYERS):
        name = f"model.layers.{DRAFT_LAYERS + layer}.self_attn.wkv.weight"
        rows = []
        for position, context in enumerate(contexts):
            normalized = normalize(linear(context, weights[name]))
            rotated = []
            for pair in range(HIDDEN_SIZE // 2):
                denominator = float32(ROPE_BASE ** (2 * pair / HIDDEN_SIZE))
                frequency = float32(position * float32(1 / denominator))
                cosine, sine = (
                    round_bf16(float32(math.cos(frequency))),
                    round_bf16(float32(math.sin(frequency))),
                )
                even, odd = normalized[2 * pair : 2 * pair + 2]
                rotated.extend(
                    (
                        round_bf16(
                            float32(float32(even * cosine) - float32(odd * sine))
                        ),
                        round_bf16(
                            float32(float32(odd * cosine) + float32(even * sine))
                        ),
                    )
                )
            rows.append(rotated)
        projected.append(rows)
    return projected


def allocate_draft_storage(config, device):
    # This explicit draft group cannot be added to an already bound target-only
    # allocation. All native specs and aliases are declared before allocation.
    import torch
    from vllm.config import set_current_vllm_config
    from vllm.v1.kv_cache_interface import CircularBufferSpec
    from vllm.v1.worker.utils import AttentionGroup
    from vllm_ascend.attention.dsa_v41 import (
        DeepseekV41CacheBackend,
        DeepseekV41CacheLayer,
    )
    from vllm_ascend.models.deepseek_v41.cache_config import (
        get_deepseek_v41_kv_cache_config,
        get_deepseek_v41_pool_bytes_per_block,
        group_cache_specs,
        make_cache_groups,
        make_index_cache_spec,
        make_mla_cache_spec,
        make_swa_cache_spec,
    )
    from vllm_ascend.models.deepseek_v41.dspark import DeepseekV41DSparkSWACache
    from vllm_ascend.worker.v2.attn_utils import (
        _allocate_kv_cache,
        _reshape_kv_cache_v2,
    )

    specs = {}
    for layer in range(DRAFT_LAYERS):
        name = f"model.layers.{layer}.self_attn"
        specs[name + ".long_kv_cache"] = make_mla_cache_spec(
            block_size=BLOCK_SIZE, head_size=HIDDEN_SIZE, compress_ratio=COMPRESS_RATIO
        )
        specs[name + ".indexer.k_cache"] = make_index_cache_spec(
            block_size=BLOCK_SIZE,
            head_size=INDEX_HEAD_SIZE,
            compress_ratio=COMPRESS_RATIO,
        )
        specs[name + ".compressor.state_cache"] = CircularBufferSpec(
            block_size=STATE_RING_ROWS,
            num_kv_heads=1,
            head_size=HIDDEN_SIZE,
            dtype=torch.bfloat16,
        )
        for prefix in (name, f"mtp.{layer}.self_attn"):
            specs[prefix + ".swa_cache"] = make_swa_cache_spec(
                block_size=BLOCK_SIZE,
                window_size=BLOCK_SIZE,
                head_size=HIDDEN_SIZE,
                dtype=torch.bfloat16,
                cache_dtype=config.cache_config.cache_dtype,
            )
    groups = make_cache_groups(group_cache_specs(specs))
    kv_config = get_deepseek_v41_kv_cache_config(
        config,
        groups,
        available_memory=NUM_BLOCKS * get_deepseek_v41_pool_bytes_per_block(groups),
    )
    assert (
        kv_config.num_blocks == NUM_BLOCKS
        and len(kv_config.kv_cache_tensors) == DRAFT_LAYERS
    )
    attention_groups = [
        AttentionGroup(
            backend=DeepseekV41CacheBackend,
            layer_names=[name],
            kv_cache_spec=group.kv_cache_spec.kv_cache_specs[name],
            kv_cache_group_id=group_id,
        )
        for group_id, group in enumerate(groups)
        for name in group.layer_names
    ]
    with set_current_vllm_config(config):
        raw = _allocate_kv_cache(kv_config, shared_layers={}, device=device)
        caches = _reshape_kv_cache_v2(
            attn_groups=attention_groups,
            kv_cache_raw_tensors=raw,
            cache_dtype=config.cache_config.cache_dtype,
            kernel_block_sizes=[group.kv_cache_spec.block_size for group in groups],
            shared_kv_cache_layers={},
            kv_cache_config=kv_config,
        )
    carriers = {}
    for name, spec in specs.items():
        if name.startswith("mtp."):
            # The native writer consumes the actual draft SWA carrier's block
            # size as well as its bound tensor. Construct the native subclass.
            carrier = DeepseekV41DSparkSWACache(
                head_dim=HIDDEN_SIZE,
                window_size=BLOCK_SIZE,
                dtype=torch.bfloat16,
                prefix=name,
                cache_config=config.cache_config,
            )
            assert carrier.spec == spec and carrier.block_size == BLOCK_SIZE
        else:
            carrier = DeepseekV41CacheLayer(config, name, spec)
        carrier.bind_kv_cache(caches[name])
        carriers[name] = carrier
    return kv_config, raw, caches, carriers


def build_projection_model(config, carriers, device, weights):
    import torch
    from torch import nn
    from vllm.model_executor.layers.layernorm import RMSNorm
    from vllm.model_executor.layers.linear import ColumnParallelLinear
    from vllm_ascend.models.deepseek_v41.dspark import (
        DeepseekV41DSparkDecoderLayer,
        DeepseekV41DSparkModel,
        DSparkDeepseekV41ForCausalLM,
    )
    from vllm_ascend.ops.rope_dsv4 import ComplexExpRotaryEmbedding

    draft = DeepseekV41DSparkModel.__new__(DeepseekV41DSparkModel)
    nn.Module.__init__(draft)
    draft.vllm_config = config
    draft.main_proj = ColumnParallelLinear(
        HIDDEN_SIZE * len(AUX_LAYER_IDS),
        HIDDEN_SIZE,
        bias=False,
        return_bias=False,
        params_dtype=torch.bfloat16,
        disable_tp=True,
    )
    draft.main_norm = RMSNorm(HIDDEN_SIZE, eps=NORM_EPSILON, dtype=torch.bfloat16)
    blocks = {}
    for layer in range(DRAFT_LAYERS):
        attn = nn.Module()
        attn.wkv = ColumnParallelLinear(
            HIDDEN_SIZE,
            HIDDEN_SIZE,
            bias=False,
            return_bias=False,
            params_dtype=torch.bfloat16,
            disable_tp=True,
        )
        attn.kv_norm = RMSNorm(HIDDEN_SIZE, eps=NORM_EPSILON, dtype=torch.bfloat16)
        attn.rotary_emb = ComplexExpRotaryEmbedding(
            config,
            f"mtp.{layer}.self_attn.attn",
            HIDDEN_SIZE,
            HIDDEN_SIZE,
            MAX_POSITIONS,
            ROPE_BASE,
            1.0,
            apply_yarn_scaling=False,
        )
        attn.nope_head_dim, attn.rope_head_dim, attn.head_dim = (
            0,
            HIDDEN_SIZE,
            HIDDEN_SIZE,
        )
        attn.packed_cache_ops = None
        attn.dsa_attn = nn.Module()
        attn.dsa_attn.swa_cache_layer = carriers[f"mtp.{layer}.self_attn.swa_cache"]
        block = DeepseekV41DSparkDecoderLayer.__new__(DeepseekV41DSparkDecoderLayer)
        nn.Module.__init__(block)
        block.self_attn = attn
        blocks[str(DRAFT_LAYERS + layer)] = block
    draft.layers = nn.ModuleDict(blocks)
    model = DSparkDeepseekV41ForCausalLM.__new__(DSparkDeepseekV41ForCausalLM)
    nn.Module.__init__(model)
    model.model = draft
    model.to(device=device)
    model.load_state_dict(
        {
            name: torch.tensor(value, dtype=torch.bfloat16, device=device)
            for name, value in weights.items()
        },
        strict=True,
    )
    # Match the normal unquantized load boundary, including Ascend's native
    # weight-format processing. No CPU/custom GEMM implementation is supplied.
    for linear in (
        draft.main_proj,
        *(block.self_attn.wkv for block in draft.layers.values()),
    ):
        linear.quant_method.process_weights_after_loading(linear)
    model.eval()
    return model


@contextmanager
def native_projection_world(config, device, output_dir, report):
    # Native weight parameters query the real TP group during construction,
    # including when this component explicitly disables weight sharding.
    from vllm.config import set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )

    with set_current_vllm_config(config):
        init_distributed_environment(
            world_size=1,
            rank=0,
            local_rank=device.index,
            distributed_init_method=(output_dir / "native-world-init")
            .resolve()
            .as_uri(),
            backend="hccl",
            timeout=timedelta(seconds=GROUP_TIMEOUT_SECONDS),
        )
        try:
            initialize_model_parallel(tensor_model_parallel_size=1, backend="hccl")
            assert get_tp_group().world_size == 1
            report["native_tp_world_size"] = get_tp_group().world_size
            report["native_groups_destroyed"] = False
            yield
        finally:
            destroy_model_parallel()
            destroy_distributed_environment()
            report["native_groups_destroyed"] = True


def run_projection(args, report):
    import torch
    import torch_npu  # noqa: F401
    from vllm.platforms import current_platform

    current_platform.pre_register_and_update()
    import vllm_ascend.ops  # noqa: F401
    from hccl_native_attention_pd_probe import make_eager_pd_config
    from hccl_staged_probe import build_config
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.distributed.kv_transfer.kv_p2p.sfa_pd_rd2h import dspark_context
    from vllm_ascend.models.deepseek_v41 import dspark
    from vllm_ascend.utils import enable_custom_op

    report.update(runtime_imported=True, npu_queried=True)
    report["native_sources"] = {
        module.__name__: {
            "path": module.__file__,
            "sha256": digest(Path(module.__file__).read_bytes()),
        }
        for module in (dspark, dspark_context)
    }
    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    report["native_custom_ops_enabled"] = enable_custom_op()
    config = build_config(1, args.model)
    config.cache_config.block_size = BLOCK_SIZE
    config.cache_config.enable_prefix_caching = False
    config.cache_config.num_gpu_blocks_override = None
    text = config.model_config.hf_text_config
    text.hidden_size, text.num_hidden_layers = HIDDEN_SIZE, DRAFT_LAYERS
    text.compress_ratios = [COMPRESS_RATIO] * DRAFT_LAYERS
    text.sliding_window = BLOCK_SIZE
    text.dspark_target_layer_ids = list(AUX_LAYER_IDS)
    config.model_config.hf_config = text
    config = make_eager_pd_config(
        config,
        role="kv_producer",
        engine_id="projection-component",
        host="127.0.0.1",
        handshake_port=23570,
    )
    init_ascend_config(config)
    weights = projection_weights()
    report["weights"] = weights
    expected = reference_projection(args.aux_bytes, weights)
    report["independent_expected_values"] = expected
    report["max_projected_BF16_ULPs"] = MAX_PROJECTED_BF16_ULPS
    report["native_projection_accepted"] = False
    write_report(args.output_dir, report)
    with (
        native_projection_world(config, device, args.output_dir, report),
        torch.device(device),
        torch.inference_mode(),
    ):
        kv_config, raw, caches, carriers = allocate_draft_storage(config, device)
        model = build_projection_model(config, carriers, device, weights)
        report["loaded_model_class"] = (
            type(model).__module__ + "." + type(model).__qualname__
        )
        report["projection_module_classes"] = {
            name: type(module).__module__ + "." + type(module).__qualname__
            for name, module in model.named_modules()
        }
        report["loaded_weight_bytes"] = {
            name: artifact(
                args.output_dir,
                name.replace(".", "-") + ".bin",
                parameter.detach()
                .cpu()
                .contiguous()
                .view(torch.uint8)
                .numpy()
                .tobytes(),
            )
            for name, parameter in model.named_parameters()
        }
        names = tuple(model.get_draft_kv_cache_layer_names())
        assert names == tuple(
            f"mtp.{layer}.self_attn.swa_cache" for layer in range(DRAFT_LAYERS)
        )
        groups = tuple(
            group_id
            for group_id, group in enumerate(kv_config.kv_cache_groups)
            if set(group.layer_names) & set(names)
        )
        assert len(groups) == 1 and set(
            kv_config.kv_cache_groups[groups[0]].layer_names
        ) == set(names)
        report["draft_group_ids"] = list(groups)
        report["draft_layer_names"] = list(names)
        pools, before, records = [], [], []
        for pool, descriptor in enumerate(kv_config.kv_cache_tensors):
            anchor = raw[descriptor.layers[0]]
            storage = anchor.untyped_storage()
            full = torch.empty(0, dtype=torch.uint8, device=device).set_(
                storage, 0, (storage.nbytes(),), (1,)
            )
            pattern = b"".join(
                struct.pack("<H", 0x3F00 + (word + pool * 17) % 128)
                for word in range(storage.nbytes() // BF16_BYTES)
            )
            full.copy_(
                torch.frombuffer(bytearray(pattern), dtype=torch.uint8).to(device)
            )
            pools.append(full)
            before.append(pattern)
            records.append(
                {
                    "pool": pool,
                    "layers": list(descriptor.layers),
                    "descriptor_size": descriptor.size,
                    "block_stride": descriptor.block_stride,
                    "storage_ptr": storage.data_ptr(),
                    "storage_offset_bytes": anchor.storage_offset()
                    * anchor.element_size(),
                    "before": artifact(
                        args.output_dir, f"pool-{pool}-before.bin", pattern
                    ),
                }
            )
        report["pools"] = records
        aux = tuple(
            torch.frombuffer(bytearray(value), dtype=torch.bfloat16)
            .reshape(PROMPT_ROWS, HIDDEN_SIZE)
            .to(device)
            for value in args.aux_bytes
        )
        features = torch.cat(aux, dim=-1)
        descriptor = dspark_context.DSparkContextDescriptor(
            "native-p-aux",
            "bounded-projection-v1",
            PROMPT_ROWS,
            AUX_LAYER_IDS,
            HIDDEN_SIZE,
        )
        chunk = dspark_context.DSparkContextChunk(descriptor, 0, PROMPT_ROWS)
        write_report(args.output_dir, report)
        dspark_context.initialize_draft_context_chunk(
            model,
            chunk,
            features,
            draft_group_ids=groups,
            draft_block_ids_by_group={groups[0]: (DRAFT_BLOCK_ID,)},
            block_sizes_by_group={groups[0]: BLOCK_SIZE},
            layer_group_ids=tuple(groups[0] for _ in names),
            device=device,
        )
        report["native_writer_and_stream_fence_returned"] = True
        for pool, (record, image, full) in enumerate(
            zip(records, before, pools, strict=True)
        ):
            actual = full.cpu().numpy().tobytes()
            record["after"] = artifact(
                args.output_dir, f"pool-{pool}-after.bin", actual
            )
            cache = caches[names[pool]]
            assert cache.dtype == torch.bfloat16 and list(cache.shape) == [
                NUM_BLOCKS,
                BLOCK_SIZE,
                1,
                HIDDEN_SIZE,
            ]
            base = record["storage_offset_bytes"]
            assert cache.data_ptr() - record["storage_ptr"] == base
            assert cache.stride() == (
                record["block_stride"] // BF16_BYTES,
                HIDDEN_SIZE,
                HIDDEN_SIZE,
                1,
            )
            guarded = bytearray(actual)
            expected_image = bytearray(image)
            numeric = []
            for position, row in enumerate(expected[pool]):
                start = (
                    base
                    + DRAFT_BLOCK_ID * record["block_stride"]
                    + position * HIDDEN_SIZE * BF16_BYTES
                )
                stop = start + HIDDEN_SIZE * BF16_BYTES
                actual_words = [
                    word[0] for word in struct.iter_unpack("<H", actual[start:stop])
                ]
                expected_words = [bf16_word(value) for value in row]
                assert all(math.isfinite(bf16_float(word)) for word in actual_words)
                differences = [
                    abs(a - e)
                    for a, e in zip(actual_words, expected_words, strict=True)
                ]
                numeric.append(
                    {
                        "position": position,
                        "offset_bytes": start,
                        "max_ULPs": max(differences),
                        "actual_words": actual_words,
                        "expected_words": expected_words,
                    }
                )
                assert max(differences) <= MAX_PROJECTED_BF16_ULPS, (
                    "native projection exceeds independent BF16 error bound"
                )
                guarded[start:stop] = image[start:stop]
                expected_image[start:stop] = bf16_bytes(row)
            record["numeric_rows"] = numeric
            record["independent_expected_image"] = artifact(
                args.output_dir, f"pool-{pool}-expected.bin", bytes(expected_image)
            )
            assert guarded == image, (
                "native context writer changed an unselected storage byte"
            )
            record["all_unselected_storage_bytes_unchanged"] = True
            record["cache_ptr"] = cache.data_ptr()
            record["cache_stride"] = list(cache.stride())
        assert all(
            tensor.cpu().contiguous().view(torch.uint8).numpy().tobytes() == value
            for tensor, value in zip(aux, args.aux_bytes, strict=True)
        )
        report["aux_input_bytes_unchanged"] = True
    report["loaded_custom_libraries_after"] = loaded_custom_libraries()
    report["native_projection_accepted"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="/mnt/workspace/models/DeepSeek-V4.1-Flash")
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--aux-dir", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.device < 0 or (args.run and args.aux_dir is None):
        parser.error("--run requires --aux-dir and a nonnegative device")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if (args.output_dir / "result.json").exists():
        parser.error("output directory already contains result.json")
    report = {
        **inspect_metadata(),
        "scope": (
            "constructor-free native DSpark lower writer with bounded loaded "
            "BF16 weights and separately archived P aux"
        ),
        "status": "metadata_only",
        "probe_sha256": digest(Path(__file__).read_bytes()),
        "native_projection_accepted": False,
        "Ready_PD_draft_proposal_checkpoint_performance_accepted": False,
    }
    if args.run:
        args.aux_bytes = tuple(
            (args.aux_dir / f"producer-aux-layer-{layer}.bin").read_bytes()
            for layer in AUX_LAYER_IDS
        )
        for value in args.aux_bytes:
            decode_rows(value)
        report["native_aux_inputs"] = [
            artifact(args.output_dir, f"producer-aux-layer-{layer}.bin", value)
            for layer, value in zip(AUX_LAYER_IDS, args.aux_bytes, strict=True)
        ]
        report["status"] = "running"
        write_report(args.output_dir, report)
        try:
            run_projection(args, report)
        except BaseException as error:
            report.update(
                status="failed",
                error_type=type(error).__name__,
                error=str(error),
                traceback=traceback.format_exc(),
            )
            try:
                report["loaded_custom_libraries_after_failure"] = (
                    loaded_custom_libraries()
                )
            except OSError as inspection_error:
                report["library_inspection_error"] = str(inspection_error)
            write_report(args.output_dir, report)
            raise
        report["status"] = "passed"
    write_report(args.output_dir, report)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
