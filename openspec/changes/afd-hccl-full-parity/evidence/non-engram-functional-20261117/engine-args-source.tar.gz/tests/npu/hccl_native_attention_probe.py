# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native Attention graph lifecycle with explicit NPU arithmetic leaves.

Imported only in the isolated device worker. This helper does not change model
admission, upstream methods, metadata builders or graph execution. The A owner
and model carriers skip heavyweight constructors; their native ModelState,
input/request/block storage, microbatch runner and ACL graph manager are real.
"""

from __future__ import annotations

import hashlib
import json
import weakref
from contextlib import suppress
from functools import partial

BLOCK_SIZE = 128
MAX_MODEL_LEN = 64
HEAD_SIZE = 16
MAX_REQUESTS = 8
HC_MULTIPLIER = 1
ROPE_BASE = 10000
ROUTER_DELTA = 0.00031
ROUTER_SCALE = 4096
LAYER_COUNT = 2
NATIVE_ATTENTION_TRANSACTIONS = 21
UBATCH_TIMEOUT_SECONDS = 45
EXPECTED_NATIVE_ATTENTION_EAGER_ERROR = (
    "controlled native Attention replacement prefill failure"
)
COMPLETED_PARENTS_BEFORE_ATTENTION_FAILURE = 25


def configure_native_attention(config):
    """Fix the independent tiny component before either role binds HELLO."""
    config.model_config.max_model_len = MAX_MODEL_LEN
    config.model_config.enable_prompt_embeds = False
    config.scheduler_config.max_num_seqs = MAX_REQUESTS
    config.scheduler_config.enable_chunked_prefill = False
    config.cache_config.block_size = BLOCK_SIZE
    config.parallel_config.dbo_decode_token_threshold = 2
    text = config.model_config.hf_text_config
    text.num_attention_heads = 1
    text.head_dim = HEAD_SIZE
    text.qk_rope_head_dim = HEAD_SIZE
    text.index_topk = 1
    text.sliding_window = 4
    text.hc_mult = HC_MULTIPLIER


def build_native_attention_arithmetic_model(
    config, device, attention_factory, *, remote_moe=False
):
    """Share controlled HC/embedding construction across real native owners.

    The caller supplies Attention over its own native KV allocations. Inherited
    V4.1 model/language/decoder methods and the remote MoE boundary stay intact.
    """
    # Lazy imports are confined to isolated device workers.
    import torch
    from torch import nn

    from afd_plugin.model_executor.models.npu.deepseek_v41 import (
        AFDDeepseekV41AttentionDecoderLayer,
        AFDDeepseekV41AttentionForCausalLM,
        AFDDeepseekV41AttentionLLMForCausalLM,
        AFDDeepseekV41AttentionModel,
        AFDDeepseekV41RemoteMoE,
    )

    hidden_size = config.model_config.hf_text_config.hidden_size
    vocab_size = config.model_config.hf_text_config.vocab_size

    class ArithmeticDecoder(AFDDeepseekV41AttentionDecoderLayer):
        def __init__(self, index):
            nn.Module.__init__(self)
            self.layer_idx, self.hc_mult = index, HC_MULTIPLIER
            self.use_sequence_parallel = False
            self.self_attn = attention_factory(index)
            if remote_moe:
                self.mlp = AFDDeepseekV41RemoteMoE(layer_idx=index)
            self.input_layernorm = nn.Identity()
            self.engram = None
            self.hc_attn_fn = self.hc_ffn_fn = 0
            self.hc_attn_scale = self.hc_ffn_scale = 0
            self.hc_attn_base = self.hc_ffn_base = 0

        def hc_pre(self, x, fn, scale, base, pre_mix=None):
            rows = x.shape[0]
            post = x.new_ones((rows, HC_MULTIPLIER), dtype=torch.float32)
            comb = x.new_zeros((rows, HC_MULTIPLIER, HC_MULTIPLIER))
            return x[:, 0], post, comb, post

        def hc_post(self, x, residual, post, comb):
            return (residual.float() + x.float().unsqueeze(1)).bfloat16()

        def rms_norm_cast(self, hidden_states):
            # Native normalization produces its own output. Preserve that
            # ownership even though this arithmetic leaf leaves values intact:
            # the real RemoteMoE connector receives in place into its input.
            return hidden_states.clone(), hidden_states.float() + ROUTER_DELTA

    core = AFDDeepseekV41AttentionModel.__new__(AFDDeepseekV41AttentionModel)
    nn.Module.__init__(core)
    core.config = config.model_config.hf_text_config
    core.hc_mult, core.has_engram = HC_MULTIPLIER, False
    core.engram_hash = None
    core.use_sequence_parallel = False
    core.start_layer, core.end_layer = 0, LAYER_COUNT
    core.layers = nn.ModuleList(ArithmeticDecoder(i) for i in range(LAYER_COUNT))
    core.shared_attention_state = core.layers[0].self_attn.shared_state
    core.norm = nn.Identity()
    core.aux_hidden_state_layers = ()
    core._mtp_hidden_buffer = None
    embedding_cpu = (
        torch.arange(vocab_size)[:, None].float()
        + torch.arange(hidden_size)[None, :].float() / hidden_size
    ).bfloat16()
    core.embed_tokens = nn.Embedding.from_pretrained(
        embedding_cpu.to(device), freeze=True
    )
    language = AFDDeepseekV41AttentionLLMForCausalLM.__new__(
        AFDDeepseekV41AttentionLLMForCausalLM
    )
    nn.Module.__init__(language)
    language.model = core
    model = AFDDeepseekV41AttentionForCausalLM.__new__(
        AFDDeepseekV41AttentionForCausalLM
    )
    nn.Module.__init__(model)
    model.language_model = language

    return model, embedding_cpu


def run_native_attention(
    config,
    connector,
    device,
    report,
    *,
    lifecycle=False,
    fail_eager=False,
    profile_dir=None,
):
    """Capture through the real coordinator, then replay fresh native inputs."""
    # Lazy imports are intentional: this is an isolated NPU process helper;
    # the supervisor/help path remains importable without torch or vLLM.
    import torch
    from torch import nn
    from vllm.config import CUDAGraphMode
    from vllm.forward_context import get_forward_context
    from vllm.v1.core.sched.output import CachedRequestData, SchedulerOutput
    from vllm.v1.kv_cache_interface import KVCacheConfig, KVCacheGroupSpec
    from vllm.v1.worker.gpu import model_runner as native_runner
    from vllm.v1.worker.gpu.block_table import BlockTables
    from vllm.v1.worker.gpu.kv_connector import get_kv_connector
    from vllm.v1.worker.utils import AttentionGroup
    from vllm.v1.worker.workspace import init_workspace_manager
    from vllm_ascend.attention.dsa_v41 import (
        AscendDSAV41MetadataBuilder,
        DeepseekV41CacheBackend,
        DeepseekV41CacheLayer,
    )
    from vllm_ascend.core.kv_cache_interface import AscendSlidingWindowMLASpec
    from vllm_ascend.models.deepseek_v41.engram.model_state import EngramModelState
    from vllm_ascend.models.deepseek_v41.model import DeepseekV41SharedAttentionState
    from vllm_ascend.ops.rope_dsv4 import ComplexExpRotaryEmbedding
    from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager
    from vllm_ascend.worker.v2.eplb import AscendEPLBController
    from vllm_ascend.worker.v2.input_batch import AscendInputBuffers
    from vllm_ascend.worker.v2.states import AscendRequestState
    from vllm_ascend.worker.v2.utils import prepare_v41_source_rope

    from afd_plugin.compat.patches.npu.mrv2_ubatching import (
        use_npu_ubatch_sm_control,
    )
    from afd_plugin.distributed.hccl_plan import encode_hccl_plan_message
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_graph_bootstrap import (
        HcclV41AttentionGraphBootstrap,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_ubatch_runner import HcclV41UBatchRunner

    transport = connector.transport
    assert config.speculative_config is None and config.kv_transfer_config is None
    assert config.engram_config is None
    assert transport.negotiated_capabilities.target_query_len == 1
    assert transport.negotiated_capabilities.layer_indices == tuple(range(LAYER_COUNT))
    assert transport.negotiated_capabilities.graph_exchange_order == "stage_serial"
    assert not any(
        (
            connector.overlap_settings.graph_u2_compute_overlap,
            connector.overlap_settings.graph_u2_hybrid_dag,
            connector.overlap_settings.graph_u2_attention_three_stream,
            connector.overlap_settings.graph_u2_ffn_recv_stream,
            connector.overlap_settings.graph_u2_ffn_cross_layer,
        )
    )
    detail = {
        "owner_constructor_executed": False,
        "model_constructor_executed": False,
        "production_model_admission_executed": False,
        "native_model_state_constructor_executed": False,
        "native_manager_constructor_executed": False,
        "native_kv_allocator_executed": False,
        "native_execute_model_executed": False,
        "native_sampling_executed": False,
        "native_sparse_fa_executed": False,
        "native_smla_tiling_executed": False,
        "native_builder_build_query_metadata": False,
        "checkpoint_weights_loaded": False,
        "full_model_accepted": False,
        "normal_serving_admission_accepted": False,
        "pd_handoff_verified": False,
        "performance_accepted": False,
        "replays": [],
        "python_attention_calls": [],
        "host_records": [],
    }
    report["native_attention_owner"] = detail
    original_error = (
        RuntimeError(EXPECTED_NATIVE_ATTENTION_EAGER_ERROR) if fail_eager else None
    )
    failure_armed = False
    bank_refs = []
    retained_before_failure = None
    if fail_eager:
        assert lifecycle
        detail["fault_contract"] = {
            "scope": (
                "controlled Python Attention failure in actual native eager execute"
            ),
            "original_error_type": type(original_error).__name__,
            "original_error_message": str(original_error),
            "injection_observed": False,
            "control_observation_starts_after_hello": True,
            "control_messages": [],
            "worker_shutdown_executed": False,
            "device_fault_injected": False,
            "rollback_verified": False,
        }
    hidden_size = config.model_config.hf_text_config.hidden_size
    vocab_size = config.model_config.hf_text_config.vocab_size
    capacity = config.scheduler_config.max_num_batched_tokens
    layer_names = tuple(
        f"model.layers.{index}.self_attn.swa_cache" for index in range(LAYER_COUNT)
    )
    spec = AscendSlidingWindowMLASpec(
        block_size=BLOCK_SIZE,
        num_kv_heads=1,
        head_size=hidden_size,
        dtype=torch.bfloat16,
        sliding_window=config.model_config.hf_text_config.sliding_window,
        compress_ratio=1,
        model_version="deepseek_v41",
    )
    kv_config = KVCacheConfig(
        num_blocks=MAX_REQUESTS + 1,
        kv_cache_tensors=[],
        kv_cache_groups=[KVCacheGroupSpec(list(layer_names), spec)],
    )
    kv_cpu = (
        torch.arange((MAX_REQUESTS + 1) * BLOCK_SIZE * hidden_size)
        .reshape(MAX_REQUESTS + 1, BLOCK_SIZE, hidden_size)
        .remainder(13)
        .float()
        .div(16)
        .bfloat16()
    )
    kv = kv_cpu.to(device)
    for name in layer_names:
        layer = DeepseekV41CacheLayer(config, name, spec)
        layer.kv_cache = [kv]

    class CoordinateAttentionGroup(AttentionGroup):
        # Native public construction option: this controlled Attention consumes
        # slots/query/seq/RoPE, not SparseFA tiling. Parent and U2 builders remain
        # actual native constructors/builds; no metadata method is replaced.
        def create_metadata_builders(
            self,
            vllm_config,
            device,
            kernel_block_size: int | None = None,
            num_metadata_builders: int = 1,
        ):
            assert kernel_block_size in (None, BLOCK_SIZE)
            self.metadata_builders = [
                AscendDSAV41MetadataBuilder(
                    self.kv_cache_spec,
                    self.layer_names,
                    vllm_config,
                    device,
                    build_query_metadata=False,
                )
                for _ in range(num_metadata_builders)
            ]
            if kernel_block_size is not None:
                for builder in self.metadata_builders:
                    builder.set_kernel_block_size(kernel_block_size)

    group = CoordinateAttentionGroup(
        backend=DeepseekV41CacheBackend,
        layer_names=list(layer_names),
        kv_cache_spec=spec,
        kv_cache_group_id=0,
    )
    group.create_metadata_builders(config, device, kernel_block_size=BLOCK_SIZE)
    shared = DeepseekV41SharedAttentionState(
        torch.full((capacity, 1), -1, dtype=torch.int32, device=device),
        torch.full((capacity, 1, 2), -1, dtype=torch.int32, device=device),
        None,
        None,
    )

    class CoordinateAttention(nn.Module):
        def __init__(self, index):
            super().__init__()
            self.layer_idx, self.shared_state = index, shared
            # Native model loading constructs device-local RoPE buffers inside
            # this device context; keep the oracle's default CPU context intact.
            with torch.device(device):
                self.rotary_emb = ComplexExpRotaryEmbedding(
                    config,
                    layer_names[index].removesuffix(".swa_cache"),
                    HEAD_SIZE,
                    HEAD_SIZE,
                    MAX_MODEL_LEN,
                    ROPE_BASE,
                    1.0,
                    apply_yarn_scaling=False,
                )

        def forward(self, positions, hidden_states, scaling=None):
            nonlocal failure_armed
            context = get_forward_context()
            metadata = context.attn_metadata[layer_names[self.layer_idx]]
            slots = metadata.slot_mapping
            assert slots.shape == (hidden_states.shape[0], 2)
            assert metadata.cache_kind == "swa"
            if failure_armed:
                assert self.layer_idx == 0 and original_error is not None
                plan = transport.plan
                assert plan is not None and plan.graph_execution.phase == "eager"
                assert not torch.npu.is_current_stream_capturing()
                failure_armed = False
                detail["fault_contract"]["injection_observed"] = True
                detail["fault_contract"]["failed_parent"] = {
                    "id": plan.transaction_id,
                    "phase": plan.graph_execution.phase,
                    "reason": plan.graph_execution.reason,
                    "layer": self.layer_idx,
                    "stage": context.ubatch_idx,
                    "valid_tokens": sum(
                        stage.attention_valid_tokens[0] for stage in plan.stages
                    ),
                }
                assert detail["fault_contract"]["failed_parent"]["valid_tokens"] == 2
                raise original_error
            detail["python_attention_calls"].append(
                {
                    "layer": self.layer_idx,
                    "stage": context.ubatch_idx,
                    "capturing": torch.npu.is_current_stream_capturing(),
                    "slot_mapping_address": slots.data_ptr(),
                    "rows": hidden_states.shape[0],
                }
            )
            # Controlled, read-only KV arithmetic. Dummy PAD slots never write
            # a page; runtime slot preparation refreshes these persistent views.
            physical = (slots[:, 0] * BLOCK_SIZE + slots[:, 1]).clamp_min(0).long()
            values = kv.flatten(0, 1).index_select(0, physical)
            values = values.masked_fill((slots[:, 0] < 0).unsqueeze(1), 0)
            if self.layer_idx == 0:
                self.shared_state.topk_indices[: positions.shape[0], 0].copy_(positions)
            source_positions = self.shared_state.topk_indices[: positions.shape[0], 0]
            return (
                hidden_states.float() + values.float() + source_positions[:, None]
            ).bfloat16()

    model, embedding_cpu = build_native_attention_arithmetic_model(
        config, device, CoordinateAttention
    )

    owner = AFDNPUAttentionModelRunnerV2.__new__(AFDNPUAttentionModelRunnerV2)
    owner.vllm_config, owner.model_config = config, config.model_config
    owner.parallel_config, owner.compilation_config = (
        config.parallel_config,
        config.compilation_config,
    )
    owner.device, owner.model = device, model
    owner.max_num_reqs, owner.decode_query_len, owner.dp_size = MAX_REQUESTS, 1, 1
    owner.model_state = EngramModelState(config, model, None, device)
    owner.model_state.attn_metadata = None
    detail["native_model_state_constructor_executed"] = True
    owner.cudagraph_manager = owner.ubatch_runner = None
    owner.hccl_v41_transport = transport
    owner.hccl_v41_graph_eager = owner.hccl_v41_graph_session = None
    owner.hccl_v41_graph_coordinator = owner.hccl_v41_diagnostics = None
    owner.pcp_manager = owner.intermediate_tensors = None
    owner.lora_config = owner.speculator = owner.adaptive_verification = None
    owner.speculative_config = None
    owner.use_aux_hidden_state_outputs = False
    owner._finegrained_tp_requires_graph = False
    owner.sync_spec_pp_cpu_counts = False
    owner.use_fia = False
    owner.eplb = AscendEPLBController(config.parallel_config, device)
    owner.kv_connector = get_kv_connector(config, dict.fromkeys(layer_names, kv))
    owner.input_buffers = AscendInputBuffers(MAX_REQUESTS, capacity, device)
    owner.req_states = AscendRequestState(
        MAX_REQUESTS, MAX_MODEL_LEN, capacity, 0, vocab_size, device
    )
    owner.attn_groups, owner.kv_cache_config, owner.kv_caches = (
        [[group]],
        kv_config,
        [kv],
    )
    owner.update_stream = torch.npu.Stream(device=device)
    owner.block_tables = BlockTables(
        [BLOCK_SIZE], MAX_REQUESTS, capacity, [1], device, [BLOCK_SIZE]
    )
    # Native A worker initialization owns this process-local manager before
    # capture_model locks it. Reproduce that prerequisite, including U2 lanes.
    init_workspace_manager(device, num_ubatches=2)
    detail["native_workspace_manager_initialized"] = True
    if lifecycle:
        from hccl_native_attention_lifecycle_probe import (
            prepare_native_attention_lifecycle,
        )

        prepare_native_attention_lifecycle(owner, report, embedding_cpu=embedding_cpu)
    bootstrap = HcclV41AttentionGraphBootstrap(
        owner,
        synchronize=lambda: torch.npu.synchronize(device),
        overlap_settings=connector.overlap_settings,
        diagnostic_sink=detail["host_records"].append,
    )
    owner.hccl_v41_graph_bootstrap = bootstrap
    bootstrap.bind_loaded_model()
    bootstrap.begin_kv_init()
    with use_npu_ubatch_sm_control():
        owner.ubatch_runner = HcclV41UBatchRunner(
            config,
            device,
            owner.model_state,
            owner.attn_groups,
            kv_config,
            MAX_REQUESTS,
            kernel_block_sizes=[BLOCK_SIZE],
            timeout_s=UBATCH_TIMEOUT_SECONDS,
            transport=transport,
            graph_owner=bootstrap.session,
        )
    owner.cudagraph_manager = ModelAclGraphManager(
        config,
        device,
        CUDAGraphMode.FULL_DECODE_ONLY,
        1,
        model_runner=owner,
        ubatch_runner=owner.ubatch_runner,
    )
    detail["native_manager_constructor_executed"] = True
    prepare_v41_source_rope(owner)
    for groups in owner.ubatch_runner.stage_attn_groups:
        # Use the same native source-RoPE setup on independent child builders.
        for cache_group in groups:
            for child_group in cache_group:
                for builder in child_group.metadata_builders:
                    builder.prepare_source_rope()
    detail["native_source_rope_prepared"] = True
    bootstrap.complete_kv_init()
    coordinator = bootstrap.coordinator
    manager, cache = owner.cudagraph_manager, bootstrap.cache
    assert coordinator is not None
    original_finish = transport.finish_forward
    original_send, original_recv = transport._send_control, transport._recv_control

    def observe_control(direction, rank, message):
        data = encode_hccl_plan_message(message)
        detail["fault_contract"]["control_messages"].append(
            {
                "direction": direction,
                "peer_world_rank": rank,
                "kind": message.kind,
                "transaction_id": message.plan.transaction_id
                if message.plan is not None
                else message.transaction_id,
                "encoded_sha256": hashlib.sha256(data).hexdigest(),
                "encoded_message": json.loads(data),
            }
        )

    def observe_send(rank, message):
        original_send(rank, message)
        observe_control("send_returned", rank, message)

    def observe_recv(rank):
        message = original_recv(rank)
        observe_control("receive_returned", rank, message)
        return message

    def resource_snapshot():
        return {
            "model": id(owner.model),
            "model_state": id(owner.model_state),
            "manager": id(owner.cudagraph_manager),
            "microbatch_runner": id(owner.ubatch_runner),
            "bootstrap": id(owner.hccl_v41_graph_bootstrap),
            "coordinator": id(owner.hccl_v41_graph_coordinator),
            "session": id(owner.hccl_v41_graph_session),
            "cache": id(cache),
            "input_ids": owner.input_buffers.input_ids.data_ptr(),
            "positions": owner.input_buffers.positions.data_ptr(),
            "kv": owner.kv_caches[0].data_ptr(),
            "output": owner.cudagraph_manager.hidden_states.data_ptr(),
            "graphs": sorted(
                (descriptor.num_tokens, descriptor.num_ubatches, id(graph))
                for descriptor, graph in owner.cudagraph_manager.graphs.items()
            ),
            "banks": [
                {
                    "object": id(bank_ref()),
                    "hidden_buffers": [
                        exchange.buffers.hidden_states.data_ptr()
                        for exchange in bank_ref().exchanges
                        if exchange is not None
                    ],
                }
                for bank_ref in bank_refs
            ],
        }

    def arm_failure():
        nonlocal failure_armed, retained_before_failure
        assert original_error is not None and not failure_armed
        for geometry in coordinator.coverage.geometries:
            entry = cache.find(coordinator.control.key_for(geometry), 0)
            assert entry is not None
            bank_refs.append(weakref.ref(entry.resources.bank))
        assert len(bank_refs) == 4
        # Weak observations do not become an extra owner of retained banks.
        retained_before_failure = resource_snapshot()
        failure_armed = True

    def record_finish():
        plan = transport.plan
        decision = plan.graph_execution
        original_finish()
        report["transactions"].append(
            {
                "id": plan.transaction_id,
                "phase": decision.phase,
                "reason": decision.reason,
                "key": None if decision.key is None else decision.key.digest,
            }
        )

    # Graph COMPLETE delegates to this public method too. Observe it once;
    # wrapping both APIs would duplicate the same completed parent.
    transport.finish_forward = record_finish
    if fail_eager:
        # Observe actual codec payloads only after the original blocking wire
        # operation returns. No reply or transport result is manufactured.
        transport._send_control, transport._recv_control = observe_send, observe_recv
    try:
        before_capture = kv.cpu()
        assert coordinator.preflight_capture()
        capture_bytes = coordinator.capture_native()
        torch.npu.synchronize(device)
        torch.testing.assert_close(kv.cpu(), before_capture, rtol=0, atol=0)
        detail["capture_kv_unchanged"] = True
        detail["native_capture_memory_delta_bytes"] = capture_bytes
        captured = tuple(manager.graphs)
        assert len(captured) == 4
        assert {desc.num_ubatches for desc in captured} == {1, 2}
        assert all(
            isinstance(graph, torch.npu.NPUGraph) for graph in manager.graphs.values()
        )
        detail["captured_descriptors"] = [
            {
                "num_tokens": descriptor.num_tokens,
                "num_reqs": descriptor.num_reqs,
                "num_stages": descriptor.num_ubatches,
                "uniform_token_count": descriptor.uniform_token_count,
                "mode": descriptor.cg_mode.name,
            }
            for descriptor in captured
        ]
        for index in range(MAX_REQUESTS):
            req_id = f"native-a-{index}"
            owner.req_states.add_request(req_id, 1, [1], 1, MAX_MODEL_LEN - 1)
            req_index = owner.req_states.req_id_to_index[req_id]
            owner.block_tables.append_block_ids(
                req_index, ([index + 1],), overwrite=True
            )
        owner.req_states.apply_staged_writes()
        owner.block_tables.apply_staged_writes()
        for wanted in captured:
            previous = None
            pointers = None
            for iteration in range(3):
                rows = wanted.num_tokens
                ids = torch.arange(rows, dtype=torch.int64) + (
                    2 if iteration == 0 else 5
                )
                position = 1 if iteration == 0 else 2
                if iteration == 2:
                    kv_cpu.add_(0.5)
                kv.copy_(kv_cpu.to(device))
                for index in range(rows):
                    req_index = owner.req_states.req_id_to_index[f"native-a-{index}"]
                    owner.req_states.num_computed_tokens_np[req_index] = position
                    owner.req_states.num_computed_tokens.stage_write_elem(
                        req_index, position
                    )
                    owner.req_states.last_sampled_tokens[req_index, 0] = int(ids[index])
                owner.req_states.apply_staged_writes()
                scheduler = SchedulerOutput(
                    scheduled_new_reqs=[],
                    scheduled_cached_reqs=CachedRequestData.make_empty(),
                    num_scheduled_tokens={f"native-a-{i}": 1 for i in range(rows)},
                    total_num_scheduled_tokens=rows,
                    scheduled_spec_decode_tokens={},
                    scheduled_encoder_inputs={},
                    num_common_prefix_blocks=[0],
                    finished_req_ids=set(),
                    free_encoder_mm_hashes=[],
                )
                # Native thresholds are immutable in normal serving. This
                # controlled dispatch uses the original native allow_ubatching
                # parameter to select each retained U1/U2 twin, without changing
                # the config or replacing dispatch/gather/preparation methods.
                python_before = len(detail["python_attention_calls"])
                with coordinator.execution_scope(
                    mode="target", valid_tokens=rows, dummy_run=False
                ):
                    state, uniform = owner.gather_batch_req_state(scheduler, False)
                    descriptor, sync = native_runner.dispatch_cg_and_sync_dp(
                        manager,
                        rows,
                        rows,
                        uniform,
                        dp_size=1,
                        dp_rank=0,
                        need_eager=False,
                        parallel_config=config.parallel_config,
                        allow_ubatching=wanted.num_ubatches == 2,
                        uniform_decode=True,
                    )
                    assert sync is None and descriptor == wanted
                    batch = owner.prepare_inputs(scheduler, state, descriptor)
                    tables = owner.block_tables.gather_block_tables(
                        batch.idx_mapping, batch.num_reqs_after_padding
                    )
                    slots = owner.block_tables.compute_slot_mappings(
                        batch.idx_mapping,
                        batch.query_start_loc,
                        batch.positions,
                        batch.num_tokens_after_padding,
                    )
                    if descriptor.num_ubatches == 2:
                        owner.ubatch_runner.prepare(
                            batch, tables, slots, CUDAGraphMode.FULL, False
                        )
                    else:
                        owner.model_state.prepare_attn(
                            batch,
                            CUDAGraphMode.FULL,
                            tables,
                            slots,
                            owner.attn_groups,
                            kv_config,
                            for_capture=False,
                        )
                    owner.model_state.prepare_inputs(batch, owner.req_states)
                    output = manager.run_fullgraph(descriptor)
                torch.npu.synchronize(device)
                assert len(detail["python_attention_calls"]) == python_before
                torch.testing.assert_close(
                    batch.input_ids.cpu(), ids.int(), rtol=0, atol=0
                )
                torch.testing.assert_close(
                    batch.positions.cpu(), torch.full((rows,), position), rtol=0, atol=0
                )
                expected = embedding_cpu[ids].clone()
                kv_rows = torch.stack([kv_cpu[i + 1, position] for i in range(rows)])
                # Independent CPU arithmetic, outside the leaf/graph bodies.
                for _ in range(LAYER_COUNT):
                    attended = (
                        expected.float() + kv_rows.float() + position
                    ).bfloat16()
                    residual = (expected.float() + attended.float()).bfloat16()
                    router = residual.float() + ROUTER_DELTA
                    remote = (
                        residual.float()
                        + (router - residual.float()) * ROUTER_SCALE
                        + ids[:, None].float()
                    ).bfloat16()
                    expected = (residual.float() + remote.float()).bfloat16()
                actual = output[:rows].cpu()
                torch.testing.assert_close(actual, expected, rtol=0, atol=0)
                if previous is not None:
                    assert not torch.equal(previous, actual)
                previous = actual.clone()
                # The completed reservation is intentionally cleared. Locate
                # its actual retained bundle by the immutable native descriptor.
                geometry = next(
                    geometry
                    for geometry in coordinator.coverage.geometries
                    if geometry.descriptor == descriptor
                )
                entry = cache.find(coordinator.control.key_for(geometry), 0)
                assert entry is not None
                addresses = (
                    id(manager.graphs[descriptor]),
                    owner.input_buffers.input_ids.data_ptr(),
                    owner.input_buffers.positions.data_ptr(),
                    kv.data_ptr(),
                    manager.hidden_states.data_ptr(),
                    *(
                        exchange.buffers.hidden_states.data_ptr()
                        for exchange in entry.resources.bank.exchanges
                        if exchange is not None
                    ),
                )
                if pointers is not None:
                    assert addresses == pointers
                pointers = addresses
                detail["replays"].append(
                    {
                        "iteration": iteration,
                        "num_tokens": rows,
                        "num_stages": descriptor.num_ubatches,
                        "key": entry.key.digest,
                        "addresses": addresses,
                        "oracle_verified": True,
                        "python_attention_executed": False,
                        "changed_inputs": iteration == 1,
                        "changed_only_kv": iteration == 2,
                        "input_ids": batch.input_ids.cpu().tolist(),
                        "positions": batch.positions.cpu().tolist(),
                        "query_start_loc": batch.query_start_loc.cpu().tolist(),
                        "seq_lens": batch.seq_lens.cpu().tolist(),
                        "slot_mapping": slots.cpu().tolist(),
                        "kv_sha256": hashlib.sha256(
                            kv_cpu.contiguous().view(torch.uint8).numpy().tobytes()
                        ).hexdigest(),
                        "output_sha256": hashlib.sha256(
                            actual.contiguous().view(torch.uint8).numpy().tobytes()
                        ).hexdigest(),
                        "expected_sha256": hashlib.sha256(
                            expected.contiguous().view(torch.uint8).numpy().tobytes()
                        ).hexdigest(),
                        "output": actual.float().tolist(),
                    }
                )
                owner.model_state.finish_execution(failed=False)
        expected_transactions = NATIVE_ATTENTION_TRANSACTIONS
        if lifecycle:
            from hccl_native_attention_lifecycle_probe import (
                LIFECYCLE_TRANSACTIONS,
                run_native_attention_lifecycle,
            )

            profile_context = None
            if profile_dir is not None:
                from hccl_native_attention_profile_probe import (
                    native_attention_profile_step,
                    prepare_native_attention_profile,
                )

                prepare_native_attention_profile(owner, report, profile_dir)
                profile_context = partial(native_attention_profile_step, owner, report)
            run_native_attention_lifecycle(
                owner,
                report,
                embedding_cpu=embedding_cpu,
                kv_cpu=kv_cpu,
                before_replacement_prefill=arm_failure if fail_eager else None,
                profile_context=profile_context,
            )
            detail["native_execute_model_executed"] = True
            detail["native_sampling_executed"] = True
            expected_transactions += LIFECYCLE_TRANSACTIONS
        assert len(report["transactions"]) == expected_transactions
        transport.stop_attention()
        detail["acknowledged_stop"] = True
        if profile_dir is not None:
            from hccl_native_attention_profile_probe import (
                finish_native_attention_profile,
            )

            finish_native_attention_profile(owner, report, profile_dir)
        detail["capture_and_fresh_input_kv_replay_verified"] = True
        return manager, cache
    except BaseException as error:
        bootstrap.fail()
        if fail_eager and error is original_error:
            fault = detail["fault_contract"]
            assert fault["injection_observed"]
            assert len(report["transactions"]) == (
                COMPLETED_PARENTS_BEFORE_ATTENTION_FAILURE
            )
            assert transport.terminal and not transport.closed
            assert cache.terminal and not cache.closed and not cache.is_empty
            assert all(bank_ref() is not None for bank_ref in bank_refs)
            assert resource_snapshot() == retained_before_failure
            fault["original_error_identity_preserved"] = True
            fault["retained_resources_before"] = retained_before_failure
            # Native preparation/finalization may already have changed request
            # state. Freeze bytes only after the original execute failure;
            # these checks prove rejection does not release/mutate the owner,
            # not transactional rollback of the failed model execution.
            kv_after_error = owner.kv_caches[0].cpu()
            messages_before_public_cleanup = list(fault["control_messages"])
            fault["public_errors"] = {}
            try:
                owner.execute_model(SchedulerOutput.make_empty())
            except ValueError as retry_error:
                assert str(retry_error) == (
                    "native execution requires one idle owning graph session"
                )
                fault["public_errors"]["execute_model_retry"] = {
                    "type": type(retry_error).__name__,
                    "message": str(retry_error),
                }
            else:
                raise AssertionError("execute_model reused a failed staged session")
            for name, operation in (
                ("prepare_shutdown", owner.prepare_shutdown),
                ("shutdown", owner.shutdown),
            ):
                try:
                    operation()
                except RuntimeError as shutdown_error:
                    assert str(shutdown_error) == (
                        "failed staged session requires worker supervision"
                    )
                    fault["public_errors"][name] = {
                        "type": type(shutdown_error).__name__,
                        "message": str(shutdown_error),
                    }
                else:
                    raise AssertionError(f"{name} accepted a failed staged session")
            assert resource_snapshot() == retained_before_failure
            assert fault["control_messages"] == messages_before_public_cleanup
            kv_after_public_cleanup = owner.kv_caches[0].cpu()
            torch.testing.assert_close(
                kv_after_public_cleanup, kv_after_error, rtol=0, atol=0
            )
            fault["kv_sha256_after_original_error"] = hashlib.sha256(
                kv_after_error.contiguous().view(torch.uint8).numpy().tobytes()
            ).hexdigest()
            fault["kv_sha256_after_public_cleanup_rejection"] = hashlib.sha256(
                kv_after_public_cleanup.contiguous().view(torch.uint8).numpy().tobytes()
            ).hexdigest()
            fault["control_messages_unchanged_by_public_rejection"] = True
            fault["retained_resources_after"] = resource_snapshot()
            failed_tx = fault["failed_parent"]["id"]
            messages = fault["control_messages"]
            completed = {parent["id"] for parent in report["transactions"]}
            assert failed_tx not in completed
            for direction in ("send_returned", "receive_returned"):
                actual = [
                    message for message in messages if message["direction"] == direction
                ]
                assert {
                    message["transaction_id"]
                    for message in actual
                    if message["kind"] == "COMPLETE"
                } == completed
                assert sum(message["kind"] == "COMPLETE" for message in actual) == len(
                    completed
                )
            assert any(
                message["direction"] == "send_returned"
                and message["kind"] == "FORWARD"
                and message["transaction_id"] == failed_tx
                for message in messages
            )
            assert (
                sum(
                    message["direction"] == "send_returned"
                    and message["kind"] == "FORWARD"
                    for message in messages
                )
                == COMPLETED_PARENTS_BEFORE_ATTENTION_FAILURE + 1
            )
            for direction in ("send_returned", "receive_returned"):
                assert (
                    sum(
                        message["direction"] == direction
                        and message["kind"] == "ACCEPT"
                        and message["transaction_id"] == failed_tx
                        for message in messages
                    )
                    == 1
                )
            assert not any(
                message["kind"] in ("STOP", "STOP_ACK")
                or message["kind"] == "COMPLETE"
                and message["transaction_id"] == failed_tx
                for message in messages
            )
            fault["completed_parent_count"] = len(completed)
            fault["failed_parent_complete_absent"] = True
            fault["stop_absent"] = True
            fault["terminal_transport_and_cache"] = True
            fault["owner_resources_retained"] = True
            fault["status"] = "passed"
            detail["native_execute_model_executed"] = True
            detail["native_sampling_executed"] = True
        raise
    finally:
        transport.finish_forward = original_finish
        if fail_eager:
            transport._send_control, transport._recv_control = (
                original_send,
                original_recv,
            )
        # On failure only the existing external supervisor owns processes/groups.
        if not transport.terminal:
            with suppress(RuntimeError):
                owner.ubatch_runner.abort_pending_run()
