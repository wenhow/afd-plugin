# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Load and bind a real, bounded native V4.1 DSpark speculator.

The default command only inspects checkpoint metadata with the standard library.
Only --run imports the device runtime. The target is an explicit interface shell;
the draft uses its complete native constructor, dummy loader and KV backend.
This first component does not execute either model, a proposal, or PD publication.
"""

from __future__ import annotations

import argparse
import hashlib
import inspect
import json
import os
import sys
import traceback
from pathlib import Path

from dsv41_dspark_a5_runtime import NATIVE_ATTENTION_HEADS

HIDDEN_SIZE = 512
HEAD_SIZE = 512
ROPE_HEAD_SIZE = 64
LORA_RANK = 64
HC_MULT = 4
TARGET_LAYERS = 2
AUX_LAYER_IDS = (1, 2)
DRAFT_LAYERS = 1
SPECULATIVE_TOKENS = 2
VOCAB_SIZE = 128
EXPERTS = 8
EXPERTS_PER_TOKEN = 2
INTERMEDIATE_SIZE = 512
MARKOV_RANK = 16
MAX_MODEL_LEN = 128
MAX_REQUESTS = 1
MAX_BATCHED_TOKENS = 16
BLOCK_SIZE = 128
NUM_BLOCKS = 9
STATE_RING_ROWS = 32
INDEX_HEAD_SIZE = 128
# The V4.1 compressed role and metadata builder use ratios 1/2. Keep this
# bounded CSA2 config and its registered native cache specs aligned.
COMPRESS_RATIO = 2
INDEX_NUM_HEADS = 64
INDEX_TOPK = 512
COMPRESSOR_STATE_COMPONENTS = 2
SEED = 0
NATIVE_PLUGINS = (
    "ascend,ascend_model,ascend_model_loader,ascend_kv_connector,"
    "ascend_service_profiling"
)


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def write_report(output_dir: Path, report: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    temporary = output_dir / "result.json.tmp"
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", "utf-8")
    temporary.replace(output_dir / "result.json")


def bounded_hf_config(hf_config):
    """Public ModelConfig callable override, also composed onto the draft."""
    values = {
        "hidden_size": HIDDEN_SIZE,
        "num_hidden_layers": TARGET_LAYERS,
        "num_attention_heads": NATIVE_ATTENTION_HEADS,
        "num_key_value_heads": 1,
        "head_dim": HEAD_SIZE,
        "qk_rope_head_dim": ROPE_HEAD_SIZE,
        "q_lora_rank": LORA_RANK,
        "kv_lora_rank": HEAD_SIZE,
        "o_lora_rank": LORA_RANK,
        "o_groups": 1,
        "hc_mult": HC_MULT,
        "vocab_size": VOCAB_SIZE,
        "intermediate_size": INTERMEDIATE_SIZE,
        "moe_intermediate_size": INTERMEDIATE_SIZE,
        "n_routed_experts": EXPERTS,
        "dspark_n_routed_experts": EXPERTS,
        "n_shared_experts": 1,
        "num_experts_per_tok": EXPERTS_PER_TOKEN,
        "dspark_num_experts_per_tok": EXPERTS_PER_TOKEN,
        "n_group": 1,
        "topk_group": 1,
        "num_hash_layers": 0,
        "max_position_embeddings": MAX_MODEL_LEN,
        "sliding_window": BLOCK_SIZE,
        "compress_ratios": [COMPRESS_RATIO] * TARGET_LAYERS,
        "index_head_dim": INDEX_HEAD_SIZE,
        "index_n_heads": INDEX_NUM_HEADS,
        "index_topk": INDEX_TOPK,
        "engram_layer_ids": [],
        "vision_n_layers": 0,
        "quantization_config": None,
        "expert_dtype": "bf16",
        "num_nextn_predict_layers": DRAFT_LAYERS,
        "n_mtp_layers": DRAFT_LAYERS,
        "dspark_num_mtp_layers": DRAFT_LAYERS,
        "dspark_target_layer_ids": list(AUX_LAYER_IDS),
        "dspark_block_size": SPECULATIVE_TOKENS,
        "dspark_markov_rank": MARKOV_RANK,
        "draft_vocab_size": VOCAB_SIZE,
        "dspark_noise_token_id": 0,
        "ptd_token_id": 0,
        "bos_token_id": 1,
        "eos_token_id": 2,
        "pad_token_id": 0,
        "rope_parameters": {
            "rope_type": "default",
            "rope_theta": 10000.0,
            "factor": 1.0,
            "beta_fast": 32,
            "beta_slow": 1,
            "original_max_position_embeddings": MAX_MODEL_LEN,
        },
    }
    # Reconstruct before ModelConfig derives its architecture. Preserve the
    # normalizer's draft architecture, n_predict and native routing function.
    raw = hf_config.to_dict()
    # HFConfigParser first passes a generic PretrainedConfig with an instance
    # dummy model_type. Its to_dict uses the class model_type, so preserve the
    # actual input marker for the native parser's registry lookup.
    raw["model_type"] = hf_config.model_type
    raw.update(values)
    raw.pop("rope_scaling", None)
    if "text_config" in raw:
        raw["text_config"] = {**raw["text_config"], **values}
        raw["text_config"].pop("rope_scaling", None)
    raw["vision_config"] = {"num_hidden_layers": 0}
    return type(hf_config)(**raw)


def create_config(model: str, output_dir: Path):
    # Runtime imports are isolated behind --run, including EngineArgs.
    from vllm.config import CompilationConfig, CompilationMode, CUDAGraphMode
    from vllm.engine.arg_utils import EngineArgs

    # Native Ascend auto-detection reads model files again after hf_overrides.
    # A dummy BF16 fixture therefore needs its own unquantized config file;
    # keep the original checkpoint directory read-only.
    source_config = Path(model) / "config.json"
    source_raw = source_config.read_bytes()
    raw_config = json.loads(source_raw)
    for container in (raw_config, raw_config.get("text_config", {})):
        container.pop("quantization_config", None)
        container.pop("compression_config", None)
        container["expert_dtype"] = "bf16"
    controlled_model = output_dir / "controlled-model"
    controlled_model.mkdir(parents=True, exist_ok=False)
    (output_dir / "checkpoint-config-original.json").write_bytes(source_raw)
    (controlled_model / "config.json").write_text(
        json.dumps(raw_config, indent=2) + "\n", "utf-8"
    )
    (controlled_model / "provenance.json").write_text(
        json.dumps(
            {
                "source_config": str(source_config),
                "source_config_sha256": sha256(source_raw),
                "dummy_unquantized_configuration_only": True,
            },
            indent=2,
        )
        + "\n",
        "utf-8",
    )
    return EngineArgs(
        model=str(controlled_model),
        trust_remote_code=True,
        skip_tokenizer_init=True,
        language_model_only=True,
        dtype="bfloat16",
        hf_overrides=bounded_hf_config,
        load_format="dummy",
        enforce_eager=True,
        max_model_len=MAX_MODEL_LEN,
        max_num_seqs=MAX_REQUESTS,
        max_num_batched_tokens=MAX_BATCHED_TOKENS,
        enable_chunked_prefill=True,
        enable_prefix_caching=False,
        tensor_parallel_size=1,
        enable_expert_parallel=False,
        enable_dbo=False,
        ubatch_size=0,
        async_scheduling=False,
        block_size=BLOCK_SIZE,
        seed=SEED,
        compilation_config=CompilationConfig(
            mode=CompilationMode.NONE,
            cudagraph_mode=CUDAGraphMode.NONE,
            use_inductor_graph_partition=False,
        ),
        speculative_config={
            "method": "dspark",
            "num_speculative_tokens": SPECULATIVE_TOKENS,
            "draft_tensor_parallel_size": 1,
            "draft_sample_method": "greedy",
            "enable_adaptive_verification": False,
            "enforce_eager": True,
        },
        additional_config={
            "enable_cpu_binding": False,
            "enable_flashcomm1": False,
            "enable_dsa_cp": False,
            "multistream_dsv4_dsa_overlap": False,
            "multistream_overlap_shared_expert": False,
            "multistream_engram_overlap": False,
        },
    ).create_engine_config()


def record_config(config) -> dict:
    from vllm.config import CUDAGraphMode

    spec = config.speculative_config
    target, draft = config.model_config, spec.draft_model_config
    names = (
        "model_type",
        "architectures",
        "hidden_size",
        "num_hidden_layers",
        "num_attention_heads",
        "head_dim",
        "qk_rope_head_dim",
        "q_lora_rank",
        "o_lora_rank",
        "o_groups",
        "hc_mult",
        "vocab_size",
        "n_routed_experts",
        "num_experts_per_tok",
        "n_mtp_layers",
        "num_nextn_predict_layers",
        "dspark_target_layer_ids",
        "dspark_block_size",
        "engram_layer_ids",
        "scoring_func",
    )
    target_values = target.hf_text_config.to_dict()
    draft_values = draft.hf_text_config.to_dict()
    detail = {
        "controlled_model_directory": target.model,
        "controlled_config_sha256": sha256(
            (Path(target.model) / "config.json").read_bytes()
        ),
        "target": {name: target_values[name] for name in names},
        "draft": {name: draft_values[name] for name in names},
        "draft_architectures": draft.architectures,
        "load_format": config.load_config.load_format,
        "max_model_len": target.max_model_len,
        "max_num_seqs": config.scheduler_config.max_num_seqs,
        "max_num_batched_tokens": config.scheduler_config.max_num_batched_tokens,
        "draft_sample_method": spec.draft_sample_method,
        "adaptive_verification": spec.enable_adaptive_verification,
    }
    assert target.hf_text_config.model_type == "deepseek_v41"
    assert draft.architectures == ["DeepseekV41DSparkModel"]
    for item in (target, draft):
        hf = item.hf_text_config
        assert hf.hidden_size == HIDDEN_SIZE and hf.head_dim == HEAD_SIZE
        assert hf.hc_mult == HC_MULT
        assert hf.num_attention_heads == NATIVE_ATTENTION_HEADS
        assert hf.n_routed_experts == EXPERTS
        assert hf.num_experts_per_tok == EXPERTS_PER_TOKEN
        assert hf.qk_rope_head_dim == ROPE_HEAD_SIZE
        assert hf.num_hidden_layers == TARGET_LAYERS
        assert hf.n_mtp_layers == DRAFT_LAYERS
        assert hf.dspark_target_layer_ids == list(AUX_LAYER_IDS)
        assert hf.engram_layer_ids == [] and item.enforce_eager
        assert item.quantization is None
    assert spec.num_speculative_tokens == SPECULATIVE_TOKENS
    assert (
        spec.draft_sample_method == "greedy" and not spec.enable_adaptive_verification
    )
    assert config.quant_config is None and config.engram_config is None
    assert config.kv_transfer_config is None
    assert config.compilation_config.cudagraph_mode == CUDAGraphMode.NONE
    assert config.parallel_config.tensor_parallel_size == 1
    assert not config.parallel_config.enable_expert_parallel
    assert not config.parallel_config.use_sequence_parallel_moe
    assert not config.parallel_config.use_ubatching
    assert config.parallel_config.prefill_context_parallel_size == 1
    assert config.parallel_config.decode_context_parallel_size == 1
    return detail


def create_target_interface(config):
    import torch
    from torch import nn
    from vllm.model_executor.layers.vocab_parallel_embedding import (
        ParallelLMHead,
        VocabParallelEmbedding,
    )
    from vllm.model_executor.models.interfaces import EagleModelMixin, SupportsEagle3
    from vllm.v1.kv_cache_interface import CircularBufferSpec
    from vllm.v1.worker.gpu.spec_decode.eagle.eagle3_utils import (
        set_eagle3_aux_hidden_state_layers,
    )
    from vllm_ascend.attention.dsa_v41 import DeepseekV41CacheLayer
    from vllm_ascend.models.deepseek_v41.cache_config import (
        make_index_cache_spec,
        make_mla_cache_spec,
    )
    from vllm_ascend.models.deepseek_v41.model import AscendDeepseekV41SWACache

    class TargetInner(nn.Module, EagleModelMixin):
        def __init__(self):
            super().__init__()
            self.start_layer, self.end_layer = 0, TARGET_LAYERS
            self.embed_tokens = VocabParallelEmbedding(VOCAB_SIZE, HIDDEN_SIZE)
            self.cache_carriers = nn.ModuleList()
            for layer in range(TARGET_LAYERS):
                prefix = f"model.layers.{layer}.self_attn"
                specs = {
                    prefix + ".long_kv_cache": make_mla_cache_spec(
                        block_size=BLOCK_SIZE,
                        head_size=HEAD_SIZE,
                        compress_ratio=COMPRESS_RATIO,
                    ),
                    prefix + ".indexer.k_cache": make_index_cache_spec(
                        block_size=BLOCK_SIZE,
                        head_size=INDEX_HEAD_SIZE,
                        compress_ratio=COMPRESS_RATIO,
                    ),
                    prefix + ".compressor.state_cache": CircularBufferSpec(
                        block_size=STATE_RING_ROWS,
                        num_kv_heads=1,
                        head_size=COMPRESSOR_STATE_COMPONENTS * HEAD_SIZE,
                        dtype=torch.float32,
                        head_size_v=0,
                    ),
                }
                for name, spec in specs.items():
                    self.cache_carriers.append(
                        DeepseekV41CacheLayer(config, name, spec)
                    )
                self.cache_carriers.append(
                    AscendDeepseekV41SWACache(
                        head_dim=HEAD_SIZE,
                        window_size=BLOCK_SIZE,
                        dtype=torch.bfloat16,
                        prefix=prefix + ".swa_cache",
                        cache_config=config.cache_config,
                    )
                )

    class TargetInterface(nn.Module, SupportsEagle3):
        def __init__(self):
            super().__init__()
            self.model = TargetInner()
            self.lm_head = ParallelLMHead(VOCAB_SIZE, HIDDEN_SIZE)

    target = TargetInterface()
    # Deterministic, bounded target interface weights. The actual native dummy
    # loader independently initializes every real draft decoder parameter.
    with torch.no_grad():
        target.model.embed_tokens.weight.fill_(0.125)
        target.lm_head.weight.fill_(0.0625)
    set_eagle3_aux_hidden_state_layers(target, config.speculative_config)
    assert target.model.aux_hidden_state_layers == AUX_LAYER_IDS
    return target


def native_source(symbol) -> dict:
    path = Path(inspect.getsourcefile(symbol))
    return {"path": str(path), "sha256": sha256(path.read_bytes())}


def loaded_runtime_libraries() -> list[dict]:
    paths = set()
    for line in Path("/proc/self/maps").read_text().splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) == 6 and fields[5].startswith("/"):
            path = Path(fields[5])
            if ".so" in path.name and path.is_file():
                paths.add(path.resolve())
    return [
        {"path": str(path), "sha256": sha256(path.read_bytes())}
        for path in sorted(paths)
    ]


def bind_native_attention(config, target, speculator, device, report):
    import torch
    from vllm.config import CUDAGraphMode, get_layers_from_vllm_config
    from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
    from vllm.v1.attention.backends.utils import (
        get_supported_kv_cache_layouts,
        resolve_kv_cache_layout,
    )
    from vllm.v1.worker.gpu import model_runner
    from vllm.v1.worker.gpu.attn_utils import init_attn_backend
    from vllm_ascend.models.deepseek_v41.cache_config import (
        get_deepseek_v41_kv_cache_config,
        get_deepseek_v41_pool_bytes_per_block,
        group_cache_specs,
        make_cache_groups,
    )
    from vllm_ascend.worker.v2.block_table import AscendBlockTables
    from vllm_ascend.worker.v2.input_batch import AscendInputBuffers

    specs = model_runner.get_kv_cache_spec(config)
    layers = get_layers_from_vllm_config(config, AttentionLayerBase)
    supported_layouts = get_supported_kv_cache_layouts(
        layer.get_attn_backend() for layer in layers.values()
    )
    # EngineCore normally resolves this once before workers allocate caches.
    # This standalone component calls the same native negotiation on the
    # actual registered backends and specs, without forcing a layout name.
    layout = resolve_kv_cache_layout(
        config, [[item.name for item in supported_layouts]], specs.values()
    )
    groups = make_cache_groups(group_cache_specs(specs))
    kv_config = get_deepseek_v41_kv_cache_config(
        config,
        groups,
        available_memory=NUM_BLOCKS * get_deepseek_v41_pool_bytes_per_block(groups),
    )
    assert kv_config.num_blocks == NUM_BLOCKS
    model_state = model_runner.init_model_state(config, target, None, device)
    input_buffers = AscendInputBuffers(MAX_REQUESTS, MAX_BATCHED_TOKENS, device)
    attn_groups, _, kernel_block_sizes = init_attn_backend(
        kv_config,
        config,
        device,
        draft_layer_names=speculator.draft_attn_layer_names,
    )
    block_sizes, widths, slots = [], [], []
    for group in kv_config.kv_cache_groups:
        spec = group.kv_cache_spec
        block_sizes.append(spec.block_size)
        widths.append(
            model_runner.get_block_table_width(
                spec.max_num_blocks_per_req(config, MAX_MODEL_LEN),
                spec.block_size,
                token_alignment=spec.block_table_token_alignment,
            )
        )
        slots.append(spec.first_spec.uses_slot_mapping)
    block_tables = AscendBlockTables(
        block_sizes=block_sizes,
        max_num_reqs=MAX_REQUESTS,
        max_num_batched_tokens=MAX_BATCHED_TOKENS,
        max_num_blocks_per_group=widths,
        device=device,
        kernel_block_sizes=kernel_block_sizes,
        slot_mapping_enabled=slots,
    )
    speculator.pcp_manager = None
    speculator.set_attn(
        model_state, kv_config, block_tables, input_buffers, attn_groups
    )
    speculator.init_cudagraph_manager(CUDAGraphMode.NONE)
    # This is the real native MRV2 allocation-and-binding entry, after set_attn.
    caches = model_runner.init_kv_cache(
        config.compilation_config.static_forward_context,
        kv_config,
        device,
        kernel_block_sizes,
        config,
        block_tables=block_tables,
    )
    layers = get_layers_from_vllm_config(config, AttentionLayerBase)
    assert set(caches) == set(specs)
    bindings = {}
    for name, cache in caches.items():
        tensors = cache if isinstance(cache, (tuple, list)) else (cache,)
        bound = layers[name].kv_cache[0]
        bound_tensors = bound if isinstance(bound, (tuple, list)) else (bound,)
        assert len(tensors) == len(bound_tensors)
        for actual, expected in zip(bound_tensors, tensors, strict=True):
            assert actual.data_ptr() == expected.data_ptr()
        bindings[name] = [
            {
                "shape": list(t.shape),
                "stride": list(t.stride()),
                "dtype": str(t.dtype),
                "device": str(t.device),
                "data_ptr": t.data_ptr(),
                "storage_offset": t.storage_offset(),
                "storage_bytes": t.untyped_storage().nbytes(),
            }
            for t in tensors
        ]
    group_ids, layer_group_ids, sizes = speculator.get_draft_context_group_layout()
    assert len(layer_group_ids) == DRAFT_LAYERS and group_ids
    draft_cache_names = set(speculator.model.get_draft_kv_cache_layer_names())
    assert draft_cache_names == speculator.draft_attn_layer_names.intersection(specs)
    # Native layer discovery also includes attention helpers with no KV spec.
    # The model's context writer names only its actual SWA cache carriers.
    uncached_draft_layers = speculator.draft_attn_layer_names.difference(specs)
    assert all(
        layers[name].get_kv_cache_spec(config) is None for name in uncached_draft_layers
    )
    torch.npu.synchronize(device)
    report["native_binding"] = {
        "model_state_class": type(model_state).__module__
        + "."
        + type(model_state).__qualname__,
        "num_blocks": kv_config.num_blocks,
        "resolved_kv_cache_layout": layout.name,
        "layout_resolution_entry": native_source(resolve_kv_cache_layout),
        "groups": [
            {
                "group_id": index,
                "layer_names": group.layer_names,
                "block_size": group.kv_cache_spec.block_size,
            }
            for index, group in enumerate(kv_config.kv_cache_groups)
        ],
        "kernel_block_sizes": kernel_block_sizes,
        "draft_group_ids": list(group_ids),
        "draft_cache_layer_names": sorted(draft_cache_names),
        "uncached_draft_attention_layers": sorted(uncached_draft_layers),
        "draft_layer_group_ids": list(layer_group_ids),
        "draft_block_sizes": sizes,
        "architecture": speculator.attn_architecture,
        "caches": bindings,
        "allocation_and_binding_entry": native_source(model_runner.init_kv_cache),
        "model_state_factory": native_source(model_runner.init_model_state),
    }
    # Keep every actual dependency alive through inspection and group teardown.
    return model_state, input_buffers, block_tables, kv_config, caches


def run_native(args, report):
    # Dedicated CLI process only: discard inherited plugin/feature selection.
    for name in tuple(os.environ):
        if name.startswith(("AFD_", "VLLM_", "MOONCAKE_", "ENGRAM_")):
            del os.environ[name]
    os.environ.update(
        {
            "VLLM_PLUGINS": NATIVE_PLUGINS,
            "VLLM_USE_V2_MODEL_RUNNER": "1",
            "VLLM_WORKER_MULTIPROC_METHOD": "spawn",
            "VLLM_ASCEND_ENABLE_FLASHCOMM1": "0",
        }
    )
    import torch
    import torch_npu  # noqa: F401
    from vllm.platforms import current_platform

    current_platform.pre_register_and_update()
    from vllm.plugins import load_general_plugins
    from vllm_ascend.utils import (
        adapt_patch,
        enable_custom_op,
        register_ascend_customop,
        set_potential_max_tokens,
    )

    load_general_plugins()
    adapt_patch()
    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    report.update(runtime_imported=True, npu_queried=True)
    report["native_custom_ops_enabled"] = enable_custom_op()
    assert report["native_custom_ops_enabled"]
    from dsv41_dspark_projection_model_probe import native_projection_world
    from vllm.config import set_current_vllm_config
    from vllm.model_executor.model_loader.dummy_loader import DummyModelLoader
    from vllm.model_executor.model_loader.utils import process_weights_after_loading
    from vllm.utils.torch_utils import set_default_torch_dtype
    from vllm.v1.worker.workspace import init_workspace_manager
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.worker.v2.spec_decode.dspark.speculator import (
        AscendDSparkSpeculator,
    )
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    config = create_config(str(args.model), args.output_dir)
    report["configuration"] = record_config(config)
    init_ascend_config(config)
    set_potential_max_tokens(config)
    init_workspace_manager(device, num_ubatches=1)
    report["native_sources"] = {
        "speculator": native_source(AscendDSparkSpeculator),
        "load_model": native_source(AscendDSparkSpeculator.load_model),
        "load_draft_model": native_source(AscendDSparkSpeculator.load_draft_model),
        "set_attn": native_source(AscendDSparkSpeculator.set_attn),
        "dummy_loader": native_source(DummyModelLoader),
        "workspace_initializer": native_source(init_workspace_manager),
        "postprocess": native_source(process_weights_after_loading),
        "config_class": native_source(type(config.speculative_config)),
        "speculative_normalizer": native_source(
            type(config.speculative_config).__post_init__
        ),
    }
    write_report(args.output_dir, report)
    with (
        native_projection_world(config, device, args.output_dir, report),
        set_current_vllm_config(config),
        torch.device(device),
        set_default_torch_dtype(torch.bfloat16),
        torch.inference_mode(),
        torch_cuda_wrapper(),
    ):
        torch.manual_seed(SEED)
        register_ascend_customop(config)
        target = create_target_interface(config)
        speculator = AscendDSparkSpeculator(config, device)
        report["speculator_constructed"] = True
        write_report(args.output_dir, report)
        speculator.update_stream = torch.npu.Stream(device=device)
        speculator.load_model(target)
        report["draft_loaded"] = True
        report["draft_model_class"] = (
            type(speculator.model).__module__
            + "."
            + type(speculator.model).__qualname__
        )
        report["draft_module_classes"] = {
            name: type(module).__module__ + "." + type(module).__qualname__
            for name, module in speculator.model.named_modules()
        }
        report["draft_sources"] = {
            type(module).__module__: native_source(type(module))
            for module in speculator.model.modules()
        }
        parameters = {}
        for name, parameter in speculator.model.named_parameters():
            host = parameter.detach().cpu().contiguous()
            assert bool(torch.isfinite(host).all())
            parameters[name] = {
                "shape": list(host.shape),
                "dtype": str(host.dtype),
                "sha256": sha256(host.view(torch.uint8).numpy().tobytes()),
                "bytes": host.numel() * host.element_size(),
            }
        report["draft_parameters"] = parameters
        report["draft_parameter_bytes"] = sum(p["bytes"] for p in parameters.values())
        report["draft_attention_layer_names"] = sorted(
            speculator.draft_attn_layer_names
        )
        report["target_aux_layers"] = list(target.model.aux_hidden_state_layers)
        assert len(speculator.model.model.layers) == DRAFT_LAYERS
        write_report(args.output_dir, report)
        dependencies = bind_native_attention(config, target, speculator, device, report)
        assert dependencies[0] is speculator.model_state
        report["native_speculator_load_and_bind_accepted"] = True
    report["success"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.device < 0:
        parser.error("--device must be nonnegative")
    args.output_dir = args.output_dir.resolve()
    config_path = args.model / "config.json"
    if args.output_dir == args.model.resolve():
        parser.error("output directory must differ from the model directory")
    report = {
        "schema_version": 1,
        "probe_sha256": sha256(Path(__file__).read_bytes()),
        "mode": "native-load-bind" if args.run else "metadata-only",
        "success": False,
        "runtime_imported": False,
        "npu_queried": False,
        "speculator_constructed": False,
        "draft_loaded": False,
        "native_speculator_load_and_bind_accepted": False,
        "native_proposal_executed": False,
        "native_target_execution": False,
        "native_draft_execution": False,
        "target_full_constructor": False,
        "checkpoint_weights_loaded": False,
        "pd_ready_or_lease": False,
        "full_worker_or_serving": False,
        "engram_enabled": False,
        "limits": [
            "Controlled target embedding/head/aux/cache interface; no target decoder.",
            "Complete native dummy-loaded draft; no checkpoint-weight equivalence.",
            "Native constructors and KV binding only; no proposal or inference.",
            "World-size-one native HCCL group cleanup is not serving-owner recovery.",
        ],
    }
    exit_code = 1
    try:
        raw = config_path.read_bytes()
        json.loads(raw)
        report["checkpoint_config"] = {"path": str(config_path), "sha256": sha256(raw)}
        if args.run:
            run_native(args, report)
        else:
            report["success"] = True
        exit_code = 0
    except BaseException as error:
        report["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }
        traceback.print_exc()
    finally:
        if report["runtime_imported"]:
            try:
                report["loaded_runtime_libraries"] = loaded_runtime_libraries()
            except OSError as error:
                report["library_identity_error"] = str(error)
        write_report(args.output_dir, report)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
