# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native eager U2 FFN daemon assembly for the DSpark/PD successor.

Only the isolated worker imports runtime packages. The caller owns distributed
setup and failure supervision. This uses real eager bootstrap/tickets and the
native worker daemon, with controlled FFN arithmetic and constructor-free
runner/worker carriers. It does not construct a GraphService or capture graphs.
"""

from __future__ import annotations

import argparse
import json
import logging
import threading
import time
from dataclasses import asdict

TARGET_QUERY_LEN = 3
SUPPORTED_UBATCHES = 2
SERVICE_POLL_SECONDS = 0.1
DIAGNOSTIC_LOGGER = "afd_plugin.connectors.npu.hccl_diagnostics"
DIAGNOSTIC_FORMAT = "AFD HCCL stage diagnostic: %s"


def run_native_dspark_eager_ffn(
    config, device, report, deadline, *, eager_stream_overlap=False
):
    """Serve only explicitly requested native eager U2; never silently serialize."""
    if eager_stream_overlap is not True:
        raise ValueError("native eager F2 requires explicit eager stream overlap")

    import torch
    from hccl_native_attention_pd_dspark_eager_probe import eager_session_storage
    from hccl_native_attention_pd_dspark_probe import ROUTER_SCALE
    from vllm.config import CUDAGraphMode
    from vllm.forward_context import get_forward_context
    from vllm_ascend.ascend_forward_context import set_mc2_mask, set_mc2_tokens_capacity

    from afd_plugin.compat.npu.runtime_config import (
        get_npu_ffn_config,
        resolve_deepseek_v41_target_shape,
    )
    from afd_plugin.compat.npu.stream import use_npu_current_stream
    from afd_plugin.compat.patches.npu.ascend_config import init_ascend_config
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import (
        HcclStagedAFDConnector,
        create_npu_runtime_connector,
    )
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner
    from afd_plugin.v1.worker.npu.ffn_worker import AFDNPUFFNWorker

    assert config.model_config.enforce_eager is True
    assert config.compilation_config.cudagraph_mode == CUDAGraphMode.NONE
    assert config.parallel_config.use_ubatching is True
    assert type(config.parallel_config.num_ubatches) is int
    assert config.parallel_config.num_ubatches == SUPPORTED_UBATCHES
    original_afd = parse_afd_config(config)
    assert (
        original_afd.connector_extra_config.get("graph_exchange_order", "stage_serial")
        == "stage_serial"
    )
    shape = resolve_deepseek_v41_target_shape(config)
    assert shape.target_query_len == TARGET_QUERY_LEN
    assert config.speculative_config is not None
    isolated = get_npu_ffn_config(config)
    assert isolated is not config
    assert isolated.speculative_config is isolated.kv_transfer_config is None
    assert isolated.engram_config is None
    init_ascend_config(isolated)
    settings = HcclOverlapSettings(
        eager_u2_stream_overlap=True,
        graph_u2_compute_overlap=False,
        graph_u2_hybrid_dag=False,
        graph_u2_attention_three_stream=False,
        graph_u2_ffn_recv_stream=False,
        graph_u2_ffn_cross_layer=False,
        stage_diagnostics=True,
        ffn_compute_sync_diagnostics=False,
    )
    connector = create_npu_runtime_connector(
        0,
        device.index,
        isolated,
        parse_afd_config(isolated),
        target_shape=shape,
        overlap_settings=settings,
    )
    assert type(connector) is HcclStagedAFDConnector
    transport, caps = connector.transport, connector.transport.capabilities
    assert caps.graph_execution_version == 0 and caps.eager_pipeline_version == 1
    assert caps.target_query_len == 1 and caps.max_stages == SUPPORTED_UBATCHES
    assert caps.graph_exchange_order == "stage_serial"
    hidden_size, vocab_size = caps.hidden_size, caps.vocab_size
    layers, capacity = caps.layer_indices, caps.max_tokens
    configured_stages = SUPPORTED_UBATCHES
    assert layers == tuple(
        range(isolated.model_config.hf_text_config.num_hidden_layers)
    )
    assert hidden_size == isolated.model_config.hf_text_config.hidden_size
    management_thread = threading.get_ident()
    calls, transactions, lifecycle, pending_plans = [], [], [], {}
    detail = report["native_ffn"] = {
        "target_graph": False,
        "eager_stream_overlap_requested": True,
        "original_target_shape": asdict(shape),
        "target_shape_resolved_before_isolation": True,
        "isolated_speculative_config": None,
        "isolated_pd_config": None,
        "isolated_engram_config": None,
        "full_ffn_constructor_executed": False,
        "worker_constructor_executed": False,
        "native_worker_shutdown_executed": False,
        "native_moe_executed": False,
        "checkpoint_weights_loaded": False,
        "factory_service_and_worker_daemon_executed": False,
        "graph_service_constructed": False,
        "native_daemon_retired": False,
        "stop_acknowledged": False,
        "hidden_size": hidden_size,
        "vocab_size": vocab_size,
        "layer_indices": list(layers),
        "capacity": capacity,
        "configured_stage_count": configured_stages,
        "router_scale": ROUTER_SCALE,
        "configured_settings": settings.effective_settings(),
        "management_thread_id": management_thread,
        "management_native_thread_id": threading.get_native_id(),
        "python_model_calls": calls,
        "transactions": transactions,
        "steps": [],
        "stage_steps": [],
        "captured_entries": [],
        "host_records": [],
        "lifecycle": lifecycle,
        "eager_streams": {},
        "observer_copy_overhead_included": True,
        "physical_stream_attribution_accepted": False,
        "overlap_measured": False,
        "performance_accepted": False,
    }

    class ControlledFFN(torch.nn.Module):
        def __init__(self):
            super().__init__()
            for name, dtype, dimensions in (
                (
                    "observed_hidden",
                    torch.bfloat16,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
                (
                    "observed_router",
                    torch.float32,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
                (
                    "observed_ids",
                    torch.int32,
                    (len(layers), configured_stages, capacity),
                ),
                (
                    "observed_output",
                    torch.bfloat16,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
            ):
                self.register_buffer(
                    name, torch.empty(dimensions, dtype=dtype, device=device)
                )

        def get_experts_layer_indices(self):
            return layers

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel,
        ):
            # The real eager ticket chooses the consumer stream. Only device
            # math/copies and host metadata are observed here; no readback/fence.
            plan = transport.plan
            assert plan.graph_execution is None
            pending_plans.setdefault(plan.transaction_id, plan)
            context = get_forward_context()
            metadata = context.additional_kwargs["afd_metadata"]
            assert 1 <= len(plan.stages) <= configured_stages
            stage_index = metadata.stage_idx
            assert 0 <= stage_index < len(plan.stages)
            stage = plan.stages[stage_index]
            rows = stage.attention_padded_tokens[0]
            valid = stage.attention_valid_tokens[0]
            assert not already_sequence_parallel
            assert context.additional_kwargs["model_instance"] is self
            assert context.input_ids is input_ids and metadata.connector is connector
            assert metadata.transaction_id == plan.transaction_id
            assert metadata.num_stages == len(plan.stages)
            assert metadata.tokens_lens == [rows]
            assert metadata.tokens_unpadded_lens == [valid]
            assert context.cudagraph_runtime_mode == CUDAGraphMode.NONE
            assert hidden_states.dtype == torch.bfloat16
            assert hidden_states_fp32.dtype == torch.float32
            assert input_ids.dtype == torch.int32
            assert (
                hidden_states.shape == hidden_states_fp32.shape == (rows, hidden_size)
            )
            assert input_ids.shape == (rows,) and 0 < rows <= capacity
            assert threading.get_ident() != management_thread
            assert torch.is_inference_mode_enabled()
            capturing = bool(torch.npu.is_current_stream_capturing())
            assert not capturing
            calls.append(
                {
                    "transaction_id": plan.transaction_id,
                    "phase": "eager",
                    "layer": layer_idx,
                    "stage": metadata.stage_idx,
                    "rows": rows,
                    "valid_rows": valid,
                    "capturing": capturing,
                    "thread_id": threading.get_ident(),
                    "native_thread_id": threading.get_native_id(),
                    "input_address": hidden_states.data_ptr(),
                    "router_address": hidden_states_fp32.data_ptr(),
                    "ids_address": input_ids.data_ptr(),
                }
            )
            self.observed_hidden[layer_idx, stage_index, :rows].copy_(hidden_states)
            self.observed_router[layer_idx, stage_index, :rows].copy_(
                hidden_states_fp32
            )
            self.observed_ids[layer_idx, stage_index, :rows].copy_(input_ids)
            output = (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()
            self.observed_output[layer_idx, stage_index, :rows].copy_(output)
            return output

    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = isolated, isolated.model_config
    runner.connector, runner.device, runner.target_shape = connector, device, shape
    runner.model, runner.prof = ControlledFFN(), None
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = runner.hccl_v41_eager_bootstrap = None
    detail["observer_buffers"] = {
        name: {
            "address": tensor.data_ptr(),
            "shape": list(tensor.shape),
            "dtype": str(tensor.dtype),
            "bytes": tensor.numel() * tensor.element_size(),
        }
        for name, tensor in runner.model.named_buffers()
    }
    set_mc2_tokens_capacity(
        isolated, isolated.scheduler_config.max_num_seqs, shape.target_query_len
    )
    set_mc2_mask(isolated, device)
    # Publish management-created observation storage before the daemon uses it.
    # This startup fence is outside every serving parent and matches Graph F2.
    torch.npu.synchronize(device)
    detail["startup_observer_storage_published"] = True
    worker = AFDNPUFFNWorker.__new__(AFDNPUFFNWorker)
    worker.vllm_config, worker.model_runner, worker.device = isolated, runner, device
    worker.local_rank, worker.rank, worker.profiler_config = device.index, 0, None
    worker.target_shape = shape
    worker._ffn_thread = worker._ffn_shutdown_event = worker._ffn_loop_error = None
    worker._hccl_stop_received = worker._hccl_configuration_logged = False
    worker._hccl_v41_transport = None
    worker._cpu_binding_attempted = False
    worker.bind_hccl_v41_transport(transport)
    detail["binding_validation_executed"] = True
    actual_step = runner.execute_hccl_v41_step

    def observed_step(accepted_transport):
        returned = actual_step(accepted_transport)
        assert accepted_transport is transport
        assert transport.plan is transport.eager_pipeline is None
        if not returned:
            return returned
        assert len(pending_plans) == 1
        transaction_id, plan = pending_plans.popitem()
        observation = {
            "transaction_id": transaction_id,
            "phase": "eager",
            "mode": plan.mode,
            "num_stages": len(plan.stages),
            "valid_tokens_by_stage": [
                stage.attention_valid_tokens[0] for stage in plan.stages
            ],
            "padded_tokens_by_stage": [
                stage.attention_padded_tokens[0] for stage in plan.stages
            ],
            "target_query_len": shape.target_query_len,
            "arithmetic_executed": True,
            "python_body_executed": True,
            "layer_observations": [],
            "parent_retired_after_real_execute": True,
        }
        # The native step restores the daemon TLS stream on return. Read back
        # on its actual parent, which already joined the consumer copy events.
        with use_npu_current_stream(runner.hccl_v41_eager_session.parent_stream):
            for layer in plan.layer_indices:
                stages = []
                for stage_index, stage in enumerate(plan.stages):
                    rows = stage.attention_padded_tokens[0]
                    assert rows > 0
                    stage_row = {
                        "transaction_id": transaction_id,
                        "phase": "eager",
                        "layer": layer,
                        "stage": stage_index,
                        "rows": rows,
                        "valid_rows": stage.attention_valid_tokens[0],
                        "input_ids": runner.model.observed_ids[
                            layer, stage_index, :rows
                        ]
                        .cpu()
                        .tolist(),
                        "hidden": runner.model.observed_hidden[
                            layer, stage_index, :rows
                        ]
                        .float()
                        .cpu()
                        .tolist(),
                        "router_fp32": runner.model.observed_router[
                            layer, stage_index, :rows
                        ]
                        .cpu()
                        .tolist(),
                        "output": runner.model.observed_output[
                            layer, stage_index, :rows
                        ]
                        .float()
                        .cpu()
                        .tolist(),
                    }
                    stages.append(stage_row)
                    detail["stage_steps"].append(stage_row)
                row = {
                    "transaction_id": transaction_id,
                    "phase": "eager",
                    "layer": layer,
                    "rows": sum(item["rows"] for item in stages),
                    "stage_observations": stages,
                }
                for name in ("input_ids", "hidden", "router_fp32", "output"):
                    row[name] = [value for stage in stages for value in stage[name]]
                observation["layer_observations"].append(row)
                detail["steps"].append(row)
        transactions.append(observation)
        return returned

    class DiagnosticCapture(logging.Handler):
        def emit(self, record):
            if record.msg == DIAGNOSTIC_FORMAT:
                assert isinstance(record.args, dict)
                detail["host_records"].append(dict(record.args))

    logger = logging.getLogger(DIAGNOSTIC_LOGGER)
    handler = DiagnosticCapture()
    logger.addHandler(handler)
    runner.execute_hccl_v41_step = observed_step
    try:
        worker.start_ffn_server_loop()
        session = runner.hccl_v41_eager_session
        assert session is not None and session.initialized
        assert session.settings == settings == connector.overlap_settings
        assert runner.hccl_v41_graph_service is None
        assert runner.hccl_v41_eager_bootstrap.session is session
        storage = eager_session_storage(session)
        detail["eager_streams"]["storage_before"] = storage
        detail["eager_streams"]["host_records"] = detail["host_records"]
        assert transport.initialized
        detail["factory_service_and_worker_daemon_executed"] = True
        lifecycle.append("factory-eager-bootstrap-bound-and-daemon-started")
        while worker.poll_hccl_ffn_service():
            if time.monotonic() >= deadline:
                raise TimeoutError("live DSpark eager F2 daemon exceeded deadline")
            time.sleep(SERVICE_POLL_SECONDS)
        assert worker._hccl_stop_received
        detail["eager_streams"]["storage_after"] = eager_session_storage(session)
        assert detail["eager_streams"]["storage_after"] == storage
        lifecycle.append("peer-stop-acknowledged")
        worker.stop_ffn_server_loop()
        assert worker.poll_hccl_ffn_service() is False
        assert transport.closed and not transport.terminal
        assert not pending_plans
        lifecycle.append("daemon-joined-and-transport-closed")
        detail["stop_acknowledged"] = True
        detail["native_daemon_retired"] = True
        detail["completed_parent_count"] = len(transactions)
    finally:
        runner.execute_hccl_v41_step = actual_step
        logger.removeHandler(handler)
        detail["transport_closed"] = transport.closed
        detail["transport_terminal"] = transport.terminal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    print(
        json.dumps(
            {
                "runtime_imported": False,
                "run": False,
                "entrypoint": (
                    "run_native_dspark_eager_ffn(config, device, report, deadline, "
                    "eager_stream_overlap=True)"
                ),
                "device_validation_accepted": False,
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
