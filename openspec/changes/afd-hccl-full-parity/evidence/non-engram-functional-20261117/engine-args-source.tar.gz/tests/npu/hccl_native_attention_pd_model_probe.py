# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Real eager D execute/sample after native PD allocation and page transfer.

Device-only helpers retain native request, metadata, sampling and F daemon
ownership. Attention/HC and FFN arithmetic are controlled; no checkpoint model,
SparseFA, DSpark, Graph or performance acceptance follows from this component.
"""

from __future__ import annotations

import hashlib
import threading
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hccl_native_attention_pd_probe import NativePdStorage
    from hccl_native_attention_pd_scheduler_probe import NativePdSchedulerHandoff
    from vllm.config import VllmConfig

COMPONENT_CAPACITY = 32
COMPONENT_VOCAB_SIZE = 4096
COMPONENT_MAX_REQUESTS = 8
COMPONENT_MAX_MODEL_LEN = 64
GROUP_TIMEOUT_SECONDS = 45
POLL_SECONDS = 0.05
FINITE_BF16_BASE = 0x3F00
FINITE_BF16_FRACTION_VALUES = 128
SOURCE_BLOCK_MULTIPLIER = 17
SOURCE_POOL_MULTIPLIER = 31


def model_source_page_bytes(pool_index: int, size: int, *, block_stride: int) -> bytes:
    """Positive finite BF16 source bytes, including native alias/padding planes."""
    assert size % block_stride == 0 and block_stride % 2 == 0
    words_per_block = block_stride // 2
    return b"".join(
        (
            FINITE_BF16_BASE
            + (
                index % words_per_block
                + SOURCE_BLOCK_MULTIPLIER * (index // words_per_block)
                + SOURCE_POOL_MULTIPLIER * pool_index
            )
            % FINITE_BF16_FRACTION_VALUES
        ).to_bytes(2, "little")
        for index in range(size // 2)
    )


def configure_pd_model_component(config: VllmConfig, *, role: str, port: int):
    """Declare the small eager/Q1/U1 AFD role before binding either runtime."""
    from hccl_native_attention_probe import configure_native_attention

    assert role in ("attention", "ffn")
    assert config.model_config.enforce_eager
    assert config.compilation_config.cudagraph_mode.name == "NONE"
    assert config.speculative_config is config.engram_config is None
    assert not config.parallel_config.use_ubatching
    config.model_config.hf_text_config.vocab_size = COMPONENT_VOCAB_SIZE
    config.scheduler_config.max_num_batched_tokens = COMPONENT_CAPACITY
    configure_native_attention(config)
    # The native cache planner uses the original controlled PD window (128).
    config.model_config.hf_text_config.sliding_window = config.cache_config.block_size
    config.additional_config = {
        "afd": {
            "connector": "P2pHcclAFDConnector",
            "role": role,
            "num_attention_ranks": 1,
            "num_ffn_ranks": 1,
            "port": port,
            "afd_process_group_timeout_s": GROUP_TIMEOUT_SECONDS,
            "connector_extra_config": {"max_tokens": COMPONENT_CAPACITY},
        }
    }


def observe_legacy_control(connector, report):
    """Record the actual codec frames after real send/receive, without injection."""
    from afd_plugin.connectors.npu.hccl_protocol import encode_hccl_control_message

    transport = connector._transport
    actual_send, actual_recv = transport._send_control, transport._recv_control
    records = []
    report["legacy_hccl_control"] = records

    def record(direction, message):
        raw = encode_hccl_control_message(message)
        records.append(
            {
                "direction": direction,
                "codec_hex": raw.hex(),
                "sha256": hashlib.sha256(raw).hexdigest(),
                "native_thread_id": threading.get_native_id(),
            }
        )

    def send(message):
        actual_send(message)
        record("send", message)

    def receive():
        message = actual_recv()
        record("receive", message)
        return message

    transport._send_control, transport._recv_control = send, receive


def create_pd_model_connector(
    config, device, *, production_u1=False, target_graph=False, report=None
):
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import (
        HcclStagedAFDConnector,
        create_npu_runtime_connector,
    )
    from afd_plugin.connectors.npu.p2p_hccl import P2pHcclAFDConnector

    if production_u1 or target_graph:
        settings = (
            HcclOverlapSettings(
                eager_u2_stream_overlap=False,
                graph_u2_compute_overlap=False,
                graph_u2_hybrid_dag=False,
                graph_u2_attention_three_stream=False,
                graph_u2_ffn_recv_stream=False,
                graph_u2_ffn_cross_layer=False,
            )
            if target_graph
            else HcclOverlapSettings(eager_u2_stream_overlap=False)
        )
        connector = create_npu_runtime_connector(
            0,
            device.index,
            config,
            parse_afd_config(config),
            overlap_settings=settings,
        )
        assert report is not None
        if target_graph:
            from hccl_native_attention_pd_graph_lifecycle_probe import (
                observe_pd_graph_control,
            )

            assert type(connector) is HcclStagedAFDConnector
            observe_pd_graph_control(connector, report)
        else:
            assert type(connector) is P2pHcclAFDConnector
            observe_legacy_control(connector, report)
        if config.additional_config["afd"]["role"] == "attention":
            connector.init_afd_connector()
            report["afd_connector_configuration"] = connector.configuration_record()
        return connector

    # Normal eager/U1 selects the legacy adapter. This component explicitly
    # binds the public counts-enabled adapter, whose validation admits logical
    # U1; it does not change production selection or claim serving admission.
    connector = HcclStagedAFDConnector(
        0,
        device.index,
        config,
        parse_afd_config(config),
        0,
        overlap_settings=HcclOverlapSettings(eager_u2_stream_overlap=False),
    )
    if config.additional_config["afd"]["role"] == "attention":
        connector.transport.initialize()
    assert connector.transport.negotiated_capabilities.graph_execution_version == 0
    assert connector.transport.negotiated_capabilities.target_query_len == 1
    return connector


def build_pd_attention_owner(
    config: VllmConfig,
    storage: NativePdStorage,
    active,
    connector,
    device,
    report,
    *,
    production_u1=False,
    graph=False,
    write_cache=False,
    native_producer=False,
    producer_aux=False,
):
    # Deferred imports keep the parent/dependency-only command CPU importable.
    import torch
    from hccl_native_attention_lifecycle_probe import prepare_native_attention_lifecycle
    from hccl_native_attention_probe import (
        HEAD_SIZE,
        MAX_MODEL_LEN,
        ROPE_BASE,
        build_native_attention_arithmetic_model,
    )
    from torch import nn
    from vllm.config import CUDAGraphMode
    from vllm.forward_context import get_forward_context
    from vllm.v1.worker.gpu.block_table import BlockTables
    from vllm.v1.worker.utils import AttentionGroup
    from vllm.v1.worker.workspace import init_workspace_manager
    from vllm_ascend.attention.dsa_v41 import (
        AscendDSAV41MetadataBuilder,
        DeepseekV41CacheBackend,
        DeepseekV41CacheLayer,
    )
    from vllm_ascend.models.deepseek_v41.engram.model_state import EngramModelState
    from vllm_ascend.models.deepseek_v41.model import DeepseekV41SharedAttentionState
    from vllm_ascend.ops.rope_dsv4 import ComplexExpRotaryEmbedding
    from vllm_ascend.utils import set_potential_max_tokens
    from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager
    from vllm_ascend.worker.v2.eplb import AscendEPLBController
    from vllm_ascend.worker.v2.input_batch import AscendInputBuffers
    from vllm_ascend.worker.v2.model_runner import NPUModelRunner
    from vllm_ascend.worker.v2.states import AscendRequestState
    from vllm_ascend.worker.v2.utils import prepare_v41_source_rope

    from afd_plugin.config import parse_afd_config
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )

    assert config is storage.vllm_config is active.vllm_config
    assert config.kv_transfer_config.kv_role == (
        "kv_producer" if native_producer else "kv_consumer"
    )
    if native_producer:
        assert connector is None and not graph and not production_u1
        assert write_cache and config.speculative_config is None
    assert not producer_aux or native_producer
    groups = []
    cache_layers = []
    for group_index, group in enumerate(storage.kv_cache_config.kv_cache_groups):
        attention_groups = []
        for name in group.layer_names:
            spec = group.kv_cache_spec.kv_cache_specs[name]
            layer = DeepseekV41CacheLayer(config, name, spec)
            layer.bind_kv_cache(storage.caches[name])
            cache_layers.append(layer)
            attention_group = AttentionGroup(
                backend=DeepseekV41CacheBackend,
                layer_names=[name],
                kv_cache_spec=spec,
                kv_cache_group_id=group_index,
            )
            # The public builder option excludes unavailable A3 SparseFA tiling.
            # Compressor metadata and source RoPE remain actual native code.
            attention_group.metadata_builders = [
                AscendDSAV41MetadataBuilder(
                    spec, [name], config, device, build_query_metadata=False
                )
            ]
            attention_group.metadata_builders[0].set_kernel_block_size(spec.block_size)
            attention_groups.append(attention_group)
        groups.append(attention_groups)
    shared = DeepseekV41SharedAttentionState(
        torch.full((COMPONENT_CAPACITY, 1), -1, dtype=torch.int32, device=device),
        torch.full((COMPONENT_CAPACITY, 1, 2), -1, dtype=torch.int32, device=device),
        None,
        None,
    )

    class ReceivedPageAttention(nn.Module):
        def __init__(self, index):
            super().__init__()
            self.layer_idx, self.shared_state = index, shared
            self.cache_name = f"model.layers.{index}.self_attn.swa_cache"
            self.cache = storage.caches[self.cache_name]
            assert isinstance(self.cache, torch.Tensor) and self.cache.ndim == 4
            with torch.device(device):
                self.rotary_emb = ComplexExpRotaryEmbedding(
                    config,
                    self.cache_name.removesuffix(".swa_cache") + ".attn",
                    HEAD_SIZE,
                    HEAD_SIZE,
                    MAX_MODEL_LEN,
                    ROPE_BASE,
                    1.0,
                    apply_yarn_scaling=False,
                )

        def forward(self, positions, hidden_states, scaling=None):
            metadata = get_forward_context().attn_metadata[self.cache_name]
            slots = metadata.slot_mapping
            assert metadata.cache_kind == "swa"
            assert slots.shape == (hidden_states.shape[0], 2)
            # Consume a computed prefix row, before the current query. A whole
            # transferred page also contains an uncomputed tail; that tail is
            # not evidence of Attention consuming a valid remote prefix.
            read_positions = (slots[:, 1] - 1).clamp_min(0)
            physical = (
                (slots[:, 0] * self.cache.shape[1] + read_positions).clamp_min(0).long()
            )
            values = self.cache.flatten(0, 2).index_select(0, physical)
            values = values.masked_fill((slots[:, 0] < 0).unsqueeze(1), 0)
            if graph:
                report["native_pd_graph"]["python_attention_calls"].append(
                    {
                        "layer": self.layer_idx,
                        "stage": get_forward_context().ubatch_idx,
                        "capturing": torch.npu.is_current_stream_capturing(),
                        "rows": hidden_states.shape[0],
                        "slot_mapping_address": slots.data_ptr(),
                    }
                )
            else:
                report["native_pd_producer" if native_producer else "native_pd_model"][
                    "attention_reads"
                ].append(
                    {
                        "layer": self.layer_idx,
                        "cache_name": self.cache_name,
                        "cache_address": self.cache.data_ptr(),
                        "slot_mapping": slots.cpu().tolist(),
                        "positions": positions.cpu().tolist(),
                        "kv_read_positions": read_positions.cpu().tolist(),
                        "received_values": values.float().cpu().tolist(),
                    }
                )
            if write_cache:
                # Capture keeps PAD slots unchanged, including the null page.
                # Actual query rows become the next target's computed SWA KV.
                flat = self.cache.flatten(0, 2)
                assert flat.data_ptr() == self.cache.data_ptr()
                destination = (
                    (slots[:, 0] * self.cache.shape[1] + slots[:, 1])
                    .clamp_min(0)
                    .long()
                )
                previous = flat.index_select(0, destination)
                updated = torch.where(
                    (slots[:, 0] > 0).unsqueeze(1), hidden_states, previous
                )
                flat.index_copy_(0, destination, updated)
            if self.layer_idx == 0:
                self.shared_state.topk_indices[: positions.shape[0], 0].copy_(positions)
            source_positions = self.shared_state.topk_indices[: positions.shape[0], 0]
            return (
                hidden_states.float() + values.float() + source_positions[:, None]
            ).bfloat16()

    model, embedding_cpu = build_native_attention_arithmetic_model(
        config, device, ReceivedPageAttention, remote_moe=production_u1
    )
    if producer_aux:
        from hccl_native_attention_pd_aux_probe import TARGET_AUX_LAYER_IDS

        # The native V4.1 API retains one-based IDs; forward matches layer_idx+1
        # and returns the entering HC residual's mean before each selected layer.
        model.set_aux_hidden_state_layers(TARGET_AUX_LAYER_IDS)
        assert (
            model.language_model.model.aux_hidden_state_layers == TARGET_AUX_LAYER_IDS
        )
    # Register native cache carriers on the model for inherited shutdown detach.
    model.pd_cache_layers = nn.ModuleList(cache_layers)
    owner_class = NPUModelRunner if native_producer else AFDNPUAttentionModelRunnerV2
    owner = owner_class.__new__(owner_class)
    owner.vllm_config, owner.model_config = config, config.model_config
    owner.parallel_config, owner.compilation_config = (
        config.parallel_config,
        config.compilation_config,
    )
    owner.device, owner.model, owner.connector = device, model, connector
    owner.max_num_reqs, owner.decode_query_len, owner.dp_size = (
        COMPONENT_MAX_REQUESTS,
        1,
        1,
    )
    owner.model_state = EngramModelState(config, model, None, device)
    owner.model_state.attn_metadata = None
    owner.cudagraph_manager = owner.ubatch_runner = None
    owner.hccl_v41_transport = (
        None if production_u1 or native_producer else connector.transport
    )
    owner.hccl_v41_graph_eager = owner.hccl_v41_graph_session = None
    owner.hccl_v41_graph_coordinator = owner.hccl_v41_graph_bootstrap = None
    owner.hccl_v41_diagnostics = owner.hccl_v41_eager_bootstrap = None
    owner.pcp_manager = owner.intermediate_tensors = None
    owner.lora_config = owner.speculator = owner.adaptive_verification = None
    owner.speculative_config = None
    owner.use_aux_hidden_state_outputs = producer_aux
    owner._finegrained_tp_requires_graph = owner.sync_spec_pp_cpu_counts = False
    owner.use_fia = False
    owner.eplb = AscendEPLBController(config.parallel_config, device)
    owner.kv_connector = active
    owner.input_buffers = AscendInputBuffers(
        COMPONENT_MAX_REQUESTS, COMPONENT_CAPACITY, device
    )
    owner.req_states = AscendRequestState(
        COMPONENT_MAX_REQUESTS,
        COMPONENT_MAX_MODEL_LEN,
        COMPONENT_CAPACITY,
        0,
        COMPONENT_VOCAB_SIZE,
        device,
    )
    owner.attn_groups, owner.kv_cache_config = groups, storage.kv_cache_config
    owner.kv_caches = list(storage.caches.values())
    owner.update_stream = torch.npu.Stream(device=device)
    # Native dispatch requires a real manager even when its mode is NONE.
    # No capture/replay is performed and no is_profile escape is used.
    if not graph:
        owner.cudagraph_manager = ModelAclGraphManager(
            config, device, CUDAGraphMode.NONE, 1, model_runner=owner
        )
    block_sizes = [
        group.kv_cache_spec.block_size
        for group in storage.kv_cache_config.kv_cache_groups
    ]
    owner.block_tables = BlockTables(
        block_sizes,
        COMPONENT_MAX_REQUESTS,
        COMPONENT_CAPACITY,
        [1] * len(block_sizes),
        device,
        block_sizes,
    )
    owner._afd_transaction_counter = 0
    if not native_producer:
        owner.afd_config = parse_afd_config(config, expected_role="attention")
    owner._afd_pending_metadata = owner._afd_hccl_execution = None
    owner._afd_suppress_metadata_send = owner._is_warmup = False
    owner._afd_is_graph_capturing = owner._afd_is_graph_replaying = False
    owner._afd_is_profile = False
    owner._afd_shutdown_prepared = owner._afd_staged_stop_completed = False
    init_workspace_manager(device, num_ubatches=2 if graph else 1)
    # The native constructor publishes this before a PD consumer's ordinary
    # should_skip_allreduce_across_dp_group decision; do not force that decision.
    set_potential_max_tokens(config)
    prepare_native_attention_lifecycle(owner, report, embedding_cpu=embedding_cpu)
    if native_producer:
        owner.kernel_block_sizes = block_sizes
        owner._init_kv_zero_meta()
    prepare_v41_source_rope(owner)
    return owner, embedding_cpu


def pd_owner_identities(owner):
    """Observe the actual owner components without replacing their state."""
    return {
        "owner_identity": id(owner),
        "model_state_identity": id(owner.model_state),
        "sampler_identity": id(owner.sampler),
        "model_identity": id(owner.model),
        "head_identity": id(owner.model.language_model.lm_head),
        "request_state_identity": id(owner.req_states),
        "input_buffers_identity": id(owner.input_buffers),
        "block_tables_identity": id(owner.block_tables),
        "active_kv_identity": id(owner.kv_connector),
    }


def record_pd_cancelled_target(owner, handoff, report):
    """Observe native cancellation before any target state was admitted."""
    assert handoff.first_target is None
    assert handoff.retirement_output_executed
    assert not owner.req_states.req_id_to_index
    assert owner.execute_model_state is None
    assert handoff.request.request_id not in handoff.scheduler.requests
    report["native_pd_model"] = {
        **pd_owner_identities(owner),
        "native_owner_reused": False,
        "native_request_state_admitted": False,
        "native_execute_model_executed": False,
        "native_sample_tokens_executed": False,
        "native_request_retired": True,
        "native_empty_execute_returned": True,
        "request_status_after_cancel": handoff.request.status.name,
        "request_index": None,
        "block_ids": [
            [destination for _, destination in group]
            for group in handoff.group_block_pairs
        ],
        "attention_reads": [],
        "full_model_accepted": False,
    }


def execute_pd_target(
    config: VllmConfig,
    storage: NativePdStorage,
    active,
    handoff: NativePdSchedulerHandoff,
    connector,
    device,
    report,
    *,
    production_u1=False,
    owner=None,
    cancel_after_sample=False,
):
    """Consume the unmodified real first target, sample, and retire the request."""
    import torch
    from hccl_native_attention_lifecycle_probe import GREEDY_TOKEN
    from hccl_native_attention_probe import LAYER_COUNT, ROUTER_DELTA, ROUTER_SCALE
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    detail = {
        "owner_constructor_executed": False,
        "checkpoint_weights_loaded": False,
        "native_sparse_fa_executed": False,
        "native_execute_model_executed": False,
        "native_sample_tokens_executed": False,
        "native_scheduler_output_replaced": False,
        "production_connector_factory_executed": production_u1,
        "explicit_staged_component_binding": not production_u1,
        "attention_reads": [],
        "full_model_accepted": False,
        "graph_pd_accepted": False,
        "performance_accepted": False,
    }
    report["native_pd_model"] = detail
    reused = owner is not None
    if owner is None:
        owner, embedding_cpu = build_pd_attention_owner(
            config,
            storage,
            active,
            connector,
            device,
            report,
            production_u1=production_u1,
        )
    else:
        assert owner.vllm_config is config and owner.kv_connector is active
        assert owner.connector is connector and owner.execute_model_state is None
        embedding_cpu = (
            torch.arange(COMPONENT_VOCAB_SIZE)[:, None].float()
            + torch.arange(config.model_config.hf_text_config.hidden_size)[
                None, :
            ].float()
            / config.model_config.hf_text_config.hidden_size
        ).bfloat16()
    detail["native_owner_reused"] = reused
    detail.update(pd_owner_identities(owner))
    step, request = handoff.first_target, handoff.request
    assert step is not None
    assert step.total_num_scheduled_tokens == 1
    admitted = step.scheduled_new_reqs[0]
    computed = admitted.num_computed_tokens
    ids = admitted.prompt_token_ids[computed:]
    assert len(ids) == 1
    assert owner.execute_model(step) is None
    detail["native_execute_model_executed"] = True
    state = owner.execute_model_state
    assert state is not None
    batch = state.input_batch
    torch.npu.synchronize(device)
    assert batch.input_ids.cpu().tolist() == ids
    assert batch.positions.cpu().tolist() == [computed]
    expected = embedding_cpu[ids].clone()
    for layer_index in range(LAYER_COUNT):
        name = f"model.layers.{layer_index}.self_attn.swa_cache"
        group_id = next(
            index
            for index, group in enumerate(storage.kv_cache_config.kv_cache_groups)
            if name in group.layer_names
        )
        destination = admitted.block_ids[group_id][0]
        assert computed > 0
        cache_row = storage.caches[name][destination, computed - 1, 0].cpu()
        assert torch.isfinite(cache_row).all() and (cache_row > 0).all()
        attended = (expected.float() + cache_row.float() + computed).bfloat16()
        residual = (expected.float() + attended.float()).bfloat16()
        router = residual.float() + ROUTER_DELTA
        remote = (
            residual.float()
            + (router - residual.float()) * ROUTER_SCALE
            + torch.tensor(ids)[:, None].float()
        ).bfloat16()
        expected = (residual.float() + remote.float()).bfloat16()
    actual = state.hidden_states.cpu()
    torch.testing.assert_close(actual, expected, rtol=0, atol=0)
    detail["input_ids"] = ids
    detail["positions"] = [computed]
    detail["block_ids"] = admitted.block_ids
    detail["hidden_states"] = actual.float().tolist()
    detail["hidden_sha256"] = hashlib.sha256(
        actual.contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    detail["expected_hidden_sha256"] = hashlib.sha256(
        expected.contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    result = owner.sample_tokens(None)
    assert isinstance(result, AsyncOutput)
    returned = result.get_output()
    assert isinstance(returned, ModelRunnerOutput)
    assert returned.req_ids == [request.request_id]
    assert returned.sampled_token_ids == [[GREEDY_TOKEN]]
    assert owner.execute_model_state is None
    detail["native_sample_tokens_executed"] = True
    detail["sampled_token_ids"] = returned.sampled_token_ids
    index = owner.req_states.req_id_to_index[request.request_id]
    detail["request_index"] = index
    total = int(owner.req_states.total_len.gpu[index].cpu())
    history = owner.req_states.all_token_ids.gpu[index, :total].cpu().tolist()
    assert history == admitted.prompt_token_ids + [GREEDY_TOKEN]
    detail["history"] = history
    detail["engine_output_client_ids"] = sorted(
        handoff.scheduler.update_from_output(step, returned)
    )
    detail["request_status_after_update"] = request.status.name
    if cancel_after_sample:
        from vllm.v1.request import RequestStatus

        assert not request.is_finished() and request.status == RequestStatus.RUNNING
        aborted = handoff.scheduler.finish_requests(
            request.request_id, RequestStatus.FINISHED_ABORTED
        )
        assert aborted == [request]
        detail["native_cancelled_request_ids"] = [item.request_id for item in aborted]
        detail["request_status_after_cancel"] = request.status.name
    assert request.is_finished()
    retirement = handoff.scheduler.schedule()
    assert retirement.total_num_scheduled_tokens == 0
    assert request.request_id in retirement.finished_req_ids
    empty = owner.execute_model(retirement)
    assert isinstance(empty, ModelRunnerOutput) and not empty.req_ids
    assert request.request_id not in owner.req_states.req_id_to_index
    assert owner.execute_model_state is None
    detail["native_request_retired"] = True
    detail["native_empty_execute_returned"] = True
    detail["passed"] = True
    report["native_attention_owner_executed"] = True
    return owner


def run_pd_ffn_service(
    config,
    device,
    connector,
    report,
    *,
    deadline,
    production_u1=False,
    target_graph=False,
):
    """Run the actual production F worker daemon and runner until A's STOP."""
    import torch
    from hccl_native_attention_probe import ROUTER_SCALE
    from vllm.forward_context import get_forward_context
    from vllm_ascend.ascend_forward_context import set_mc2_mask, set_mc2_tokens_capacity

    from afd_plugin.compat.npu.runtime_config import resolve_deepseek_v41_target_shape
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner
    from afd_plugin.v1.worker.npu.ffn_worker import AFDNPUFFNWorker

    transport = None if production_u1 else connector.transport
    detail = {
        "native_worker_constructor_executed": False,
        "native_runner_constructor_executed": False,
        "native_moe_executed": False,
        "steps": [],
    }
    report["native_pd_ffn"] = detail
    detail["production_connector_factory_executed"] = production_u1 or target_graph
    detail["explicit_staged_component_binding"] = not (production_u1 or target_graph)

    class ControlledFFN(torch.nn.Module):
        def get_experts_layer_indices(self):
            return (
                connector.target_layer_indices
                if production_u1
                else transport.negotiated_capabilities.layer_indices
            )

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel=False,
        ):
            context = get_forward_context()
            assert context.additional_kwargs["model_instance"] is self
            assert not already_sequence_parallel
            metadata = context.additional_kwargs["afd_metadata"]
            assert metadata.connector is connector
            plan = connector.active_forward_plan if production_u1 else transport.plan
            assert metadata.transaction_id == plan.transaction_id
            assert metadata.num_stages == (1 if production_u1 else len(plan.stages))
            assert 0 <= metadata.stage_idx < metadata.num_stages
            assert hidden_states.dtype == torch.bfloat16
            assert hidden_states_fp32.dtype == torch.float32
            assert input_ids.dtype == torch.int32
            if not target_graph:
                assert metadata.stage_idx == 0 and metadata.num_stages == 1
            assert threading.get_ident() != management_thread
            observation = {
                "parent": metadata.transaction_id,
                "layer": layer_idx,
                "stage": metadata.stage_idx,
                "phase": plan.graph_execution.phase if target_graph else "eager",
                "rows": hidden_states.shape[0],
                "hidden_dtype": str(hidden_states.dtype),
                "router_dtype": str(hidden_states_fp32.dtype),
                "ids_dtype": str(input_ids.dtype),
                "capturing": torch.npu.is_current_stream_capturing(),
            }
            if not target_graph or plan.graph_execution.phase == "eager":
                observation.update(
                    {
                        "input_ids": input_ids.cpu().tolist(),
                        "hidden": hidden_states.float().cpu().tolist(),
                        "router_fp32": hidden_states_fp32.cpu().tolist(),
                    }
                )
            detail["steps"].append(observation)
            return (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()

    management_thread = threading.get_ident()
    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = config, config.model_config
    runner.connector, runner.device = connector, device
    runner.target_shape = resolve_deepseek_v41_target_shape(config)
    runner.model, runner.prof = ControlledFFN(), None
    if target_graph:
        from vllm.platforms import current_platform

        runner.graph_pool = current_platform.get_global_graph_pool()
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = runner.hccl_v41_eager_bootstrap = None
    set_mc2_tokens_capacity(config, COMPONENT_MAX_REQUESTS, 1)
    set_mc2_mask(config, device)
    worker = AFDNPUFFNWorker.__new__(AFDNPUFFNWorker)
    worker.vllm_config, worker.model_runner, worker.device = config, runner, device
    worker.local_rank, worker.rank, worker.profiler_config = device.index, 0, None
    worker.target_shape = runner.target_shape
    worker._ffn_thread = worker._ffn_shutdown_event = worker._ffn_loop_error = None
    worker._hccl_stop_received = worker._hccl_configuration_logged = False
    worker._hccl_v41_transport = None
    worker._cpu_binding_attempted = False
    if not production_u1:
        worker.bind_hccl_v41_transport(transport)
    worker.start_ffn_server_loop()
    report["afd_connector_configuration"] = connector.configuration_record()
    while worker.poll_hccl_ffn_service():
        if time.monotonic() >= deadline:
            raise TimeoutError("native PD F daemon exceeded caller deadline")
        time.sleep(POLL_SECONDS)
    assert worker._hccl_stop_received
    worker.stop_ffn_server_loop()
    assert worker._ffn_thread is None
    assert not connector.is_initialized
    detail["peer_stop_acknowledged"] = True
    detail["native_daemon_retired"] = True
