# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Bounded eager component probe; no checkpoint, native MoE or overlap claim.

Every payload operation goes through the public matched-warm transport and its
owner-issued loans. The CPU supervisor imports no torch. Launch only after a
separate review and explicit device allocation; this file is also reviewable
with --help on a CPU host.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import threading
import time
import traceback
from datetime import timedelta
from functools import partial
from pathlib import Path

import hccl_eager_backend_probe as supervision
import hccl_staged_probe as helpers

PARENT_EXTENTS = (
    ((3, 5), (2, 5)),
    ((1, 4), (1, 2)),
    ((0, 3), (0, 1)),
    ((2, 0), (0, 0)),
    ((0, 0), (0, 0)),
    ((5, 2), (4, 0)),
)
FP32_DELTA = 1 / 1_024
FP32_DELTA_SCALE = 1_024
SUPERVISOR_POLL_SECONDS = 0.1


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tp-size", type=int, choices=(1, 2), default=1)
    parser.add_argument(
        "--devices", default="0,2", help="FFN ranks then Attention ranks"
    )
    parser.add_argument("--model", default=helpers.CHECKPOINT, help="config only")
    parser.add_argument(
        "--native-bootstrap",
        action="store_true",
        help="use the actual connector/settings/bootstrap over a tiny config; no model",
    )
    parser.add_argument(
        "--native-ffn-runner",
        action="store_true",
        help=(
            "exercise the real FFN eager runner on a separate thread; "
            "requires native bootstrap"
        ),
    )
    parser.add_argument(
        "--stage-diagnostics",
        action="store_true",
        help="record scalar actual-owner host milestones; no added device fences",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=helpers.TOTAL_TIMEOUT_SECONDS)
    parser.add_argument("--role", choices=("attention", "ffn"), help=argparse.SUPPRESS)
    parser.add_argument("--role-rank", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.native_ffn_runner and not args.native_bootstrap:
        parser.error("--native-ffn-runner requires --native-bootstrap")
    try:
        args.devices = tuple(map(int, args.devices.split(",")))
    except ValueError:
        parser.error("devices must be comma-separated NPU indices")
    if (
        len(args.devices) != args.tp_size * 2
        or len(set(args.devices)) != len(args.devices)
        or min(args.devices) < 0
    ):
        parser.error("provide exactly two distinct NPUs per native TP coordinate")
    if not 0 < args.timeout <= helpers.TOTAL_TIMEOUT_SECONDS:
        parser.error("timeout is outside the bounded supervisor limit")
    if args.role and (
        args.port is None
        or args.role_rank is None
        or not 0 <= args.role_rank < args.tp_size
    ):
        parser.error("worker invocation requires a valid role rank and port")
    return args


def payload(torch, parent_index, stage_index, padded, valid, previous=None):
    if previous is None:
        values = torch.arange(
            padded * helpers.HIDDEN_SIZE, dtype=torch.float32
        ).reshape(padded, helpers.HIDDEN_SIZE)
        hidden = (values / 64 + parent_index / 8 + stage_index / 4).bfloat16()
    else:
        hidden = previous.clone()
    fp32 = hidden.float() + FP32_DELTA
    ids = (
        torch.arange(padded, dtype=torch.int32)
        + 1
        + parent_index * 16
        + stage_index * 8
    )
    ids[valid:] = 0
    return hidden, fp32, ids


def arithmetic(hidden, fp32, ids, layer, stage):
    return (
        hidden.float() / 4
        + (fp32 - hidden.float()) * FP32_DELTA_SCALE
        + ids[:, None].float() / 16
        + layer / 8
        + stage / 16
    ).bfloat16()


def cpu_expected(torch, parent_index, layer_position, stage_index, padded, valid):
    previous = None
    for layer in helpers.LAYERS[:layer_position]:
        previous = arithmetic(
            *payload(torch, parent_index, stage_index, padded, valid, previous),
            layer,
            stage_index,
        )
    return payload(torch, parent_index, stage_index, padded, valid, previous)


def run_attention(torch, transport, owner, plan, parent_index, compute, report):
    from afd_plugin.compat.npu.stream import use_npu_current_stream

    previous = {}
    for position, layer in enumerate(plan.layer_indices):
        tickets, originals = {}, {}
        for stage in plan.stages:
            rows, valid = (
                stage.attention_padded_tokens[transport.role_rank],
                stage.attention_valid_tokens[transport.role_rank],
            )
            if not rows:
                continue
            with use_npu_current_stream(compute):
                if stage.stage_idx in previous:
                    hidden = previous[stage.stage_idx]
                    fp32 = hidden.float() + FP32_DELTA
                    ids = payload(torch, parent_index, stage.stage_idx, rows, valid)[
                        2
                    ].to(hidden.device)
                    values = hidden, fp32, ids
                else:
                    values = tuple(
                        value.to(owner.parent_stream.device)
                        for value in payload(
                            torch, parent_index, stage.stage_idx, rows, valid
                        )
                    )
            originals[stage.stage_idx] = values
            tickets[stage.stage_idx] = owner.post_attention(
                layer,
                stage.stage_idx,
                *values,
                producer_stream=compute,
                retain=tuple(previous.values()),
            )
        report["posting_frontiers"].append(
            {
                "parent": plan.transaction_id,
                "layer": layer,
                "occupied_stages_before_output_loans": list(owner.occupied_stages),
                "ticket_stages": list(tickets),
            }
        )
        if len(owner.occupied_stages) > len(plan.stages):
            raise AssertionError("owner exceeded its U-stage occupancy bound")
        for stage in plan.stages:
            if stage.stage_idx not in tickets:
                continue
            rows, valid = (
                stage.attention_padded_tokens[transport.role_rank],
                stage.attention_valid_tokens[transport.role_rank],
            )
            expected_inputs = cpu_expected(
                torch, parent_index, position, stage.stage_idx, rows, valid
            )
            with use_npu_current_stream(compute):
                for actual, expected in zip(
                    originals[stage.stage_idx], expected_inputs, strict=True
                ):
                    torch.testing.assert_close(actual.cpu(), expected, rtol=0, atol=0)
            with owner.attention_output(
                tickets[stage.stage_idx],
                consumer_stream=compute,
                retain=originals[stage.stage_idx],
            ) as output:
                # This clone is the actual delayed next-layer dependency. No
                # borrowed output escapes its loan for asynchronous later use.
                previous[stage.stage_idx] = output.clone()
            expected_output = arithmetic(*expected_inputs, layer, stage.stage_idx)
            with use_npu_current_stream(compute):
                torch.testing.assert_close(
                    previous[stage.stage_idx].cpu(), expected_output, rtol=0, atol=0
                )
            report["checked_steps"].append(
                {
                    "parent": plan.transaction_id,
                    "layer": layer,
                    "stage": stage.stage_idx,
                    "rows": rows,
                    "valid": valid,
                    "independent_fp32": True,
                    "raw_ids_exact": True,
                    "full_output_exact": True,
                }
            )


def run_ffn(torch, transport, owner, plan, parent_index, compute, report):
    for position, layer in enumerate(plan.layer_indices):
        for stage in plan.stages:
            rows = stage.attention_padded_tokens[transport.role_rank]
            valid = stage.attention_valid_tokens[transport.role_rank]
            if not rows:
                continue
            expected = cpu_expected(
                torch, parent_index, position, stage.stage_idx, rows, valid
            )
            ticket = owner.post_ffn_receive(layer, stage.stage_idx)
            with owner.ffn_inputs(ticket, consumer_stream=compute) as inputs:
                for actual, reference in zip(
                    (inputs.hidden_states, inputs.hidden_states_fp32, inputs.input_ids),
                    expected,
                    strict=True,
                ):
                    torch.testing.assert_close(actual.cpu(), reference, rtol=0, atol=0)
                output = arithmetic(
                    inputs.hidden_states,
                    inputs.hidden_states_fp32,
                    inputs.input_ids,
                    layer,
                    stage.stage_idx,
                )
            owner.post_ffn_output(ticket, output, producer_stream=compute)
            report["checked_steps"].append(
                {
                    "parent": plan.transaction_id,
                    "layer": layer,
                    "stage": stage.stage_idx,
                    "rows": rows,
                    "valid": valid,
                    "bf16_exact": True,
                    "original_fp32_exact": True,
                    "raw_ids_exact": True,
                }
            )


def run_serial_profile(torch, transport, report):
    """Exercise the serial pre-KV route after warmup, without allocating KV."""
    from afd_plugin.distributed.hccl_plan import HcclLocalForward

    plan = (
        transport.submit_forward(
            HcclLocalForward("profile", (1,), (2,)),
            transaction_id="bootstrap-profile" if transport.is_coordinator else None,
        )
        if transport.role == "attention"
        else transport.receive_forward()
    )
    assert plan is not None and plan.mode == "profile" and len(plan.stages) == 1
    for position, layer in enumerate(plan.layer_indices):
        expected = cpu_expected(torch, 0, position, 0, 2, 1)
        if transport.role == "attention":
            values = tuple(
                value.to(torch.device("npu", transport.local_device))
                for value in expected
            )
            transport.send_layer_inputs(layer, 0, *values)
            output = transport.receive_layer_output(layer, 0)
        else:
            inputs = transport.receive_layer(layer, 0)
            values = inputs.hidden_states, inputs.hidden_states_fp32, inputs.input_ids
            for value, reference in zip(values, expected, strict=True):
                torch.testing.assert_close(value.cpu(), reference, rtol=0, atol=0)
            output = arithmetic(*values, layer, 0)
            transport.send_layer_output(layer, 0, output)
        torch.testing.assert_close(
            output.cpu(), arithmetic(*expected, layer, 0), rtol=0, atol=0
        )
    transport.finish_forward()
    report["serial_pre_kv_profile"] = {
        "transaction_id": plan.transaction_id,
        "layer_indices": list(plan.layer_indices),
        "full_output_exact": True,
        "no_eager_pipeline": transport.eager_pipeline is None,
        "native_kv_allocator_executed": False,
    }


def prepare_native_ffn_runner(torch, config, connector, bootstrap, report):
    """Use actual binding/context/consumer APIs, excluding native construction."""
    # These dependencies stay inside the isolated device worker.
    from vllm.forward_context import get_forward_context
    from vllm.utils import torch_utils
    from vllm_ascend.ascend_forward_context import set_mc2_mask, set_mc2_tokens_capacity

    from afd_plugin.compat.npu.runtime_config import resolve_deepseek_v41_target_shape
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner

    transport, session = connector.transport, bootstrap.session
    layer_indices = transport.negotiated_capabilities.layer_indices
    parent_indices = {
        f"eager-owner-{index}": index for index in range(len(PARENT_EXTENTS))
    }

    class ControlledArithmetic(torch.nn.Module):
        def get_experts_layer_indices(self):
            return layer_indices

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel,
        ):
            plan = transport.plan
            context = get_forward_context()
            metadata = context.additional_kwargs["afd_metadata"]
            stage = plan.stages[metadata.stage_idx]
            rows = stage.attention_padded_tokens[transport.role_rank]
            valid = stage.attention_valid_tokens[transport.role_rank]
            if (
                context.additional_kwargs["model_instance"] is not self
                or metadata.connector is not connector
                or metadata.transaction_id != plan.transaction_id
                or metadata.num_stages != len(plan.stages)
                or metadata.tokens_lens != [rows]
                or metadata.tokens_unpadded_lens != [valid]
                or already_sequence_parallel
                or not torch.is_inference_mode_enabled()
                or threading.get_ident()
                == report["native_ffn_runner"]["management_thread_id"]
                or torch.npu.current_stream(session.parent_stream.device)
                != session.compute_stream
                or torch_utils.current_stream() != session.compute_stream
                or not torch.equal(context.input_ids, input_ids)
            ):
                raise AssertionError("actual FFN context or compute stream differs")
            expected = cpu_expected(
                torch,
                parent_indices[plan.transaction_id],
                plan.layer_indices.index(layer_idx),
                stage.stage_idx,
                rows,
                valid,
            )
            for value, reference in zip(
                (hidden_states, hidden_states_fp32, input_ids), expected, strict=True
            ):
                torch.testing.assert_close(value.cpu(), reference, rtol=0, atol=0)
            output = arithmetic(
                hidden_states, hidden_states_fp32, input_ids, layer_idx, stage.stage_idx
            )
            torch.testing.assert_close(
                output.cpu(),
                arithmetic(*expected, layer_idx, stage.stage_idx),
                rtol=0,
                atol=0,
            )
            report["checked_steps"].append(
                {
                    "parent": plan.transaction_id,
                    "layer": layer_idx,
                    "stage": stage.stage_idx,
                    "rows": rows,
                    "valid": valid,
                    "bf16_exact": True,
                    "original_fp32_exact": True,
                    "raw_ids_exact": True,
                    "full_output_exact": True,
                    "forward_context_exact": True,
                    "input_ids_context_exact": True,
                    "native_compute_stream_exact": True,
                    "tls_compute_stream_exact": True,
                    "serving_thread_id": threading.get_ident(),
                }
            )
            return output

    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = config, config.model_config
    runner.connector, runner.device = connector, session.parent_stream.device
    runner.target_shape = resolve_deepseek_v41_target_shape(config)
    runner.model = ControlledArithmetic()
    runner.prof = None
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = None
    runner.hccl_v41_eager_bootstrap = bootstrap
    set_mc2_tokens_capacity(config, config.scheduler_config.max_num_seqs, 1)
    set_mc2_mask(config, runner.device)
    if bootstrap.diagnostics is not None:
        runner.bind_hccl_v41_diagnostics(bootstrap.diagnostics)
    report["native_ffn_runner"] = {
        "management_thread_id": threading.get_ident(),
        "native_runner_constructor_executed": False,
        "native_worker_daemon_or_shutdown_executed": False,
        "native_mc2_capacity_and_mask_initialized": True,
        "controlled_arithmetic_model": True,
        "native_moe_exercised": False,
    }
    return runner


def run_native_ffn_thread(torch, args, runner, session, report):
    """Actual receive/execute/COMPLETE/STOP, with a foreign native/TLS ambient."""
    from vllm.utils import torch_utils

    from afd_plugin.compat.npu.stream import use_npu_current_stream

    transport = runner.connector.transport
    accepted, errors = [], []
    original_receive = transport.receive_forward
    details = report["native_ffn_runner"]
    details["ambient_restored_after_steps"] = []
    details["execute_step_results"] = []
    details["receive_parent_stream_checks"] = 0

    def observed_receive():
        # Observe the real method without accepting or finishing any protocol
        # operation here. In particular, empty parents retain their identity.
        if (
            torch.npu.current_stream(runner.device) != session.parent_stream
            or torch_utils.current_stream() != session.parent_stream
        ):
            raise AssertionError("runner receive did not select its warmed parent")
        details["receive_parent_stream_checks"] += 1
        plan = original_receive()
        index = len(accepted)
        if plan is None:
            if index != len(PARENT_EXTENTS) or not transport.terminal:
                raise AssertionError(
                    "actual runner stopped before completing all parents"
                )
            details["actual_stop_acknowledged"] = True
            return None
        if index >= len(PARENT_EXTENTS):
            raise AssertionError("actual runner accepted an extra parent")
        padded, valid = PARENT_EXTENTS[index]
        if (
            plan.transaction_id != f"eager-owner-{index}"
            or plan.mode != "target"
            or plan.layer_indices != transport.negotiated_capabilities.layer_indices
            or tuple(
                s.attention_padded_tokens[transport.role_rank] for s in plan.stages
            )
            != padded
            or tuple(s.attention_valid_tokens[transport.role_rank] for s in plan.stages)
            != valid
        ):
            raise AssertionError("actual runner accepted unexpected parent geometry")
        accepted.append(plan)
        return plan

    def serve():
        try:
            torch.npu.set_device(runner.device)
            foreign = torch.npu.Stream(device=runner.device)
            if any(
                foreign == stream
                for stream in (
                    session.parent_stream,
                    session.compute_stream,
                    session.send_stream,
                    session.receive_stream,
                )
            ):
                raise AssertionError(
                    "foreign ambient must differ from all session streams"
                )
            details["serving_thread_id"] = threading.get_ident()
            if details["serving_thread_id"] == details["management_thread_id"]:
                raise AssertionError("native FFN must execute on a separate thread")
            with use_npu_current_stream(foreign):
                for index in range(len(PARENT_EXTENTS) + 1):
                    expected_running = index < len(PARENT_EXTENTS)
                    result = runner.execute_hccl_v41_step(transport)
                    details["execute_step_results"].append(result)
                    if result is not expected_running:
                        raise AssertionError(
                            "actual runner returned an unexpected step result"
                        )
                    if (
                        torch.npu.current_stream(runner.device) != foreign
                        or torch_utils.current_stream() != foreign
                        or transport.plan is not None
                        or transport.eager_pipeline is not None
                    ):
                        raise AssertionError(
                            "actual runner did not restore/retire its parent"
                        )
                    details["ambient_restored_after_steps"].append(True)
                    if expected_running:
                        plan = accepted[index]
                        report["parents"].append(
                            {
                                "transaction_id": plan.transaction_id,
                                "padded": [
                                    s.attention_padded_tokens[transport.role_rank]
                                    for s in plan.stages
                                ],
                                "valid": [
                                    s.attention_valid_tokens[transport.role_rank]
                                    for s in plan.stages
                                ],
                                "finished": True,
                            }
                        )
        except BaseException as error:
            details["error"] = traceback.format_exc()
            errors.append(error)

    transport.receive_forward = observed_receive
    thread = threading.Thread(target=serve, name="afd-eager-native-ffn", daemon=True)
    thread.start()
    thread.join(timeout=args.timeout)
    if thread.is_alive():
        raise TimeoutError("native FFN thread exceeded the bounded probe lifetime")
    transport.receive_forward = original_receive
    if errors:
        raise errors[0]
    if torch.npu.current_stream(runner.device) != session.parent_stream:
        raise AssertionError("serving thread changed the management parent stream")
    expected_steps = [
        (f"eager-owner-{index}", layer, stage)
        for index, (padded, _) in enumerate(PARENT_EXTENTS)
        for layer in transport.negotiated_capabilities.layer_indices
        for stage, rows in enumerate(padded)
        if rows
    ]
    if [
        (step["parent"], step["layer"], step["stage"])
        for step in report["checked_steps"]
    ] != expected_steps:
        raise AssertionError("native FFN omitted or repeated a model context")
    if any(
        step["serving_thread_id"] != details["serving_thread_id"]
        for step in report["checked_steps"]
    ):
        raise AssertionError("native FFN compute changed its serving thread")
    if args.stage_diagnostics and any(
        sum(record["event"] == event for record in report["diagnostic_records"])
        != len(expected_steps)
        for event in ("compute_begin", "compute_returned")
    ):
        raise AssertionError("actual FFN diagnostics omitted or repeated compute")
    details["checked_model_context_count"] = len(expected_steps)
    details["actual_received_parent_count"] = len(accepted)
    details["management_parent_stream_preserved"] = True
    details["thread_joined"] = True


def verify_diagnostics(report):
    """Scalar-only validation after normal STOP and native TP preservation."""
    records = report["diagnostic_records"]
    parents = {parent["transaction_id"]: parent for parent in report["parents"]}
    actual = report["diagnostic_actual_streams"]
    if not records or any(
        type(value) not in (str, int, bool)
        for record in records
        for value in record.values()
    ):
        raise AssertionError("diagnostic records must contain scalar fields only")
    for record in records:
        if (
            record["transaction_id"] not in parents
            or record["role"] != report["role"]
            or record["role_rank"] != report["role_rank"]
            or record["world_rank"] != report["world_rank"]
            or record["phase"] != "eager"
            or record["num_stages"] != 2
            or record["actual.mode"] != "eager-streamed"
            or record["actual.ffn_compute_sync"] is not False
            or record["boundary"] != "host_enqueue"
            or any(record[key] != value for key, value in actual.items())
        ):
            raise AssertionError(
                "diagnostics differ from the actual accepted rank/streams"
            )
    required = {
        "send_post_begin",
        "send_post_returned",
        "recv_post_begin",
        "recv_post_returned",
        "loan_wait_begin",
        "loan_wait_returned",
        "stage_reuse_wait_begin",
        "stage_reuse_wait_returned",
    }
    for transaction, parent in parents.items():
        events = [r["event"] for r in records if r["transaction_id"] == transaction]
        if (
            events[0] != "configuration"
            or events[-1] != "parent_finish_returned"
            or events.count("configuration") != 1
            or events.count("parent_finish_begin") != 1
            or events.count("parent_finish_returned") != 1
        ):
            raise AssertionError(
                "each accepted parent needs configuration and COMPLETE milestones"
            )
        if any(parent["padded"]):
            if not required.issubset(events):
                raise AssertionError("active eager parent omitted an owner milestone")
        elif events != [
            "configuration",
            "parent_finish_begin",
            "parent_finish_returned",
        ]:
            raise AssertionError("empty parent unexpectedly posted or borrowed payload")
    report["diagnostic_validation"] = {
        "configuration_count": sum(r["event"] == "configuration" for r in records),
        "record_count": len(records),
        "all_rank_identity_exact": True,
        "all_u2_compute_sync_inactive": True,
        "actual_stream_aliases_exact": True,
        "empty_parent_configuration": True,
        "owner_milestones_present": True,
    }


def worker(args):
    # Runtime isolation: supervisor and --help do not import device packages.
    import torch
    import torch.distributed as dist
    import vllm_ascend.ops  # noqa: F401
    from vllm.config import set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )
    from vllm.platforms import current_platform
    from vllm.plugins import load_general_plugins
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.utils import adapt_patch

    from afd_plugin.compat.patches.npu.ascend_config import (
        init_ascend_config as init_afd_ascend_config,
    )
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import create_npu_runtime_connector
    from afd_plugin.connectors.npu.hccl_staged_transport import HcclStagedTransport
    from afd_plugin.distributed.hccl_plan import HcclLocalForward, HcclPlanCapabilities
    from afd_plugin.v1.worker.npu.hccl_v41_diagnostics import HcclV41DiagnosticBinding
    from afd_plugin.v1.worker.npu.hccl_v41_eager_bootstrap import HcclV41EagerBootstrap

    role_offset = args.tp_size if args.role == "attention" else 0
    device_index = args.devices[role_offset + args.role_rank]
    device = torch.device("npu", device_index)
    report = {
        "scope": "actual eager ticket/loan component; controlled arithmetic only",
        "role": args.role,
        "role_rank": args.role_rank,
        "device": str(device),
        "pid": os.getpid(),
        "success": False,
        "model_weights_loaded": False,
        "native_moe_exercised": False,
        "overlap_or_performance_claim": False,
        "checked_steps": [],
        "posting_frontiers": [],
        "parents": [],
    }
    if args.stage_diagnostics:
        report["diagnostic_records"] = []
    if args.native_ffn_runner:
        report["scope"] = (
            "actual threaded FFN eager runner/consumer with controlled arithmetic; "
            "no native model/KV constructor, worker lifecycle or MoE acceptance"
        )

    def native_check():
        value = torch.tensor([1.0], device=device)
        dist.all_reduce(value, group=get_tp_group().device_group)
        torch.testing.assert_close(
            value.cpu(), torch.tensor([float(args.tp_size)]), rtol=0, atol=0
        )
        return value.cpu().tolist()

    try:
        current_platform.pre_register_and_update()
        load_general_plugins()
        torch.npu.set_device(device_index)
        adapt_patch()
        config = helpers.build_config(args.tp_size, args.model)
        if args.native_bootstrap:
            # These are deliberately component dimensions, without building a
            # model or loading checkpoint tensors; the original config is not
            # evidence for checkpoint execution at this geometry.
            config.model_config.hf_text_config.hidden_size = helpers.HIDDEN_SIZE
            config.model_config.hf_text_config.vocab_size = helpers.VOCAB_SIZE
            config.model_config.hf_text_config.num_hidden_layers = 2
            config.parallel_config.rank = args.role_rank
            # Native read-only use_ubatching/num_ubatches derive from this flag.
            config.parallel_config.enable_dbo = True
            config.additional_config = {
                "afd": {
                    "connector": "P2pHcclAFDConnector",
                    "role": args.role,
                    "num_attention_ranks": args.tp_size,
                    "num_ffn_ranks": args.tp_size,
                    "port": args.port,
                    "afd_process_group_timeout_s": helpers.GROUP_TIMEOUT_SECONDS,
                    "connector_extra_config": {"max_tokens": helpers.CAPACITY},
                }
            }
        if args.native_bootstrap:
            # Normal AFD startup filters its namespace through this existing
            # pinned compatibility entry, preserving the native config owner.
            init_afd_ascend_config(config)
        else:
            init_ascend_config(config)
        with set_current_vllm_config(config):
            native_port = args.port + 1 + int(args.role == "attention")
            init_distributed_environment(
                world_size=args.tp_size,
                rank=args.role_rank,
                local_rank=device_index,
                distributed_init_method=f"tcp://127.0.0.1:{native_port}",
                backend="hccl",
                timeout=timedelta(seconds=helpers.GROUP_TIMEOUT_SECONDS),
            )
            initialize_model_parallel(
                tensor_model_parallel_size=args.tp_size, backend="hccl"
            )
            report["native_tp_before"] = native_check()
            bootstrap = None
            native_ffn_runner = None
            if args.native_bootstrap:
                settings = HcclOverlapSettings.from_environment(
                    {
                        "AFD_HCCL_EAGER_U2_STREAM_OVERLAP": "1",
                        "AFD_HCCL_STAGE_DIAGNOSTICS": str(int(args.stage_diagnostics)),
                        "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS": str(
                            int(args.stage_diagnostics)
                        ),
                    },
                    num_stages=2,
                )
                connector = create_npu_runtime_connector(
                    args.role_rank,
                    device_index,
                    config,
                    parse_afd_config(config),
                    overlap_settings=settings,
                )
                transport = connector.transport
            else:
                transport = HcclStagedTransport(
                    args.role,
                    args.role_rank,
                    HcclPlanCapabilities(
                        helpers.HIDDEN_SIZE,
                        helpers.VOCAB_SIZE,
                        helpers.CAPACITY,
                        helpers.LAYERS,
                        args.tp_size,
                        args.tp_size,
                        args.tp_size,
                        local_counts_version=1,
                    ),
                    init_method=f"tcp://127.0.0.1:{args.port}",
                    local_device=device_index,
                    timeout_seconds=helpers.GROUP_TIMEOUT_SECONDS,
                )
            transport.initialize()
            if args.native_bootstrap:
                bootstrap = HcclV41EagerBootstrap(
                    config,
                    transport,
                    overlap_settings=connector.overlap_settings,
                    synchronize=partial(torch.npu.synchronize, device),
                    diagnostic_sink=report["diagnostic_records"].append
                    if args.stage_diagnostics
                    else None,
                )
                bootstrap.prepare(torch.npu.current_stream(device))
                # Capture the real idle-live connector record before profile or
                # parent work. This is component configuration, not readiness.
                report["session_configuration_record"] = (
                    connector.configuration_record()
                )
                session = bootstrap.session
                assert session is not None and session.initialized
                parent, compute, send, receive = (
                    session.parent_stream,
                    session.compute_stream,
                    session.send_stream,
                    session.receive_stream,
                )
                run_serial_profile(torch, transport, report)
                bound_sessions = []
                if args.native_ffn_runner and args.role == "ffn":
                    native_ffn_runner = prepare_native_ffn_runner(
                        torch, config, connector, bootstrap, report
                    )
                bootstrap.begin_kv_init()
                bootstrap.complete_kv_init(
                    native_ffn_runner.bind_hccl_v41_eager_session
                    if native_ffn_runner is not None
                    else bound_sessions.append
                )
                if native_ffn_runner is not None:
                    assert native_ffn_runner.hccl_v41_eager_session is session
                else:
                    assert bound_sessions == [session]
                negotiated = transport.negotiated_capabilities
                report["bootstrap"] = {
                    "eager_pipeline_version": negotiated.eager_pipeline_version,
                    "same_session_after_controlled_kv_handoff": True,
                    "same_connector_settings": session.settings
                    is connector.overlap_settings,
                    "native_model_or_kv_constructor_executed": False,
                }
            else:
                parent, send, receive, compute = (
                    torch.npu.current_stream(device),
                    *(torch.npu.Stream(device=device) for _ in range(3)),
                )
                transport.warmup_eager_pipeline(parent_stream=parent)
            report["matched_stage_groups_warmed"] = transport.eager_pipeline_warmed
            binding = None
            if args.stage_diagnostics:
                report["world_rank"] = transport.world_rank
                report["diagnostic_actual_streams"] = {
                    "actual.compute_stream": "parent"
                    if compute == parent
                    else "compute",
                    "actual.send_stream": "parent" if send == parent else "send",
                    "actual.recv_stream": "parent" if receive == parent else "recv",
                    "actual.compute_send_alias": compute == send,
                    "actual.compute_recv_alias": compute == receive,
                    "actual.send_recv_alias": send == receive,
                }
                binding = (
                    bootstrap.diagnostics
                    if bootstrap is not None
                    else HcclV41DiagnosticBinding(
                        transport,
                        HcclOverlapSettings(
                            stage_diagnostics=True, ffn_compute_sync_diagnostics=True
                        ),
                        emit=report["diagnostic_records"].append,
                    )
                )
                binding.require_idle(transport)
            if native_ffn_runner is not None:
                run_native_ffn_thread(torch, args, native_ffn_runner, session, report)
            else:
                for index, (padded, valid) in enumerate(PARENT_EXTENTS):
                    transaction = f"eager-owner-{index}"
                    if args.role == "attention":
                        plan = transport.submit_forward(
                            HcclLocalForward("target", valid, padded),
                            transaction_id=transaction
                            if transport.is_coordinator
                            else None,
                        )
                    else:
                        plan = transport.receive_forward()
                    if plan is None or plan.transaction_id != transaction:
                        raise AssertionError("accepted unexpected parent")
                    owner = (
                        session.open_parent()
                        if bootstrap is not None
                        else transport.open_eager_pipeline(
                            parent_stream=parent,
                            send_stream=send,
                            receive_stream=receive,
                        )
                    )
                    if binding is not None:
                        progress = binding.bind_parent(
                            eager_pipeline=owner, compute_stream=compute
                        )
                        if progress is None:
                            raise AssertionError(
                                "requested diagnostics returned no progress"
                            )
                        owner.bind_progress(progress, compute_stream=compute)
                    run = run_attention if args.role == "attention" else run_ffn
                    run(torch, transport, owner, plan, index, compute, report)
                    owner.finish()
                    if (
                        not owner.finished
                        or transport.eager_pipeline is not None
                        or transport.plan is not None
                    ):
                        raise AssertionError("parent failed to retire its eager owner")
                    report["parents"].append(
                        {
                            "transaction_id": transaction,
                            "padded": list(padded),
                            "valid": list(valid),
                            "finished": True,
                        }
                    )
            if args.role == "attention":
                transport.stop_attention()
            elif native_ffn_runner is None and transport.receive_forward() is not None:
                raise AssertionError("expected normal STOP")
            report["normal_stop"] = transport.terminal
            transport.close()
            report["native_tp_after_plugin_close"] = native_check()
            destroy_model_parallel()
            destroy_distributed_environment()
            if args.stage_diagnostics:
                verify_diagnostics(report)
            report["success"] = True
    except BaseException:
        # Keep live communication/storage in place; the supervisor owns failed
        # processes. There is no opportunistic close/abort after a tensor fault.
        report["error"] = traceback.format_exc()
        raise
    finally:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        (args.output_dir / f"{args.role}-{args.role_rank}.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        if args.native_bootstrap and args.stage_diagnostics:
            startup = report.get("session_configuration_record")
            observations = ([] if startup is None else [startup]) + report.get(
                "diagnostic_records", []
            )
            (
                args.output_dir / f"{args.role}-{args.role_rank}-observations.json"
            ).write_text(json.dumps(observations, indent=2) + "\n")


def supervise(args):
    args.output_dir.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    port = helpers.select_port_block(3)
    children, logs, owned = {}, [], {}
    summary = {
        "scope": "actual eager owner component; no MoE/model/overlap acceptance",
        "success": False,
        "tp_size": args.tp_size,
        "devices": args.devices,
    }
    if args.native_ffn_runner:
        summary["native_ffn_runner_requested"] = True
    try:
        for role in ("ffn", "attention"):
            for rank in range(args.tp_size):
                name = f"{role}-{rank}"
                log = (args.output_dir / f"{name}.log").open("w")
                logs.append(log)
                diagnostic_flags = (
                    ["--stage-diagnostics"] if args.stage_diagnostics else []
                )
                bootstrap_flags = (
                    ["--native-bootstrap"] if args.native_bootstrap else []
                )
                runner_flags = (
                    ["--native-ffn-runner", "--timeout", str(args.timeout)]
                    if args.native_ffn_runner
                    else []
                )
                children[name] = subprocess.Popen(
                    [
                        sys.executable,
                        "-B",
                        str(Path(__file__).resolve()),
                        "--tp-size",
                        str(args.tp_size),
                        "--devices",
                        ",".join(map(str, args.devices)),
                        "--model",
                        args.model,
                        "--output-dir",
                        str(args.output_dir),
                        "--role",
                        role,
                        "--role-rank",
                        str(rank),
                        "--port",
                        str(port),
                        *diagnostic_flags,
                        *bootstrap_flags,
                        *runner_flags,
                    ],
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
        deadline = started + args.timeout - helpers.REAP_TIMEOUT_SECONDS
        while any(child.poll() is None for child in children.values()):
            for child in children.values():
                if child.poll() is None:
                    supervision.observe_owned(child.pid, owned)
            if any(child.poll() not in (None, 0) for child in children.values()):
                raise RuntimeError("a rank failed; retain per-rank logs")
            if time.monotonic() >= deadline:
                summary["timed_out"] = True
                break
            time.sleep(SUPERVISOR_POLL_SECONDS)
    except BaseException:
        summary["supervisor_error"] = traceback.format_exc()
    finally:
        for child in children.values():
            if child.poll() is None:
                supervision.observe_owned(child.pid, owned)
        summary["killed_owned_pids"] = (
            supervision.kill_owned(owned)
            if any(child.poll() is None for child in children.values())
            else []
        )
        for child in children.values():
            child.wait(timeout=helpers.REAP_TIMEOUT_SECONDS)
        for log in logs:
            log.close()
        summary["exit_codes"] = {
            name: child.returncode for name, child in children.items()
        }
        summary["workers"] = {
            name: json.loads(path.read_text()) if path.exists() else None
            for name in children
            for path in [args.output_dir / f"{name}.json"]
        }
        summary["owned_pid_start_ticks"] = owned
        summary["success"] = (
            not summary.get("supervisor_error")
            and not summary.get("timed_out")
            and not summary["killed_owned_pids"]
            and len(children) == args.tp_size * 2
            and all(child.returncode == 0 for child in children.values())
            and all(
                report is not None and report["success"]
                for report in summary["workers"].values()
            )
        )
        summary["elapsed_seconds"] = time.monotonic() - started
        (args.output_dir / "result.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
    print(json.dumps(summary, indent=2), flush=True)
    return 0 if summary["success"] else 1


if __name__ == "__main__":
    parsed = parse_args()
    if parsed.role:
        worker(parsed)
    else:
        raise SystemExit(supervise(parsed))
