# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Dynamic Q3 F2 Graph-service assembly for the live DSpark/PD component.

Import/default/help are stdlib only. The caller owns native distributed setup,
runtime configuration, output persistence and failed-process supervision. This
helper uses the real connector factory, FFN daemon and GraphService. Only the
final MoE arithmetic and constructor-free FFN carriers are controlled leaves.
No capture buckets or parent counts are inferred from an older device probe.
Captured device copies into observation buffers add correctness-observer work;
this helper provides no performance or physical-stream overlap evidence.
"""

from __future__ import annotations

import argparse
import json
import logging
import threading
import time
from dataclasses import asdict
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import torch
    from vllm.config import VllmConfig

TARGET_QUERY_LEN = 3
SUPPORTED_UBATCHES = 2
SERVICE_POLL_SECONDS = 0.1
DIAGNOSTIC_LOGGER = "afd_plugin.connectors.npu.hccl_diagnostics"
DIAGNOSTIC_FORMAT = "AFD HCCL stage diagnostic: %s"


def run_native_dspark_graph_ffn(
    config: VllmConfig,
    device: torch.device,
    report: dict,
    deadline: float,
    *,
    graph_compute_overlap: bool = False,
    graph_all_axes: bool = False,
    graph_exchange_order: Literal["stage_serial", "cross_layer_v1"] = "stage_serial",
) -> None:
    """Serve actual A-selected Q3 parents until peer STOP, then retire F storage.

    ``config`` is the original target-Graph F2 view, including the original
    DSpark/PD metadata. Resolve its Q3 shape before native F role isolation.
    The caller must already select the device, initialize native TP/world and
    install the existing runtime/configuration shims in its isolated process.
    Errors propagate with the service/cache/transport retained for supervision.
    Optional compute overlap selects the real Graph/U2 compute pipeline.
    All-axes mode enables its four policies. A separate exchange-order argument
    must match the first target configuration; cross_layer_v1 requires all axes
    and native U2. Eager overlap remains disabled.
    """
    import torch
    from hccl_native_attention_pd_dspark_graph_probe import graph_pipeline_storage
    from hccl_native_attention_pd_dspark_probe import ROUTER_SCALE
    from vllm.config import CompilationMode, CUDAGraphMode
    from vllm.forward_context import get_forward_context
    from vllm.platforms import current_platform
    from vllm_ascend.ascend_forward_context import (
        set_mc2_mask,
        set_mc2_tokens_capacity,
    )

    from afd_plugin.compat.npu.runtime_config import (
        get_npu_ffn_config,
        resolve_deepseek_v41_target_shape,
    )
    from afd_plugin.compat.patches.npu.ascend_config import init_ascend_config
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import (
        HcclStagedAFDConnector,
        create_npu_runtime_connector,
    )
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner
    from afd_plugin.v1.worker.npu.ffn_worker import AFDNPUFFNWorker

    assert type(graph_compute_overlap) is bool and type(graph_all_axes) is bool
    if graph_all_axes and not graph_compute_overlap:
        raise ValueError("All Graph axes require Graph compute overlap")
    if graph_exchange_order not in ("stage_serial", "cross_layer_v1"):
        raise ValueError("unsupported component Graph exchange order")
    original_afd = parse_afd_config(config)
    assert (
        original_afd.connector_extra_config.get("graph_exchange_order", "stage_serial")
        == graph_exchange_order
    )
    shape = resolve_deepseek_v41_target_shape(config)
    assert shape.target_query_len == TARGET_QUERY_LEN
    assert config.speculative_config is not None
    assert not config.model_config.enforce_eager
    assert config.compilation_config.mode == CompilationMode.NONE
    assert config.compilation_config.cudagraph_mode == CUDAGraphMode.FULL_DECODE_ONLY
    configured_stages = 1
    if config.parallel_config.use_ubatching:
        assert type(config.parallel_config.num_ubatches) is int
        assert config.parallel_config.num_ubatches == SUPPORTED_UBATCHES
        configured_stages = config.parallel_config.num_ubatches
    if graph_compute_overlap and configured_stages != SUPPORTED_UBATCHES:
        raise ValueError("Graph compute overlap requires target Graph U2")
    if graph_exchange_order == "cross_layer_v1" and not (
        graph_all_axes and configured_stages == SUPPORTED_UBATCHES
    ):
        raise ValueError("Cross-layer Graph requires all axes and native U2")
    isolated = get_npu_ffn_config(config)
    assert isolated is not config
    assert isolated.speculative_config is isolated.kv_transfer_config is None
    assert isolated.engram_config is None
    init_ascend_config(isolated)
    settings = HcclOverlapSettings(
        eager_u2_stream_overlap=False,
        graph_u2_compute_overlap=graph_compute_overlap,
        graph_u2_hybrid_dag=graph_all_axes,
        graph_u2_attention_three_stream=graph_all_axes,
        graph_u2_ffn_recv_stream=graph_all_axes,
        graph_u2_ffn_cross_layer=graph_all_axes,
        stage_diagnostics=True,
        ffn_compute_sync_diagnostics=False,
    )
    connector = create_npu_runtime_connector(
        0,
        device.index,
        isolated,
        parse_afd_config(isolated),
        target_shape=shape,
        overlap_settings=settings,
    )
    assert isinstance(connector, HcclStagedAFDConnector)
    transport = connector.transport
    caps = transport.capabilities
    assert caps.graph_exchange_order == graph_exchange_order
    hidden_size, vocab_size = caps.hidden_size, caps.vocab_size
    layers, capacity = caps.layer_indices, caps.max_tokens
    assert layers == tuple(
        range(isolated.model_config.hf_text_config.num_hidden_layers)
    )
    assert hidden_size == isolated.model_config.hf_text_config.hidden_size
    assert vocab_size == isolated.model_config.hf_text_config.vocab_size
    assert caps.graph_execution_version == 1
    assert caps.target_query_len == shape.target_query_len
    management_thread = threading.get_ident()
    calls, transactions, captured, lifecycle = [], [], [], []
    captured_addresses, retained_pipeline = {}, {}
    detail = report["native_ffn"] = {
        "target_graph": True,
        "graph_compute_overlap_requested": graph_compute_overlap,
        "graph_all_axes_requested": graph_all_axes,
        "graph_exchange_order_requested": graph_exchange_order,
        "original_target_shape": asdict(shape),
        "target_shape_resolved_before_isolation": True,
        "isolated_speculative_config": None,
        "isolated_pd_config": None,
        "isolated_engram_config": None,
        "full_ffn_constructor_executed": False,
        "worker_constructor_executed": False,
        "native_worker_shutdown_executed": False,
        "native_moe_executed": False,
        "checkpoint_weights_loaded": False,
        "factory_service_and_worker_daemon_executed": False,
        "native_daemon_retired": False,
        "stop_acknowledged": False,
        "hidden_size": hidden_size,
        "vocab_size": vocab_size,
        "layer_indices": list(layers),
        "capacity": capacity,
        "configured_stage_count": configured_stages,
        "router_scale": ROUTER_SCALE,
        "configured_settings": settings.effective_settings(),
        "management_thread_id": management_thread,
        "management_native_thread_id": threading.get_native_id(),
        "python_model_calls": calls,
        "transactions": transactions,
        "steps": [],
        "stage_steps": [],
        "captured_entries": captured,
        "host_records": [],
        "body_records": [],
        "lifecycle": lifecycle,
        "default_graph_api": "torch.npu.NPUGraph/torch.npu.graph",
        "graph_pool_source": "current_platform.get_global_graph_pool",
        "per_layer_observer_copies_captured": True,
        "observer_copy_overhead_included": True,
        "capture_is_arithmetic_execution": False,
        "physical_stream_attribution_accepted": False,
        "overlap_measured": False,
        "performance_accepted": False,
    }

    class ControlledFFN(torch.nn.Module):
        def __init__(self):
            super().__init__()
            for name, dtype, dimensions in (
                (
                    "observed_hidden",
                    torch.bfloat16,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
                (
                    "observed_router",
                    torch.float32,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
                (
                    "observed_ids",
                    torch.int32,
                    (len(layers), configured_stages, capacity),
                ),
                (
                    "observed_output",
                    torch.bfloat16,
                    (len(layers), configured_stages, capacity, hidden_size),
                ),
            ):
                self.register_buffer(
                    name, torch.empty(dimensions, dtype=dtype, device=device)
                )

        def get_experts_layer_indices(self):
            return layers

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel,
        ):
            # This body also runs under native capture. Record host metadata
            # and device copies only; never synchronize or read values to CPU.
            plan = transport.plan
            decision = plan.graph_execution
            context = get_forward_context()
            metadata = context.additional_kwargs["afd_metadata"]
            assert 1 <= len(plan.stages) <= configured_stages
            stage_index = metadata.stage_idx
            assert 0 <= stage_index < len(plan.stages)
            stage = plan.stages[stage_index]
            rows = stage.attention_padded_tokens[0]
            valid = stage.attention_valid_tokens[0]
            graph_phase = decision.phase in ("warmup", "capture")
            assert not already_sequence_parallel
            assert context.additional_kwargs["model_instance"] is self
            assert context.input_ids is input_ids and metadata.connector is connector
            assert metadata.transaction_id == plan.transaction_id
            assert metadata.num_stages == len(plan.stages)
            assert metadata.tokens_lens == [rows]
            assert metadata.tokens_unpadded_lens == [valid]
            assert (context.cudagraph_runtime_mode == CUDAGraphMode.FULL) == graph_phase
            assert hidden_states.dtype == torch.bfloat16
            assert hidden_states_fp32.dtype == torch.float32
            assert input_ids.dtype == torch.int32
            assert (
                hidden_states.shape == hidden_states_fp32.shape == (rows, hidden_size)
            )
            assert input_ids.shape == (rows,) and 0 < rows <= capacity
            assert threading.get_ident() != management_thread
            assert torch.is_inference_mode_enabled()
            capturing = bool(torch.npu.is_current_stream_capturing())
            assert capturing == (decision.phase == "capture")
            calls.append(
                {
                    "transaction_id": plan.transaction_id,
                    "phase": decision.phase,
                    "layer": layer_idx,
                    "stage": metadata.stage_idx,
                    "rows": rows,
                    "valid_rows": valid,
                    "capturing": capturing,
                    "thread_id": threading.get_ident(),
                    "native_thread_id": threading.get_native_id(),
                    "input_address": hidden_states.data_ptr(),
                    "router_address": hidden_states_fp32.data_ptr(),
                    "ids_address": input_ids.data_ptr(),
                }
            )
            self.observed_hidden[layer_idx, stage_index, :rows].copy_(hidden_states)
            self.observed_router[layer_idx, stage_index, :rows].copy_(
                hidden_states_fp32
            )
            self.observed_ids[layer_idx, stage_index, :rows].copy_(input_ids)
            output = (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()
            self.observed_output[layer_idx, stage_index, :rows].copy_(output)
            return output

    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = isolated, isolated.model_config
    runner.connector, runner.device, runner.target_shape = connector, device, shape
    runner.model, runner.prof = ControlledFFN(), None
    runner.graph_pool = current_platform.get_global_graph_pool()
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = runner.hccl_v41_eager_bootstrap = None
    detail["observer_buffers"] = {
        name: {
            "address": tensor.data_ptr(),
            "shape": list(tensor.shape),
            "dtype": str(tensor.dtype),
            "bytes": tensor.numel() * tensor.element_size(),
        }
        for name, tensor in runner.model.named_buffers()
    }
    set_mc2_tokens_capacity(
        isolated, isolated.scheduler_config.max_num_seqs, shape.target_query_len
    )
    set_mc2_mask(isolated, device)
    # Management creates observer/MC2 storage; publish it before the native
    # daemon chooses its own stream. No new fence is added to a serving parent.
    torch.npu.synchronize(device)
    detail["startup_observer_storage_published"] = True

    worker = AFDNPUFFNWorker.__new__(AFDNPUFFNWorker)
    worker.vllm_config, worker.model_runner, worker.device = isolated, runner, device
    worker.local_rank, worker.rank, worker.profiler_config = device.index, 0, None
    worker.target_shape = shape
    worker._ffn_thread = worker._ffn_shutdown_event = worker._ffn_loop_error = None
    worker._hccl_stop_received = worker._hccl_configuration_logged = False
    worker._hccl_v41_transport = None
    worker._cpu_binding_attempted = False
    worker.bind_hccl_v41_transport(transport)
    detail["binding_validation_executed"] = True
    actual_finish, actual_close = transport.finish_forward, transport.close

    def bank_addresses(bank):
        return [
            tensor.data_ptr()
            for index, rows in enumerate(bank.stage_rows)
            if rows
            for tensor in (
                bank.buffers(index).hidden_states,
                bank.buffers(index).hidden_states_fp32,
                bank.buffers(index).input_ids,
                bank.buffers(index).output,
            )
        ]

    def observe_finish():
        plan = transport.plan
        decision = plan.graph_execution
        # The real method owns its device synchronization and COMPLETE
        # handshake. Readbacks occur only after it returns, outside capture.
        actual_finish()
        assert not torch.npu.is_current_stream_capturing()
        service = runner.hccl_v41_graph_service
        assert 1 <= len(plan.stages) <= configured_stages
        rows = sum(stage.attention_padded_tokens[0] for stage in plan.stages)
        observation = {
            "transaction_id": plan.transaction_id,
            "phase": decision.phase,
            "mode": plan.mode,
            "reason": decision.reason,
            "key": None if decision.key is None else decision.key.digest,
            "decision_digest": decision.digest,
            "valid_tokens_by_stage": [s.attention_valid_tokens[0] for s in plan.stages],
            "padded_tokens_by_stage": [
                s.attention_padded_tokens[0] for s in plan.stages
            ],
            "target_query_len": shape.target_query_len,
            "num_stages": len(plan.stages),
            "observation_rows": rows if decision.phase != "capture" else 0,
            "arithmetic_executed": decision.phase != "capture" and rows > 0,
            "python_body_executed": any(
                call["transaction_id"] == plan.transaction_id for call in calls
            ),
            "layer_observations": [],
        }
        if decision.phase in ("capture", "replay"):
            entry = service.cache.find(decision.key, service.generation())
            assert entry is not None and isinstance(entry.graph, torch.npu.NPUGraph)
            addresses = bank_addresses(entry.resources.bank)
            pipeline = graph_pipeline_storage(
                entry.resources.pipeline,
                graph_all_axes=graph_all_axes,
                graph_exchange_order=graph_exchange_order,
            )
            assert (pipeline is not None) == (
                graph_compute_overlap
                and decision.key.num_ubatches == SUPPORTED_UBATCHES
            )
            if pipeline is not None:
                assert pipeline["bank"] == id(entry.resources.bank)
                assert pipeline["device"] == device.index
            if decision.phase == "capture":
                captured_addresses[decision.key.digest] = addresses
                retained_pipeline[decision.key.digest] = pipeline
                captured.append(
                    {
                        "key": decision.key.digest,
                        "graph_type": type(entry.graph).__qualname__,
                        "bank_identity": id(entry.resources.bank),
                        "bank_addresses": addresses,
                        "stage_rows": list(entry.resources.bank.stage_rows),
                        "num_tokens": decision.key.num_tokens,
                        "num_ubatches": decision.key.num_ubatches,
                        "num_reqs": decision.key.num_reqs,
                        "uniform_token_count": decision.key.uniform_token_count,
                        "max_query_len": decision.key.max_query_len,
                        "pipeline_allocated": entry.resources.pipeline is not None,
                        "pipeline_storage": pipeline,
                        **(
                            {
                                "bank_exchange_order": (
                                    entry.resources.bank.exchange_order
                                )
                            }
                            if graph_exchange_order == "cross_layer_v1"
                            else {}
                        ),
                    }
                )
            else:
                assert captured_addresses[decision.key.digest] == addresses
                assert retained_pipeline[decision.key.digest] == pipeline
                assert observation["python_body_executed"] is False
            observation["bank_addresses"] = addresses
            observation["bank_identity"] = id(entry.resources.bank)
            observation["pipeline_storage"] = pipeline
            if graph_exchange_order == "cross_layer_v1":
                observation["bank_exchange_order"] = entry.resources.bank.exchange_order
        if observation["arithmetic_executed"]:
            for layer in plan.layer_indices:
                stage_observations = []
                for stage_index, stage in enumerate(plan.stages):
                    stage_rows = stage.attention_padded_tokens[0]
                    if not stage_rows:
                        continue
                    stage_row = {
                        "transaction_id": plan.transaction_id,
                        "phase": decision.phase,
                        "layer": layer,
                        "stage": stage_index,
                        "rows": stage_rows,
                        "valid_rows": stage.attention_valid_tokens[0],
                        "input_ids": runner.model.observed_ids[
                            layer, stage_index, :stage_rows
                        ]
                        .cpu()
                        .tolist(),
                        "hidden": runner.model.observed_hidden[
                            layer, stage_index, :stage_rows
                        ]
                        .float()
                        .cpu()
                        .tolist(),
                        "router_fp32": runner.model.observed_router[
                            layer, stage_index, :stage_rows
                        ]
                        .cpu()
                        .tolist(),
                        "output": runner.model.observed_output[
                            layer, stage_index, :stage_rows
                        ]
                        .float()
                        .cpu()
                        .tolist(),
                    }
                    stage_observations.append(stage_row)
                    detail["stage_steps"].append(stage_row)
                row = {
                    "transaction_id": plan.transaction_id,
                    "phase": decision.phase,
                    "layer": layer,
                    "stage": 0 if len(plan.stages) == 1 else None,
                    "rows": rows,
                    "valid_rows": sum(
                        item["valid_rows"] for item in stage_observations
                    ),
                    "stage_observations": stage_observations,
                }
                # Stage order is the parent token order from its accepted plan.
                # Preserve both the per-stage evidence and the complete layer.
                for name in ("input_ids", "hidden", "router_fp32", "output"):
                    row[name] = [
                        value
                        for stage_row in stage_observations
                        for value in stage_row[name]
                    ]
                observation["layer_observations"].append(row)
                detail["steps"].append(row)
        transactions.append(observation)

    def observe_close():
        service = runner.hccl_v41_graph_service
        assert service.acknowledged_stop and service.cache.closed
        lifecycle.append("graph-cache-closed-before-transport")
        actual_close()
        lifecycle.append("transport-closed-before-caller-groups")

    class DiagnosticCapture(logging.Handler):
        def emit(self, record):
            if record.msg == DIAGNOSTIC_FORMAT:
                # LogRecord unwraps a single nonempty mapping argument.
                assert isinstance(record.args, dict)
                value = dict(record.args)
                target = (
                    detail["host_records"]
                    if value["event"].startswith("graph_parent_")
                    else detail["body_records"]
                )
                target.append(value)

    diagnostics_logger = logging.getLogger(DIAGNOSTIC_LOGGER)
    handler = DiagnosticCapture()
    diagnostics_logger.addHandler(handler)
    transport.finish_forward, transport.close = observe_finish, observe_close
    try:
        worker.start_ffn_server_loop()
        service = runner.hccl_v41_graph_service
        assert service is not None and service.graph_factory is torch.npu.NPUGraph
        assert service.overlap_settings == settings == connector.overlap_settings
        assert transport.initialized
        assert (
            transport.negotiated_capabilities.target_query_len == shape.target_query_len
        )
        detail["factory_service_and_worker_daemon_executed"] = True
        lifecycle.append("factory-service-bound-and-daemon-started")
        while worker.poll_hccl_ffn_service():
            if time.monotonic() >= deadline:
                raise TimeoutError("live DSpark Graph F2 daemon exceeded deadline")
            time.sleep(SERVICE_POLL_SECONDS)
        assert service.acknowledged_stop
        lifecycle.append("peer-stop-acknowledged")
        worker.stop_ffn_server_loop()
        assert worker.poll_hccl_ffn_service() is False
        assert service.cache.closed and service.cache.is_empty and transport.closed
        lifecycle.append("daemon-joined-and-service-closed")
        detail["stop_acknowledged"] = True
        detail["native_daemon_retired"] = True
        detail["completed_parent_count"] = len(transactions)
    finally:
        diagnostics_logger.removeHandler(handler)
        transport.finish_forward, transport.close = actual_finish, actual_close
        service = runner.hccl_v41_graph_service
        detail["transport_closed"] = transport.closed
        detail["transport_terminal"] = transport.terminal
        if service is not None:
            detail["cache_closed"] = service.cache.closed
            detail["cache_terminal"] = service.cache.terminal


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    print(
        json.dumps(
            {
                "runtime_imported": False,
                "run": False,
                "target_query_len": TARGET_QUERY_LEN,
                "entrypoint": (
                    "run_native_dspark_graph_ffn(config, device, report, deadline)"
                ),
                "parent_counts": "selected by actual Attention parents",
                "device_validation_accepted": False,
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
