# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Graph/U1 observations for the live native N2 PD decode component.

The driver is hccl_native_attention_pd_dspark_decode_probe.py --target-graph.
Only completed real v3 codec calls are recorded. CPU validation of these
records is a harness contract, separate from executing the NPU component.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import sys
from collections import Counter
from contextlib import contextmanager
from pathlib import Path
from types import ModuleType

TARGET_ROWS = 3
TARGET_REQUESTS = 1
TARGET_STAGES = 1
NEGOTIATED_STAGE_CAPACITY = 2
TARGET_LAYERS = (0, 1)
TARGET_HIDDEN_SIZE = 512
TARGET_VOCAB_SIZE = 128
WARMUP_PARENTS = 1
CAPTURE_PARENTS = 1
REPLAY_PARENTS = 1
FIXED_PARENTS = 6


@contextmanager
def observe_graph_pair_controls(report):
    """Observe actual completed transport calls; never synthesize a peer frame."""
    from afd_plugin.connectors.npu.hccl_staged_transport import HcclStagedTransport
    from afd_plugin.distributed.hccl_plan import encode_hccl_plan_message

    records = report["pair_control_messages"] = []
    original_send = HcclStagedTransport._send_control
    original_receive = HcclStagedTransport._recv_control

    def record(direction, transport, rank, message):
        raw = encode_hccl_plan_message(message)
        records.append(
            {
                "ordinal": len(records),
                "direction": direction,
                "role": transport.role,
                "world_rank": transport.world_rank,
                "peer_world_rank": rank,
                "encoded_message": json.loads(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )

    def send(transport, rank, message):
        result = original_send(transport, rank, message)
        record("send_returned", transport, rank, message)
        return result

    def receive(transport, rank):
        message = original_receive(transport, rank)
        record("receive_returned", transport, rank, message)
        return message

    try:
        HcclStagedTransport._send_control = send
        HcclStagedTransport._recv_control = receive
        yield
    finally:
        HcclStagedTransport._send_control = original_send
        HcclStagedTransport._recv_control = original_receive


@contextmanager
def graph_codec():
    """Load the actual CPU codec without executing the plugin entry point.

    The supervisor has no runtime imports. A temporary package search root
    skips afd_plugin.__init__ only; every codec/config/layout leaf is genuine.
    Restore the import namespace when the supervisor has finished validation.
    """
    original = {
        name: module
        for name, module in sys.modules.items()
        if name == "afd_plugin" or name.startswith("afd_plugin.")
    }
    if "afd_plugin" not in original:
        package = ModuleType("afd_plugin")
        package.__path__ = [str(Path(__file__).resolve().parents[2] / "afd_plugin")]
        sys.modules["afd_plugin"] = package
    try:
        yield importlib.import_module("afd_plugin.distributed.hccl_plan")
    finally:
        for name in tuple(sys.modules):
            if (
                name == "afd_plugin" or name.startswith("afd_plugin.")
            ) and name not in original:
                del sys.modules[name]
        sys.modules.update(original)


def graph_pipeline_storage(
    pipeline, *, graph_all_axes=False, graph_exchange_order="stage_serial"
):
    """Observe retained native pipeline owners; IDs do not prove overlap."""
    if pipeline is None:
        return None
    assert pipeline.bank is not None
    policy = {
        "hybrid": pipeline.policy.hybrid,
        "attention_three_stream": pipeline.policy.attention_three_stream,
        "ffn_recv_stream": pipeline.policy.ffn_recv_stream,
        "ffn_cross_layer": pipeline.policy.ffn_cross_layer,
    }
    assert type(graph_all_axes) is bool
    assert all(value is graph_all_axes for value in policy.values())
    events = [
        id(event)
        for _, step in sorted(pipeline.step_events.items())
        for event in (step.ready, step.compute_done, step.receive_done, step.send_done)
    ] + [
        id(event)
        for _, tail in sorted(pipeline.tail_events.items())
        for event in (tail.ready, tail.done)
    ]
    assert len(events) == len(set(events))
    result = {
        "pipeline": id(pipeline),
        "bank": id(pipeline.bank),
        "compute_stream": id(pipeline.compute_stream),
        "device": pipeline.compute_stream.device.index,
        "events": events,
        "steps": [list(step) for step in sorted(pipeline.step_events)],
        "stages": sorted(pipeline.tail_events),
    }
    if graph_all_axes:
        assert pipeline.bank.exchange_order == graph_exchange_order
        result.update(policy=policy, exchange_order=pipeline.bank.exchange_order)
        if graph_exchange_order == "cross_layer_v1":
            assert pipeline.schedule is not None
            result["schedule"] = {
                "identity": id(pipeline.schedule),
                "actions": [
                    [action.kind, action.layer_idx, action.stage_idx]
                    for action in pipeline.schedule.actions
                ],
                "compute_steps": [
                    list(step) for step in pipeline.schedule.compute_steps
                ],
            }
        else:
            assert pipeline.schedule is None
    return result


def graph_storage(owner, *, target_requests=TARGET_REQUESTS, allow_u2=False):
    """Observe retained published resources through the cache's public lookup."""
    coordinator = owner.hccl_v41_graph_coordinator
    control = coordinator.control
    result = {
        "owner": id(owner),
        "model": id(owner.model),
        "model_state": id(owner.model_state),
        "input_buffers": id(owner.input_buffers),
        "block_tables": id(owner.block_tables),
        "speculator": id(owner.speculator),
        "consumer": id(owner.dspark_pd_consumer),
        "manager": id(owner.cudagraph_manager),
        "session": id(coordinator.session),
        "transport": id(coordinator.transport),
        "physical_kv": [tensor.data_ptr() for tensor in owner.kv_caches],
        "entries": [],
    }
    for geometry in coordinator.coverage.geometries:
        key = control.key_for(geometry)
        entry = control.cache.find(key, control.generation())
        assert entry is not None
        assert key.num_tokens == TARGET_ROWS * key.num_reqs
        assert 1 <= key.num_reqs <= target_requests
        assert key.uniform_token_count == key.max_query_len == TARGET_ROWS
        assert key.num_ubatches in ((1, 2) if allow_u2 else (TARGET_STAGES,))
        resources = entry.resources
        assert resources.manager is owner.cudagraph_manager
        assert resources.model_state is owner.model_state
        assert resources.input_buffers is owner.input_buffers
        assert resources.hidden_states is not None
        assert len(resources.auxiliary) == len(TARGET_LAYERS)
        compute_overlap = coordinator.overlap_settings.graph_u2_compute_overlap
        settings = coordinator.overlap_settings
        graph_all_axes = settings.graph_u2_hybrid_dag
        assert all(
            value is graph_all_axes
            for value in (
                settings.graph_u2_attention_three_stream,
                settings.graph_u2_ffn_recv_stream,
                settings.graph_u2_ffn_cross_layer,
            )
        )
        pipeline = graph_pipeline_storage(
            resources.pipeline,
            graph_all_axes=graph_all_axes,
            graph_exchange_order=(
                coordinator.transport.negotiated_capabilities.graph_exchange_order
            ),
        )
        assert (pipeline is not None) == (compute_overlap and key.num_ubatches == 2)
        result["entries"].append(
            {
                "key_digest": key.digest,
                "num_tokens": key.num_tokens,
                "num_reqs": key.num_reqs,
                "num_stages": key.num_ubatches,
                "generation": entry.generation,
                "graph": id(entry.graph),
                "bank": id(resources.bank),
                "pipeline_storage": pipeline,
                "hidden": resources.hidden_states.data_ptr(),
                "auxiliary": [value.data_ptr() for value in resources.auxiliary],
                "exchange": [
                    value.data_ptr()
                    for stage, rows in enumerate(resources.bank.stage_rows)
                    if rows
                    for value in (
                        resources.bank.buffers(stage).hidden_states,
                        resources.bank.buffers(stage).hidden_states_fp32,
                        resources.bank.buffers(stage).input_ids,
                        resources.bank.buffers(stage).output,
                    )
                ],
            }
        )
        if (
            coordinator.transport.negotiated_capabilities.graph_exchange_order
            == "cross_layer_v1"
        ):
            result["entries"][-1]["bank_exchange_order"] = resources.bank.exchange_order
    if allow_u2:
        assert any(
            entry["num_reqs"] == target_requests and entry["num_stages"] == 2
            for entry in result["entries"]
        )
    else:
        assert len(result["entries"]) == 1
    return result


@contextmanager
def observe_graph_decode(
    bindings,
    report,
    *,
    target_requests=TARGET_REQUESTS,
    allow_u2=False,
    expected_target_batches=None,
):
    """Observe unchanged public execution and Python target entry on the D owner.

    Capture has already returned through that owner's public capture_model.
    Wrappers only observe host calls after capture and are removed on exit.
    Numerical/sample/proposal/whole-pool checks remain in the common driver.
    """
    owner = bindings.owner
    model = owner.model
    coordinator = owner.hccl_v41_graph_coordinator
    startup = report["native_live_owner"]["target_graph"]
    assert startup["capture_kv_bytes_unchanged"]
    assert startup["capture_physical_pages_unchanged"]
    records = startup["host_records"]
    if expected_target_batches is None:
        expected_target_batches = (
            (target_requests, "eager", 2 if allow_u2 else 1),
            (target_requests, "replay", 0),
        )
    baseline = graph_storage(owner, target_requests=target_requests, allow_u2=allow_u2)
    detail = report["target_graph_decode"] = {
        "storage_before": baseline,
        "executions": [],
        "expected_target_batches": expected_target_batches,
        "python_target_calls": [],
        "accepted": False,
        "consumer_ready_publications": [],
        "target_requests": target_requests,
        "target_u2": allow_u2,
    }
    assert "execute_model" not in owner.__dict__
    assert "forward" not in owner.model.__dict__
    execute = owner.execute_model
    forward = model.forward
    connector = owner.kv_connector.kv_connector
    assert "publish_dspark_ready" not in connector.__dict__
    publish = connector.publish_dspark_ready

    def observed_publish(ready_batch):
        detail["consumer_ready_publications"].append(len(ready_batch))
        return publish(ready_batch)

    def observed_forward(*args, **kwargs):
        detail["python_target_calls"].append(
            {"execute_ordinal": len(detail["executions"])}
        )
        return forward(*args, **kwargs)

    def observed_execute(step, intermediate_tensors=None):
        before_records = len(records)
        before_calls = len(detail["python_target_calls"])
        assert (
            graph_storage(owner, target_requests=target_requests, allow_u2=allow_u2)
            == baseline
        )
        output = execute(step, intermediate_tensors)
        observed = records[before_records:]
        finished = [
            value
            for value in observed
            if value["event"]
            in ("graph_parent_finish_returned", "graph_parent_scope_returned")
        ]
        assert len(finished) == 1
        parent = finished[0]
        entry = {
            "ordinal": len(detail["executions"]),
            "scheduled_tokens": step.total_num_scheduled_tokens,
            "finished_req_ids": sorted(step.finished_req_ids),
            "transaction_id": parent["transaction_id"],
            "phase": parent["phase"],
            "mode": parent["mode"],
            "reason": parent["reason"],
            "key_digest": parent["key_digest"],
            "python_target_calls": len(detail["python_target_calls"]) - before_calls,
            "host_records": observed,
        }
        if step.total_num_scheduled_tokens:
            ordinal = sum(
                bool(previous["scheduled_tokens"]) for previous in detail["executions"]
            )
            requests, phase, python_calls = expected_target_batches[ordinal]
            assert step.total_num_scheduled_tokens == TARGET_ROWS * requests
            assert owner.execute_model_state is not None
            assert parent["phase"] == phase
            assert entry["python_target_calls"] == python_calls
            if phase == "eager":
                assert not parent["key_present"]
            else:
                assert phase == "replay"
                captured = next(
                    item
                    for item in baseline["entries"]
                    if item["key_digest"] == parent["key_digest"]
                )
                assert requests <= captured["num_reqs"] <= target_requests
                assert captured["num_stages"] == (
                    2 if allow_u2 and requests == 2 else 1
                )
                assert entry["python_target_calls"] == 0
                state = owner.execute_model_state
                assert state.hidden_states.data_ptr() == captured["hidden"]
                assert [value.data_ptr() for value in state.aux_hidden_states] == (
                    captured["auxiliary"]
                )
        else:
            assert parent["phase"] == "eager" and entry["python_target_calls"] == 0
        assert (
            graph_storage(owner, target_requests=target_requests, allow_u2=allow_u2)
            == baseline
        )
        detail["executions"].append(entry)
        return output

    try:
        owner.execute_model = observed_execute
        model.forward = observed_forward
        connector.publish_dspark_ready = observed_publish
        yield
        assert sum(
            bool(item["scheduled_tokens"]) for item in detail["executions"]
        ) == len(expected_target_batches)
        assert report["native_decode_and_verification_accepted"]
        if allow_u2:
            assert report["two_request_native_decode_accepted"]
        assert report["receiver_retired"] and report["native_owner_shutdown_returned"]
        assert coordinator.control.cache.closed
        assert coordinator.transport.closed
        assert not any(detail["consumer_ready_publications"])
        detail["accepted"] = True
    finally:
        del owner.execute_model
        del model.forward
        del connector.publish_dspark_ready
        # The worker's finally writes the complete report even on failure.
        # Do not perform a final cache lookup after real owner shutdown/reset.


def verify_graph_pair_messages(
    attention,
    ffn,
    expected_parent_count,
    *,
    target_requests=TARGET_REQUESTS,
    allow_u2=False,
    graph_exchange_order="stage_serial",
):
    """Validate the full TP1 v3 handshake, reservations, plans and retirement."""
    first, second = (
        attention["pair_control_messages"],
        ffn["pair_control_messages"],
    )
    assert len(first) == len(second) == 5 + 10 * expected_parent_count
    with graph_codec() as codec:
        decoded = []
        for ordinal, (one, two) in enumerate(zip(first, second, strict=True)):
            assert one["sha256"] == two["sha256"]
            assert one["encoded_message"] == two["encoded_message"]
            for entry, role, rank in ((one, "attention", 1), (two, "ffn", 0)):
                assert type(entry["ordinal"]) is int and entry["ordinal"] == ordinal
                assert entry["role"] == role
                assert type(entry["world_rank"]) is int and entry["world_rank"] == rank
                assert type(entry["peer_world_rank"]) is int
                assert entry["peer_world_rank"] == 1 - rank
                assert entry["direction"] in ("send_returned", "receive_returned")
            assert one["direction"] != two["direction"]
            raw = json.dumps(
                one["encoded_message"],
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode()
            message = codec.decode_hccl_plan_message(raw)
            assert codec.encode_hccl_plan_message(message) == raw
            assert hashlib.sha256(raw).hexdigest() == one["sha256"]
            decoded.append(message)

        def take(index, direction, kind):
            assert first[index]["direction"] == direction
            message = decoded[index]
            assert message.kind == kind
            return message

        for index, direction, role, rank in (
            (0, "receive_returned", "ffn", 0),
            (1, "send_returned", "attention", 1),
        ):
            hello = take(index, direction, "HELLO")
            assert hello.role == role and hello.world_rank == rank
            cap = hello.capabilities
            assert cap is not None
            assert cap.hidden_size == TARGET_HIDDEN_SIZE
            assert cap.vocab_size == TARGET_VOCAB_SIZE
            assert cap.max_tokens >= TARGET_ROWS * target_requests
            assert cap.layer_indices == TARGET_LAYERS
            assert cap.attention_size == cap.ffn_size == cap.native_tp_size == 1
            # HELLO advertises the factory's capacity, independent of this
            # U1 key's actual one-stage execution geometry.
            assert cap.max_stages == NEGOTIATED_STAGE_CAPACITY
            assert cap.local_counts_version == cap.graph_execution_version == 1
            assert cap.target_query_len == TARGET_ROWS
            assert cap.graph_exchange_order == graph_exchange_order
            assert cap.eager_pipeline_version == 0
        assert decoded[0].capabilities == decoded[1].capabilities
        capabilities = decoded[1].capabilities
        parents = []
        for ordinal in range(expected_parent_count):
            index = 2 + 10 * ordinal
            query = take(index, "send_returned", "GRAPH_QUERY")
            report = take(index + 1, "receive_returned", "GRAPH_REPORT")
            decision = take(index + 2, "send_returned", "GRAPH_DECISION").graph_decision
            assert decision is not None and query.graph_candidate is not None
            assert (
                query.transaction_id == report.transaction_id == decision.transaction_id
            )
            assert report.world_rank == 0
            assert report.graph_digest == query.graph_candidate.digest
            assert report.graph_report is not None
            candidate = query.graph_candidate
            if ordinal == 0:
                # Real native capture eligibility: a missing cache agrees an
                # empty eager parent before any warmup/capture can publish it.
                assert candidate.capture_sequence_digest is not None
                assert candidate.phase == "replay" and candidate.mode == "warmup"
                assert candidate.eager_padded_tokens == (0,)
                assert report.graph_report.availability == "missing"
                assert decision.phase == "eager" and decision.key is None
                assert decision.padded_tokens == (0,)
                assert decision.reason == "cache_miss"
            else:
                assert candidate.capture_sequence_digest is None
                availability = (
                    "unsupported"
                    if candidate.phase == "eager"
                    else "missing"
                    if candidate.phase in ("warmup", "capture")
                    else "ready"
                )
                assert report.graph_report.availability == availability
                assert decision.phase == candidate.phase
                assert decision.key == candidate.key
                assert decision.reason == "requested"
            assert decision.mode == candidate.mode
            if candidate.key is not None:
                key = candidate.key
                assert key.num_tokens == TARGET_ROWS * key.num_reqs
                assert key.uniform_token_count == TARGET_ROWS
                assert key.max_query_len == TARGET_ROWS
                assert 1 <= key.num_reqs <= target_requests
                assert key.num_ubatches in ((1, 2) if allow_u2 else (TARGET_STAGES,))
            for offset, direction, rank in (
                (3, "receive_returned", 0),
                (4, "send_returned", 1),
            ):
                ack = take(index + offset, direction, "GRAPH_ACK")
                assert ack.transaction_id == decision.transaction_id
                assert ack.world_rank == rank and ack.graph_digest == decision.digest
            plan = take(index + 5, "send_returned", "FORWARD").plan
            assert plan is not None
            plan.validate(capabilities)
            assert plan.transaction_id == decision.transaction_id
            assert plan.graph_execution == decision
            assert plan.layer_indices == TARGET_LAYERS
            assert len(plan.stages) in ((1, 2) if allow_u2 else (TARGET_STAGES,))
            assert all(len(stage.attention_valid_tokens) == 1 for stage in plan.stages)
            assert tuple(stage.attention_padded_tokens[0] for stage in plan.stages) == (
                decision.padded_tokens
            )
            for offset, direction, kind, rank in (
                (6, "receive_returned", "ACCEPT", 0),
                (7, "send_returned", "ACCEPT", 1),
                (8, "receive_returned", "COMPLETE", None),
                (9, "send_returned", "COMPLETE", None),
            ):
                message = take(index + offset, direction, kind)
                assert message.transaction_id == plan.transaction_id
                assert message.plan_digest == plan.digest
                if rank is not None:
                    assert message.world_rank == rank
            parents.append(
                {
                    "transaction_id": plan.transaction_id,
                    "phase": decision.phase,
                    "mode": decision.mode,
                    "reason": decision.reason,
                    "key_digest": "" if decision.key is None else decision.key.digest,
                    "decision_digest": decision.digest,
                    "valid_tokens": [
                        stage.attention_valid_tokens[0] for stage in plan.stages
                    ],
                    "padded_tokens": [
                        stage.attention_padded_tokens[0] for stage in plan.stages
                    ],
                }
            )
        assert len({item["transaction_id"] for item in parents}) == len(parents)
        start = 2 + 10 * expected_parent_count
        take(start, "send_returned", "STOP")
        take(start + 1, "receive_returned", "STOP_ACK")
        take(start + 2, "send_returned", "STOP_ACK")
    return {"parents": parents, "bidirectional_codec_records_match": True}


def verify_graph_host_records(
    records, parents, *, role, graph_compute_overlap=False, graph_all_axes=False
):
    """Validate the two real diagnostic schemas against completed v3 parents.

    Stage records describe host enqueue boundaries and deliberately have no
    outcome. Parent records describe host API returns, including eager scopes;
    neither schema claims device completion. COMPLETE is checked by the codec.
    """
    assert type(graph_all_axes) is bool
    assert not graph_all_axes or graph_compute_overlap
    rank = 1 if role == "attention" else 0
    by_id = {parent["transaction_id"]: parent for parent in parents}
    host = []
    body_events = {
        f"{name}_{suffix}"
        for name in (
            "recv",
            "compute",
            "send",
            "layer_send_wait",
            "final_send_wait",
            "send_post",
            "recv_post",
            "loan_wait",
            "stage_reuse_wait",
            "parent_finish",
            "prepare",
            "continuation",
            "collapse",
        )
        for suffix in ("begin", "returned")
    }
    for record in records:
        assert record["role"] == role
        assert record["world_rank"] == rank and record["role_rank"] == 0
        event = record["event"]
        if record["boundary"] == "host_control":
            parent = by_id[record["transaction_id"]]
            assert record["local_device"] == (2 if role == "attention" else 6)
            assert all(
                record[name] == parent[name]
                for name in ("phase", "mode", "reason", "key_digest", "decision_digest")
            )
            assert record["key_present"] == bool(parent["key_digest"])
            assert record["num_stages"] == len(parent["padded_tokens"])
            assert record["outcome"] == (
                "begin" if event.endswith("_begin") else "returned"
            )
            assert "error_type" not in record
            settings = {
                "AFD_HCCL_EAGER_U2_STREAM_OVERLAP": False,
                "AFD_HCCL_GRAPH_U2_COMPUTE_OVERLAP": graph_compute_overlap,
                "AFD_HCCL_GRAPH_U2_HYBRID_DAG": graph_all_axes,
                "AFD_HCCL_GRAPH_U2_ATTENTION_THREE_STREAM": graph_all_axes,
                "AFD_HCCL_GRAPH_U2_FFN_RECV_STREAM": graph_all_axes,
                "AFD_HCCL_GRAPH_U2_FFN_CROSS_LAYER": graph_all_axes,
                "AFD_HCCL_STAGE_DIAGNOSTICS": True,
                "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS": False,
            }
            assert all(
                record[f"configured.{name}"] is value
                for name, value in settings.items()
            )
            host.append(record)
            continue
        assert record["boundary"] == "host_enqueue"
        assert "outcome" not in record and "error_type" not in record
        assert event == "configuration" or event in body_events
        assert record["phase"] in ("eager", "graph_warmup", "graph_capture")
        assert record["num_stages"] in (1, 2)
        assert any(
            record["phase"]
            == ("eager" if parent["phase"] == "eager" else f"graph_{parent['phase']}")
            and record["num_stages"] == len(parent["padded_tokens"])
            for parent in parents
        )
        side_compute = (
            graph_compute_overlap
            and record["phase"] != "eager"
            and record["num_stages"] == 2
        )
        assert record["actual.mode"] == ("graph-streamed" if side_compute else "serial")
        assert record["actual.compute_stream"] == (
            "compute" if side_compute else "parent"
        )
        assert all(
            record[f"actual.{name}_stream"] == "parent" for name in ("send", "recv")
        )
        assert record["actual.compute_pipeline_enabled"] is side_compute
        assert record["actual.ffn_compute_sync"] is False
        if graph_all_axes and event == "configuration":
            assert record["logical.compute_stream"] == (
                "compute" if side_compute else "parent"
            )
            assert all(
                record[f"logical.{name}_stream"] == (name if side_compute else "parent")
                for name in ("send", "recv")
            )
            effective = {
                "AFD_HCCL_EAGER_U2_STREAM_OVERLAP": False,
                "AFD_HCCL_GRAPH_U2_COMPUTE_OVERLAP": side_compute,
                "AFD_HCCL_GRAPH_U2_HYBRID_DAG": side_compute and role == "attention",
                "AFD_HCCL_GRAPH_U2_ATTENTION_THREE_STREAM": (
                    side_compute and role == "attention"
                ),
                "AFD_HCCL_GRAPH_U2_FFN_RECV_STREAM": side_compute and role == "ffn",
                "AFD_HCCL_GRAPH_U2_FFN_CROSS_LAYER": side_compute and role == "ffn",
                "AFD_HCCL_STAGE_DIAGNOSTICS": True,
                "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS": False,
            }
            assert all(
                record[f"effective.{name}"] is value
                for name, value in effective.items()
            )
            assert record["parent_transport_override"] is (record["phase"] != "eager")
        assert type(record["in_profile_run"]) is bool
        assert type(record["is_warmup"]) is bool
        if "transaction_id" in record:
            parent = by_id[record["transaction_id"]]
            assert record["phase"] == (
                "eager" if parent["phase"] == "eager" else f"graph_{parent['phase']}"
            )
            assert record["num_stages"] == len(parent["padded_tokens"])
        if event != "configuration":
            assert record["layer"] in TARGET_LAYERS
            assert 0 <= record["stage"] < record["num_stages"]
    expected = []
    for parent in parents:
        tx = parent["transaction_id"]
        expected.append((tx, "graph_parent_reserved", "graph_reservation"))
        if parent["phase"] == "eager" and (
            role == "ffn" or any(parent["valid_tokens"])
        ):
            expected.append(
                (
                    tx,
                    "graph_parent_scope_returned",
                    "native_eager_scope"
                    if role == "attention"
                    else "execute_hccl_v41_parent",
                )
            )
            continue
        if parent["phase"] == "replay":
            api = "run_fullgraph" if role == "attention" else "graph.replay"
            expected.extend(
                (tx, f"graph_parent_replay_{suffix}", api)
                for suffix in ("begin", "returned")
            )
        api = (
            "finish_forward" if parent["phase"] == "eager" else "complete_graph_forward"
        )
        expected.extend(
            (tx, f"graph_parent_finish_{suffix}", api)
            for suffix in ("begin", "returned")
        )
    assert [
        (item["transaction_id"], item["event"], item["boundary_api"]) for item in host
    ] == expected


def verify_graph_decode(attention, ffn):
    """Join real protocol, native dispatch, fixed storage and per-layer oracles."""
    detail = attention["target_graph_decode"]
    assert detail["accepted"]
    assert attention["native_decode_and_verification_accepted"]
    assert not attention["u2_accepted"] and not attention["full_model_accepted"]
    zero_count = len(attention["zero_steps"])
    assert len(detail["executions"]) == zero_count + 3
    protocol = verify_graph_pair_messages(attention, ffn, FIXED_PARENTS + zero_count)
    parents = protocol["parents"]
    assert Counter(item["phase"] for item in parents) == {
        "warmup": WARMUP_PARENTS,
        "capture": CAPTURE_PARENTS,
        "replay": REPLAY_PARENTS,
        "eager": zero_count + 3,
    }
    by_id = {item["transaction_id"]: item for item in parents}
    assert [entry["transaction_id"] for entry in detail["executions"]] == [
        parent["transaction_id"]
        for parent in parents[1 + WARMUP_PARENTS + CAPTURE_PARENTS :]
    ]
    for entry in detail["executions"]:
        parent = by_id[entry["transaction_id"]]
        assert all(
            parent[name] == entry[name]
            for name in ("phase", "mode", "reason", "key_digest")
        )
        assert parent["valid_tokens"] == [entry["scheduled_tokens"]]
    decode = [item for item in detail["executions"] if item["scheduled_tokens"]]
    assert [item["phase"] for item in decode] == ["eager", "replay"]
    assert [item["python_target_calls"] for item in decode] == [1, 0]
    assert parents.index(by_id[decode[0]["transaction_id"]]) > next(
        index for index, parent in enumerate(parents) if parent["phase"] == "capture"
    )
    assert ffn["native_ffn"]["native_daemon_retired"]
    transactions = ffn["native_ffn"]["transactions"]
    assert len(transactions) == len(parents)
    assert [item["transaction_id"] for item in transactions] == [
        item["transaction_id"] for item in parents
    ]
    for actual, expected in zip(transactions, parents, strict=True):
        assert actual["phase"] == expected["phase"]
        assert actual["mode"] == expected["mode"]
        assert actual["reason"] == expected["reason"]
        assert (actual["key"] or "") == expected["key_digest"]
        assert actual["valid_tokens_by_stage"] == expected["valid_tokens"]
        assert actual["padded_tokens_by_stage"] == expected["padded_tokens"]
    verify_graph_host_records(
        attention["native_live_owner"]["target_graph"]["host_records"],
        parents,
        role="attention",
    )
    verify_graph_host_records(ffn["native_ffn"]["host_records"], parents, role="ffn")
    # Per-layer numerical evidence from the completed F parents is joined by
    # transaction identity, including replay's captured observation copies.
    for execution, target_step in zip(decode, attention["decode_steps"], strict=True):
        ffn_parent = transactions[parents.index(by_id[execution["transaction_id"]])]
        assert [item["layer"] for item in ffn_parent["layer_observations"]] == list(
            TARGET_LAYERS
        )
        assert [
            item["layer"] for item in target_step["independent_layer_oracles"]
        ] == list(TARGET_LAYERS)
        for actual, expected in zip(
            ffn_parent["layer_observations"],
            target_step["independent_layer_oracles"],
            strict=True,
        ):
            assert all(
                len(actual[name]) == len(expected[name]) == TARGET_ROWS
                for name in ("input_ids", "hidden", "router_fp32", "output")
            )
            assert all(
                actual[name] == expected[name]
                for name in ("input_ids", "layer", "hidden", "router_fp32", "output")
            )
    return protocol | {
        "native_target_graph_component_accepted": True,
        "full_model_accepted": False,
        "u2_accepted": False,
        "zero_parent_count": zero_count,
    }
