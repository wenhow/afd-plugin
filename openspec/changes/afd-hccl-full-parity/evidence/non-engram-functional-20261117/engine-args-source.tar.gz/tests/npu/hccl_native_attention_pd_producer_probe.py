# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native P scheduling, controlled KV generation and delayed block retirement.

The original prompt enters the actual hybrid connector. Its native truncation,
sampling, EngineCoreOutput export and subsequent send metadata remain intact.
Only model arithmetic is controlled; this is not checkpoint or SparseFA evidence.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vllm.v1.core.sched.scheduler import Scheduler
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm_ascend.worker.v2.model_runner import NPUModelRunner

PRODUCER_ORIGINAL_PROMPT = (11, 12, 13, 14, 15)
PRODUCER_SAMPLE_TOKEN = 7
PRODUCER_REQUEST_MAX_TOKENS = 3
POLL_SECONDS = 0.05
BF16_BYTES = 2


@dataclass
class NativePdProducer:
    owner: NPUModelRunner
    scheduler: Scheduler
    structured_output_manager: StructuredOutputManager


def run_native_pd_producer(args, config, storage, active, report, deadline):
    # Runtime imports are confined to the supervised P process.
    import torch
    from hccl_native_attention_pd_model_probe import build_pd_attention_owner
    from hccl_native_attention_pd_probe import (
        HEAD_SIZE,
        LAYER_COUNT,
        await_peer_record,
        snapshot_pages,
        write_json,
    )
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from hccl_native_attention_probe import ROUTER_DELTA, ROUTER_SCALE
    from torch import nn
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm.v1.worker.gpu.async_utils import AsyncOutput
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    detail = report["native_pd_producer"] = {
        "passed": False,
        "attention_reads": [],
        "original_prompt_token_ids": list(PRODUCER_ORIGINAL_PROMPT),
        "checkpoint_weights_loaded": False,
        "native_sparse_fa_executed": False,
        "full_model_accepted": False,
        "normal_worker_constructor_executed": False,
        "controlled_prefill_reads_fresh_zeroed_cache": True,
    }

    class LocalArithmeticMoE(nn.Module):
        def forward(
            self,
            hidden_states,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel=False,
        ):
            assert not already_sequence_parallel
            assert hidden_states.dtype == torch.bfloat16
            assert hidden_states_fp32.dtype == torch.float32
            return (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()

    source_id = args.run_id + "-source"
    with torch.inference_mode(), torch_cuda_wrapper():
        owner, embedding = build_pd_attention_owner(
            config,
            storage,
            active,
            None,
            torch.device("npu", args.device),
            report,
            write_cache=True,
            native_producer=True,
            producer_aux=args.producer_aux,
        )
        for layer in owner.model.language_model.model.layers:
            layer.mlp = LocalArithmeticMoE()
        detail["runner_class"] = type(owner).__module__ + "." + type(owner).__qualname__
        config.cache_config.num_gpu_blocks = storage.kv_cache_config.num_blocks
        structured = StructuredOutputManager(config)
        scheduler = native_scheduler.Scheduler(
            config,
            storage.kv_cache_config,
            structured,
            block_size=config.cache_config.block_size,
            hash_block_size=config.cache_config.block_size,
        )
        idle_usage = scheduler.kv_cache_manager.usage
        detail["kv_usage_before_request"] = idle_usage
        request = Request(
            source_id,
            list(PRODUCER_ORIGINAL_PROMPT),
            SamplingParams(
                temperature=0,
                max_tokens=PRODUCER_REQUEST_MAX_TOKENS,
                extra_args={
                    "kv_transfer_params": {
                        "do_remote_prefill": False,
                        "do_remote_decode": True,
                    }
                },
            ),
            None,
        )
        scheduler.add_request(request)
        assert request.prompt_token_ids == list(PRODUCER_ORIGINAL_PROMPT[:-1])
        assert request.max_tokens == 1
        detail["native_truncated_prompt_token_ids"] = list(request.prompt_token_ids)
        detail["native_max_tokens"] = request.max_tokens
        step = scheduler.schedule()
        detail["prefill_schedule"] = scheduler_record(step)
        admitted = step.scheduled_new_reqs[0]
        assert admitted.req_id == source_id and admitted.num_computed_tokens == 0
        assert step.num_scheduled_tokens == {source_id: len(request.prompt_token_ids)}
        assert owner.execute_model(step) is None
        state = owner.execute_model_state
        batch = state.input_batch
        ids, positions = batch.input_ids.cpu().tolist(), batch.positions.cpu().tolist()
        assert ids == request.prompt_token_ids and positions == list(range(len(ids)))
        expected = embedding[ids].clone()
        expected_pools = [
            bytearray((args.output_dir / e["path"]).read_bytes())
            for e in report["before"]
        ]
        # The native scheduler's fresh global IDs own complete physical tiles,
        # including overlaid compressed KV, index scales, state and SWA bytes.
        # Derive the oracle from its descriptor contract, independently of the
        # adapter's segment construction or private native zeroer metadata.
        zero_regions = []
        zero_carriers = {
            name: type(
                config.compilation_config.static_forward_context[name].kv_cache
            ).__name__
            for descriptor in storage.kv_cache_config.kv_cache_tensors
            for name in descriptor.layers
        }
        assert step.new_block_ids_to_zero
        for pool, descriptor in enumerate(storage.kv_cache_config.kv_cache_tensors):
            for block in step.new_block_ids_to_zero:
                offset = block * descriptor.block_stride
                length = descriptor.block_stride
                assert 0 <= offset <= descriptor.size - length
                expected_pools[pool][offset : offset + length] = bytes(length)
                zero_regions.append(
                    {
                        "pool": pool,
                        "block_id": block,
                        "byte_offset": offset,
                        "length": length,
                    }
                )
        detail["native_zero_block_ids"] = step.new_block_ids_to_zero
        detail["native_zero_cache_carriers"] = zero_carriers
        detail["physical_tile_zeroing_required"] = True
        detail["fresh_block_zeroing_accepted"] = False
        detail["expected_zero_regions"] = zero_regions
        writes = []
        expected_aux = []
        for layer_index in range(LAYER_COUNT):
            if args.producer_aux:
                # Each controlled HC channel carries this same independent
                # entering residual. Native forward produces mean(dim=1).
                expected_aux.append(expected.clone())
            name = f"model.layers.{layer_index}.self_attn.swa_cache"
            group = next(
                i
                for i, g in enumerate(storage.kv_cache_config.kv_cache_groups)
                if name in g.layer_names
            )
            block = admitted.block_ids[group][0]
            pool = next(
                i
                for i, p in enumerate(storage.kv_cache_config.kv_cache_tensors)
                if name in p.layers
            )
            descriptor = storage.kv_cache_config.kv_cache_tensors[pool]
            raw, cache = storage.raw_tensors[descriptor.layers[0]], storage.caches[name]
            offset, strides = cache.data_ptr() - raw.data_ptr(), cache.stride()
            initial_layer = bytes(expected_pools[pool])
            previous = torch.empty_like(expected)
            for row, position in enumerate(positions):
                read_at = offset + BF16_BYTES * (
                    block * strides[0] + max(0, position - 1) * strides[1]
                )
                write_at = offset + BF16_BYTES * (
                    block * strides[0] + position * strides[1]
                )
                previous[row] = torch.frombuffer(
                    bytearray(
                        initial_layer[read_at : read_at + HEAD_SIZE * BF16_BYTES]
                    ),
                    dtype=torch.bfloat16,
                )
                value = expected[row].view(torch.uint8).numpy().tobytes()
                expected_pools[pool][write_at : write_at + len(value)] = value
                writes.append(
                    {
                        "layer": layer_index,
                        "pool": pool,
                        "position": position,
                        "byte_offset": write_at,
                        "value_hex": value.hex(),
                    }
                )
            attended = (
                expected.float() + previous.float() + torch.tensor(positions)[:, None]
            ).bfloat16()
            residual = (expected.float() + attended.float()).bfloat16()
            router = residual.float() + ROUTER_DELTA
            remote = (
                residual.float()
                + (router - residual.float()) * ROUTER_SCALE
                + torch.tensor(ids)[:, None].float()
            ).bfloat16()
            expected = (residual.float() + remote.float()).bfloat16()
        actual = state.hidden_states.cpu()
        detail["numeric_observation"] = {
            "actual": actual.float().tolist(),
            "expected": expected.float().tolist(),
            "input_ids": ids,
            "positions": positions,
        }
        torch.testing.assert_close(actual, expected, rtol=0, atol=0)
        pages = snapshot_pages(storage, args.output_dir, label="producer-generated")
        for index, page in enumerate(pages):
            assert (args.output_dir / page["path"]).read_bytes() == expected_pools[
                index
            ]
            page["expected_sha256"] = hashlib.sha256(expected_pools[index]).hexdigest()
        detail.update(
            fresh_block_zeroing_accepted=True,
            native_prefill_executed=True,
            input_ids=ids,
            positions=positions,
            hidden_states=actual.float().tolist(),
            hidden_sha256=hashlib.sha256(
                actual.view(torch.uint8).numpy().tobytes()
            ).hexdigest(),
            cache_writes=writes,
            generated_pages=pages,
        )
        aux_snapshot = None
        if args.producer_aux:
            from hccl_native_attention_pd_aux_probe import observe_native_pd_aux

            assert config.speculative_config is None and owner.speculator is None
            assert owner.execute_model_state is state
            aux_snapshot = observe_native_pd_aux(
                state,
                tuple(expected_aux),
                source_request_id=source_id,
                input_ids=ids,
                positions=positions,
                output_dir=args.output_dir,
                report=report,
            )
        sampled = owner.sample_tokens(None)
        assert isinstance(sampled, AsyncOutput)
        returned = sampled.get_output()
        assert returned.req_ids == [source_id]
        assert returned.sampled_token_ids == [[PRODUCER_SAMPLE_TOKEN]]
        if args.producer_aux:
            from hccl_native_attention_pd_aux_probe import (
                verify_native_pd_aux_after_sample,
            )

            verify_native_pd_aux_after_sample(owner, aux_snapshot, report=report)
        outputs = scheduler.update_from_output(step, returned)
        engine_outputs = [
            item for client in outputs.values() for item in client.outputs
        ]
        assert len(engine_outputs) == 1 and engine_outputs[0].request_id == source_id
        assert engine_outputs[0].finished
        assert engine_outputs[0].new_token_ids == [PRODUCER_SAMPLE_TOKEN]
        exported = engine_outputs[0].kv_transfer_params
        assert exported["remote_request_id"] == source_id
        assert exported["last_token_id"] == PRODUCER_SAMPLE_TOKEN
        assert exported["remote_block_ids"] == tuple(
            list(b) for b in admitted.block_ids
        )
        assert request.status == RequestStatus.FINISHED_LENGTH_CAPPED
        assert scheduler.requests[source_id] is request
        held = tuple(
            tuple(b) for b in scheduler.kv_cache_manager.get_block_ids(source_id)
        )
        assert held == tuple(tuple(b) for b in admitted.block_ids)
        detail.update(
            sampled_token_ids=returned.sampled_token_ids,
            engine_output_transfer_params=exported,
            request_status_after_sample=request.status.name,
            blocks_retained_after_sample=held,
            computed_prefix_tokens=request.num_prompt_tokens,
            engine_output_new_token_ids=engine_outputs[0].new_token_ids,
            engine_output_finish_reason=engine_outputs[0].finish_reason.name,
            kv_usage_while_retained=scheduler.kv_cache_manager.usage,
        )
        assert scheduler.kv_cache_manager.usage > idle_usage
        report["request_mapping"] = {
            "source_request_id": source_id,
            "source_block_ids": exported["remote_block_ids"],
            "source_blocks_chosen_by_native_scheduler": True,
            "num_groups": len(admitted.block_ids),
        }
        send_step = scheduler.schedule()
        assert not send_step.total_num_scheduled_tokens
        assert send_step.finished_req_ids == {source_id}
        assert set(send_step.kv_connector_metadata.requests_to_send) == {source_id}
        detail["send_registration_schedule"] = scheduler_record(send_step)
        detail["native_send_registration_request_ids"] = sorted(
            send_step.kv_connector_metadata.requests_to_send
        )
        sent_output = owner.execute_model(send_step)
        assert isinstance(sent_output, ModelRunnerOutput) and not sent_output.req_ids
        assert (
            not owner.req_states.req_id_to_index and owner.execute_model_state is None
        )
        assert source_id in scheduler.requests
        scheduler.update_from_output(send_step, sent_output)
        write_json(
            args.output_dir / "producer-ready.json",
            {
                "run_id": args.run_id,
                **report["handshake"],
                "source_transfer_params": exported,
                "source_pages": pages,
                "original_prompt_token_ids": PRODUCER_ORIGINAL_PROMPT,
                "computed_prefix_tokens": request.num_prompt_tokens,
            },
        )
        detail["zero_work_steps"] = []
        while source_id in scheduler.requests:
            if time.monotonic() >= deadline:
                raise TimeoutError("native P source did not retire after real DONE")
            time.sleep(POLL_SECONDS)
            poll = scheduler.schedule()
            assert not poll.total_num_scheduled_tokens
            output = owner.execute_model(poll)
            assert isinstance(output, ModelRunnerOutput) and not output.req_ids
            kv = output.kv_connector_output
            sent = set(() if kv is None else kv.finished_sending or ())
            assert not sent or sent == {source_id}
            assert kv is None or not (
                kv.finished_recving or kv.failed_recving or kv.invalid_block_ids
            )
            before_blocks = scheduler.kv_cache_manager.get_block_ids(source_id)
            assert tuple(tuple(b) for b in before_blocks) == tuple(
                tuple(b) for b in held
            )
            scheduler.update_from_output(poll, output)
            detail["zero_work_steps"].append(
                {"schedule": scheduler_record(poll), "finished_sending": sorted(sent)}
            )
            if sent:
                report["native_done_observed"] = True
        assert not scheduler.kv_cache_manager.get_block_ids(source_id)[0]
        assert report["native_done_observed"]
        assert scheduler.kv_cache_manager.usage == idle_usage
        detail["kv_usage_after_done"] = scheduler.kv_cache_manager.usage
        detail["native_request_and_blocks_retired_after_done"] = True
        detail["passed"] = True
        await_peer_record(
            args.output_dir / "consumer-verified.json",
            run_id=args.run_id,
            deadline=deadline,
        )
        return NativePdProducer(owner, scheduler, structured)
