# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Supervised live native P sample/propose -> typed Ready -> real TE read.

The default and --help import only the standard library. --run starts three
owned processes; runtime dependencies are imported only inside those workers.
The target/FFN arithmetic is controlled. The real native draft decoder, public
sampling, prefix consumer, agreement and transfer protocol are not replaced.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
import uuid
from contextlib import ExitStack
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hccl_native_attention_pd_dspark_ready_probe import ReadyFrontierObserver

PROMPT = (11, 12, 13, 14, 15)
POLL_SECONDS = 0.1
DEFAULT_TIMEOUT = 360
RETENTION_TIMEOUT = 720
GROUP_TIMEOUT = 60
GREEDY_TOKEN = 7
SOURCE_PATTERN = 0x3F00


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def await_record(path: Path, run_id: str, deadline: float) -> dict:
    while not path.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError(f"missing peer observation: {path.name}")
        time.sleep(POLL_SECONDS)
    result = json.loads(path.read_text())
    assert result["run_id"] == run_id
    return result


def save_tensor(tensor, path: Path) -> dict:
    import torch

    value = tensor.detach().contiguous().cpu()
    raw = value.reshape(-1).view(torch.uint8).numpy().tobytes()
    path.write_bytes(raw)
    return {
        "path": path.name,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "shape": list(value.shape),
        "dtype": str(value.dtype),
        "data_ptr": tensor.data_ptr(),
        "storage_offset": tensor.storage_offset(),
        "stride": list(tensor.stride()),
    }


def physical_pages(bindings):
    """Expose complete real registered descriptor spans, including view offsets."""
    import torch

    from afd_plugin.compat.npu.kv_layout_native import collect_deepseek_v41_kv_layout

    layout = collect_deepseek_v41_kv_layout(bindings.kv_config, bindings.caches)
    pages = []
    for descriptor, page in zip(
        bindings.kv_config.kv_cache_tensors, layout.pages, strict=True
    ):
        cache = bindings.caches[descriptor.layers[0]]
        tensor = cache if isinstance(cache, torch.Tensor) else cache[0]
        raw = torch.empty(0, dtype=torch.uint8, device=tensor.device).set_(
            tensor.untyped_storage(),
            page.storage_offset_bytes,
            (page.size_bytes,),
            (1,),
        )
        assert raw.data_ptr() == (
            tensor.untyped_storage().data_ptr() + page.storage_offset_bytes
        )
        pages.append(raw)
    return layout, pages


def snapshot_pages(pages, directory: Path, stem: str) -> list[dict]:
    return [
        save_tensor(page, directory / f"{stem}-pool-{index}.bin")
        for index, page in enumerate(pages)
    ]


def run_prefill(
    args,
    bindings,
    report: dict,
    deadline: float,
    *,
    ready_observer: ReadyFrontierObserver | None = None,
) -> None:
    """Execute the actual public P frontier and retain original parent tensors."""
    import torch
    from hccl_native_attention_pd_aux_probe import batch_coordinates
    from hccl_native_attention_pd_dspark_probe import ROUTER_DELTA, ROUTER_SCALE
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    from afd_plugin.compat.npu.kv_layout_connector import DSPARK_SOURCE_PARAM

    owner = bindings.owner
    config = owner.vllm_config
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    structured = StructuredOutputManager(config)
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        structured,
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    request_id = args.run_id + "-source"
    request = Request(
        request_id,
        list(PROMPT),
        SamplingParams(
            temperature=0,
            max_tokens=3,
            extra_args={
                "kv_transfer_params": {
                    "do_remote_prefill": False,
                    "do_remote_decode": True,
                }
            },
        ),
        None,
    )
    idle_usage = scheduler.kv_cache_manager.usage
    scheduler.add_request(request)
    assert request.prompt_token_ids == list(PROMPT[:-1]) and request.max_tokens == 1
    step = scheduler.schedule()
    report["prefill_schedule"] = scheduler_record(step)
    assert step.num_scheduled_tokens == {request_id: len(PROMPT) - 1}
    assert len(step.scheduled_new_reqs) == 1
    admitted = step.scheduled_new_reqs[0]
    blocks = tuple(tuple(ids) for ids in admitted.block_ids)
    # One actual allocator, with all target and draft groups preserved.
    assert len(blocks) == len(bindings.kv_config.kv_cache_groups)
    assert all(ids and all(value > 0 for value in ids) for ids in blocks)
    report["allocation_block_ids"] = blocks
    if ready_observer is not None:
        ready_observer.bind_source(step)
    from hccl_native_attention_pd_dspark_decode_probe import target_reference

    layout, pages = physical_pages(bindings)
    before_target = [bytes(page.cpu().numpy()) for page in pages]
    oracle_hidden, oracle_aux, oracle_pages, oracle_layers = target_reference(
        bindings, pages, before_target, blocks, PROMPT[:-1],
        tuple(range(len(PROMPT) - 1)), step.new_block_ids_to_zero
    )
    report["independent_layer_oracles"] = oracle_layers
    report["before_target"] = snapshot_pages(
        pages, args.output_dir, "producer-before-target"
    )
    assert owner.execute_model(step) is None
    assert [bytes(page.cpu().numpy()) for page in pages] == oracle_pages
    report["after_target"] = snapshot_pages(
        pages, args.output_dir, "producer-after-target"
    )
    report["whole_pool_target_write_oracle_accepted"] = True
    if ready_observer is not None:
        ready_observer.execute_returned()
    state = owner.execute_model_state
    assert state is not None and state.aux_hidden_states is not None
    coords = batch_coordinates(state)
    assert coords["input_ids"] == list(PROMPT[:-1])
    assert coords["positions"] == list(range(len(PROMPT) - 1))
    assert coords["num_computed_tokens"] == [0]
    assert coords["prefill_lengths"] == [len(PROMPT) - 1]
    assert len(state.aux_hidden_states) == 2
    assert torch.equal(state.hidden_states.cpu(), oracle_hidden)
    assert all(torch.equal(actual.cpu(), expected) for actual, expected in
               zip(state.aux_hidden_states, oracle_aux, strict=True))
    report["original_state_identity"] = id(state)
    report["original_batch_identity"] = id(state.input_batch)
    report["batch_before_sample"] = coords
    actual_aux, contents = [], []
    expected = bindings.embedding_cpu[list(PROMPT[:-1])].clone()
    position = torch.arange(len(PROMPT) - 1, device="cpu")[:, None]
    for index, actual in enumerate(state.aux_hidden_states):
        assert actual.dtype == torch.bfloat16
        assert torch.equal(actual.cpu(), expected)
        actual_aux.append(
            save_tensor(actual, args.output_dir / f"producer-aux-{index}.bin")
        )
        contents.append(actual.clone())
        save_tensor(expected, args.output_dir / f"expected-aux-{index}.bin")
        # Fresh selected physical pages are zeroed by the real native adapter;
        # this vectorized target Attention reads all prior positions before its
        # one write. The two controlled HC residual updates are explicit here.
        attention = (expected.float() + position).bfloat16()
        residual = (expected.float() + attention.float()).bfloat16()
        router = residual.float() + ROUTER_DELTA
        moe = (
            residual.float()
            + (router - residual.float()) * ROUTER_SCALE
            + torch.tensor(PROMPT[:-1], device="cpu")[:, None]
        ).bfloat16()
        expected = (residual.float() + moe.float()).bfloat16()
    assert torch.equal(state.hidden_states.cpu(), expected)
    report["target_output"] = save_tensor(
        state.hidden_states, args.output_dir / "producer-target-output.bin"
    )
    save_tensor(expected, args.output_dir / "expected-target-output.bin")
    report["auxiliary_states"] = actual_aux
    # Production sample retains this original state while native sample clears
    # owner.execute_model_state and performs real draft proposal + post-forward.
    returned = owner.sample_tokens(None)
    assert isinstance(returned, AsyncOutput)
    output = returned.get_output()
    assert isinstance(output, ModelRunnerOutput)
    assert output.req_ids == [request_id] and output.sampled_token_ids == [
        [GREEDY_TOKEN]
    ]
    assert owner.execute_model_state is None
    assert owner._dspark_pd_pending_scheduler is None
    assert not owner.dspark_pd_consumer.terminal
    assert owner.speculator.input_batch is state.input_batch
    assert batch_coordinates(state) == coords
    for actual, saved in zip(state.aux_hidden_states, contents, strict=True):
        assert torch.equal(actual, saved)
    report["batch_after_sample"] = batch_coordinates(state)
    report["auxiliary_after_sample"] = [
        save_tensor(value, args.output_dir / f"producer-aux-after-{index}.bin")
        for index, value in enumerate(state.aux_hidden_states)
    ]
    report["draft_tokens_after_native_proposal"] = (
        owner.req_states.draft_tokens.cpu().tolist()
    )
    report["sampled_token_ids"] = output.sampled_token_ids
    report["native_sample_and_proposal_returned"] = True
    report["native_proposal_batch_identity"] = id(owner.speculator.input_batch)
    report["native_proposal_input_ids"] = (
        owner.speculator.input_buffers.input_ids[:2].cpu().tolist()
    )
    report["native_proposal_positions"] = (
        owner.speculator.input_buffers.positions[:2].cpu().tolist()
    )
    if ready_observer is None:
        report["ready_before_sample_observed"] = "not_observed"
    report["proposal_failure_frontier_accepted"] = False
    engine_outputs = scheduler.update_from_output(step, output)
    envelopes = [item for batch in engine_outputs.values() for item in batch.outputs]
    assert len(envelopes) == 1 and envelopes[0].request_id == request_id
    assert envelopes[0].finished and envelopes[0].new_token_ids == [GREEDY_TOKEN]
    params = envelopes[0].kv_transfer_params
    assert DSPARK_SOURCE_PARAM in params
    assert params["remote_request_id"] == request_id
    assert tuple(tuple(ids) for ids in params["remote_block_ids"]) == blocks
    assert request.status == RequestStatus.FINISHED_LENGTH_CAPPED
    assert scheduler.requests[request_id] is request
    assert scheduler.kv_cache_manager.usage > idle_usage
    report["engine_output_transfer_params"] = params
    report["held_after_sample"] = blocks
    layout, pages = physical_pages(bindings)
    report["after_sample"] = snapshot_pages(pages, args.output_dir, "producer-after")
    report["layout"] = json.loads(layout.to_json())
    send = scheduler.schedule()
    assert send.total_num_scheduled_tokens == 0
    assert send.finished_req_ids == {request_id}
    assert set(send.kv_connector_metadata.requests_to_send) == {request_id}
    returned = owner.execute_model(send)
    assert isinstance(returned, ModelRunnerOutput) and not returned.req_ids
    scheduler.update_from_output(send, returned)
    write_json(
        args.output_dir / "producer-ready.json",
        {
            "run_id": args.run_id,
            "source_transfer_params": params,
            "source_pages": report["after_sample"],
            "source_layout": report["layout"],
            "draft_weights": report["draft_weights"],
            **report["handshake"],
        },
    )
    report["poll_steps"] = []
    while request_id in scheduler.requests:
        if time.monotonic() >= deadline:
            raise TimeoutError("P typed lease/DONE did not retire")
        poll = scheduler.schedule()
        assert poll.total_num_scheduled_tokens == 0
        returned = owner.execute_model(poll)
        assert isinstance(returned, ModelRunnerOutput)
        kv = returned.kv_connector_output
        sent = set(() if kv is None else kv.finished_sending or ())
        assert sent <= {request_id}
        assert kv is None or not (kv.failed_recving or kv.invalid_block_ids)
        scheduler.update_from_output(poll, returned)
        report["poll_steps"].append(
            {"schedule": scheduler_record(poll), "finished_sending": sorted(sent)}
        )
        if sent:
            report["typed_done_observed"] = True
        time.sleep(POLL_SECONDS)
    assert report["typed_done_observed"]
    assert scheduler.kv_cache_manager.usage == idle_usage
    assert not owner.req_states.req_id_to_index
    await_record(args.output_dir / "consumer-verified.json", args.run_id, deadline)
    owner.prepare_shutdown()
    report["stop_returned"] = True
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown

    ensure_kv_transfer_shutdown()
    scheduler.shutdown()
    owner.shutdown()
    report["native_owner_shutdown_returned"] = True


def run_read(args, bindings, report: dict, deadline: float) -> None:
    """Actual D scheduler/ActiveKV read; stop before any D target execution."""
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.distributed.kv_transfer import ensure_kv_transfer_shutdown
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager

    from afd_plugin.compat.npu.kv_layout_connector import (
        DSPARK_SOURCE_PARAM,
        DsparkMooncakeConnectorMetadata,
    )

    peer = await_record(args.output_dir / "producer-ready.json", args.run_id, deadline)
    assert report["draft_weights"] == peer["draft_weights"]
    owner, config = bindings.owner, bindings.owner.vllm_config
    config.cache_config.num_gpu_blocks = bindings.kv_config.num_blocks
    structured = StructuredOutputManager(config)
    scheduler = native_scheduler.Scheduler(
        config,
        bindings.kv_config,
        structured,
        block_size=config.cache_config.block_size,
        hash_block_size=config.cache_config.block_size,
    )
    params = dict(peer["source_transfer_params"])
    params["remote_block_ids"] = tuple(list(ids) for ids in params["remote_block_ids"])
    assert DSPARK_SOURCE_PARAM in params
    assert params["remote_engine_id"] == peer["engine_id"]
    assert params["remote_host"] == peer["host"]
    assert params["remote_port"] == peer["port"]
    request_id = args.run_id + "-destination"
    request = Request(
        request_id,
        list(PROMPT),
        SamplingParams(
            temperature=0,
            max_tokens=1,
            extra_args={"kv_transfer_params": params},
        ),
        None,
    )
    scheduler.add_request(request)
    step = scheduler.schedule()
    report["first_schedule"] = scheduler_record(step)
    assert step.total_num_scheduled_tokens == 0 and not step.has_sync_kv_loads
    assert request.status == RequestStatus.WAITING_FOR_REMOTE_KVS
    metadata = step.kv_connector_metadata
    assert isinstance(metadata, DsparkMooncakeConnectorMetadata)
    assert set(metadata.requests) == set(metadata.dspark_destinations) == {request_id}
    transfer = metadata.requests[request_id]
    report["destination"] = asdict(metadata.dspark_destinations[request_id])
    assert transfer.num_external_tokens == len(PROMPT) - 1
    pairs = tuple(
        tuple(zip(source, destination, strict=True))
        for source, destination in zip(
            transfer.remote_block_ids, transfer.local_block_ids, strict=True
        )
    )
    report["group_block_pairs"] = pairs
    assert all(group for group in pairs)
    completed = set()
    report["zero_steps"] = []
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("D typed Ready/lease/read/DONE did not complete")
        assert step.total_num_scheduled_tokens == 0
        # Original native ActiveKV pre/no/post path. No synthesized output or
        # early finished result is passed to Scheduler.update_from_output.
        returned = owner.kv_connector.no_forward(step)
        assert isinstance(returned, ModelRunnerOutput)
        kv = returned.kv_connector_output
        received = set(() if kv is None else kv.finished_recving or ())
        assert received <= {request_id}
        assert kv is None or not (
            kv.finished_sending or kv.failed_recving or kv.invalid_block_ids
        )
        completed.update(received)
        report["zero_steps"].append(
            {"schedule": scheduler_record(step), "finished_recving": sorted(received)}
        )
        scheduler.update_from_output(step, returned)
        step = scheduler.schedule()
        if step.total_num_scheduled_tokens:
            report["first_target_schedule"] = scheduler_record(step)
            report["first_target_speculative_tokens"] = dict(
                step.scheduled_spec_decode_tokens
            )
            assert completed == {request_id}
            # Native synchronous N2 scheduling pads a restored one-token
            # query to N+1 rows. Preserve the original schedule and its draft
            # placeholders; this read-only D component does not execute them.
            assert step.num_scheduled_tokens == {
                request_id: config.num_speculative_tokens + 1
            }
            assert step.scheduled_spec_decode_tokens == {
                request_id: [-1] * config.num_speculative_tokens
            }
            break
        time.sleep(POLL_SECONDS)
    layout, pages = physical_pages(bindings)
    report["layout"] = json.loads(layout.to_json())
    after = snapshot_pages(pages, args.output_dir, "consumer-after")
    report["after_read"] = after
    source_layout = peer["source_layout"]
    # Each descriptor is one real complete physical pool; several logical
    # groups may alias it. Require all of their true block pairs to agree.
    for index, descriptor in enumerate(bindings.kv_config.kv_cache_tensors):
        source_page = source_layout["pages"][index]
        assert source_page["layers"] == list(descriptor.layers)
        assert source_page["block_stride_bytes"] == descriptor.block_stride
        expected = bytearray(
            (args.output_dir / report["before"][index]["path"]).read_bytes()
        )
        source = (args.output_dir / peer["source_pages"][index]["path"]).read_bytes()
        mapping = {}
        for group_id, group in enumerate(bindings.kv_config.kv_cache_groups):
            if set(group.layer_names).intersection(descriptor.layers):
                for remote, local in pairs[group_id]:
                    assert mapping.setdefault(local, remote) == remote
        for local, remote in mapping.items():
            size = descriptor.block_stride
            expected[local * size : (local + 1) * size] = source[
                remote * size : (remote + 1) * size
            ]
        actual = (args.output_dir / after[index]["path"]).read_bytes()
        assert actual == expected
        report.setdefault("whole_pool_oracles", []).append(
            {
                "pool": index,
                "mapping": mapping,
                "sha256": hashlib.sha256(expected).hexdigest(),
            }
        )
    # The first target is deliberately unexecuted. Native abort retires the
    # scheduled request; this component does not claim D target/sample serving.
    scheduler.finish_requests(request_id, RequestStatus.FINISHED_ABORTED)
    retirement = scheduler.schedule()
    assert retirement.total_num_scheduled_tokens == 0
    returned = owner.kv_connector.no_forward(retirement)
    scheduler.update_from_output(retirement, returned)
    report["retirement_schedule"] = scheduler_record(retirement)
    receiver = owner.kv_connector.kv_connector.connector_worker.kv_recv_thread
    assert receiver.is_alive() and not receiver.retired
    ensure_kv_transfer_shutdown()
    assert receiver.retired and not receiver.is_alive()
    scheduler.shutdown()
    report["receiver_retired"] = True
    report["d_target_executed"] = False
    report["typed_read_and_whole_pool_oracle_passed"] = True
    write_json(args.output_dir / "consumer-verified.json", {"run_id": args.run_id})


def run_ffn(
    config,
    device,
    report: dict,
    deadline: float,
    *,
    expected_input_batches: tuple[tuple[int, ...], ...] | None = None,
) -> None:
    """Original F daemon/runner with controlled arithmetic and original N2 shape."""
    import threading

    import torch
    from hccl_native_attention_pd_dspark_probe import ROUTER_SCALE
    from vllm.forward_context import get_forward_context
    from vllm_ascend.ascend_forward_context import set_mc2_mask, set_mc2_tokens_capacity

    from afd_plugin.compat.npu.runtime_config import (
        get_npu_ffn_config,
        resolve_deepseek_v41_target_shape,
    )
    from afd_plugin.compat.patches.npu.ascend_config import init_ascend_config
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import create_npu_runtime_connector
    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner
    from afd_plugin.v1.worker.npu.ffn_worker import AFDNPUFFNWorker

    shape = resolve_deepseek_v41_target_shape(config)
    assert shape.target_query_len == 3
    isolated = get_npu_ffn_config(config)
    assert isolated.speculative_config is isolated.kv_transfer_config is None
    assert isolated.engram_config is None
    init_ascend_config(isolated)
    connector = create_npu_runtime_connector(
        0,
        device.index,
        isolated,
        parse_afd_config(isolated),
        target_shape=shape,
        overlap_settings=HcclOverlapSettings(eager_u2_stream_overlap=False),
    )
    management_thread = threading.get_ident()
    detail = report["native_ffn"] = {
        "original_target_shape": asdict(shape),
        "isolated_speculative_config": None,
        "isolated_pd_config": None,
        "full_ffn_constructor_executed": False,
        "native_moe_executed": False,
        "steps": [],
    }

    class ControlledFFN(torch.nn.Module):
        def get_experts_layer_indices(self):
            return connector.target_layer_indices

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel=False,
        ):
            assert not already_sequence_parallel
            assert threading.get_ident() != management_thread
            context = get_forward_context()
            metadata = context.additional_kwargs["afd_metadata"]
            assert context.additional_kwargs["model_instance"] is self
            assert metadata.connector is connector
            assert (
                metadata.transaction_id == connector.active_forward_plan.transaction_id
            )
            assert metadata.num_stages == 1 and metadata.stage_idx == 0
            assert hidden_states.dtype == torch.bfloat16
            assert hidden_states_fp32.dtype == torch.float32
            assert input_ids.dtype == torch.int32
            detail["steps"].append(
                {
                    "transaction_id": metadata.transaction_id,
                    "layer": layer_idx,
                    "thread_id": threading.get_ident(),
                    "input_ids": input_ids.cpu().tolist(),
                    "hidden": hidden_states.float().cpu().tolist(),
                    "router_fp32": hidden_states_fp32.cpu().tolist(),
                }
            )
            return (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()

    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = isolated, isolated.model_config
    runner.device, runner.connector, runner.target_shape = device, connector, shape
    runner.model, runner.prof = ControlledFFN(), None
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = runner.hccl_v41_eager_bootstrap = None
    set_mc2_tokens_capacity(isolated, isolated.scheduler_config.max_num_seqs, 1)
    set_mc2_mask(isolated, device)
    worker = AFDNPUFFNWorker.__new__(AFDNPUFFNWorker)
    worker.vllm_config, worker.model_runner, worker.device = isolated, runner, device
    worker.local_rank, worker.rank, worker.profiler_config = device.index, 0, None
    worker.target_shape = shape
    worker._ffn_thread = worker._ffn_shutdown_event = worker._ffn_loop_error = None
    worker._hccl_stop_received = worker._hccl_configuration_logged = False
    worker._hccl_v41_transport = None
    worker._cpu_binding_attempted = False
    worker.start_ffn_server_loop()
    while worker.poll_hccl_ffn_service():
        if time.monotonic() >= deadline:
            raise TimeoutError("live prefix F daemon exceeded deadline")
        time.sleep(POLL_SECONDS)
    worker.stop_ffn_server_loop()
    assert worker._hccl_stop_received and worker._ffn_thread is None
    batches = (
        (PROMPT[:-1],) if expected_input_batches is None else expected_input_batches
    )
    assert len(detail["steps"]) == 2 * len(batches)
    assert [step["layer"] for step in detail["steps"]] == [0, 1] * len(batches)
    assert [step["input_ids"] for step in detail["steps"]] == [
        list(batch) for batch in batches for _ in range(2)
    ]
    detail["stop_acknowledged"] = True
    detail["native_daemon_retired"] = True


def run_worker(args) -> None:
    report = {
        "run_id": args.run_id,
        "role": args.role,
        "success": False,
        "full_model_accepted": False,
        "full_worker_accepted": False,
        "model_admission_accepted": False,
        "engram_accepted": False,
        "graph_accepted": False,
        "u2_accepted": False,
        "performance_accepted": False,
        "ready_frontier": {
            "status": (
                "not_reached"
                if args.observe_ready_frontier and args.role == "kv_producer"
                else "not_requested"
            )
        },
        "ready_before_sample_observed": (
            "not_reached"
            if args.observe_ready_frontier and args.role == "kv_producer"
            else "not_observed"
        ),
    }
    runtime_imported = False
    try:
        from dsv41_dspark_speculator_probe import NATIVE_PLUGINS

        # Worker-local isolation matches the standalone native components;
        # CANN, ATB, native OPP and library paths remain caller-owned.
        for name in tuple(os.environ):
            if name.startswith(("AFD_", "VLLM_", "MOONCAKE_", "ENGRAM_")):
                del os.environ[name]
        os.environ.update(
            VLLM_PLUGINS=NATIVE_PLUGINS,
            VLLM_USE_V2_MODEL_RUNNER="1",
            VLLM_WORKER_MULTIPROC_METHOD="spawn",
            VLLM_ASCEND_ENABLE_FLASHCOMM1="0",
            VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT=str(RETENTION_TIMEOUT),
        )
        import msgspec
        import torch
        import torch_npu  # noqa: F401
        from dsv41_dspark_projection_model_probe import native_projection_world
        from dsv41_dspark_speculator_probe import SEED
        from hccl_native_attention_pd_dspark_owner_probe import (
            build_native_live_prefix_owner,
        )
        from hccl_native_attention_pd_dspark_probe import create_live_prefix_config
        from vllm.config import set_current_vllm_config
        from vllm.platforms import current_platform

        current_platform.pre_register_and_update()
        from vllm.plugins import load_general_plugins
        from vllm_ascend.utils import (
            adapt_patch,
            enable_custom_op,
            register_ascend_customop,
        )
        from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

        load_general_plugins()
        adapt_patch()
        device = torch.device("npu", args.device)
        torch.npu.set_device(device)
        runtime_imported = True
        report["custom_ops_enabled"] = enable_custom_op()
        assert report["custom_ops_enabled"]
        torch.manual_seed(SEED)
        role_directory = args.output_dir / args.role
        role_directory.mkdir()
        role = "kv_consumer" if args.role == "kv_consumer" else "kv_producer"
        requested_engine_id = args.run_id + "-" + role
        config = create_live_prefix_config(
            args.model,
            role_directory,
            role=role,
            engine_id=requested_engine_id,
            host=args.host,
            handshake_port=args.handshake_port,
            afd_port=args.afd_port,
            afd_role="ffn" if args.role == "ffn" else "attention",
        )
        report["requested_engine_id"] = requested_engine_id
        report["actual_engine_id"] = config.kv_transfer_config.engine_id
        deadline = time.monotonic() + args.timeout
        with (
            set_current_vllm_config(config),
            torch.inference_mode(),
            torch_cuda_wrapper(),
            native_projection_world(config, device, role_directory, report),
        ):
            register_ascend_customop(config)
            if args.role == "ffn":
                run_ffn(config, device, report, deadline)
            else:
                bindings = build_native_live_prefix_owner(
                    config,
                    device,
                    report,
                    connect_ffn=args.role == "kv_producer",
                )
                layout, pages = physical_pages(bindings)
                report["layout"] = json.loads(layout.to_json())
                for index, page in enumerate(pages):
                    assert page.numel() % 2 == 0
                    # Each full physical span is initialized once; alias views
                    # never overwrite one another with incompatible patterns.
                    page.view(torch.int16).fill_(SOURCE_PATTERN + index)
                torch.npu.synchronize(device)
                report["before"] = snapshot_pages(
                    pages, args.output_dir, args.role + "-before"
                )
                weights = []
                for index, (name, value) in enumerate(
                    bindings.owner.speculator.model.state_dict().items()
                ):
                    assert torch.isfinite(value).all().item()
                    entry = save_tensor(
                        value,
                        args.output_dir / f"{args.role}-draft-weight-{index}.bin",
                    )
                    weights.append(
                        {key: entry[key] for key in ("sha256", "shape", "dtype")}
                        | {"name": name}
                    )
                report["draft_weights"] = weights
                report["draft_weight_files"] = [
                    f"{args.role}-draft-weight-{index}.bin"
                    for index in range(len(weights))
                ]
                handshake = (
                    bindings.owner.kv_connector.kv_connector.get_handshake_metadata()
                )
                assert handshake.engine_id == config.kv_transfer_config.engine_id
                handshake_path = args.output_dir / f"{args.role}-handshake.msgpack"
                handshake_path.write_bytes(msgspec.msgpack.encode(handshake))
                report["handshake"] = {
                    "engine_id": handshake.engine_id,
                    "host": handshake.local_ip,
                    "port": config.kv_transfer_config.kv_port,
                    "path": handshake_path.name,
                    "sha256": hashlib.sha256(handshake_path.read_bytes()).hexdigest(),
                }
                if args.role == "kv_producer":
                    with ExitStack() as observations:
                        ready_observer = None
                        if args.observe_ready_frontier:
                            from hccl_native_attention_pd_dspark_ready_probe import (
                                observe_ready_frontier,
                            )

                            ready_observer = observations.enter_context(
                                observe_ready_frontier(
                                    bindings,
                                    run_id=args.run_id,
                                    host=handshake.local_ip,
                                    port=config.kv_transfer_config.kv_port,
                                    deadline=deadline,
                                    report=report,
                                )
                            )
                        run_prefill(
                            args,
                            bindings,
                            report,
                            deadline,
                            ready_observer=ready_observer,
                        )
                else:
                    run_read(args, bindings, report, deadline)
        report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
        raise
    finally:
        if runtime_imported:
            from dsv41_dspark_speculator_probe import loaded_runtime_libraries

            try:
                report["loaded_runtime_libraries"] = loaded_runtime_libraries()
            except OSError as error:
                report["loaded_runtime_libraries_error"] = {
                    "type": type(error).__name__,
                    "message": str(error),
                }
        write_json(args.output_dir / f"{args.role}.json", report)


def supervise(args) -> dict:
    from hccl_eager_backend_probe import kill_owned, observe_owned
    from hccl_staged_probe import select_port_block

    ports = select_port_block(3)
    run_id = uuid.uuid4().hex
    started = time.monotonic()
    children, owned = {}, {}
    report = {
        "success": False,
        "run_id": run_id,
        "timed_out": False,
        "forced_killed_pids": [],
        "observe_ready_frontier_requested": args.observe_ready_frontier,
    }
    try:
        with ExitStack() as stack:
            for index, role in enumerate(("kv_producer", "kv_consumer", "ffn")):
                log = stack.enter_context((args.output_dir / f"{role}.log").open("wb"))
                command = [
                    sys.executable,
                    "-B",
                    str(Path(__file__).resolve()),
                    "--run",
                    "--worker",
                    "--role",
                    role,
                    "--run-id",
                    run_id,
                    "--device",
                    str(args.devices[index]),
                    "--model",
                    args.model,
                    "--output-dir",
                    str(args.output_dir),
                    "--timeout",
                    str(args.timeout),
                    "--host",
                    args.host,
                    "--handshake-port",
                    str(ports + min(index, 1)),
                    "--afd-port",
                    str(ports + 2),
                ]
                if args.observe_ready_frontier:
                    command.append("--observe-ready-frontier")
                children[role] = subprocess.Popen(
                    command,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                    env=os.environ
                    | {"VLLM_MOONCAKE_ABORT_REQUEST_TIMEOUT": str(RETENTION_TIMEOUT)},
                )
            while any(child.poll() is None for child in children.values()):
                for child in children.values():
                    if child.poll() is None:
                        observe_owned(child.pid, owned)
                write_json(
                    args.output_dir / "ownership.json",
                    {
                        "supervisor_pid": os.getpid(),
                        "workers": {
                            role: child.pid for role, child in children.items()
                        },
                        "owned_pid_start_ticks": {
                            str(pid): ticks for pid, ticks in owned.items()
                        },
                    },
                )
                failures = {
                    role: child.returncode
                    for role, child in children.items()
                    if child.poll() is not None and child.returncode != 0
                }
                if failures:
                    raise RuntimeError(f"live native prefix worker failed: {failures}")
                if time.monotonic() - started >= args.timeout:
                    report["timed_out"] = True
                    raise TimeoutError(
                        "live native prefix supervision exceeded total bound"
                    )
                time.sleep(POLL_SECONDS)
            report["returncodes"] = {
                role: child.returncode for role, child in children.items()
            }
            report["workers"] = {
                role: json.loads((args.output_dir / f"{role}.json").read_text())
                for role in children
            }
            assert all(code == 0 for code in report["returncodes"].values())
            assert all(worker["success"] for worker in report["workers"].values())
            assert report["workers"]["kv_producer"]["typed_done_observed"]
            assert report["workers"]["kv_consumer"][
                "typed_read_and_whole_pool_oracle_passed"
            ]
            assert report["workers"]["ffn"]["native_ffn"]["native_daemon_retired"]
            if args.observe_ready_frontier:
                assert (
                    report["workers"]["kv_producer"]["ready_frontier"]["status"]
                    == "passed"
                )
            report["success"] = True
    except BaseException:
        report["traceback"] = traceback.format_exc()
    finally:
        for child in children.values():
            if child.poll() is None:
                observe_owned(child.pid, owned)
        report["forced_killed_pids"] = kill_owned(owned)
        for child in children.values():
            if child.poll() is None:
                child.wait(timeout=GROUP_TIMEOUT)
        report["elapsed_seconds"] = time.monotonic() - started
        write_json(args.output_dir / "summary.json", report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--devices", default="0,2,4")
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--run", action="store_true")
    parser.add_argument(
        "--observe-ready-frontier",
        action="store_true",
        help="observe exact not-ready replies around original P proposal/publication",
    )
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument(
        "--role", choices=("kv_producer", "kv_consumer", "ffn"), help=argparse.SUPPRESS
    )
    parser.add_argument("--run-id", help=argparse.SUPPRESS)
    parser.add_argument("--device", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--handshake-port", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--afd-port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        args.devices = tuple(int(value) for value in args.devices.split(","))
    except ValueError:
        parser.error("--devices requires three comma-separated device integers")
    if len(args.devices) != 3 or len(set(args.devices)) != 3 or min(args.devices) < 0:
        parser.error("--devices requires three distinct nonnegative device integers")
    if not 0 < args.timeout < RETENTION_TIMEOUT:
        parser.error("--timeout must be positive and below source retention timeout")
    if args.worker and (
        not args.run or not args.run_id or args.device is None or args.role is None
    ):
        parser.error("hidden worker requires --run and complete supervisor identity")
    if not args.run:
        print(
            json.dumps(
                {
                    "run": False,
                    "runtime_imported": False,
                    "observe_ready_frontier_requested": args.observe_ready_frontier,
                    "devices": args.devices,
                    "scope": (
                        "controlled live P/native draft/Ready/TE component; "
                        "explicit --run required"
                    ),
                }
            )
        )
        return 0
    args.output_dir = args.output_dir.resolve()
    if args.worker:
        run_worker(args)
        return 0
    args.output_dir.mkdir(parents=True, exist_ok=False)
    return 0 if supervise(args)["success"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
