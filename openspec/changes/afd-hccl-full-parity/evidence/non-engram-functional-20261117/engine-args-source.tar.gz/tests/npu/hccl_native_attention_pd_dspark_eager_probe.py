# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Observe eager U2 parents around unchanged native DSpark/PD execution.

These host observations add no synchronization, tensor readback or device work.
Graph fallback uses a separate family. Runtime imports are deferred to the
explicit worker contexts; codec verification remains usable on a CPU host.
"""

from __future__ import annotations

import hashlib
import json
from contextlib import contextmanager

TARGET_REQUESTS = (2, 2, 1, 1, 1)
TARGET_STAGES = (2, 2, 1, 1, 1)
TARGET_ROWS = 3
TARGET_LAYERS = (0, 1)
TARGET_HIDDEN_SIZE = 512
TARGET_VOCAB_SIZE = 128
ATTENTION_DEVICE = 2
FFN_DEVICE = 6


def eager_session_storage(session):
    """Snapshot public session owners, without inspecting private ticket slots."""
    return {
        "session": id(session),
        "transport": id(session.transport),
        "initialized": session.initialized,
        "settings": session.settings.effective_settings(),
        "streams": {
            name: {"identity": id(stream), "device": str(stream.device)}
            for name, stream in (
                ("parent", session.parent_stream),
                ("compute", session.compute_stream),
                ("send", session.send_stream),
                ("recv", session.receive_stream),
            )
        },
    }


@contextmanager
def observe_eager_pipeline_finishes(report):
    """Record the actual finish return; COMPLETE and device progress stay distinct."""
    from afd_plugin.connectors.npu.hccl_eager_pipeline import HcclEagerPipeline

    original = HcclEagerPipeline.finish
    records = report["eager_pipeline_finishes"] = []

    def finish(pipeline):
        plan = pipeline.plan
        record = {
            "ordinal": len(records),
            "transaction_id": plan.transaction_id,
            "role": pipeline.transport.role,
            "pipeline": id(pipeline),
            "stage_rows": [stage.attention_padded_tokens[0] for stage in plan.stages],
            "streams": {
                name: id(stream)
                for name, stream in (
                    ("parent", pipeline.parent_stream),
                    ("send", pipeline.send_stream),
                    ("recv", pipeline.receive_stream),
                )
            },
            "returned": False,
        }
        records.append(record)
        try:
            returned = original(pipeline)
        except BaseException as error:
            record["error_type"] = type(error).__name__
            raise
        record.update(
            returned=True,
            finished=pipeline.finished,
            failed=pipeline.failed,
            occupied_stages=list(pipeline.occupied_stages),
            transport_parent_retired=pipeline.transport.plan is None,
            transport_pipeline_retired=pipeline.transport.eager_pipeline is None,
        )
        return returned

    try:
        HcclEagerPipeline.finish = finish
        yield
    finally:
        HcclEagerPipeline.finish = original


@contextmanager
def observe_eager_decode(bindings, report):
    """Observe native parent completion before its original sample/propose calls."""
    owner = bindings.owner
    session = owner.ubatch_runner.eager_session
    transport = session.transport
    model, speculator = owner.model, owner.speculator
    storage = eager_session_storage(session)
    detail = report["target_eager_decode"] = {
        "accepted": False,
        "storage_before": storage,
        "executions": [],
        "events": [],
        "consumer_ready_publications": [],
    }
    execute, sample, propose, forward = (
        owner.execute_model,
        owner.sample_tokens,
        speculator.propose,
        model.forward,
    )
    connector = owner.kv_connector.kv_connector
    publish = connector.publish_dspark_ready
    layers = tuple(model.language_model.model.layers)
    layer_methods = [(layer, layer.prepare_remote_ffn) for layer in layers]
    assert all("prepare_remote_ffn" not in layer.__dict__ for layer in layers)
    for instance, name in (
        (owner, "execute_model"),
        (owner, "sample_tokens"),
        (speculator, "propose"),
        (model, "forward"),
        (connector, "publish_dspark_ready"),
    ):
        assert name not in instance.__dict__
    active = None

    def event(kind):
        assert active is not None
        detail["events"].append({"event": kind, "execute_ordinal": active["ordinal"]})

    def observed_forward(*args, **kwargs):
        assert active is not None
        active["python_target_calls"] += 1
        return forward(*args, **kwargs)

    def observed_execute(step, intermediate_tensors=None):
        nonlocal active
        assert owner.execute_model_state is None
        assert eager_session_storage(session) == storage
        assert transport.plan is transport.eager_pipeline is None
        active = {
            "ordinal": len(detail["executions"]),
            "scheduled_tokens": step.total_num_scheduled_tokens,
            "finished_req_ids": sorted(step.finished_req_ids),
            "python_target_calls": 0,
            "layer_entries": [],
        }
        detail["executions"].append(active)
        event("execute_begin")
        before_controls = len(report["pair_control_messages"])
        returned = execute(step, intermediate_tensors)
        forwarded = [
            record["encoded_message"]["plan"]
            for record in report["pair_control_messages"][before_controls:]
            if record["encoded_message"]["kind"] == "FORWARD"
        ]
        assert len(forwarded) == int(bool(step.total_num_scheduled_tokens))
        active["transaction_id"] = forwarded[0]["transaction_id"] if forwarded else None
        assert transport.plan is transport.eager_pipeline is None
        assert not transport.terminal and not transport.closed
        active["parent_retired_before_sample"] = True
        active["pipeline_finishes_after_execute"] = len(
            report["eager_pipeline_finishes"]
        )
        if step.total_num_scheduled_tokens:
            state = owner.execute_model_state
            assert returned is None and state is not None
            active["execute_state"] = id(state)
        else:
            assert returned is not None and owner.execute_model_state is None
            assert not active["python_target_calls"]
        event("execute_returned")
        assert eager_session_storage(session) == storage
        return returned

    def observed_sample(*args, **kwargs):
        assert active is not None and active["scheduled_tokens"] > 0
        assert id(owner.execute_model_state) == active["execute_state"]
        assert transport.plan is transport.eager_pipeline is None
        event("sample_begin")
        returned = sample(*args, **kwargs)
        assert owner.execute_model_state is None
        event("sample_returned")
        return returned

    def observed_propose(*args, **kwargs):
        assert transport.plan is transport.eager_pipeline is None
        event("propose_begin")
        returned = propose(*args, **kwargs)
        event("propose_returned")
        return returned

    def observed_publish(batch):
        detail["consumer_ready_publications"].append(len(batch))
        return publish(batch)

    def observe_layer(layer, original):
        def prepare(positions, hidden_states, pre_mix, llama_4_scaling=None):
            assert active is not None
            active["layer_entries"].append(
                {"layer": layer.layer_idx, "rows": positions.shape[0]}
            )
            return original(positions, hidden_states, pre_mix, llama_4_scaling)

        return prepare

    try:
        owner.execute_model, owner.sample_tokens = observed_execute, observed_sample
        speculator.propose, model.forward = observed_propose, observed_forward
        connector.publish_dspark_ready = observed_publish
        for layer, original in layer_methods:
            layer.prepare_remote_ffn = observe_layer(layer, original)
        yield
        assert report["native_dspark_request_lifecycle_accepted"]
        detail["storage_after"] = eager_session_storage(session)
        report["native_live_owner"]["eager_streams"]["storage_after"] = detail[
            "storage_after"
        ]
        assert detail["storage_after"] == storage
        assert transport.closed and not transport.terminal
        assert not any(detail["consumer_ready_publications"])
        detail["accepted"] = True
    finally:
        del owner.execute_model, owner.sample_tokens
        del speculator.propose, model.forward
        del connector.publish_dspark_ready
        for layer, _ in layer_methods:
            del layer.prepare_remote_ffn


def verify_eager_pair_messages(attention, ffn):
    """Check the real v3 non-Graph handshake, five plans and matched retirement."""
    from hccl_native_attention_pd_dspark_graph_probe import graph_codec

    first, second = (
        attention["pair_control_messages"],
        ffn["pair_control_messages"],
    )
    assert len(first) == len(second) == 5 + 5 * len(TARGET_REQUESTS)
    with graph_codec() as codec:
        decoded = []
        for ordinal, (one, two) in enumerate(zip(first, second, strict=True)):
            assert one["encoded_message"] == two["encoded_message"]
            assert one["sha256"] == two["sha256"]
            for record, role, rank in ((one, "attention", 1), (two, "ffn", 0)):
                assert type(record["ordinal"]) is int and record["ordinal"] == ordinal
                assert record["role"] == role
                assert type(record["world_rank"]) is int
                assert record["world_rank"] == rank
                assert type(record["peer_world_rank"]) is int
                assert record["peer_world_rank"] == 1 - rank
                assert record["direction"] in ("send_returned", "receive_returned")
            assert one["direction"] != two["direction"]
            raw = json.dumps(
                one["encoded_message"],
                sort_keys=True,
                separators=(",", ":"),
                ensure_ascii=False,
                allow_nan=False,
            ).encode()
            message = codec.decode_hccl_plan_message(raw)
            assert codec.encode_hccl_plan_message(message) == raw
            assert hashlib.sha256(raw).hexdigest() == one["sha256"]
            decoded.append(message)

        def take(index, direction, kind):
            assert first[index]["direction"] == direction
            message = decoded[index]
            assert message.kind == kind
            return message

        for index, direction, role, rank in (
            (0, "receive_returned", "ffn", 0),
            (1, "send_returned", "attention", 1),
        ):
            hello = take(index, direction, "HELLO")
            assert hello.role == role and hello.world_rank == rank
            caps = hello.capabilities
            assert caps is not None
            assert caps.hidden_size == TARGET_HIDDEN_SIZE
            assert caps.vocab_size == TARGET_VOCAB_SIZE
            assert caps.max_tokens >= TARGET_ROWS * max(TARGET_REQUESTS)
            assert caps.layer_indices == TARGET_LAYERS
            assert caps.attention_size == caps.ffn_size == caps.native_tp_size == 1
            assert caps.max_stages == 2 and caps.local_counts_version == 1
            assert (
                caps.graph_execution_version == 0 and caps.eager_pipeline_version == 1
            )
            assert caps.graph_exchange_order == "stage_serial"
            # This field describes Graph key width, not native eager N+1 rows.
            assert caps.target_query_len == 1
        assert decoded[0].capabilities == decoded[1].capabilities
        caps = decoded[1].capabilities
        parents = []
        for ordinal, (requests, stages) in enumerate(
            zip(TARGET_REQUESTS, TARGET_STAGES, strict=True)
        ):
            start = 2 + 5 * ordinal
            plan = take(start, "send_returned", "FORWARD").plan
            assert plan is not None
            plan.validate(caps)
            assert plan.mode == "target" and plan.graph_execution is None
            assert plan.layer_indices == TARGET_LAYERS
            assert len(plan.stages) == stages
            rows = TARGET_ROWS * requests // stages
            assert all(
                stage.attention_valid_tokens == stage.attention_padded_tokens == (rows,)
                for stage in plan.stages
            )
            for offset, direction, kind, rank in (
                (1, "receive_returned", "ACCEPT", 0),
                (2, "send_returned", "ACCEPT", 1),
                (3, "receive_returned", "COMPLETE", None),
                (4, "send_returned", "COMPLETE", None),
            ):
                message = take(start + offset, direction, kind)
                assert message.transaction_id == plan.transaction_id
                assert message.plan_digest == plan.digest
                if rank is not None:
                    assert message.world_rank == rank
            parents.append(
                {
                    "transaction_id": plan.transaction_id,
                    "valid_tokens": [rows] * stages,
                    "padded_tokens": [rows] * stages,
                    "num_requests": requests,
                }
            )
        assert len({parent["transaction_id"] for parent in parents}) == len(parents)
        start = 2 + 5 * len(parents)
        take(start, "send_returned", "STOP")
        take(start + 1, "receive_returned", "STOP_ACK")
        take(start + 2, "send_returned", "STOP_ACK")
    return {"parents": parents, "bidirectional_codec_records_match": True}


def verify_eager_session_storage(value, *, role):
    """Require one warmed, distinct stream family on the role's actual device."""
    assert value["initialized"] is True
    assert all(
        type(value[name]) is int and value[name] > 0
        for name in ("session", "transport")
    )
    settings = value["settings"]
    assert set(settings) == {
        "AFD_HCCL_EAGER_U2_STREAM_OVERLAP",
        "AFD_HCCL_GRAPH_U2_COMPUTE_OVERLAP",
        "AFD_HCCL_GRAPH_U2_HYBRID_DAG",
        "AFD_HCCL_GRAPH_U2_ATTENTION_THREE_STREAM",
        "AFD_HCCL_GRAPH_U2_FFN_RECV_STREAM",
        "AFD_HCCL_GRAPH_U2_FFN_CROSS_LAYER",
        "AFD_HCCL_STAGE_DIAGNOSTICS",
        "AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS",
    }
    assert settings["AFD_HCCL_EAGER_U2_STREAM_OVERLAP"] is True
    assert settings["AFD_HCCL_STAGE_DIAGNOSTICS"] is True
    assert settings["AFD_HCCL_FFN_COMPUTE_SYNC_DIAGNOSTICS"] is False
    assert all(
        enabled is False
        for name, enabled in settings.items()
        if name.startswith("AFD_HCCL_GRAPH_")
    )
    streams = value["streams"]
    assert set(streams) == {"parent", "compute", "send", "recv"}
    ids = [stream["identity"] for stream in streams.values()]
    assert all(type(identity) is int and identity > 0 for identity in ids)
    assert len(set(ids)) == len(ids)
    assert role in ("attention", "ffn")
    device = ATTENTION_DEVICE if role == "attention" else FFN_DEVICE
    assert all(stream["device"] == f"npu:{device}" for stream in streams.values())


def verify_eager_pipeline_finishes(records, parents, session, *, role):
    """Join public closed-loan state to the exact completed U2 parent IDs."""
    expected = [parent for parent in parents if len(parent["padded_tokens"]) == 2]
    assert len(records) == len(expected) == 2
    for ordinal, (record, parent) in enumerate(zip(records, expected, strict=True)):
        assert type(record["ordinal"]) is int and record["ordinal"] == ordinal
        assert record["role"] == role
        assert record["transaction_id"] == parent["transaction_id"]
        assert record["stage_rows"] == parent["padded_tokens"]
        assert type(record["pipeline"]) is int and record["pipeline"] > 0
        assert record["returned"] is True and "error_type" not in record
        assert record["finished"] is True and record["failed"] is False
        assert record["occupied_stages"] == []
        assert record["transport_parent_retired"] is True
        assert record["transport_pipeline_retired"] is True
        assert record["streams"] == {
            name: session["streams"][name]["identity"]
            for name in ("parent", "send", "recv")
        }


def verify_eager_host_records(records, parents, settings, *, role):
    """Require original per-parent enqueue diagnostics and actual stream labels."""
    assert role in ("attention", "ffn")
    by_id = {parent["transaction_id"]: [] for parent in parents}
    assert records
    for record in records:
        by_id[record["transaction_id"]].append(record)
    assert [record["transaction_id"] for record in records] == [
        parent["transaction_id"]
        for parent in parents
        for _ in by_id[parent["transaction_id"]]
    ]
    events = {
        f"{name}_{suffix}"
        for name in (
            "recv",
            "compute",
            "send",
            "layer_send_wait",
            "final_send_wait",
            "send_post",
            "recv_post",
            "loan_wait",
            "stage_reuse_wait",
            "parent_finish",
            "prepare",
            "continuation",
            "collapse",
        )
        for suffix in ("begin", "returned")
    }
    for parent in parents:
        group = by_id[parent["transaction_id"]]
        assert group and group[0]["event"] == "configuration"
        assert sum(record["event"] == "configuration" for record in group) == 1
        stages = len(parent["padded_tokens"])
        streamed = stages == 2
        paired = {}
        for record in group:
            fields = {
                "world_rank",
                "role_rank",
                "role",
                "phase",
                "num_stages",
                "actual.mode",
                "actual.compute_stream",
                "actual.send_stream",
                "actual.recv_stream",
                "actual.compute_pipeline_enabled",
                "actual.ffn_compute_sync",
                "in_profile_run",
                "is_warmup",
                "boundary",
                "transaction_id",
                "event",
            }
            if streamed:
                fields.update(
                    f"actual.{name}_alias"
                    for name in ("compute_send", "compute_recv", "send_recv")
                )
            if record["event"] == "configuration":
                fields.update(
                    f"{prefix}.{name}"
                    for prefix in ("configured", "effective")
                    for name in settings
                )
                fields.update(
                    f"{prefix}.{name}_stream"
                    for prefix in ("logical", "physical")
                    for name in ("compute", "send", "recv")
                )
                fields.add("parent_transport_override")
            else:
                fields.update(("layer", "stage"))
            assert set(record) == fields
            assert record["role"] == role
            assert type(record["world_rank"]) is int
            assert record["world_rank"] == (1 if role == "attention" else 0)
            assert type(record["role_rank"]) is int and record["role_rank"] == 0
            assert record["phase"] == "eager"
            assert type(record["num_stages"]) is int and record["num_stages"] == stages
            assert record["boundary"] == "host_enqueue"
            assert "outcome" not in record and "error_type" not in record
            assert record["actual.mode"] == ("eager-streamed" if streamed else "serial")
            for name in ("compute", "send", "recv"):
                assert record[f"actual.{name}_stream"] == (
                    name if streamed else "parent"
                )
            assert record["actual.compute_pipeline_enabled"] is streamed
            assert record["actual.ffn_compute_sync"] is False
            assert record["in_profile_run"] is record["is_warmup"] is False
            if streamed:
                assert all(
                    record[f"actual.{name}_alias"] is False
                    for name in ("compute_send", "compute_recv", "send_recv")
                )
            else:
                assert not any(name.endswith("_alias") for name in record)
            if record["event"] == "configuration":
                for name, enabled in settings.items():
                    assert record[f"configured.{name}"] is enabled
                    assert record[f"effective.{name}"] is (
                        streamed
                        if name == "AFD_HCCL_EAGER_U2_STREAM_OVERLAP"
                        else enabled
                    )
                for name in ("compute", "send", "recv"):
                    expected = name if streamed else "parent"
                    assert record[f"logical.{name}_stream"] == expected
                    assert record[f"physical.{name}_stream"] == expected
                assert record["parent_transport_override"] is False
            else:
                assert record["event"] in events
                assert type(record["layer"]) is int and record["layer"] in TARGET_LAYERS
                assert type(record["stage"]) is int and 0 <= record["stage"] < stages
                stem, boundary = record["event"].rsplit("_", 1)
                paired.setdefault((stem, record["layer"], record["stage"]), []).append(
                    boundary
                )
        assert all(
            boundaries == ["begin", "returned"] for boundaries in paired.values()
        )
        expected_compute = [
            (f"compute_{boundary}", layer, stage)
            for layer in TARGET_LAYERS
            for stage in range(stages)
            for boundary in ("begin", "returned")
        ]
        assert [
            (record["event"], record["layer"], record["stage"])
            for record in group
            if record["event"] in ("compute_begin", "compute_returned")
        ] == expected_compute
        if streamed:
            assert [
                record["event"]
                for record in group
                if record["event"].startswith("parent_finish_")
            ] == ["parent_finish_begin", "parent_finish_returned"]


def verify_eager_lifecycle(attention, ffn):
    """Join real codec, retained owners, original sampling and independent rows."""
    from hccl_native_attention_pd_dspark_lifecycle_probe import (
        verify_native_request_lifecycle,
    )

    for report in (attention, ffn):
        assert report["eager_stream_overlap_requested"] is True
        assert report["target_graph_requested"] is False
        assert report["full_model_accepted"] is False
    protocol = verify_eager_pair_messages(attention, ffn)
    parents = protocol["parents"]
    service = ffn["native_ffn"]
    assert service["native_daemon_retired"] is service["stop_acknowledged"] is True
    assert service["transport_closed"] is True
    assert service["transport_terminal"] is False
    assert service["target_graph"] is False and service["captured_entries"] == []
    transactions = service["transactions"]
    assert len(transactions) == len(parents)
    for actual, parent in zip(transactions, parents, strict=True):
        assert actual["transaction_id"] == parent["transaction_id"]
        assert actual["phase"] == "eager"
        assert actual["mode"] == "target"
        assert type(actual["num_stages"]) is int
        assert actual["num_stages"] == len(parent["padded_tokens"])
        assert actual["valid_tokens_by_stage"] == parent["valid_tokens"]
        assert actual["padded_tokens_by_stage"] == parent["padded_tokens"]
        assert all(
            actual[name] is True
            for name in (
                "arithmetic_executed",
                "python_body_executed",
                "parent_retired_after_real_execute",
            )
        )
    lifecycle = verify_native_request_lifecycle(
        attention,
        target_transactions=transactions,
        padded_tokens_by_step=((3, 3), (3, 3), (3,), (3,), (3,)),
    )
    for report, detail, role in (
        (attention, attention["native_live_owner"]["eager_streams"], "attention"),
        (ffn, service["eager_streams"], "ffn"),
    ):
        before = detail["storage_before"]
        verify_eager_session_storage(before, role=role)
        assert detail["storage_after"] == before
        verify_eager_pipeline_finishes(
            report["eager_pipeline_finishes"], parents, before, role=role
        )
        verify_eager_host_records(
            detail["host_records"], parents, before["settings"], role=role
        )
    decode = attention["target_eager_decode"]
    assert decode["accepted"] is True
    assert (
        decode["storage_before"]
        == decode["storage_after"]
        == (attention["native_live_owner"]["eager_streams"]["storage_before"])
    )
    executions = decode["executions"]
    assert len(executions) == len(attention["zero_steps"]) + len(parents)
    targets = [record for record in executions if record["scheduled_tokens"]]
    for record, step in zip(targets, attention["decode_steps"], strict=True):
        assert record["finished_req_ids"] == step["schedule"]["finished_req_ids"]
    zeros = [record for record in executions if not record["scheduled_tokens"]]
    for record, step in zip(zeros, attention["zero_steps"], strict=True):
        assert record["finished_req_ids"] == step["schedule"]["finished_req_ids"]
    assert [record["transaction_id"] for record in targets] == [
        parent["transaction_id"] for parent in parents
    ]
    expected_events = [
        {"event": event, "execute_ordinal": ordinal}
        for ordinal, record in enumerate(executions)
        for event in (
            (
                "execute_begin",
                "execute_returned",
                "sample_begin",
                "propose_begin",
                "propose_returned",
                "sample_returned",
            )
            if record["scheduled_tokens"]
            else ("execute_begin", "execute_returned")
        )
    ]
    assert decode["events"] == expected_events
    assert all(type(event["execute_ordinal"]) is int for event in decode["events"])
    for ordinal, record in enumerate(executions):
        assert type(record["ordinal"]) is int and record["ordinal"] == ordinal
        assert type(record["scheduled_tokens"]) is int
        assert record["parent_retired_before_sample"] is True
        assert type(record["python_target_calls"]) is int
        assert record["python_target_calls"] == 0
        if not record["scheduled_tokens"]:
            assert record["transaction_id"] is None and record["layer_entries"] == []
    for index, (record, parent, stages) in enumerate(
        zip(targets, parents, TARGET_STAGES, strict=True)
    ):
        assert type(record["execute_state"]) is int and record["execute_state"] > 0
        assert record["scheduled_tokens"] == sum(parent["valid_tokens"])
        assert type(record["pipeline_finishes_after_execute"]) is int
        assert record["pipeline_finishes_after_execute"] == min(index + 1, 2)
        assert record["layer_entries"] == [
            {"layer": layer, "rows": TARGET_ROWS}
            for layer in TARGET_LAYERS
            for _ in range(stages)
        ]
        assert all(
            type(value) is int
            for entry in record["layer_entries"]
            for value in entry.values()
        )
    assert not any(decode["consumer_ready_publications"])
    return (
        protocol
        | lifecycle
        | {
            "native_dspark_eager_stream_lifecycle_component_accepted": True,
            "physical_overlap_accepted": False,
            "performance_accepted": False,
        }
    )
