# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native D scheduler handoff for the supervised eager PD transfer probe.

This helper uses the installed scheduler, Request, StructuredOutputManager and
ActiveKVConnector. It does not execute a target model, manufacture worker output,
replace allocator block IDs or claim DSpark/Graph/whole-model qualification.
Runtime imports are deferred to the explicitly selected D worker process.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hccl_native_attention_pd_probe import NativePdStorage
    from vllm.config import VllmConfig
    from vllm.v1.core.sched.output import SchedulerOutput
    from vllm.v1.core.sched.scheduler import Scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector

    from afd_plugin.compat.npu.kv_layout_connector import (
        AttestedMooncakeAgentMetadata,
    )

PROMPT_TOKEN_IDS = (11, 12, 13, 14, 15)
SOURCE_BLOCK = 1
POLL_SECONDS = 0.05


@dataclass(frozen=True)
class NativePdSchedulerHandoff:
    """Keep actual scheduler allocations alive through worker retirement."""

    scheduler: Scheduler
    structured_output_manager: StructuredOutputManager
    request: Request
    first_target: SchedulerOutput | None
    group_block_pairs: tuple[tuple[tuple[int, int], ...], ...]
    retirement_output: SchedulerOutput | None = None
    retirement_output_executed: bool = False


def scheduler_record(output: SchedulerOutput) -> dict:
    """Describe the public schedule without modifying it or its metadata."""
    return {
        "total_num_scheduled_tokens": output.total_num_scheduled_tokens,
        "num_scheduled_tokens": dict(output.num_scheduled_tokens),
        "has_sync_kv_loads": output.has_sync_kv_loads,
        "finished_req_ids": sorted(output.finished_req_ids),
        "new_requests": [
            {
                "request_id": request.req_id,
                "prompt_token_ids": request.prompt_token_ids,
                "num_computed_tokens": request.num_computed_tokens,
                "block_ids": request.block_ids,
            }
            for request in output.scheduled_new_reqs
        ],
        "cached_request_ids": list(output.scheduled_cached_reqs.req_ids),
        "new_block_ids_to_zero": output.new_block_ids_to_zero,
    }


def run_scheduler_handoff(
    config: VllmConfig,
    storage: NativePdStorage,
    active: ActiveKVConnector,
    *,
    source_metadata: AttestedMooncakeAgentMetadata,
    source_port: int,
    source_request_id: str,
    destination_request_id: str,
    deadline: float,
    report: dict,
    prompt_token_ids: tuple[int, ...] = PROMPT_TOKEN_IDS,
    max_tokens: int = 1,
    source_block: int = SOURCE_BLOCK,
    source_transfer_params: dict | None = None,
    scheduler_context: NativePdSchedulerHandoff | None = None,
    cancel_before_load: bool = False,
    execute_empty: Callable[[SchedulerOutput], ModelRunnerOutput] | None = None,
) -> NativePdSchedulerHandoff:
    """Load remote prefix pages and stop at the first real target schedule.

    Caller owns native distributed initialization, TransferEngine/ActiveKV,
    physical-byte checks, receiver retirement and final scheduler shutdown.
    ``deadline`` is the caller's absolute time.monotonic deadline. An allocator,
    attestation, transfer or native scheduler error is retained without fallback.
    A reused context must have no remaining native requests or undelivered
    finished-request schedule. The caller executes the real retirement schedule
    on its model owner before invoking this helper again; this helper cannot
    attest a model owner's request-state retirement.

    ``cancel_before_load`` aborts after the native zero-token allocation but
    before its original load metadata is submitted. It requires the owning
    runner's real ``execute_empty`` callback for every zero-token schedule,
    including the finished-request notification. The returned retirement output
    has already been executed and must not be submitted a second time. No target
    schedule is returned in this mode.
    """
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )

    assert config is storage.vllm_config is active.vllm_config
    assert config.kv_transfer_config.kv_role == "kv_consumer"
    assert config.model_config.enforce_eager
    assert config.speculative_config is config.engram_config is None
    assert config.parallel_config.tensor_parallel_size == 1
    assert config.parallel_config.pipeline_parallel_size == 1
    assert config.parallel_config.data_parallel_size == 1
    assert config.cache_config.enable_prefix_caching is False
    assert isinstance(prompt_token_ids, tuple) and len(prompt_token_ids) > 1
    assert len(prompt_token_ids) <= config.cache_config.block_size
    assert len(prompt_token_ids) <= config.model_config.max_model_len
    assert all(
        type(token) is int and 0 <= token < config.model_config.get_vocab_size()
        for token in prompt_token_ids
    )
    assert type(max_tokens) is int and max_tokens > 0
    assert type(source_block) is int
    assert 0 < source_block < storage.kv_cache_config.num_blocks
    assert type(cancel_before_load) is bool
    if cancel_before_load:
        assert execute_empty is not None

    previous_capacity = config.cache_config.num_gpu_blocks
    assert previous_capacity in (None, storage.kv_cache_config.num_blocks)
    if scheduler_context is None:
        # Native engine initialization publishes the profiled capacity before
        # Scheduler construction. Reuse does not republish or change capacity.
        config.cache_config.num_gpu_blocks = storage.kv_cache_config.num_blocks
    else:
        assert previous_capacity == storage.kv_cache_config.num_blocks
    detail = {
        "cache_num_gpu_blocks_before_scheduler": previous_capacity,
        "cache_num_gpu_blocks": config.cache_config.num_gpu_blocks,
        "scheduler_block_size": config.cache_config.block_size,
        "prompt_token_ids": list(prompt_token_ids),
        "max_tokens": max_tokens,
        "source_block": source_block if source_transfer_params is None else None,
        "destination_request_id": destination_request_id,
        "source_request_id": source_request_id,
        "public_steps": [],
        "native_scheduler_constructed": False,
        "native_scheduler_reused": scheduler_context is not None,
        "native_update_from_output_executed": False,
        "first_target_scheduled": False,
        "first_target_validated": False,
        "target_model_executed": False,
        "model_runner_output_manufactured": False,
        "block_ids_overridden": False,
        "dspark_ready_lease_accepted": False,
        "graph_pd_accepted": False,
        "full_model_accepted": False,
        "performance_accepted": False,
        "cancel_before_load": cancel_before_load,
        "cancelled_before_load": False,
        "retirement_output_executed": False,
    }
    report["native_scheduler_handoff"] = detail
    if scheduler_context is None:
        structured_output_manager = StructuredOutputManager(config)
        scheduler = native_scheduler.Scheduler(
            config,
            storage.kv_cache_config,
            structured_output_manager,
            block_size=config.cache_config.block_size,
            hash_block_size=config.cache_config.block_size,
        )
        detail["native_scheduler_constructed"] = True
    else:
        scheduler = scheduler_context.scheduler
        structured_output_manager = scheduler_context.structured_output_manager
        assert scheduler.vllm_config is config
        assert scheduler.kv_cache_config is storage.kv_cache_config
        assert scheduler.structured_output_manager is structured_output_manager
        assert scheduler_context.request.is_finished()
        assert scheduler_context.request.request_id not in scheduler.requests
        assert not scheduler.requests
        assert scheduler.get_num_unfinished_requests() == 0
        assert not scheduler.finished_req_ids
        assert (
            scheduler_context.request.request_id
            not in scheduler.finished_recving_kv_req_ids
        )
        assert destination_request_id != scheduler_context.request.request_id
        assert (
            source_request_id
            != scheduler_context.request.kv_transfer_params["remote_request_id"]
        )
        detail["previous_destination_request_id"] = scheduler_context.request.request_id
        detail["previous_request_status"] = scheduler_context.request.status.name
    detail["scheduler_class"] = (
        type(scheduler).__module__ + "." + type(scheduler).__qualname__
    )
    scheduler_connector = scheduler.get_kv_connector()
    assert scheduler_connector is not None
    detail["scheduler_connector_class"] = (
        type(scheduler_connector).__module__
        + "."
        + type(scheduler_connector).__qualname__
    )
    group_count = len(storage.kv_cache_config.kv_cache_groups)
    remote_block_ids = tuple([source_block] for _ in range(group_count))
    parameters = {
        "do_remote_prefill": True,
        "do_remote_decode": False,
        "remote_block_ids": remote_block_ids,
        "remote_engine_id": source_metadata.engine_id,
        "remote_request_id": source_request_id,
        "remote_host": source_metadata.local_ip,
        "remote_port": source_port,
        "remote_ptp_size": 1,
        "remote_pcp_size": 1,
        "num_prompt_blocks": 1,
    }
    if source_transfer_params is not None:
        # Consume the real P EngineCoreOutput envelope. The caller's source
        # handshake must agree; never replace the allocator's per-group IDs.
        parameters = dict(source_transfer_params)
        assert parameters["do_remote_prefill"] is True
        assert parameters["do_remote_decode"] is False
        assert parameters["remote_engine_id"] == source_metadata.engine_id
        assert parameters["remote_request_id"] == source_request_id
        assert parameters["remote_host"] == source_metadata.local_ip
        assert parameters["remote_port"] == source_port
        remote_block_ids = tuple(list(ids) for ids in parameters["remote_block_ids"])
        assert len(remote_block_ids) == group_count
        assert all(
            len(ids) == 1 and 0 < ids[0] < storage.kv_cache_config.num_blocks
            for ids in remote_block_ids
        )
        parameters["remote_block_ids"] = remote_block_ids
        detail["source_engine_output_params"] = source_transfer_params
    request = Request(
        destination_request_id,
        list(prompt_token_ids),
        SamplingParams(
            temperature=0,
            max_tokens=max_tokens,
            extra_args={"kv_transfer_params": parameters},
        ),
        None,
    )
    assert request.kv_transfer_params is parameters
    assert request.max_tokens == max_tokens
    scheduler.add_request(request)
    first = scheduler.schedule()
    detail["first_schedule"] = scheduler_record(first)
    assert first.total_num_scheduled_tokens == 0
    assert first.has_sync_kv_loads is False
    assert request.status == RequestStatus.WAITING_FOR_REMOTE_KVS
    metadata = first.kv_connector_metadata
    assert isinstance(metadata, MooncakeConnectorMetadata)
    assert set(metadata.requests) == {destination_request_id}
    transfer = metadata.requests[destination_request_id]
    assert transfer.remote_engine_id == source_metadata.engine_id
    assert transfer.remote_request_id == source_request_id
    assert transfer.remote_block_ids == remote_block_ids
    assert 0 < transfer.num_external_tokens < request.num_prompt_tokens
    assert len(transfer.local_block_ids) == group_count
    group_block_pairs = tuple(
        tuple(zip(source, destination, strict=True))
        for source, destination in zip(
            transfer.remote_block_ids, transfer.local_block_ids, strict=True
        )
    )
    assert all(group for group in group_block_pairs)
    detail["transfer"] = {
        "local_block_ids": transfer.local_block_ids,
        "local_block_ids_container": type(transfer.local_block_ids).__name__,
        "remote_block_ids": transfer.remote_block_ids,
        "group_block_pairs": group_block_pairs,
        "num_external_tokens": transfer.num_external_tokens,
        "num_prompt_blocks": transfer.num_prompt_blocks,
        "remote_engine_id": transfer.remote_engine_id,
        "remote_request_id": transfer.remote_request_id,
        "remote_host": transfer.remote_host,
        "remote_port": transfer.remote_port,
    }
    detail["native_async_computed_frontier"] = request.num_computed_tokens
    assert request.num_computed_tokens == transfer.num_external_tokens

    retirement_output = None
    if cancel_before_load:
        allocated = scheduler.kv_cache_manager.get_block_ids(destination_request_id)
        before_cancel = tuple(tuple(ids) for ids in allocated)
        aborted = scheduler.finish_requests(
            destination_request_id, RequestStatus.FINISHED_ABORTED
        )
        assert aborted == [request]
        assert request.status == RequestStatus.FINISHED_ABORTED
        assert scheduler.requests[destination_request_id] is request
        after_cancel = scheduler.kv_cache_manager.get_block_ids(destination_request_id)
        assert tuple(tuple(ids) for ids in after_cancel) == before_cancel
        assert destination_request_id in scheduler.finished_req_ids
        assert not first.finished_req_ids
        assert first.kv_connector_metadata is metadata
        detail["native_cancelled_request_ids"] = [item.request_id for item in aborted]
        detail["cancel_request_status"] = request.status.name
        detail["cancel_request_retained_until_receive"] = True
        detail["block_ids_before_cancel"] = before_cancel
        detail["block_ids_immediately_after_cancel"] = after_cancel
        detail["cancelled_before_load"] = True

    output = first
    received = set()
    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError("native scheduler PD handoff exceeded caller deadline")
        assert output.total_num_scheduled_tokens == 0
        assert output.has_sync_kv_loads is False
        if cancel_before_load:
            assert execute_empty is not None
            returned = execute_empty(output)
            assert isinstance(returned, ModelRunnerOutput)
            assert not returned.req_ids and not returned.sampled_token_ids
        else:
            returned = active.no_forward(output)
        connector_output = returned.kv_connector_output
        sent = set(
            () if connector_output is None else connector_output.finished_sending or ()
        )
        completed = set(
            () if connector_output is None else connector_output.finished_recving or ()
        )
        failed = set(
            () if connector_output is None else connector_output.failed_recving or ()
        )
        invalid = set(
            () if connector_output is None else connector_output.invalid_block_ids or ()
        )
        observation = {
            "schedule": scheduler_record(output),
            "kv_connector_output_present": connector_output is not None,
            "finished_sending": sorted(sent),
            "finished_recving": sorted(completed),
            "failed_recving": sorted(failed),
            "invalid_block_ids": sorted(invalid),
            "request_status_before_update": request.status.name,
            "num_computed_tokens_before_update": request.num_computed_tokens,
            "native_owner_empty_execute": cancel_before_load,
        }
        detail["public_steps"].append(observation)
        if cancel_before_load and destination_request_id in output.finished_req_ids:
            assert retirement_output is None
            retirement_output = output
            detail["retirement_schedule"] = scheduler_record(output)
            detail["retirement_output_executed"] = True
        assert not sent and not failed and not invalid
        assert completed <= {destination_request_id}
        received.update(completed)
        # This is exactly the real no-forward result, including a legitimately
        # absent empty KV output. No sampled token or completion is synthesized.
        engine_outputs = scheduler.update_from_output(output, returned)
        detail["native_update_from_output_executed"] = True
        observation["engine_output_client_ids"] = sorted(engine_outputs)
        observation["request_status_after_update"] = request.status.name
        observation["num_computed_tokens_after_update"] = request.num_computed_tokens
        if cancel_before_load:
            observation["request_retained_after_update"] = (
                destination_request_id in scheduler.requests
            )
            assert request.status == RequestStatus.FINISHED_ABORTED
            if destination_request_id not in scheduler.requests:
                assert received == {destination_request_id}
                detail["request_removed_after_receive"] = True
            if (
                received == {destination_request_id}
                and destination_request_id not in scheduler.requests
                and retirement_output is not None
            ):
                assert scheduler.get_num_unfinished_requests() == 0
                assert not scheduler.requests and not scheduler.finished_req_ids
                assert (
                    destination_request_id not in scheduler.finished_recving_kv_req_ids
                )
                assert destination_request_id not in scheduler.failed_recving_kv_req_ids
                detail["received_request_ids"] = sorted(received)
                detail["all_created_empty_schedules_executed"] = True
                # Do not call schedule again here: that would create another
                # maintenance output whose metadata has not reached the owner.
                break
        before_target = request.num_computed_tokens
        output = scheduler.schedule()
        if cancel_before_load:
            assert output.total_num_scheduled_tokens == 0
            assert not output.scheduled_new_reqs
            assert not output.scheduled_cached_reqs.req_ids
            time.sleep(POLL_SECONDS)
            continue
        if output.total_num_scheduled_tokens:
            # Preserve the real schedule even if a following observation check
            # fails; JSON arrays alone lose the native outer container type.
            detail["first_target_schedule"] = scheduler_record(output)
            detail["first_target_block_id_containers"] = [
                type(admitted.block_ids).__name__
                for admitted in output.scheduled_new_reqs
            ]
            detail["computed_frontier_before_first_target_schedule"] = before_target
            # Scheduler optimistically advances this field for in-flight work.
            # It does not establish that the target has executed those tokens.
            detail["computed_frontier_after_first_target_schedule"] = (
                request.num_computed_tokens
            )
            detail["first_target_scheduled"] = True
            detail["first_target_request_status"] = request.status.name
            assert received == {destination_request_id}
            assert output.num_scheduled_tokens == {
                destination_request_id: request.num_prompt_tokens
                - transfer.num_external_tokens
            }
            assert len(output.scheduled_new_reqs) == 1
            admitted = output.scheduled_new_reqs[0]
            assert admitted.req_id == destination_request_id
            assert admitted.prompt_token_ids == list(prompt_token_ids)
            assert admitted.num_computed_tokens == transfer.num_external_tokens
            # KVCacheBlocks.get_block_ids returns tuple[list[int], ...], while
            # get_unhashed_block_ids_all_groups supplies list[list[int]] to
            # Mooncake ReqMeta. Compare ordered IDs without changing either.
            assert tuple(tuple(ids) for ids in admitted.block_ids) == tuple(
                tuple(ids) for ids in transfer.local_block_ids
            )
            assert not output.scheduled_cached_reqs.req_ids
            detail["first_target_validated"] = True
            break
        time.sleep(POLL_SECONDS)

    return NativePdSchedulerHandoff(
        scheduler=scheduler,
        structured_output_manager=structured_output_manager,
        request=request,
        first_target=None if cancel_before_load else output,
        group_block_pairs=group_block_pairs,
        retirement_output=retirement_output,
        retirement_output_executed=retirement_output is not None,
    )
