# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Public native execute/sample lifecycle for the controlled A Graph owner.

Imported only in an isolated NPU worker. Native request admission, metadata,
sampling, history writes and AsyncOutput remain intact. The head weights and
Attention/HC arithmetic are controlled component inputs, not checkpoint weights.
"""

from __future__ import annotations

import hashlib

LIFECYCLE_TRANSACTIONS = 6
GREEDY_TOKEN = 7
REQUEST_MAX_TOKENS = 8


def prepare_native_attention_lifecycle(owner, report, *, embedding_cpu):
    # Intentional worker-local imports keep the stdlib supervisor/help isolated.
    import torch
    from vllm.model_executor.layers.logits_processor import LogitsProcessor
    from vllm.model_executor.layers.vocab_parallel_embedding import ParallelLMHead
    from vllm.v1.worker.gpu.async_utils import StepTimingCollector
    from vllm.v1.worker.gpu.ec_connector import ECConnector
    from vllm.v1.worker.gpu.lora_utils import LoraState
    from vllm.v1.worker.gpu.sample.prompt_logprob import PromptLogprobsWorker
    from vllm.v1.worker.gpu.sample.sampler import Sampler
    from vllm_ascend.ascend_config import get_ascend_config
    from vllm_ascend.worker.v2.kvpp import KVPPRuntime

    config, device = owner.vllm_config, owner.device
    owner.cache_config, owner.scheduler_config = (
        config.cache_config,
        config.scheduler_config,
    )
    owner.observability_config = config.observability_config
    owner.ascend_config = get_ascend_config()
    owner.kvpp = KVPPRuntime()
    owner.model_state.kvpp_runtime = owner.kvpp
    owner.dtype, owner.vocab_size = config.model_config.dtype, embedding_cpu.shape[0]
    owner.max_num_tokens = config.scheduler_config.max_num_batched_tokens
    owner.max_model_len = config.model_config.max_model_len
    owner.dp_rank, owner.dcp_size, owner.dcp_rank = 0, 1, 0
    owner.cp_interleave = config.parallel_config.cp_kv_cache_interleave_size
    owner.is_first_pp_rank = owner.is_last_pp_rank = True
    owner.use_pp = owner.use_spec_pp = False
    owner.is_encoder_decoder = owner.supports_mm_inputs = False
    owner.uses_inputs_embeds = owner.is_pooling_model = False
    owner.pooling_runner = owner.encoder_cache = owner.pp_handler = None
    owner.kv_block_zeroer = owner.routed_experts_capturer = None
    owner.rejection_sampler = owner.batch_sharder = None
    owner.structured_outputs_worker = None
    owner.num_speculative_steps = 0
    owner.check_ep_fault = False
    owner.prof = owner.dspark_pd_consumer = None
    # Constructor-equivalent initialization only. The actual sample method
    # retires every subsequent ExecuteModelState, including the failure frontier.
    owner.execute_model_state = None
    owner.lora_state = LoraState(owner.max_num_reqs)
    owner.ec_connector = ECConnector()
    owner.step_timing = StepTimingCollector()
    owner.output_copy_stream = torch.npu.Stream(device=device)
    owner.sampler = Sampler(
        max_num_reqs=owner.max_num_reqs,
        vocab_size=owner.vocab_size,
        device=device,
        req_states=owner.req_states,
        logprobs_mode=config.model_config.logprobs_mode,
        num_speculative_tokens=owner.decode_query_len,
        use_fp64_gumbel=config.model_config.use_fp64_gumbel,
        enable_trace_replay=config.model_config.enable_trace_replay,
        reasoning_config=config.reasoning_config,
        return_sampling_mask=config.model_config.return_sampling_mask,
    )
    owner.prompt_logprobs_worker = PromptLogprobsWorker(
        owner.max_num_reqs, logprobs_mode=config.model_config.logprobs_mode
    )
    language = owner.model.language_model
    with torch.device(device):
        language.lm_head = ParallelLMHead(
            owner.vocab_size,
            embedding_cpu.shape[1],
            params_dtype=torch.bfloat16,
            quant_config=None,
            prefix="native_lifecycle.lm_head",
        )
        language.logits_processor = LogitsProcessor(owner.vocab_size)
    # A positive controlled hidden vector has a unique native greedy argmax.
    # Keep the inherited wrapper/language compute_logits and real head kernel.
    language.lm_head.weight.zero_()
    language.lm_head.weight[GREEDY_TOKEN].fill_(1)
    # Preserve normal load/profile-before-capture ordering. Execute the actual
    # head once before native capture locks the process-local workspace manager.
    logits = owner.model.compute_logits(
        torch.ones((1, embedding_cpu.shape[1]), dtype=torch.bfloat16, device=device)
    )
    torch.npu.synchronize(device)
    assert logits.shape == (1, owner.vocab_size)
    assert logits.argmax(-1).cpu().tolist() == [GREEDY_TOKEN]
    detail = {
        "native_execute_model_executed": False,
        "native_sample_tokens_executed": False,
        "native_sampler_constructor_executed": True,
        "native_lm_head_constructor_executed": True,
        "native_lm_head_warmed_before_capture": True,
        "native_async_output_executed": False,
        "checkpoint_head_weights_loaded": False,
        "execute_state_manually_cleared": False,
        "full_model_accepted": False,
        "normal_serving_admission_accepted": False,
        "pd_handoff_verified": False,
        "steps": [],
    }
    report["native_attention_lifecycle"] = detail


def run_native_attention_lifecycle(
    owner, report, *, embedding_cpu, kv_cpu, before_replacement_prefill=None
):
    # Native worker-only imports; this helper is never imported by the supervisor.
    import torch
    from hccl_native_attention_probe import LAYER_COUNT, ROUTER_DELTA, ROUTER_SCALE
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched.output import (
        CachedRequestData,
        NewRequestData,
        SchedulerOutput,
    )
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.worker.gpu.async_utils import AsyncOutput

    device = owner.device
    detail = report["native_attention_lifecycle"]
    graph_addresses = {
        (descriptor.num_tokens, descriptor.num_ubatches): id(graph)
        for descriptor, graph in owner.cudagraph_manager.graphs.items()
    }
    request_indices = {}
    kv_before = owner.kv_caches[0].cpu()
    torch.testing.assert_close(kv_before, kv_cpu, rtol=0, atol=0)
    start_transaction = len(report["transactions"])

    def empty_step(name, finished):
        scheduler = SchedulerOutput.make_empty()
        scheduler.finished_req_ids = set(finished)
        finished_indices = {
            req_id: owner.req_states.req_id_to_index[req_id] for req_id in finished
        }
        assert owner.execute_model_state is None
        before = len(report["transactions"])
        output = owner.execute_model(scheduler)
        detail["native_execute_model_executed"] = True
        assert isinstance(output, ModelRunnerOutput) and output.req_ids == []
        assert owner.execute_model_state is None
        assert len(report["transactions"]) == before + 1
        assert not set(finished).intersection(owner.req_states.req_id_to_index)
        detail["steps"].append(
            {
                "name": name,
                "zero_tokens": True,
                "finished_request_ids": sorted(finished),
                "finished_request_indices": finished_indices,
                "returned_request_ids": output.req_ids,
                "remaining_request_ids": sorted(owner.req_states.req_id_to_index),
                "parent": report["transactions"][-1],
                "native_sampling_required": False,
            }
        )

    def target_step(name, req_id, prompt, *, computed, block_id, new):
        scheduler = SchedulerOutput.make_empty()
        if new:
            scheduler.scheduled_new_reqs = [
                NewRequestData(
                    req_id=req_id,
                    prompt_token_ids=list(prompt),
                    mm_features=[],
                    sampling_params=SamplingParams(
                        temperature=0, max_tokens=REQUEST_MAX_TOKENS
                    ),
                    pooling_params=None,
                    block_ids=([block_id],),
                    num_computed_tokens=0,
                    lora_request=None,
                    prefill_token_ids=list(prompt),
                )
            ]
            ids, positions = list(prompt), list(range(len(prompt)))
        else:
            scheduler.scheduled_cached_reqs = CachedRequestData(
                req_ids=[req_id],
                resumed_req_ids=set(),
                new_token_ids=[],
                all_token_ids={},
                new_block_ids=[None],
                num_computed_tokens=[computed],
                num_output_tokens=[1],
            )
            ids, positions = [GREEDY_TOKEN], [computed]
        scheduler.num_scheduled_tokens = {req_id: len(ids)}
        scheduler.total_num_scheduled_tokens = len(ids)
        assert owner.execute_model_state is None
        before = len(report["transactions"])
        assert owner.execute_model(scheduler) is None
        detail["native_execute_model_executed"] = True
        assert owner.execute_model_state is not None
        batch = owner.execute_model_state.input_batch
        torch.npu.synchronize(device)
        torch.testing.assert_close(
            batch.input_ids[: len(ids)].cpu(),
            torch.tensor(ids, dtype=torch.int32),
            rtol=0,
            atol=0,
        )
        torch.testing.assert_close(
            batch.positions[: len(ids)].cpu(),
            torch.tensor(positions),
            rtol=0,
            atol=0,
        )
        expected = embedding_cpu[ids].clone()
        kv_rows = kv_cpu[block_id, positions]
        for _ in range(LAYER_COUNT):
            attended = (
                expected.float() + kv_rows.float() + torch.tensor(positions)[:, None]
            ).bfloat16()
            residual = (expected.float() + attended.float()).bfloat16()
            router = residual.float() + ROUTER_DELTA
            remote = (
                residual.float()
                + (router - residual.float()) * ROUTER_SCALE
                + torch.tensor(ids)[:, None].float()
            ).bfloat16()
            expected = (residual.float() + remote.float()).bfloat16()
        hidden = owner.execute_model_state.hidden_states[: len(ids)].cpu()
        torch.testing.assert_close(hidden, expected, rtol=0, atol=0)
        assert bool((hidden.float().sum(-1) > 0).all())
        native_output = owner.sample_tokens(None)
        detail["native_sample_tokens_executed"] = True
        assert isinstance(native_output, AsyncOutput)
        output = native_output.get_output()
        detail["native_async_output_executed"] = True
        assert owner.execute_model_state is None
        assert output.req_ids == [req_id]
        assert output.sampled_token_ids == [[GREEDY_TOKEN]]
        assert len(report["transactions"]) == before + 1
        parent = report["transactions"][-1]
        assert parent["phase"] == ("eager" if new else "replay")
        req_index = owner.req_states.req_id_to_index[req_id]
        request_indices[req_id] = req_index
        if new and req_id == "lifecycle-b":
            assert req_index == request_indices["lifecycle-a"]
        history = owner.req_states.all_token_ids.gpu[req_index].cpu()
        total = int(owner.req_states.total_len.gpu[req_index].cpu())
        expected_history = list(prompt) + [GREEDY_TOKEN] * (1 if new else 2)
        assert history[:total].tolist() == expected_history
        assert int(owner.req_states.num_computed_tokens.gpu[req_index].cpu()) == (
            computed + len(ids)
        )
        detail["steps"].append(
            {
                "name": name,
                "zero_tokens": False,
                "request_id": req_id,
                "request_index": req_index,
                "physical_block_id": block_id,
                "native_batch_request_ids": list(batch.req_ids),
                "active_request_ids": sorted(owner.req_states.req_id_to_index),
                "parent": parent,
                "input_ids": batch.input_ids.cpu().tolist(),
                "positions": batch.positions.cpu().tolist(),
                "query_start_loc": batch.query_start_loc.cpu().tolist(),
                "seq_lens": batch.seq_lens.cpu().tolist(),
                "valid_tokens": len(ids),
                "padded_tokens": batch.num_tokens_after_padding,
                "output": hidden.float().tolist(),
                "output_sha256": hashlib.sha256(
                    hidden.contiguous().view(torch.uint8).numpy().tobytes()
                ).hexdigest(),
                "expected_output_sha256": hashlib.sha256(
                    expected.contiguous().view(torch.uint8).numpy().tobytes()
                ).hexdigest(),
                "sampled_token_ids": output.sampled_token_ids,
                "history": history[:total].tolist(),
                "num_computed_tokens": computed + len(ids),
                "native_num_computed_tokens_cpu": int(
                    owner.req_states.num_computed_tokens_cpu[req_index]
                ),
                "native_num_computed_tokens_gpu": int(
                    owner.req_states.num_computed_tokens.gpu[req_index].cpu()
                ),
                "native_execute_state_retired": True,
                "oracle_verified": True,
            }
        )

    # Retire the eight earlier direct-preparation requests through the actual
    # native public finish/add/remove machinery before native sampling begins.
    empty_step("retire_preparation_requests", tuple(owner.req_states.req_id_to_index))
    target_step(
        "first_prefill_eager",
        "lifecycle-a",
        [2, 3, 4, 5],
        computed=0,
        block_id=1,
        new=True,
    )
    target_step(
        "first_decode_full",
        "lifecycle-a",
        [2, 3, 4, 5],
        computed=4,
        block_id=1,
        new=False,
    )
    empty_step("cancel_first_request", ("lifecycle-a",))
    if before_replacement_prefill is not None:
        before_replacement_prefill()
    target_step(
        "replacement_prefill_eager",
        "lifecycle-b",
        [6, 8],
        computed=0,
        block_id=2,
        new=True,
    )
    target_step(
        "replacement_decode_full",
        "lifecycle-b",
        [6, 8],
        computed=2,
        block_id=2,
        new=False,
    )
    assert len(report["transactions"]) - start_transaction == LIFECYCLE_TRANSACTIONS
    assert graph_addresses == {
        (descriptor.num_tokens, descriptor.num_ubatches): id(graph)
        for descriptor, graph in owner.cudagraph_manager.graphs.items()
    }
    kv_after = owner.kv_caches[0].cpu()
    torch.testing.assert_close(kv_after, kv_before, rtol=0, atol=0)
    detail["kv_sha256_before"] = hashlib.sha256(
        kv_before.contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    detail["kv_sha256_after"] = hashlib.sha256(
        kv_after.contiguous().view(torch.uint8).numpy().tobytes()
    ).hexdigest()
    detail["cancelled_request_slot_reused"] = True
    detail["cancelled_request_block_unchanged"] = True
    detail["same_graphs_retained"] = True
    detail["passed"] = True
