# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Explicit native NPU draft scatter/RoPE operations, without a model or PD.

Default/--help use the standard library only. --run preserves native operators
and failures; it never substitutes a CPU scatter, RoPE, or an unavailable op.
An external supervisor owns device admission and failed-process cleanup.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import math
import os
import struct
import sys
import threading
import traceback
from pathlib import Path

HEAD_SIZE = 16
BLOCK_COUNT = 4
BLOCK_ROWS = 4
PADDING_WORDS = 32
PREFIX_WORDS = 32
SUFFIX_WORDS = 32
BLOCK_STRIDE = BLOCK_ROWS * HEAD_SIZE + PADDING_WORDS
STORAGE_WORDS = PREFIX_WORDS + BLOCK_COUNT * BLOCK_STRIDE + SUFFIX_WORDS
SLOTS = ((1, 0), (2, 2), (-1, -1), (1, 3))
POSITIONS = (0, 1, 4)
ROPE_BASE = 10000
MAX_POSITIONS = 16
SCATTER_OPERATOR = "_C_ascend::npu_scatter_nd_update_sk"
ENVIRONMENT_NAMES = (
    "ASCEND_HOME_PATH",
    "ASCEND_OPP_PATH",
    "ASCEND_CUSTOM_OPP_PATH",
    "LD_LIBRARY_PATH",
    "VLLM_PLUGINS",
    "VLLM_USE_V2_MODEL_RUNNER",
    "VLLM_ASCEND_ENABLE_FLASHCOMM1",
)


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def float32(value: float) -> float:
    return struct.unpack("<f", struct.pack("<f", value))[0]


def bf16_word(value: float) -> int:
    bits = struct.unpack("<I", struct.pack("<f", value))[0]
    return ((bits + 0x7FFF + ((bits >> 16) & 1)) >> 16) & 0xFFFF


def round_bf16(value: float) -> float:
    return struct.unpack("<f", struct.pack("<I", bf16_word(value) << 16))[0]


def bf16_bytes(values: list[float]) -> bytes:
    return b"".join(struct.pack("<H", bf16_word(value)) for value in values)


def artifact(directory: Path, name: str, data: bytes) -> dict:
    path = directory / name
    path.write_bytes(data)
    return {"path": name, "size": len(data), "sha256": digest(data)}


def write_report(directory: Path, report: dict) -> None:
    temporary = directory / "result.json.tmp"
    temporary.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    temporary.replace(directory / "result.json")


def inspect_metadata() -> dict:
    packages = {}
    for name in ("torch", "torch-npu", "vllm", "vllm-ascend"):
        try:
            dist = importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:
            packages[name] = None
        else:
            packages[name] = {
                "version": dist.version,
                "root": str(Path(dist.locate_file("")).resolve()),
            }
    return {
        "packages": packages,
        "environment": {name: os.environ.get(name) for name in ENVIRONMENT_NAMES},
        "runtime_imported": False,
        "npu_queried": False,
        "scope": "native scatter and draft RoPE operations only",
        "PD_Ready_model_checkpoint_performance_accepted": False,
    }


def loaded_custom_libraries() -> list[dict]:
    """Read actual resolved mappings; never inject or load a replacement library."""
    paths = set()
    for line in Path("/proc/self/maps").read_text(encoding="utf-8").splitlines():
        fields = line.split(maxsplit=5)
        if len(fields) != 6 or not fields[5].startswith("/"):
            continue
        path = Path(fields[5])
        if (
            "vllm_ascend" in path.parts
            or path.name.startswith("libcust_opapi")
            or path.name.startswith("libopapi")
        ) and ".so" in path.name:
            paths.add(path.resolve(strict=True))
    return [
        {
            "path": str(path),
            "size": path.stat().st_size,
            "sha256": digest(path.read_bytes()),
        }
        for path in sorted(paths)
    ]


def scatter_reference() -> tuple[bytes, bytes, list[list[float]]]:
    before = b"".join(
        struct.pack("<H", 0x3F00 + word % 128) for word in range(STORAGE_WORDS)
    )
    expected = bytearray(before)
    values = [
        [row + 1 + column / HEAD_SIZE for column in range(HEAD_SIZE)]
        for row in range(len(SLOTS))
    ]
    for (block, offset), row in zip(SLOTS, values, strict=True):
        if block < 0:
            continue
        start = 2 * (PREFIX_WORDS + block * BLOCK_STRIDE + offset * HEAD_SIZE)
        expected[start : start + HEAD_SIZE * 2] = bf16_bytes(row)
    return before, bytes(expected), values


def rope_reference(inputs: list[list[float]]) -> list[list[float]]:
    """Independent interleaved rotation from the pinned non-YARN formula."""
    expected = []
    for position, row in zip(POSITIONS, inputs, strict=True):
        output = []
        for pair in range(HEAD_SIZE // 2):
            denominator = float32(ROPE_BASE ** (2 * pair / HEAD_SIZE))
            frequency = float32(position * float32(1 / denominator))
            # Native op-plugin 8b9c8534 casts mixed-dtype coefficients to
            # x.dtype before aclnnRotaryPositionEmbedding. Keep that boundary.
            cos, sin = (
                round_bf16(float32(math.cos(frequency))),
                round_bf16(float32(math.sin(frequency))),
            )
            even, odd = row[2 * pair : 2 * pair + 2]
            output.extend(
                (
                    float32(float32(even * cos) - float32(odd * sin)),
                    float32(float32(odd * cos) + float32(even * sin)),
                )
            )
        expected.append(output)
    return expected


def run_operations(args: argparse.Namespace, report: dict) -> None:
    # Worker isolation: metadata/help never import native runtime packages.
    import torch
    import torch_npu  # noqa: F401
    from vllm.platforms import current_platform

    current_platform.pre_register_and_update()
    # Native startup order avoids device_op -> ops -> device_op circular import.
    import vllm_ascend.ops  # noqa: F401
    from hccl_staged_probe import build_config
    from vllm.config import set_current_vllm_config
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.attention import dsa_v41
    from vllm_ascend.models.deepseek_v41 import dspark
    from vllm_ascend.ops import rope_dsv4
    from vllm_ascend.utils import enable_custom_op

    report["runtime_imported"] = True
    report["native_thread_id"] = threading.get_native_id()
    config = build_config(1, args.model)
    init_ascend_config(config)
    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    report["npu_queried"] = True
    report["device"] = str(device)
    # Platform registration deliberately defers this native extension import
    # until after device selection. Preserve its real loader and registration.
    report["native_custom_ops_enabled"] = enable_custom_op()
    names = set(torch._C._dispatch_get_all_op_names())
    report["operator_registration"] = {
        "name": SCATTER_OPERATOR,
        "registered": SCATTER_OPERATOR in names,
        "PrivateUse1_kernel_registered": (
            torch._C._dispatch_has_kernel_for_dispatch_key(
                SCATTER_OPERATOR, "PrivateUse1"
            )
            if SCATTER_OPERATOR in names
            else False
        ),
    }
    report["loaded_custom_libraries_before"] = loaded_custom_libraries()
    report["native_source"] = {
        module.__name__: {
            "path": module.__file__,
            "sha256": digest(Path(module.__file__).read_bytes()),
        }
        for module in (dsa_v41, dspark, rope_dsv4)
    }
    write_report(args.output_dir, report)
    before, expected, values = scatter_reference()
    host = torch.frombuffer(bytearray(before), dtype=torch.bfloat16)
    storage = host.to(device=device)
    cache = storage.as_strided(
        (BLOCK_COUNT, BLOCK_ROWS, 1, HEAD_SIZE),
        (BLOCK_STRIDE, HEAD_SIZE, HEAD_SIZE, 1),
        PREFIX_WORDS,
    )
    slots = torch.tensor(SLOTS, dtype=torch.int32, device=device)
    updates = torch.tensor(values, dtype=torch.bfloat16, device=device)
    report["scatter"] = {
        "input": artifact(args.output_dir, "scatter-before.bin", before),
        "expected": artifact(args.output_dir, "scatter-expected.bin", expected),
        "shape": list(cache.shape),
        "stride": list(cache.stride()),
        "storage_words": STORAGE_WORDS,
        "storage_offset_words": cache.storage_offset(),
        "storage_ptr": storage.data_ptr(),
        "cache_ptr": cache.data_ptr(),
        "slots": [list(pair) for pair in SLOTS],
        "slots_dtype": str(slots.dtype),
        "values": values,
        "values_dtype": str(updates.dtype),
        "guards_and_padding_preserved": False,
    }
    write_report(args.output_dir, report)
    # Missing registration raises the original operator lookup error here.
    dspark.scatter_cache_sk(cache, slots, updates)
    torch.npu.current_stream(device).synchronize()
    actual = storage.cpu().view(torch.uint8).numpy().tobytes()
    report["scatter"]["actual"] = artifact(
        args.output_dir, "scatter-actual.bin", actual
    )
    write_report(args.output_dir, report)
    assert actual == expected, "native scatter complete storage differs from oracle"
    report["scatter"]["guards_and_padding_preserved"] = True
    inputs = [
        [(row + 1) / 8 + column / 64 for column in range(HEAD_SIZE)]
        for row in range(len(POSITIONS))
    ]
    expected_values = rope_reference(inputs)
    expected_rope = bf16_bytes([value for row in expected_values for value in row])
    x = torch.tensor(inputs, dtype=torch.bfloat16, device=device).unsqueeze(1)
    positions = torch.tensor(POSITIONS, dtype=torch.long, device=device)
    with set_current_vllm_config(config), torch.device(device):
        rotary = rope_dsv4.ComplexExpRotaryEmbedding(
            vllm_config=config,
            layername="mtp.0.self_attn.attn",
            head_size=HEAD_SIZE,
            rotary_dim=HEAD_SIZE,
            max_position_embeddings=MAX_POSITIONS,
            base=ROPE_BASE,
            scaling_factor=1,
            rope_groups=["default"],
            apply_yarn_scaling=False,
        )
        report["rope"] = {
            "positions": list(POSITIONS),
            "head_size": HEAD_SIZE,
            "rotary_dim": HEAD_SIZE,
            "base": ROPE_BASE,
            "apply_yarn_scaling": False,
            "reference_coefficient_dtype": "torch.bfloat16",
            "input_values": inputs,
            "expected_FP32_values": expected_values,
            "input": artifact(
                args.output_dir,
                "rope-input.bin",
                bf16_bytes([value for row in inputs for value in row]),
            ),
            "expected_BF16": artifact(
                args.output_dir, "rope-expected.bin", expected_rope
            ),
            "input_ptr": x.data_ptr(),
            "native_rope_accepted": False,
        }
        write_report(args.output_dir, report)
        output = dspark._apply_dsv4_rope(rotary, positions, x)
        torch.npu.current_stream(device).synchronize()
    actual_rope = output.cpu().view(torch.uint8).numpy().tobytes()
    report["rope"]["actual_BF16"] = artifact(
        args.output_dir, "rope-actual.bin", actual_rope
    )
    report["rope"]["output_ptr"] = output.data_ptr()
    write_report(args.output_dir, report)
    assert actual_rope == expected_rope, "native draft RoPE BF16 output differs"
    report["rope"]["native_rope_accepted"] = True
    report["loaded_custom_libraries_after"] = loaded_custom_libraries()
    report["native_operations_accepted"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="/mnt/workspace/models/DeepSeek-V4.1-Flash")
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument(
        "--output-dir", type=Path, default=Path("dspark-projection-ops")
    )
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.device < 0:
        parser.error("device must be nonnegative")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if (args.output_dir / "result.json").exists():
        parser.error("output directory already contains result.json")
    report = {
        "schema_version": 1,
        "status": "metadata_only",
        "pid": os.getpid(),
        "requested_run": args.run,
        "probe_sha256": digest(Path(__file__).read_bytes()),
        **inspect_metadata(),
        "native_operations_accepted": False,
    }
    write_report(args.output_dir, report)
    if args.run:
        report["status"] = "running"
        write_report(args.output_dir, report)
        try:
            run_operations(args, report)
        except BaseException as error:
            report["status"] = "failed"
            report["error_type"] = type(error).__name__
            report["error"] = str(error)
            report["traceback"] = traceback.format_exc()
            try:
                report["loaded_custom_libraries_after_failure"] = (
                    loaded_custom_libraries()
                )
            except OSError as inspection_error:
                report["library_inspection_error"] = str(inspection_error)
            write_report(args.output_dir, report)
            raise
        report["status"] = "passed"
        write_report(args.output_dir, report)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
