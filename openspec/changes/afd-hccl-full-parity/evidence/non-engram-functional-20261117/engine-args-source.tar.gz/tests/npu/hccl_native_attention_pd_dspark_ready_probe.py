# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Opt-in transparent observation of the live native P Ready frontier.

Importing this helper requires only the standard library. Runtime imports and
three temporary observation bindings belong to the isolated P worker. The
original proposal, native projection/fence and public publication run unchanged.
No observer performs a successful read, a DONE operation or device synchronization.
"""

from __future__ import annotations

import hashlib
import inspect
import json
import time
from collections.abc import Iterator
from contextlib import contextmanager
from functools import wraps
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hccl_native_attention_pd_dspark_owner_probe import NativeLivePrefixOwner
    from vllm.v1.core.sched.output import SchedulerOutput

    from afd_plugin.compat.npu.dspark_pd import DsparkPdReady

QUERY_TIMEOUT_MILLISECONDS = 5_000
NOT_READY_ERROR = "DSpark source is not ready for this query"
NEGATIVE_BOUNDARIES = (
    "execute_returned",
    "propose_entered",
    "original_propose_returned",
)


def callable_identity(function) -> dict:
    """Record the delegated callable before installing an observation binding."""
    original = inspect.unwrap(function)
    path = Path(inspect.getfile(original)).resolve()
    return {
        "module": original.__module__,
        "qualname": original.__qualname__,
        "path": str(path),
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "first_line": inspect.getsourcelines(original)[1],
    }


class ReadyFrontierObserver:
    """One P transaction's raw typed observations; it owns no device resource."""

    def __init__(
        self,
        bindings: NativeLivePrefixOwner,
        *,
        run_id: str,
        host: str,
        port: int,
        deadline: float,
        report: dict,
    ) -> None:
        self.bindings = bindings
        self.run_id, self.host, self.port = run_id, host, port
        self.deadline, self.report = deadline, report
        self.expected_ready: DsparkPdReady | None = None
        self.detail = report["ready_frontier"] = {
            "status": "not_reached",
            "events": [],
            "negative_queries": [],
            "negative_boundaries": [],
            "observer_leases_granted": 0,
            "observation_destination_is_registered_storage": False,
            "positive_observer_queries": 0,
            "proposal_failure_frontier_accepted": False,
            "added_device_synchronization": False,
        }
        report["ready_before_sample_observed"] = "not_reached"

    def record(self, event: str, **fields) -> None:
        record = {"ordinal": len(self.detail["events"]), "event": event, **fields}
        if self.expected_ready is not None:
            record.update(
                source_request_id=self.expected_ready.source_request_id,
                source_generation=self.expected_ready.source_generation,
            )
        self.detail["events"].append(record)

    def bind_source(self, scheduler_output: SchedulerOutput) -> None:
        from afd_plugin.compat.npu.dspark_pd import (
            DsparkPdReady,
            layout_digest,
            ready_payload,
            source_request_payload,
        )
        from afd_plugin.compat.npu.kv_layout_native import (
            collect_deepseek_v41_kv_layout,
        )

        assert self.expected_ready is None
        owner = self.bindings.owner
        consumer = owner.dspark_pd_consumer
        sources = owner.kv_connector.kv_connector.get_dspark_prefill_sources(
            scheduler_output.kv_connector_metadata
        )
        assert len(sources) == 1 and consumer.tp_size == 1
        source = sources[0]
        assert source.source_engine_id == consumer.source_engine_id
        layout = collect_deepseek_v41_kv_layout(
            self.bindings.kv_config, self.bindings.caches
        )
        self.expected_ready = DsparkPdReady(
            source.source_engine_id,
            source.request_id,
            source.source_generation,
            source.original_prompt_tokens,
            source.computed_prefix_tokens,
            source.prompt_digest,
            layout_digest(layout),
            source.draft_schema_digest,
            source.transfer_block_ids,
            consumer.tp_rank,
            consumer.tp_size,
        )
        self.detail["source"] = source_request_payload(source)
        payload = ready_payload(self.expected_ready)
        self.detail["expected_ready"] = payload
        self.detail["expected_ready_sha256"] = hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        self.detail["endpoint"] = {"host": self.host, "port": self.port}
        self.record("source_bound")

    def require_not_ready(self, boundary: str) -> None:
        import msgspec
        import zmq

        from afd_plugin.compat.npu.dspark_pd import (
            DsparkPdReadQuery,
            read_query_payload,
        )
        from afd_plugin.compat.npu.kv_layout_connector import (
            GET_DSPARK_READY_MSG,
            MAX_METADATA_BYTES,
        )

        assert self.expected_ready is not None
        observed = self.detail["negative_boundaries"]
        assert len(observed) < len(NEGATIVE_BOUNDARIES)
        assert boundary == NEGATIVE_BOUNDARIES[len(observed)]
        query = DsparkPdReadQuery(
            self.expected_ready,
            self.run_id + "-ready-observer",
            self.run_id + "-ready-observer-" + boundary,
            tuple(
                tuple(range(1, len(group) + 1))
                for group in self.expected_ready.transfer_block_ids
            ),
            self.run_id + "-ready-observer-query-" + boundary,
        )
        query_payload = read_query_payload(query)
        encoded = msgspec.msgpack.encode((GET_DSPARK_READY_MSG, query_payload))
        entry = {
            "boundary": boundary,
            "query": query_payload,
            "request_hex": encoded.hex(),
            "request_sha256": hashlib.sha256(encoded).hexdigest(),
        }
        self.detail["negative_queries"].append(entry)
        remaining = int((self.deadline - time.monotonic()) * 1_000)
        if remaining <= 0:
            raise TimeoutError("Ready frontier query exceeded the worker deadline")
        timeout = min(QUERY_TIMEOUT_MILLISECONDS, remaining)
        context = zmq.Context()
        socket = context.socket(zmq.REQ)
        try:
            socket.setsockopt(zmq.LINGER, 0)
            socket.setsockopt(zmq.SNDTIMEO, timeout)
            socket.setsockopt(zmq.RCVTIMEO, timeout)
            socket.connect(f"tcp://{self.host}:{self.port}")
            socket.send(encoded)
            self.record(
                "query_send_returned", boundary=boundary, query_id=query.query_id
            )
            reply = socket.recv()
        finally:
            socket.close(linger=0)
            context.term()
        entry["response_hex"] = reply.hex()
        entry["response_sha256"] = hashlib.sha256(reply).hexdigest()
        if len(reply) > MAX_METADATA_BYTES:
            raise ValueError("Ready frontier response exceeds the byte limit")
        decoded = msgspec.msgpack.decode(reply)
        entry["decoded_type"] = type(decoded).__name__
        if isinstance(decoded, dict) and decoded.get("ok") is True:
            self.detail["observer_leases_granted"] += 1
        if not (
            isinstance(decoded, dict)
            and set(decoded) == {"ok", "error"}
            and decoded["ok"] is False
            and decoded["error"] == NOT_READY_ERROR
        ):
            # A premature successful acquire is intentionally not cancelled.
            # Its real lease and P owner remain available to the supervisor.
            raise RuntimeError("Ready frontier query did not return exact not-ready")
        entry["response"] = decoded
        observed.append(boundary)
        self.record("not_ready_returned", boundary=boundary, query_id=query.query_id)
        if tuple(observed) == NEGATIVE_BOUNDARIES:
            self.report["ready_before_sample_observed"] = "not_ready_observed"

    def execute_returned(self) -> None:
        assert self.bindings.owner.execute_model_state is not None
        self.record("execute_returned")
        self.require_not_ready("execute_returned")


@contextmanager
def observe_ready_frontier(
    bindings: NativeLivePrefixOwner,
    *,
    run_id: str,
    host: str,
    port: int,
    deadline: float,
    report: dict,
) -> Iterator[ReadyFrontierObserver]:
    """Observe original calls through P's normal read/DONE and cleanup frontier."""
    from afd_plugin.compat.npu import dspark_pd
    from afd_plugin.compat.npu.dspark_pd import ready_payload

    observer = ReadyFrontierObserver(
        bindings,
        run_id=run_id,
        host=host,
        port=port,
        deadline=deadline,
        report=report,
    )
    speculator = bindings.owner.speculator
    connector = bindings.owner.kv_connector.kv_connector
    original_propose = speculator.propose
    original_projection = dspark_pd.initialize_draft_context_chunk
    original_publish = connector.publish_dspark_ready
    own_propose = "propose" in vars(speculator)
    own_publish = "publish_dspark_ready" in vars(connector)
    instance_propose = vars(speculator).get("propose")
    instance_publish = vars(connector).get("publish_dspark_ready")
    observer.detail["original_callables"] = {
        "propose": callable_identity(original_propose),
        "projection_with_native_fence": callable_identity(original_projection),
        "publish": callable_identity(original_publish),
    }
    completed = set()

    @wraps(original_propose)
    def observed_propose(*args, **kwargs):
        assert "propose" not in completed
        observer.record("propose_entered")
        observer.require_not_ready("propose_entered")
        try:
            result = original_propose(*args, **kwargs)
        except BaseException as error:
            observer.record(
                "original_propose_failed",
                error_type=type(error).__name__,
                error_message=str(error),
                error_identity=id(error),
            )
            raise
        observer.record("original_propose_returned")
        observer.require_not_ready("original_propose_returned")
        completed.add("propose")
        return result

    @wraps(original_projection)
    def observed_projection(*args, **kwargs):
        observer.record("final_projection_entered")
        assert completed == {"propose"}
        try:
            result = original_projection(*args, **kwargs)
        except BaseException as error:
            observer.record(
                "original_final_projection_failed",
                error_type=type(error).__name__,
                error_message=str(error),
                error_identity=id(error),
            )
            raise
        observer.record("original_final_projection_and_fence_returned")
        completed.add("projection")
        return result

    @wraps(original_publish)
    def observed_publish(ready_batch):
        payloads = [ready_payload(ready) for ready in ready_batch]
        observer.record(
            "public_publication_entered",
            ready=payloads,
            ready_batch_sha256=hashlib.sha256(
                json.dumps(payloads, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest(),
        )
        assert completed == {"propose", "projection"}
        assert observer.expected_ready is not None
        assert ready_batch == (observer.expected_ready,)
        try:
            result = original_publish(ready_batch)
        except BaseException as error:
            observer.record(
                "original_publication_failed",
                error_type=type(error).__name__,
                error_message=str(error),
                error_identity=id(error),
            )
            raise
        observer.record("public_publication_returned")
        completed.add("publish")
        return result

    try:
        speculator.propose = observed_propose
        dspark_pd.initialize_draft_context_chunk = observed_projection
        connector.publish_dspark_ready = observed_publish
        yield observer
        assert completed == {"propose", "projection", "publish"}
        assert tuple(observer.detail["negative_boundaries"]) == NEGATIVE_BOUNDARIES
        assert observer.detail["observer_leases_granted"] == 0
        assert report["typed_done_observed"]
        assert report["native_owner_shutdown_returned"]
        observer.record("real_read_done_and_native_owner_shutdown_returned")
        observer.detail["status"] = "passed"
    except BaseException as error:
        observer.detail["status"] = "failed"
        observer.record(
            "failed", error_type=type(error).__name__, error_message=str(error)
        )
        raise
    finally:
        if own_propose:
            speculator.propose = instance_propose
        else:
            del speculator.propose
        dspark_pd.initialize_draft_context_chunk = original_projection
        if own_publish:
            connector.publish_dspark_ready = instance_publish
        else:
            del connector.publish_dspark_ready
