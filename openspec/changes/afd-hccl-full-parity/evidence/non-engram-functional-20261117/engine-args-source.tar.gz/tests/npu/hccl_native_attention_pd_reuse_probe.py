# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Cancel a sampled PD request and reuse its real D owner for a new prefix."""

from __future__ import annotations

import hashlib

REPLACEMENT_PROMPT = (21, 22, 23)
REPLACEMENT_SOURCE_BLOCK = 2
INITIAL_REQUEST_MAX_TOKENS = 2


def run_pd_replacement(
    args, config, storage, active, first_handoff, owner, connector, report, deadline
):
    # Runtime dependencies remain confined to explicitly selected NPU workers.
    import msgspec
    import torch
    from hccl_native_attention_pd_model_probe import (
        execute_pd_target,
        model_source_page_bytes,
    )
    from hccl_native_attention_pd_probe import (
        await_peer_record,
        file_sha256,
        snapshot_pages,
        write_json,
    )
    from hccl_native_attention_pd_scheduler_probe import run_scheduler_handoff
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    from afd_plugin.compat.npu.kv_layout_connector import AttestedMooncakeAgentMetadata

    first_model = report["native_pd_model"]
    first_schedule = report["native_scheduler_handoff"]
    assert first_model["request_status_after_cancel"] == "FINISHED_ABORTED"
    assert first_model["native_request_retired"]
    assert not owner.req_states.req_id_to_index
    receiver = active.kv_connector.connector_worker.kv_recv_thread
    engine = active.kv_connector.connector_worker.engine
    assert receiver.is_alive() and not receiver.retired
    assert receiver.engine is engine
    detail = {
        "phases": [{"scheduler": first_schedule, "model": first_model}],
        "receiver_identity": id(receiver),
        "same_engine_identity": id(engine),
        "full_model_accepted": False,
        "same_request_id_reuse_accepted": False,
        "pending_read_cancel_accepted": False,
        "waiting_before_submission_cancel_executed": args.cancel_before_load,
        "old_done_replay_security_accepted": False,
        "passed": False,
    }
    report["native_pd_request_reuse"] = detail
    write_json(
        args.output_dir / "consumer-reuse-retired.json",
        {
            "run_id": args.run_id,
            "request_id": first_handoff.request.request_id,
            "status": first_handoff.request.status.name,
            "native_empty_execute_retired": True,
        },
    )
    peer = await_peer_record(
        args.output_dir / "producer-reuse-ready.json",
        run_id=args.run_id,
        deadline=deadline,
    )
    source_id, destination_id = (
        args.run_id + "-source-b",
        args.run_id + "-destination-b",
    )
    assert peer["request_id"] == source_id
    assert peer["source_block"] == REPLACEMENT_SOURCE_BLOCK
    path = args.output_dir / peer["path"]
    assert file_sha256(path) == peer["sha256"]
    source = msgspec.msgpack.decode(
        path.read_bytes(), type=AttestedMooncakeAgentMetadata
    )
    assert source.engine_id == peer["engine_id"]
    prior = [
        (args.output_dir / entry["path"]).read_bytes()
        for entry in report["after_model"]
    ]
    second = run_scheduler_handoff(
        config,
        storage,
        active,
        source_metadata=source,
        source_port=peer["port"],
        source_request_id=source_id,
        destination_request_id=destination_id,
        deadline=deadline,
        report=report,
        prompt_token_ids=REPLACEMENT_PROMPT,
        source_block=REPLACEMENT_SOURCE_BLOCK,
        scheduler_context=first_handoff,
    )
    assert second.scheduler is first_handoff.scheduler
    assert second.structured_output_manager is first_handoff.structured_output_manager
    detail["replacement_group_block_pairs"] = second.group_block_pairs
    after = snapshot_pages(storage, args.output_dir, label="kv_consumer-replacement")
    for index, descriptor in enumerate(storage.kv_cache_config.kv_cache_tensors):
        expected = bytearray(prior[index])
        source_bytes = model_source_page_bytes(
            index, descriptor.size, block_stride=descriptor.block_stride
        )
        copies = {}
        for group_index, group in enumerate(storage.kv_cache_config.kv_cache_groups):
            if not set(group.layer_names).intersection(descriptor.layers):
                continue
            for source_block, destination in second.group_block_pairs[group_index]:
                if destination in copies:
                    assert copies[destination] == source_block
                copies[destination] = source_block
        assert copies
        stride = descriptor.block_stride
        for destination, source_block in copies.items():
            expected[destination * stride : (destination + 1) * stride] = source_bytes[
                source_block * stride : (source_block + 1) * stride
            ]
        actual = (args.output_dir / after[index]["path"]).read_bytes()
        assert actual == expected
        assert after[index]["data_ptr"] == report["after_model"][index]["data_ptr"]
        after[index]["expected_sha256"] = hashlib.sha256(expected).hexdigest()
        after[index]["expected_block_copies"] = sorted(
            (source_block, destination) for destination, source_block in copies.items()
        )
    detail["replacement_after_transfer"] = after
    detail["replacement_full_physical_oracle_verified"] = True
    with torch.inference_mode(), torch_cuda_wrapper():
        second_owner = execute_pd_target(
            config,
            storage,
            active,
            second,
            connector,
            owner.device,
            report,
            production_u1=True,
            owner=owner,
        )
    assert second_owner is owner
    second_model = report["native_pd_model"]
    assert second_model["native_owner_reused"]
    identity_names = (
        "owner_identity",
        "model_state_identity",
        "sampler_identity",
        "model_identity",
        "head_identity",
        "request_state_identity",
        "input_buffers_identity",
        "block_tables_identity",
        "active_kv_identity",
    )
    for name in identity_names:
        assert first_model[name] == second_model[name]
    if args.cancel_before_load:
        assert first_model["request_index"] is None
        assert not first_model["native_request_state_admitted"]
    else:
        assert first_model["request_index"] == second_model["request_index"]
    first_blocks = {block for group in first_model["block_ids"] for block in group}
    second_blocks = {block for group in second_model["block_ids"] for block in group}
    assert first_blocks == second_blocks
    final = snapshot_pages(
        storage, args.output_dir, label="kv_consumer-replacement-model"
    )
    for transferred, consumed in zip(after, final, strict=True):
        assert transferred["sha256"] == consumed["sha256"]
        assert transferred["data_ptr"] == consumed["data_ptr"]
    assert active.kv_connector.connector_worker.kv_recv_thread is receiver
    assert active.kv_connector.connector_worker.engine is engine
    assert receiver.engine is engine
    assert receiver.is_alive() and not receiver.retired
    detail["replacement_after_model"] = final
    detail["phases"].append(
        {
            "scheduler": report["native_scheduler_handoff"],
            "model": second_model,
        }
    )
    detail["native_request_slot_reused"] = not args.cancel_before_load
    detail["physical_block_set_reused"] = sorted(first_blocks)
    detail["same_native_owner_and_receiver"] = True
    detail["passed"] = True
    report["request_cancellation_executed"] = True
    return second
