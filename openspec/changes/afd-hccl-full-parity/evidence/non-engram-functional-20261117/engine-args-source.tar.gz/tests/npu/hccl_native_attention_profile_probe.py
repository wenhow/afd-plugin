# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Optional real Attention profiler around the public native lifecycle.

The production execute wrapper alone starts and advances the deferred session.
This helper records host scopes and exports after the probe's normal peer STOP;
it does not infer device stream ownership, overlap, or full-model acceptance.
"""

from __future__ import annotations

import hashlib
import os
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )

PROFILED_EXECUTE_STEPS = 6
# Native execute advances the profiler before sample_tokens runs. Preserve one
# additional active interval for the final sample and export it with finish().
ACTIVE_PROFILE_STEPS = PROFILED_EXECUTE_STEPS + 1
PROFILE_SCOPE_PREFIX = "afd_native_attention_lifecycle/"
PROFILE_STEP_NAMES = (
    "retire_preparation_requests",
    "first_prefill_eager",
    "first_decode_full",
    "cancel_first_request",
    "replacement_prefill_eager",
    "replacement_decode_full",
)


def _file_inventory(directory: Path) -> list[dict[str, str | int]]:
    return [
        {
            "path": str(path.resolve()),
            "relative_path": path.relative_to(directory).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
        for path in sorted(directory.rglob("*"))
        if path.is_file()
    ]


def prepare_native_attention_profile(
    owner: AFDNPUAttentionModelRunnerV2, report, profile_dir: Path
) -> None:
    # Worker-local loading preserves the stdlib supervisor/help boundary.
    from afd_plugin.compat.npu.profiler import create_deferred_afd_npu_profiler

    assert owner.prof is None
    profile_dir = profile_dir.resolve()
    profile_dir.mkdir(parents=True, exist_ok=True)
    assert not any(profile_dir.iterdir()), "Attention trace directory must be fresh"
    prefix = "AFD_NPU_ATTENTION_PROFILER"
    settings = {
        f"{prefix}_ENABLE": "1",
        f"{prefix}_WAIT": "0",
        f"{prefix}_WARMUP": "0",
        f"{prefix}_ACTIVE": str(ACTIVE_PROFILE_STEPS),
        f"{prefix}_REPEAT": "1",
        f"{prefix}_SKIP_FIRST": "0",
        f"{prefix}_DIR": str(profile_dir),
        f"{prefix}_RANKS": "0",
        f"{prefix}_WITH_STACK": "0",
    }
    previous_environment = {name: os.environ.get(name) for name in settings}
    try:
        os.environ.update(settings)
        session = create_deferred_afd_npu_profiler("attention", role_rank=0)
    finally:
        # The production factory freezes its configuration. Restore the isolated
        # worker environment without changing that immutable session snapshot.
        for name, value in previous_environment.items():
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value
    assert session is not None
    status = session.status()
    assert status["selected"] and status["requested"] and status["pending"]
    assert not status["applied"] and not status["closed"] and not status["failed"]
    assert status["steps"] == 0 and status["owner_thread_id"] is None
    owner.prof = session
    report["native_attention_profile"] = {
        "scope": "real A role profiler and public execute/sample lifecycle",
        "pid": os.getpid(),
        "setup_thread_id": threading.get_ident(),
        "setup_native_thread_id": threading.get_native_id(),
        "trace_root": str(profile_dir),
        "frozen_environment": settings,
        "expected_public_execute_steps": PROFILED_EXECUTE_STEPS,
        "configured_active_intervals": ACTIVE_PROFILE_STEPS,
        "last_sampling_interval_retained": True,
        "production_deferred_factory_executed": True,
        "profiler_started_by_helper": False,
        "profiler_stepped_by_helper": False,
        "worker_shutdown_executed": False,
        "device_functions_replaced": False,
        "physical_stream_ownership_verified": False,
        "overlap_verified": False,
        "performance_accepted": False,
        "first_host_scope_may_precede_profiler_start": True,
        "scope_prefix": PROFILE_SCOPE_PREFIX,
        "status_after_prepare": status,
        "steps": [],
    }


@contextmanager
def native_attention_profile_step(
    owner: AFDNPUAttentionModelRunnerV2, report, name: str
) -> Iterator[None]:
    # This CPU trace scope surrounds the unmodified execute and sample calls.
    import torch

    from afd_plugin.compat.npu.profiler import AFDNPUProfilerSession

    session = owner.prof
    assert isinstance(session, AFDNPUProfilerSession)
    detail = report["native_attention_profile"]
    index = len(detail["steps"])
    assert index < PROFILED_EXECUTE_STEPS and name == PROFILE_STEP_NAMES[index]
    status_before = session.status()
    assert status_before["steps"] == index and not status_before["closed"]
    record = {
        "name": name,
        "scope_name": PROFILE_SCOPE_PREFIX + name,
        "pid": os.getpid(),
        "thread_id": threading.get_ident(),
        "native_thread_id": threading.get_native_id(),
        "host_begin_time_ns": time.time_ns(),
        "host_begin_monotonic_ns": time.monotonic_ns(),
        "parents_before": len(report["transactions"]),
        "status_before": status_before,
        "returned": False,
    }
    detail["steps"].append(record)
    try:
        with torch.autograd.profiler.record_function(record["scope_name"]):
            yield
        status_after = session.status()
        assert status_after["steps"] == index + 1
        assert status_after["owner_thread_id"] == threading.get_ident()
        assert status_after["applied"] and not status_after["failed"]
        assert len(report["transactions"]) == record["parents_before"] + 1
        record["returned"] = True
    except BaseException as error:
        record["error"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        record["host_end_time_ns"] = time.time_ns()
        record["host_end_monotonic_ns"] = time.monotonic_ns()
        record["parents_after"] = len(report["transactions"])
        record["status_after"] = session.status()


def finish_native_attention_profile(
    owner: AFDNPUAttentionModelRunnerV2, report, profile_dir: Path
) -> None:
    from afd_plugin.compat.npu.profiler import AFDNPUProfilerSession

    session = owner.prof
    assert isinstance(session, AFDNPUProfilerSession)
    detail = report["native_attention_profile"]
    assert profile_dir.resolve() == Path(detail["trace_root"])
    assert report["native_attention_owner"]["acknowledged_stop"]
    assert len(detail["steps"]) == PROFILED_EXECUTE_STEPS
    assert all(step["returned"] for step in detail["steps"])
    status_before = session.status()
    assert status_before["steps"] == PROFILED_EXECUTE_STEPS
    assert status_before["owner_thread_id"] == threading.get_ident()
    assert status_before["applied"] and not status_before["closed"]
    assert not status_before["failed"]
    detail["stop_acknowledged_before_finish"] = True
    detail["finish_thread_id"] = threading.get_ident()
    detail["finish_native_thread_id"] = threading.get_native_id()
    detail["status_before_finish"] = status_before
    detail["trace_before_finish"] = _file_inventory(profile_dir)
    detail["finish_begin_time_ns"] = time.time_ns()
    detail["finish_begin_monotonic_ns"] = time.monotonic_ns()
    try:
        # The probe explicitly exports on the same execution owner after STOP.
        # This is the real session method, not a Worker shutdown surrogate.
        session.finish()
    except BaseException as error:
        detail["finish_error"] = {
            "type": type(error).__name__,
            "message": str(error),
        }
        raise
    finally:
        detail["finish_end_time_ns"] = time.time_ns()
        detail["finish_end_monotonic_ns"] = time.monotonic_ns()
        detail["status_after_finish"] = session.status()
    status_after = detail["status_after_finish"]
    assert status_after["closed"] and not status_after["failed"]
    assert not status_after["applied"] and not status_after["pending"]
    assert status_after["steps"] == PROFILED_EXECUTE_STEPS
    files = _file_inventory(profile_dir)
    detail["files_after_finish"] = files
    detail["trace_paths"] = [
        entry for entry in files if Path(entry["path"]).name == "trace_view.json"
    ]
    detail["csv_paths"] = [
        entry for entry in files if Path(entry["path"]).name == "kernel_details.csv"
    ]
    detail["finish_returned"] = True
    detail["raw_trace_and_csv_present"] = bool(
        detail["trace_paths"] and detail["csv_paths"]
    )
    detail["trace_verification"] = "pending-independent-offline-parse"
