# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Assemble a real target-only PD Graph owner before any remote request.

Runtime imports are isolated to the selected NPU worker. The caller supplies the
same allocated PD storage and constructor-free controlled Attention model used
by its real ActiveKVConnector. This helper does not schedule requests or replace
native capture, input preparation, metadata builds or graph replay. SparseFA
query tiling and checkpoint model arithmetic remain outside this component.
"""

from __future__ import annotations

import hashlib
from functools import partial
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hccl_native_attention_pd_probe import NativePdStorage
    from vllm.config import VllmConfig

    from afd_plugin.connectors.npu.hccl_staged import HcclStagedAFDConnector
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )

TARGET_QUERY_LEN = 1
TARGET_STAGES = 2
CAPTURE_SIZES = (2, 4)
GRAPH_WARMUP_RUNS = 1
UBATCH_TIMEOUT_SECONDS = 45


def configure_pd_target_graph(config: VllmConfig) -> None:
    """Fix the controlled D/F declaration before model/connector construction."""
    # Worker-only imports preserve the standalone parent's stdlib preflight.
    from vllm.config import CompilationMode, CUDAGraphMode

    from afd_plugin.compat.npu.runtime_config import validate_deepseek_v41_pd

    config.speculative_config = config.engram_config = None
    config.model_config.enforce_eager = False
    compilation = config.compilation_config
    compilation.mode = CompilationMode.NONE
    compilation.cudagraph_mode = CUDAGraphMode.FULL_DECODE_ONLY
    compilation.use_inductor_graph_partition = False
    compilation.cudagraph_capture_sizes = list(CAPTURE_SIZES)
    compilation.max_cudagraph_capture_size = max(CAPTURE_SIZES)
    compilation.cudagraph_num_of_warmups = GRAPH_WARMUP_RUNS
    parallel = config.parallel_config
    parallel.enable_dbo = False
    parallel.ubatch_size = TARGET_STAGES
    parallel.dbo_decode_token_threshold = TARGET_STAGES
    assert parallel.use_ubatching and parallel.num_ubatches == TARGET_STAGES
    assert config.scheduler_config.max_num_batched_tokens >= max(CAPTURE_SIZES)
    extra = config.additional_config["afd"]["connector_extra_config"]
    extra["graph_exchange_order"] = "stage_serial"
    validate_deepseek_v41_pd(config)


def initialize_pd_target_graph(
    owner: AFDNPUAttentionModelRunnerV2,
    storage: NativePdStorage,
    connector: HcclStagedAFDConnector,
    report: dict,
) -> None:
    """Capture on the owner's registered KV, before any PD request is admitted."""
    import torch
    from vllm.config import CUDAGraphMode, set_current_vllm_config
    from vllm.v1.worker.gpu.kv_connector import ActiveKVConnector
    from vllm.v1.worker.utils import AttentionGroup
    from vllm_ascend.attention.dsa_v41 import AscendDSAV41MetadataBuilder
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )
    from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager
    from vllm_ascend.worker.v2.utils import prepare_v41_source_rope

    from afd_plugin.compat.patches.npu.mrv2_ubatching import use_npu_ubatch_sm_control
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.v1.worker.npu.hccl_v41_graph_bootstrap import (
        HcclV41AttentionGraphBootstrap,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_ubatch_runner import HcclV41UBatchRunner

    config, device = owner.vllm_config, owner.device
    transport = connector.transport
    assert config is storage.vllm_config is owner.kv_connector.vllm_config
    assert owner.connector is connector and owner.hccl_v41_transport is transport
    assert owner.kv_cache_config is storage.kv_cache_config
    assert isinstance(owner.kv_connector, ActiveKVConnector)
    assert not owner.req_states.req_id_to_index and owner.execute_model_state is None
    assert owner.cudagraph_manager is owner.ubatch_runner is None
    assert config.speculative_config is config.engram_config is None
    assert owner.decode_query_len == TARGET_QUERY_LEN
    assert config.parallel_config.num_ubatches == TARGET_STAGES
    assert transport.initialized and not transport.terminal and not transport.closed
    assert transport.plan is transport.graph_reservation is None
    assert transport.negotiated_capabilities.graph_execution_version == 1
    assert transport.negotiated_capabilities.target_query_len == TARGET_QUERY_LEN
    assert transport.negotiated_capabilities.graph_exchange_order == "stage_serial"
    settings = HcclOverlapSettings(
        eager_u2_stream_overlap=False,
        graph_u2_compute_overlap=False,
        graph_u2_hybrid_dag=False,
        graph_u2_attention_three_stream=False,
        graph_u2_ffn_recv_stream=False,
        graph_u2_ffn_cross_layer=False,
    )
    assert connector.overlap_settings == settings
    detail = report.setdefault("native_pd_graph", {})
    assert not detail.get("native_capture_completed", False)
    detail.setdefault("python_attention_calls", [])
    kv_connector = owner.kv_connector.kv_connector
    # Native Mooncake constructs an empty metadata object before any request.
    # Check that exact empty state before establishing an idle capture boundary;
    # never clear metadata that contains a pending real transfer.
    assert kv_connector.has_connector_metadata()
    initial_metadata = kv_connector._get_connector_metadata()
    assert type(initial_metadata) is MooncakeConnectorMetadata
    assert not initial_metadata.requests
    assert not initial_metadata.requests_to_send
    assert not initial_metadata.reqs_in_batch
    kv_connector.clear_connector_metadata()
    assert not kv_connector.has_connector_metadata()
    detail["initial_empty_pd_metadata_cleared"] = True
    detail.update(
        native_builder_build_query_metadata=False,
        native_sparse_fa_executed=False,
        checkpoint_weights_loaded=False,
        full_model_accepted=False,
        normal_serving_constructor_executed=False,
        native_kv_initialization_executed=False,
        same_owner_native_capture=False,
        physical_stream_overlap_accepted=False,
        performance_accepted=False,
        capture_started_without_requests=True,
        capture_started_without_pd_metadata=True,
    )

    class ComponentAttentionGroup(AttentionGroup):
        # Public native constructor option for this controlled cache-reading
        # Attention. Copying these groups for U2 preserves the option while
        # retaining genuine builders, source RoPE and FULL metadata semantics.
        def create_metadata_builders(
            self,
            vllm_config,
            device,
            kernel_block_size: int | None = None,
            num_metadata_builders: int = 1,
        ):
            self.metadata_builders = [
                AscendDSAV41MetadataBuilder(
                    self.kv_cache_spec,
                    self.layer_names,
                    vllm_config,
                    device,
                    build_query_metadata=False,
                )
                for _ in range(num_metadata_builders)
            ]
            if kernel_block_size is not None:
                for builder in self.metadata_builders:
                    builder.set_kernel_block_size(kernel_block_size)

    kernel_block_sizes = [
        group.kv_cache_spec.block_size
        for group in storage.kv_cache_config.kv_cache_groups
    ]
    rebuilt = []
    with set_current_vllm_config(config):
        for group_index, cache_group in enumerate(owner.attn_groups):
            groups = []
            for group in cache_group:
                replacement = ComponentAttentionGroup(
                    backend=group.backend,
                    layer_names=list(group.layer_names),
                    kv_cache_spec=group.kv_cache_spec,
                    kv_cache_group_id=group.kv_cache_group_id,
                )
                replacement.create_metadata_builders(
                    config, device, kernel_block_size=kernel_block_sizes[group_index]
                )
                groups.append(replacement)
            rebuilt.append(groups)
    # This occurs before the bootstrap retains its group/builders. The real
    # native U2 constructor copies these actual groups for its child builders.
    owner.attn_groups = rebuilt
    physical = [
        storage.raw_tensors[descriptor.layers[0]]
        for descriptor in storage.kv_cache_config.kv_cache_tensors
    ]
    before = [tensor.detach().cpu().clone() for tensor in physical]
    addresses = [tensor.data_ptr() for tensor in physical]
    detail["physical_pool_addresses_before_capture"] = addresses
    detail["physical_pool_sha256_before_capture"] = [
        hashlib.sha256(tensor.numpy().tobytes()).hexdigest() for tensor in before
    ]
    bootstrap = HcclV41AttentionGraphBootstrap(
        owner,
        synchronize=partial(torch.npu.synchronize, device),
        overlap_settings=connector.overlap_settings,
    )
    owner.hccl_v41_graph_bootstrap = bootstrap
    try:
        bootstrap.bind_loaded_model()
        bootstrap.begin_kv_init()
        with use_npu_ubatch_sm_control():
            owner.ubatch_runner = HcclV41UBatchRunner(
                config,
                device,
                owner.model_state,
                owner.attn_groups,
                storage.kv_cache_config,
                owner.max_num_reqs,
                kernel_block_sizes=kernel_block_sizes,
                timeout_s=UBATCH_TIMEOUT_SECONDS,
                transport=transport,
                graph_owner=bootstrap.session,
            )
        detail["native_ubatch_constructor_executed"] = True
        owner.cudagraph_manager = ModelAclGraphManager(
            config,
            device,
            CUDAGraphMode.FULL_DECODE_ONLY,
            TARGET_QUERY_LEN,
            model_runner=owner,
            ubatch_runner=owner.ubatch_runner,
        )
        detail["native_manager_constructor_executed"] = True
        prepare_v41_source_rope(owner)
        for groups in owner.ubatch_runner.stage_attn_groups:
            for cache_group in groups:
                for group in cache_group:
                    for builder in group.metadata_builders:
                        builder.prepare_source_rope()
        bootstrap.complete_kv_init()
        # The actual AFD entry performs all-peer preflight and the pinned native
        # capture_model/ModelAclGraphManager/ModelWithContext/NPUGraph lifecycle.
        detail["capture_memory_bytes"] = owner.capture_model()
        assert not owner.req_states.req_id_to_index
        assert owner.execute_model_state is None
        assert not owner.kv_connector.kv_connector.has_connector_metadata()
        assert [tensor.data_ptr() for tensor in physical] == addresses
        after = [tensor.detach().cpu() for tensor in physical]
        assert all(
            torch.equal(old, new) for old, new in zip(before, after, strict=True)
        )
        detail["physical_pool_addresses_after_capture"] = [
            tensor.data_ptr() for tensor in physical
        ]
        detail["physical_pool_sha256_after_capture"] = [
            hashlib.sha256(tensor.numpy().tobytes()).hexdigest() for tensor in after
        ]
        detail["capture_preserved_physical_kv"] = True
        detail["captured_descriptors"] = [
            {
                "mode": descriptor.cg_mode.name,
                "num_tokens": descriptor.num_tokens,
                "num_reqs": descriptor.num_reqs,
                "num_ubatches": descriptor.num_ubatches,
                "uniform_token_count": descriptor.uniform_token_count,
                "max_query_len": descriptor.max_query_len,
                "graph_class": type(graph).__module__ + "." + type(graph).__qualname__,
            }
            for descriptor, graph in owner.cudagraph_manager.graphs.items()
        ]
        assert owner.cudagraph_manager.graphs
        detail["same_owner_native_capture"] = True
        detail["native_capture_completed"] = True
    except BaseException:
        bootstrap.fail()
        raise
