# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Real two-request PD scheduling followed by eager and native Graph targets."""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vllm.v1.core.sched.output import SchedulerOutput
    from vllm.v1.core.sched.scheduler import Scheduler
    from vllm.v1.request import Request
    from vllm.v1.structured_output import StructuredOutputManager

    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )

GRAPH_PROMPTS = ((11, 12, 13, 14, 15), (21, 22, 23))
GRAPH_SOURCE_BLOCKS = (1, 2)
GRAPH_SAMPLE_ROUNDS = 3
GRAPH_SAMPLE_TOKEN = 7
BF16_BYTES = 2
POLL_SECONDS = 0.05


def graph_request_ids(run_id):
    return tuple(run_id + f"-source-g{i}" for i in range(len(GRAPH_PROMPTS))), tuple(
        run_id + f"-destination-g{i}" for i in range(len(GRAPH_PROMPTS))
    )


def observe_pd_graph_control(connector, report):
    # Observe successful real codec operations, never replace peer replies.
    from afd_plugin.distributed.hccl_plan import encode_hccl_plan_message

    transport = connector.transport
    actual_send, actual_recv = transport._send_control, transport._recv_control
    actual_finish = transport.finish_forward
    records, completed = [], []
    report["graph_hccl_control"], report["graph_completed_parents"] = records, completed

    def record(direction, rank, message):
        raw = encode_hccl_plan_message(message)
        records.append(
            {
                "direction": direction,
                "peer_world_rank": rank,
                "canonical_hex": raw.hex(),
                "sha256": hashlib.sha256(raw).hexdigest(),
            }
        )

    def send(rank, message):
        actual_send(rank, message)
        record("send", rank, message)

    def receive(rank):
        message = actual_recv(rank)
        record("receive", rank, message)
        return message

    def finish():
        plan = transport.plan
        actual_finish()
        completed.append(
            {
                "id": plan.transaction_id,
                "phase": plan.graph_execution.phase,
                "reason": plan.graph_execution.reason,
                "key": None
                if plan.graph_execution.key is None
                else plan.graph_execution.key.digest,
                "num_stages": len(plan.stages),
                "valid_tokens": [list(s.attention_valid_tokens) for s in plan.stages],
            }
        )

    transport._send_control, transport._recv_control = send, receive
    transport.finish_forward = finish


def register_graph_sources(args, active, report, deadline, zero_step):
    from hccl_native_attention_pd_probe import await_peer_record, write_json
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )

    source_ids, _ = graph_request_ids(args.run_id)
    metadata = MooncakeConnectorMetadata()
    metadata.reqs_in_batch.update(source_ids)
    metadata.requests_to_send.update((req_id, time.time()) for req_id in source_ids)
    sent, received = zero_step(active, metadata)
    assert not sent and not received
    write_json(
        args.output_dir / "producer-ready.json",
        {
            "run_id": args.run_id,
            **report["handshake"],
            "source_request_ids": source_ids,
        },
    )
    finished = set()
    while finished != set(source_ids):
        if time.monotonic() >= deadline:
            raise TimeoutError("Graph PD sources did not observe both native DONEs")
        time.sleep(POLL_SECONDS)
        sent, received = zero_step(active, MooncakeConnectorMetadata())
        assert not received and not finished.intersection(sent)
        finished.update(sent)
    report["native_done_request_ids"] = sorted(finished)
    report["native_done_observed"] = True
    await_peer_record(
        args.output_dir / "consumer-verified.json",
        run_id=args.run_id,
        deadline=deadline,
    )


@dataclass
class NativePdGraphBatch:
    owner: AFDNPUAttentionModelRunnerV2
    scheduler: Scheduler
    structured_output_manager: StructuredOutputManager
    requests: tuple[Request, ...]
    first_target: SchedulerOutput
    group_block_pairs: tuple[tuple[tuple[int, int], ...], ...]


def run_pd_graph_handoff(
    args, config, storage, active, connector, source, peer, report, deadline
):
    import torch
    from hccl_native_attention_pd_graph_probe import initialize_pd_target_graph
    from hccl_native_attention_pd_model_probe import build_pd_attention_owner
    from hccl_native_attention_pd_probe import snapshot_pages
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from vllm.sampling_params import SamplingParams
    from vllm.v1.core.sched import scheduler as native_scheduler
    from vllm.v1.core.sched.interface import PauseState
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.request import Request, RequestStatus
    from vllm.v1.structured_output import StructuredOutputManager
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    detail = report.setdefault("native_pd_graph", {"python_attention_calls": []})
    detail["passed"] = False
    source_ids, destination_ids = graph_request_ids(args.run_id)
    assert peer["source_request_ids"] == list(source_ids)
    with torch.inference_mode(), torch_cuda_wrapper():
        owner, _ = build_pd_attention_owner(
            config,
            storage,
            active,
            connector,
            torch.device("npu", args.device),
            report,
            graph=True,
            write_cache=True,
        )
        initialize_pd_target_graph(owner, storage, connector, report)
        after_capture = snapshot_pages(
            storage, args.output_dir, label="graph-after-capture"
        )
        assert [e["sha256"] for e in after_capture] == [
            e["sha256"] for e in report["before"]
        ]
        detail["after_capture"] = after_capture
        detail["capture_physical_pools_unchanged"] = True
        config.cache_config.num_gpu_blocks = storage.kv_cache_config.num_blocks
        structured = StructuredOutputManager(config)
        scheduler = native_scheduler.Scheduler(
            config,
            storage.kv_cache_config,
            structured,
            block_size=config.cache_config.block_size,
            hash_block_size=config.cache_config.block_size,
        )
        group_count = len(storage.kv_cache_config.kv_cache_groups)
        requests = []
        for prompt, source_block, source_id, dest_id in zip(
            GRAPH_PROMPTS, GRAPH_SOURCE_BLOCKS, source_ids, destination_ids, strict=True
        ):
            params = {
                "do_remote_prefill": True,
                "do_remote_decode": False,
                "remote_block_ids": tuple([source_block] for _ in range(group_count)),
                "remote_engine_id": source.engine_id,
                "remote_request_id": source_id,
                "remote_host": source.local_ip,
                "remote_port": peer["port"],
                "remote_ptp_size": 1,
                "remote_pcp_size": 1,
                "num_prompt_blocks": 1,
            }
            request = Request(
                dest_id,
                list(prompt),
                SamplingParams(
                    temperature=0,
                    max_tokens=GRAPH_SAMPLE_ROUNDS,
                    extra_args={"kv_transfer_params": params},
                ),
                None,
            )
            scheduler.add_request(request)
            requests.append(request)
        output = scheduler.schedule()
        assert output.total_num_scheduled_tokens == 0
        assert all(r.status == RequestStatus.WAITING_FOR_REMOTE_KVS for r in requests)
        transfers = output.kv_connector_metadata.requests
        assert set(transfers) == set(destination_ids)
        pairs = [[] for _ in range(group_count)]
        transfer_records = []
        for index, dest_id in enumerate(destination_ids):
            transfer = transfers[dest_id]
            assert transfer.remote_request_id == source_ids[index]
            assert transfer.remote_block_ids == tuple(
                [GRAPH_SOURCE_BLOCKS[index]] for _ in range(group_count)
            )
            assert transfer.num_external_tokens == len(GRAPH_PROMPTS[index]) - 1
            for group_id, (src, dst) in enumerate(
                zip(transfer.remote_block_ids, transfer.local_block_ids, strict=True)
            ):
                pairs[group_id].extend(zip(src, dst, strict=True))
            transfer_records.append(
                {
                    "request_id": dest_id,
                    "remote_request_id": transfer.remote_request_id,
                    "local_block_ids": transfer.local_block_ids,
                    "remote_block_ids": transfer.remote_block_ids,
                    "num_external_tokens": transfer.num_external_tokens,
                }
            )
        detail["transfers"] = transfer_records
        detail["initial_schedule"] = scheduler_record(output)
        detail["zero_work_steps"] = []
        # Use the native public pause API to admit the ready requests together.
        # Different real read completion times must not create a flaky batch.
        scheduler.set_pause_state(PauseState.PAUSED_NEW)
        detail["admission_pause_states"] = [scheduler.pause_state.name]
        received = set()
        while True:
            if time.monotonic() >= deadline:
                raise TimeoutError("Graph PD native batch admission exceeded deadline")
            assert (
                not output.total_num_scheduled_tokens and not output.has_sync_kv_loads
            )
            returned = owner.execute_model(output)
            assert isinstance(returned, ModelRunnerOutput) and not returned.req_ids
            kv = returned.kv_connector_output
            completed = set(() if kv is None else kv.finished_recving or ())
            assert not received.intersection(completed)
            assert completed <= set(destination_ids)
            assert kv is None or not (
                kv.finished_sending or kv.failed_recving or kv.invalid_block_ids
            )
            received.update(completed)
            scheduler.update_from_output(output, returned)
            detail["zero_work_steps"].append(
                {
                    "schedule": scheduler_record(output),
                    "finished_recving": sorted(completed),
                    "original_owner_output": True,
                }
            )
            if received == set(destination_ids):
                scheduler.set_pause_state(PauseState.UNPAUSED)
                detail["admission_pause_states"].append(scheduler.pause_state.name)
            output = scheduler.schedule()
            if output.total_num_scheduled_tokens:
                assert received == set(destination_ids)
                assert output.num_scheduled_tokens == dict.fromkeys(destination_ids, 1)
                assert len(output.scheduled_new_reqs) == len(requests)
                detail["first_target_schedule"] = scheduler_record(output)
                break
            time.sleep(POLL_SECONDS)
    return NativePdGraphBatch(
        owner,
        scheduler,
        structured,
        tuple(requests),
        output,
        tuple(tuple(group) for group in pairs),
    )


def run_pd_graph_targets(handoff, storage, report, output_dir):
    import torch
    from hccl_native_attention_pd_probe import HEAD_SIZE, LAYER_COUNT, snapshot_pages
    from hccl_native_attention_pd_scheduler_probe import scheduler_record
    from hccl_native_attention_probe import ROUTER_DELTA, ROUTER_SCALE
    from vllm.v1.outputs import ModelRunnerOutput
    from vllm.v1.worker.gpu.async_utils import AsyncOutput
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    owner, scheduler = handoff.owner, handoff.scheduler
    detail = report["native_pd_graph"]
    expected_pools = [
        bytearray((output_dir / e["path"]).read_bytes()) for e in report["after"]
    ]
    request_info = {
        request.request_id: (prompt, transfer["local_block_ids"])
        for request, prompt, transfer in zip(
            handoff.requests, GRAPH_PROMPTS, detail["transfers"], strict=True
        )
    }
    detail["target_steps"] = []
    with torch.inference_mode(), torch_cuda_wrapper():
        step = handoff.first_target
        for round_index in range(GRAPH_SAMPLE_ROUNDS):
            if round_index:
                step = scheduler.schedule()
            assert step.num_scheduled_tokens == dict.fromkeys(request_info, 1)
            python_calls = len(detail["python_attention_calls"])
            assert owner.execute_model(step) is None
            state = owner.execute_model_state
            batch = state.input_batch
            ids = batch.input_ids.cpu().tolist()
            positions = batch.positions.cpu().tolist()
            request_ids = list(batch.req_ids)
            assert set(request_ids) == set(request_info)
            expected = torch.empty((len(request_ids), HEAD_SIZE), dtype=torch.bfloat16)
            writes = []
            for row, req_id in enumerate(request_ids):
                prompt, blocks = request_info[req_id]
                token = prompt[-1] if round_index == 0 else GRAPH_SAMPLE_TOKEN
                position = len(prompt) - 1 + round_index
                assert ids[row] == token and positions[row] == position
                hidden = (
                    torch.arange(HEAD_SIZE).float() / HEAD_SIZE + token
                ).bfloat16()
                for layer in range(LAYER_COUNT):
                    name = f"model.layers.{layer}.self_attn.swa_cache"
                    group_id = next(
                        i
                        for i, g in enumerate(storage.kv_cache_config.kv_cache_groups)
                        if name in g.layer_names
                    )
                    block = blocks[group_id][0]
                    pool = next(
                        i
                        for i, p in enumerate(storage.kv_cache_config.kv_cache_tensors)
                        if name in p.layers
                    )
                    descriptor = storage.kv_cache_config.kv_cache_tensors[pool]
                    raw = storage.raw_tensors[descriptor.layers[0]]
                    cache = storage.caches[name]
                    strides = cache.stride()
                    offset = cache.data_ptr() - raw.data_ptr()
                    read_at = offset + BF16_BYTES * (
                        block * strides[0] + (position - 1) * strides[1]
                    )
                    write_at = offset + BF16_BYTES * (
                        block * strides[0] + position * strides[1]
                    )
                    row_bytes = HEAD_SIZE * BF16_BYTES
                    previous = torch.frombuffer(
                        expected_pools[pool][read_at : read_at + row_bytes],
                        dtype=torch.bfloat16,
                    ).clone()
                    raw_hidden = hidden.view(torch.uint8).numpy().tobytes()
                    expected_pools[pool][write_at : write_at + row_bytes] = raw_hidden
                    writes.append(
                        {
                            "request_id": req_id,
                            "layer": layer,
                            "pool": pool,
                            "byte_offset": write_at,
                            "value_hex": raw_hidden.hex(),
                        }
                    )
                    attended = (hidden.float() + previous.float() + position).bfloat16()
                    residual = (hidden.float() + attended.float()).bfloat16()
                    router = residual.float() + ROUTER_DELTA
                    remote = (
                        residual.float()
                        + (router - residual.float()) * ROUTER_SCALE
                        + token
                    ).bfloat16()
                    hidden = (residual.float() + remote.float()).bfloat16()
                expected[row] = hidden
            actual = state.hidden_states.cpu()
            detail["last_numeric_observation"] = {
                "round": round_index,
                "request_ids": request_ids,
                "input_ids": ids,
                "positions": positions,
                "actual": actual.float().tolist(),
                "expected": expected.float().tolist(),
                "cache_writes": writes,
                "physical_pages": snapshot_pages(
                    storage, output_dir, label=f"graph-observed-{round_index}"
                ),
            }
            torch.testing.assert_close(actual, expected, rtol=0, atol=0)
            sampled = owner.sample_tokens(None)
            assert isinstance(sampled, AsyncOutput)
            returned = sampled.get_output()
            assert isinstance(returned, ModelRunnerOutput)
            assert set(returned.req_ids) == set(request_info)
            assert returned.sampled_token_ids == [[GRAPH_SAMPLE_TOKEN]] * len(
                request_info
            )
            assert owner.execute_model_state is None
            histories = {}
            for req_id, (prompt, _) in request_info.items():
                index = owner.req_states.req_id_to_index[req_id]
                total = int(owner.req_states.total_len.gpu[index].cpu())
                history = (
                    owner.req_states.all_token_ids.gpu[index, :total].cpu().tolist()
                )
                assert history == list(prompt) + [GRAPH_SAMPLE_TOKEN] * (
                    round_index + 1
                )
                histories[req_id] = history
            scheduler.update_from_output(step, returned)
            pages = snapshot_pages(
                storage, output_dir, label=f"graph-model-{round_index}"
            )
            for index, page in enumerate(pages):
                assert (output_dir / page["path"]).read_bytes() == expected_pools[index]
                assert page["data_ptr"] == report["after"][index]["data_ptr"]
                page["expected_sha256"] = hashlib.sha256(
                    expected_pools[index]
                ).hexdigest()
            parent = report["graph_completed_parents"][-1]
            if round_index:
                assert parent["phase"] == "replay" and parent["num_stages"] == 2
                assert len(detail["python_attention_calls"]) == python_calls
            else:
                assert parent["phase"] == "eager"
            detail["target_steps"].append(
                {
                    "schedule": scheduler_record(step),
                    "request_ids": request_ids,
                    "input_ids": ids,
                    "positions": positions,
                    "hidden_states": actual.float().tolist(),
                    "hidden_sha256": hashlib.sha256(
                        actual.view(torch.uint8).numpy().tobytes()
                    ).hexdigest(),
                    "sampled_token_ids": returned.sampled_token_ids,
                    "histories": histories,
                    "cache_writes": writes,
                    "physical_pages": pages,
                    "completed_parent": parent,
                    "python_attention_calls_before": python_calls,
                    "python_attention_calls_after": len(
                        detail["python_attention_calls"]
                    ),
                }
            )
        assert all(request.is_finished() for request in handoff.requests)
        retirement = scheduler.schedule()
        assert not retirement.total_num_scheduled_tokens
        assert retirement.finished_req_ids == set(request_info)
        returned = owner.execute_model(retirement)
        assert isinstance(returned, ModelRunnerOutput) and not returned.req_ids
        assert (
            not owner.req_states.req_id_to_index and owner.execute_model_state is None
        )
        detail["retirement_schedule"] = scheduler_record(retirement)
        detail["native_requests_retired"] = True
        detail["all_physical_bytes_match_write_oracle"] = True
        detail["passed"] = True
        report["native_attention_owner_executed"] = True
