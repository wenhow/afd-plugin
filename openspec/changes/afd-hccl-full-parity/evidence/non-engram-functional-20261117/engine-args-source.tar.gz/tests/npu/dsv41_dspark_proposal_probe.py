# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Run an unchanged native V4.1 DSpark proposal with explicit fixture auxiliaries.

The default and --help use only the standard library. --run reuses the frozen
native constructor/loader/binding component, then runs real prepare/Attention/
HC/MoE/Markov sampling. This is neither target execution nor live P/PD serving.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import struct
import sys
import traceback
from pathlib import Path

from dsv41_dspark_speculator_probe import (
    AUX_LAYER_IDS,
    HIDDEN_SIZE,
    NATIVE_PLUGINS,
    ROPE_HEAD_SIZE,
    SEED,
    SPECULATIVE_TOKENS,
    VOCAB_SIZE,
    bind_native_attention,
    create_config,
    create_target_interface,
    loaded_runtime_libraries,
    native_source,
    record_config,
    sha256,
    write_report,
)

PROMPT_IDS = (11, 12, 13, 14)
LAST_SAMPLED_TOKEN = 7
REQUEST_INDEX = 0
ALLOCATED_BLOCK = 1
MAX_PREFIX_BF16_ULPS = 2
ROPE_BASE = 10000.0
BYTE_MASK = 255
BF16_SIGN_BIT = 32768
PATTERN_BASE = 16000
PATTERN_PERIOD = 128


def artifact(output_dir: Path, name: str, raw: bytes) -> dict:
    path = output_dir / name
    path.write_bytes(raw)
    return {"path": name, "bytes": len(raw), "sha256": sha256(raw)}


def tensor_artifact(output_dir: Path, name: str, tensor) -> dict:
    import torch

    host = tensor.detach().cpu().contiguous()
    record = artifact(output_dir, name, host.view(torch.uint8).numpy().tobytes())
    record.update(
        shape=list(host.shape), dtype=str(host.dtype), data_ptr=tensor.data_ptr()
    )
    return record


def make_input_batch(buffers, block_tables, device):
    """Declare actual non-dummy native input; no target or scheduler is simulated."""
    import numpy as np
    import torch
    from vllm_ascend.attention.attention_v1 import AscendAttentionState
    from vllm_ascend.worker.v2.input_batch import AscendInputBatch

    count = len(PROMPT_IDS)
    query_cpu = np.array([0, count], dtype=np.int32)
    mapping_cpu = np.array([REQUEST_INDEX], dtype=np.intp)
    mapping = torch.tensor(mapping_cpu, dtype=torch.int64, device=device)
    buffers.input_ids[:count].copy_(
        torch.tensor(PROMPT_IDS, dtype=torch.int32, device=device)
    )
    buffers.positions[:count].copy_(
        torch.arange(count, dtype=torch.int64, device=device)
    )
    buffers.is_padding[:count].fill_(False)
    buffers.query_start_loc[:2].copy_(torch.tensor(query_cpu, device=device))
    buffers.seq_lens[:1].fill_(count)
    buffers.seq_lens_cpu[:1].fill_(count)
    batch = AscendInputBatch(
        req_ids=["native-proposal-fixture"],
        num_reqs=1,
        num_reqs_after_padding=1,
        idx_mapping=mapping,
        idx_mapping_np=mapping_cpu,
        expanded_idx_mapping=mapping,
        expanded_local_pos=torch.zeros(1, dtype=torch.int32, device=device),
        num_scheduled_tokens=np.array([count], dtype=np.int32),
        num_tokens=count,
        num_tokens_after_padding=count,
        num_draft_tokens=0,
        num_draft_tokens_per_req=None,
        query_start_loc=buffers.query_start_loc[:2],
        query_start_loc_np=query_cpu,
        seq_lens=buffers.seq_lens[:1],
        seq_lens_cpu_upper_bound=buffers.seq_lens_cpu[:1],
        dcp_local_seq_lens=None,
        num_computed_tokens_np=np.zeros(1, dtype=np.int32),
        prefill_len_np=np.array([count], dtype=np.int32),
        num_computed_prefill_tokens_np=np.zeros(1, dtype=np.int32),
        is_prefilling_np=np.ones(1, dtype=np.bool_),
        has_prefill=True,
        input_ids=buffers.input_ids[:count],
        positions=buffers.positions[:count],
        is_padding=buffers.is_padding[:count],
        logits_indices=torch.tensor([count - 1], dtype=torch.int64, device=device),
        cu_num_logits=torch.tensor([0, 1], dtype=torch.int32, device=device),
        cu_num_logits_np=np.array([0, 1], dtype=np.int32),
        has_structured_output_reqs=False,
        prompt_lens=None,
        max_query_len=count,
        seq_lens_np=buffers.seq_lens_np[:1],
        attn_state=AscendAttentionState.PrefillNoCache,
        is_dummy=False,
    )
    allocations = tuple([ALLOCATED_BLOCK] for _ in block_tables.block_sizes)
    block_tables.append_block_ids(REQUEST_INDEX, allocations, overwrite=True)
    block_tables.apply_staged_writes()
    block_tables.gather_block_tables(batch.idx_mapping, batch.num_reqs_after_padding)
    slots = block_tables.compute_slot_mappings(
        batch.idx_mapping,
        batch.query_start_loc,
        batch.positions,
        batch.num_tokens_after_padding,
    )
    return batch, slots, allocations


def storage_images(caches, output_dir: Path):
    """Initialize each real allocation once, retaining all aliases and padding."""
    import torch

    pools, bindings = [], {}
    by_storage = {}
    for name, cache in caches.items():
        tensors = cache if isinstance(cache, (list, tuple)) else (cache,)
        bindings[name] = []
        for tensor in tensors:
            storage = tensor.untyped_storage()
            key = (str(tensor.device), storage.data_ptr(), storage.nbytes())
            if key not in by_storage:
                index = len(pools)
                by_storage[key] = index
                view = torch.empty(0, dtype=torch.uint8, device=tensor.device).set_(
                    storage, 0, (storage.nbytes(),), (1,)
                )
                assert storage.nbytes() % 2 == 0
                raw = b"".join(
                    struct.pack("<H", PATTERN_BASE + (word + index) % PATTERN_PERIOD)
                    for word in range(storage.nbytes() // 2)
                )
                view.copy_(
                    torch.frombuffer(bytearray(raw), dtype=torch.uint8).to(
                        tensor.device
                    )
                )
                pools.append(
                    {"view": view, "before": raw, "writable": bytearray(len(raw))}
                )
            index = by_storage[key]
            bindings[name].append(
                {
                    "pool": index,
                    "tensor_identity": id(tensor),
                    "shape": list(tensor.shape),
                    "stride": list(tensor.stride()),
                    "storage_offset": tensor.storage_offset(),
                    "element_size": tensor.element_size(),
                    "dtype": str(tensor.dtype),
                    "data_ptr": tensor.data_ptr(),
                }
            )
    records = []
    for index, pool in enumerate(pools):
        records.append(
            {"before": artifact(output_dir, f"pool-{index}-before.bin", pool["before"])}
        )
    return pools, bindings, records


def declare_writable_rows(cache, binding, pool, positions):
    """Independent physical address mask for the declared draft SWA rows."""
    assert cache.ndim == 4 and cache.shape[2:] == (1, HIDDEN_SIZE)
    assert cache.element_size() == 2 and cache.stride(-1) == 1
    assert cache.stride(-2) == HIDDEN_SIZE
    for position in positions:
        block, row = ALLOCATED_BLOCK, position
        assert 0 <= block < cache.shape[0] and 0 <= row < cache.shape[1]
        start = 2 * (
            cache.storage_offset() + block * cache.stride(0) + row * cache.stride(1)
        )
        stop = start + 2 * HIDDEN_SIZE
        assert 0 <= start < stop <= len(pool["writable"])
        pool["writable"][start:stop] = bytes([1]) * (stop - start)
    assert binding["storage_offset"] == cache.storage_offset()


def reference_prefix(aux, model, config, output_dir: Path):
    """CPU FP32 math/BF16 boundaries; no native model/operator is evaluated."""
    import torch

    inner = model.model
    host_aux = torch.cat([tensor.detach().cpu() for tensor in aux], dim=-1)
    parameters = {
        "main_proj.weight": tensor_artifact(
            output_dir, "main-proj-weight.bin", inner.main_proj.weight
        ),
        "main_norm.weight": tensor_artifact(
            output_dir, "main-norm-weight.bin", inner.main_norm.weight
        ),
        "main_norm.epsilon": inner.main_norm.variance_epsilon,
    }

    def linear(values, weight):
        return (values.float() @ weight.detach().cpu().float().T).to(torch.bfloat16)

    def norm(values, layer):
        result = values.float()
        result = result * torch.rsqrt(
            result.square().mean(-1, keepdim=True) + layer.variance_epsilon
        )
        return (result * layer.weight.detach().cpu().float()).to(torch.bfloat16)

    combined = norm(linear(host_aux, inner.main_proj.weight), inner.main_norm)
    references = []
    for index, layer in enumerate(inner.layers.values()):
        attention = layer.self_attn
        parameters[f"draft-{index}"] = {
            "wkv.weight": tensor_artifact(
                output_dir, f"draft-{index}-wkv-weight.bin", attention.wkv.weight
            ),
            "kv_norm.weight": tensor_artifact(
                output_dir,
                f"draft-{index}-kv-norm-weight.bin",
                attention.kv_norm.weight,
            ),
            "kv_norm.epsilon": attention.kv_norm.variance_epsilon,
            "nope_head_dim": attention.nope_head_dim,
            "rope_head_dim": attention.rope_head_dim,
            "rope_layer_name": attention.rotary_emb.layername,
        }
        expected = norm(linear(combined, attention.wkv.weight), attention.kv_norm)
        assert attention.nope_head_dim + attention.rope_head_dim == HIDDEN_SIZE
        assert attention.rope_head_dim == ROPE_HEAD_SIZE
        # The frozen config uses factor one; op-plugin converts RoPE coefficients
        # to the BF16 input dtype before the FP32 multiply/add and final cast.
        assert config.model_config.hf_text_config.rope_parameters["factor"] == 1.0
        for position in range(len(PROMPT_IDS)):
            for pair in range(ROPE_HEAD_SIZE // 2):
                angle = position / ROPE_BASE ** (2 * pair / ROPE_HEAD_SIZE)
                cosine = (
                    torch.tensor(math.cos(angle), dtype=torch.float32, device="cpu")
                    .to(torch.bfloat16)
                    .float()
                )
                sine = (
                    torch.tensor(math.sin(angle), dtype=torch.float32, device="cpu")
                    .to(torch.bfloat16)
                    .float()
                )
                offset = attention.nope_head_dim + 2 * pair
                even, odd = expected[position, offset : offset + 2].float().unbind()
                expected[position, offset] = even * cosine - odd * sine
                expected[position, offset + 1] = odd * cosine + even * sine
        references.append(expected)
        tensor_artifact(output_dir, f"draft-{index}-prefix-expected.bin", expected)
    return references, parameters


def verify_bindings(config, caches, bindings):
    from vllm.config import get_layers_from_vllm_config
    from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase

    layers = get_layers_from_vllm_config(config, AttentionLayerBase)
    for name, cache in caches.items():
        tensors = cache if isinstance(cache, (list, tuple)) else (cache,)
        bound = layers[name].kv_cache[0]
        bound_tensors = bound if isinstance(bound, (list, tuple)) else (bound,)
        assert len(tensors) == len(bound_tensors)
        for tensor, actual, before in zip(
            tensors, bound_tensors, bindings[name], strict=True
        ):
            assert actual is tensor
            assert id(actual) == before["tensor_identity"]
            assert actual.data_ptr() == before["data_ptr"]
            assert list(actual.shape) == before["shape"]
            assert list(actual.stride()) == before["stride"]
            assert actual.storage_offset() == before["storage_offset"]


def verify_storage(speculator, caches, pools, bindings, records, expected, output_dir):
    import torch

    # Persist complete raw post-images even if a later numerical check rejects.
    for index, (pool, record) in enumerate(zip(pools, records, strict=True)):
        raw = pool["view"].cpu().numpy().tobytes()
        record["after"] = artifact(output_dir, f"pool-{index}-after.bin", raw)
    prefix_reports = []
    for index, name in enumerate(speculator.model.get_draft_kv_cache_layer_names()):
        cache = caches[name]
        assert isinstance(cache, torch.Tensor)
        binding = bindings[name][0]
        pool = pools[binding["pool"]]
        declare_writable_rows(
            cache, binding, pool, range(len(PROMPT_IDS) + SPECULATIVE_TOKENS)
        )
        actual = (
            cache[ALLOCATED_BLOCK, : len(PROMPT_IDS), 0].detach().cpu().contiguous()
        )
        assert bool(torch.isfinite(actual).all())
        actual_words = actual.view(torch.uint16).to(torch.int32)
        expected_words = expected[index].view(torch.uint16).to(torch.int32)

        def ordered(words):
            return torch.where(
                words >= BF16_SIGN_BIT,
                BF16_SIGN_BIT - (words - BF16_SIGN_BIT),
                BF16_SIGN_BIT + words,
            )

        differences = (ordered(actual_words) - ordered(expected_words)).abs()
        maximum = int(differences.max())
        record = tensor_artifact(output_dir, f"draft-{index}-prefix-actual.bin", actual)
        record.update(
            layer=name,
            max_bf16_ulps=maximum,
            max_accepted_bf16_ulps=MAX_PREFIX_BF16_ULPS,
        )
        prefix_reports.append(record)
        assert bool(torch.isfinite(expected[index]).all())
        assert maximum <= MAX_PREFIX_BF16_ULPS, record
    for index, (pool, record) in enumerate(zip(pools, records, strict=True)):
        raw = pool["view"].cpu().numpy().tobytes()
        record["after"] = artifact(output_dir, f"pool-{index}-after.bin", raw)
        record["writable_mask"] = artifact(
            output_dir, f"pool-{index}-writable-mask.bin", bytes(pool["writable"])
        )
        changed = sum(a != b for a, b in zip(pool["before"], raw, strict=True))
        protected_changes = sum(
            a != b and not writable
            for a, b, writable in zip(
                pool["before"], raw, pool["writable"], strict=True
            )
        )
        record.update(changed_bytes=changed, protected_changed_bytes=protected_changes)
        assert protected_changes == 0, record
    assert any(record["changed_bytes"] for record in records)
    return prefix_reports


def run_native(args, report):
    # Dedicated process: match the native-only frozen constructor component.
    for name in tuple(os.environ):
        if name.startswith(("AFD_", "VLLM_", "MOONCAKE_", "ENGRAM_")):
            del os.environ[name]
    os.environ.update(
        VLLM_PLUGINS=NATIVE_PLUGINS,
        VLLM_USE_V2_MODEL_RUNNER="1",
        VLLM_WORKER_MULTIPROC_METHOD="spawn",
        VLLM_ASCEND_ENABLE_FLASHCOMM1="0",
    )
    import torch
    import torch_npu  # noqa: F401
    from vllm.platforms import current_platform

    current_platform.pre_register_and_update()
    from vllm.plugins import load_general_plugins
    from vllm_ascend.utils import (
        adapt_patch,
        enable_custom_op,
        register_ascend_customop,
        set_potential_max_tokens,
    )

    load_general_plugins()
    adapt_patch()
    device = torch.device("npu", args.device)
    torch.npu.set_device(device)
    report.update(runtime_imported=True, npu_queried=True)
    report["native_custom_ops_enabled"] = enable_custom_op()
    assert report["native_custom_ops_enabled"]
    from dsv41_dspark_projection_model_probe import native_projection_world
    from vllm.config import set_current_vllm_config
    from vllm.utils.torch_utils import set_default_torch_dtype
    from vllm.v1.worker.gpu.attn_utils import build_slot_mappings_by_layer
    from vllm.v1.worker.workspace import init_workspace_manager
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.worker.v2.spec_decode.dspark.speculator import (
        AscendDSparkSpeculator,
    )
    from vllm_ascend.worker.v2.utils import prepare_v41_source_rope, torch_cuda_wrapper

    config = create_config(str(args.model), args.output_dir)
    report["configuration"] = record_config(config)
    init_ascend_config(config)
    set_potential_max_tokens(config)
    init_workspace_manager(device, num_ubatches=1)
    report["native_sources"] = {
        "speculator": native_source(AscendDSparkSpeculator),
        "propose": native_source(AscendDSparkSpeculator.propose),
        "source_rope": native_source(prepare_v41_source_rope),
    }
    write_report(args.output_dir, report)
    with (
        native_projection_world(config, device, args.output_dir, report),
        set_current_vllm_config(config),
        torch.device(device),
        set_default_torch_dtype(torch.bfloat16),
        torch.inference_mode(),
        torch_cuda_wrapper(),
    ):
        torch.manual_seed(SEED)
        register_ascend_customop(config)
        target = create_target_interface(config)
        speculator = AscendDSparkSpeculator(config, device)
        speculator.update_stream = torch.npu.Stream(device=device)
        speculator.load_model(target)
        dependencies = bind_native_attention(config, target, speculator, device, report)
        _, buffers, block_tables, kv_config, caches = dependencies
        assert speculator.model_state is dependencies[0]
        prepare_v41_source_rope(speculator)
        report["native_speculator_load_and_bind_accepted"] = True
        batch, slots, allocations = make_input_batch(buffers, block_tables, device)
        slot_mappings = build_slot_mappings_by_layer(slots, kv_config)
        report["input_batch"] = {
            "class": type(batch).__module__ + "." + type(batch).__qualname__,
            "req_ids": batch.req_ids,
            "idx_mapping": batch.idx_mapping.cpu().tolist(),
            "input_ids": batch.input_ids.cpu().tolist(),
            "positions": batch.positions.cpu().tolist(),
            "query_start_loc": batch.query_start_loc.cpu().tolist(),
            "seq_lens": batch.seq_lens.cpu().tolist(),
            "num_computed_tokens": batch.num_computed_tokens_np.tolist(),
            "prefill_len": batch.prefill_len_np.tolist(),
            "block_ids": allocations,
            "group_slot_mappings": slots.cpu().tolist(),
            "is_dummy": batch.is_dummy,
        }
        pools, bindings, storage_records = storage_images(caches, args.output_dir)
        report.update(storage_bindings=bindings, storage=storage_records)
        aux = [
            torch.tensor(
                [
                    [
                        (layer + 1) / 8 + row / 32 + (column % 16) / 256
                        for column in range(HIDDEN_SIZE)
                    ]
                    for row in range(len(PROMPT_IDS))
                ],
                dtype=torch.bfloat16,
                device=device,
            )
            for layer in range(len(AUX_LAYER_IDS))
        ]
        aux_records = [
            tensor_artifact(args.output_dir, f"aux-{layer}-before.bin", tensor)
            for layer, tensor in zip(AUX_LAYER_IDS, aux, strict=True)
        ]
        report["fixture_aux"] = aux_records
        expected, projection_parameters = reference_prefix(
            aux, speculator.model, config, args.output_dir
        )
        report["projection_parameters"] = projection_parameters
        report["native_sources"].update(
            input_batch=native_source(type(batch)),
            block_tables=native_source(type(block_tables)),
            draft=native_source(type(speculator.model)),
            draft_forward=native_source(speculator.model.forward),
            context_writer=native_source(
                speculator.model.precompute_and_store_context_kv
            ),
        )
        forwards = []

        def observe_forward(module, inputs, output):
            forwards.append(
                {
                    "class": type(module).__module__ + "." + type(module).__qualname__,
                    "shape": list(output.shape),
                    "finite": bool(torch.isfinite(output).all()),
                }
            )

        # The decorated outer native __call__ delegates directly to forward in
        # eager mode. Observe the undecorated complete native backbone instead.
        # This hook changes no inputs, outputs, metadata, or operators.
        hook = speculator.model.model.register_forward_hook(observe_forward)
        write_report(args.output_dir, report)
        try:
            draft_tokens = speculator.propose(
                input_batch=batch,
                attn_metadata={},  # Original DFlash real path builds its own metadata.
                slot_mappings=slot_mappings,
                last_hidden_states=torch.zeros(
                    len(PROMPT_IDS), HIDDEN_SIZE, dtype=torch.bfloat16, device=device
                ),
                aux_hidden_states=aux,
                num_sampled=torch.ones(1, dtype=torch.int32, device=device),
                num_rejected=torch.zeros(1, dtype=torch.int32, device=device),
                last_sampled=torch.tensor(
                    [LAST_SAMPLED_TOKEN], dtype=torch.int64, device=device
                ),
                next_prefill_tokens=torch.zeros(1, dtype=torch.int32, device=device),
                temperature=torch.zeros(1, dtype=torch.float32, device=device),
                seeds=torch.zeros(1, dtype=torch.int64, device=device),
                dummy_run=False,
                skip_attn_for_dummy_run=False,
            )
            torch.npu.synchronize(device)
        finally:
            hook.remove()
        report["native_proposal_returned"] = True
        report["native_draft_forwards"] = forwards
        assert forwards and all(record["finite"] for record in forwards)
        assert tuple(draft_tokens.shape) == (1, SPECULATIVE_TOKENS)
        assert bool(((draft_tokens >= 0) & (draft_tokens < VOCAB_SIZE)).all())
        report["draft_tokens"] = draft_tokens.cpu().tolist()
        report["draft_preparation"] = {
            "query_ids": speculator.input_buffers.input_ids[:SPECULATIVE_TOKENS]
            .cpu()
            .tolist(),
            "query_positions": speculator.input_buffers.positions[:SPECULATIVE_TOKENS]
            .cpu()
            .tolist(),
            "query_start_loc": speculator.input_buffers.query_start_loc[:2]
            .cpu()
            .tolist(),
            "seq_lens": speculator.input_buffers.seq_lens[:1].cpu().tolist(),
            "context_positions": speculator.context_positions[: len(PROMPT_IDS)]
            .cpu()
            .tolist(),
            "group_query_slots": {
                str(group): block_tables.slot_mappings[group, :SPECULATIVE_TOKENS]
                .cpu()
                .tolist()
                for group in speculator.draft_kv_cache_group_ids
            },
        }
        prepared = report["draft_preparation"]
        assert prepared["query_ids"] == [
            LAST_SAMPLED_TOKEN,
            speculator.parallel_drafting_token_id,
        ]
        assert prepared["query_positions"] == [len(PROMPT_IDS), len(PROMPT_IDS) + 1]
        assert prepared["context_positions"] == list(range(len(PROMPT_IDS)))
        assert prepared["query_start_loc"] == [0, SPECULATIVE_TOKENS]
        assert prepared["seq_lens"] == [len(PROMPT_IDS) + SPECULATIVE_TOKENS]
        for group in speculator.draft_kv_cache_group_ids:
            size = block_tables.kernel_block_sizes[group]
            assert prepared["group_query_slots"][str(group)] == [
                ALLOCATED_BLOCK * size + position
                for position in prepared["query_positions"]
            ]
        for layer, tensor, before in zip(AUX_LAYER_IDS, aux, aux_records, strict=True):
            after = tensor_artifact(args.output_dir, f"aux-{layer}-after.bin", tensor)
            assert (
                before["sha256"] == after["sha256"]
                and before["data_ptr"] == after["data_ptr"]
            )
            before["after"] = after
        report["prefix_verification"] = verify_storage(
            speculator,
            caches,
            pools,
            bindings,
            storage_records,
            expected,
            args.output_dir,
        )
        verify_bindings(config, caches, bindings)
        report["storage_bindings_unchanged"] = True
        report["native_proposal_accepted"] = True
    report["success"] = True


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--device", type=int, default=0)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--run", action="store_true")
    args = parser.parse_args()
    if args.device < 0:
        parser.error("--device must be nonnegative")
    args.output_dir = args.output_dir.resolve()
    if args.output_dir == args.model.resolve():
        parser.error("output directory must differ from the model directory")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "schema_version": 1,
        "probe_sha256": sha256(Path(__file__).read_bytes()),
        "reused_constructor_probe": native_source(create_config),
        "mode": "native-proposal" if args.run else "metadata-only",
        "success": False,
        "runtime_imported": False,
        "npu_queried": False,
        "native_speculator_load_and_bind_accepted": False,
        "native_proposal_returned": False,
        "native_proposal_accepted": False,
        "native_target_execution": False,
        "checkpoint_weights_loaded": False,
        "live_p_aux": False,
        "pd_ready_or_lease": False,
        "full_worker_or_serving": False,
        "engram_enabled": False,
        "limits": [
            "Ordered aux and InputBatch are component fixtures, "
            "not target/scheduler outputs.",
            "Complete dummy-loaded native draft; "
            "no HC/Attention/MoE or sampling leaf is replaced.",
            "Prefix CPU math and protected byte checks "
            "do not establish complete draft numerical equivalence.",
            "No live P, PD publication, rejection loop, "
            "model admission, or performance claim.",
            "World-size-one HCCL group cleanup does not prove serving-owner recovery.",
        ],
    }
    exit_code = 1
    try:
        config_path = args.model / "config.json"
        raw = config_path.read_bytes()
        json.loads(raw)
        report["checkpoint_config"] = {"path": str(config_path), "sha256": sha256(raw)}
        if args.run:
            run_native(args, report)
        else:
            report["success"] = True
        exit_code = 0
    except BaseException as error:
        report["error"] = {
            "type": type(error).__name__,
            "message": str(error),
            "traceback": traceback.format_exc(),
        }
        traceback.print_exc()
    finally:
        if report["runtime_imported"]:
            try:
                report["loaded_runtime_libraries"] = loaded_runtime_libraries()
            except OSError as error:
                report["loaded_runtime_libraries_error"] = {
                    "type": type(error).__name__,
                    "message": str(error),
                }
        write_report(args.output_dir, report)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
