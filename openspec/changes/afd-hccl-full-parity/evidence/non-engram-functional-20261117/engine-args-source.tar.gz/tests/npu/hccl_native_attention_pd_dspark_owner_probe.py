# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Native N2 construction and production AFD P sample/publication component.

Runtime imports are deliberately deferred to the explicitly started worker.
This component invokes the real NPU runner constructor on an AFD typed carrier;
it does not invoke the guarded AFD constructor or claim serving admission.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    import torch
    from vllm.config import VllmConfig
    from vllm.v1.kv_cache_interface import KVCacheConfig

    from afd_plugin.compat.npu.kv_layout_native import KVCacheValue
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )

WORKSPACE_LANES = 2
DRAFT_WORKSPACE_LANE = 1
NUM_BLOCKS = 9
NULL_BLOCK_RESERVE = 1


@dataclass(frozen=True)
class NativeLivePrefixOwner:
    owner: AFDNPUAttentionModelRunnerV2
    kv_config: KVCacheConfig
    caches: dict[str, KVCacheValue]
    embedding_cpu: torch.Tensor


def build_native_live_prefix_owner(
    config: VllmConfig,
    device: torch.device,
    report: dict,
    *,
    connect_ffn: bool = True,
    kv_role: Literal["kv_producer", "kv_consumer"] | None = None,
    target_logits_policy: Literal["constant7", "reject-second-verification-row"]
    | None = None,
    target_graph: bool = False,
    target_u2: bool = False,
    graph_compute_overlap: bool = False,
    graph_all_axes: bool = False,
    graph_exchange_order: Literal["stage_serial", "cross_layer_v1"] = "stage_serial",
    eager_stream_overlap: bool = False,
    retained_prefixes: int = 1,
) -> NativeLivePrefixOwner:
    """Construct real N2 state and register one immutable model/KV generation.

    The bounded target replaces the checkpoint target at the post-load seam.
    The actual draft load, model state, samplers, KV initialization and public
    execute/sample implementation remain native. No qualification switch is
    set and no production admission guard is changed by this component.
    Explicit KV role permits a consumer to own its independent FFN connection.
    None retains the previous role inference and target logits behavior.
    Target Graph is an opt-in consumer branch with the same native constructor,
    loaded models and KV generation; its default remains the eager component.
    Graph compute overlap selects the existing U2 compute pipeline. Optional
    all-axes mode fixes its four policies on before capture. Exchange order must
    match the first configuration; cross_layer_v1 additionally requires all
    policies and native U2. Eager overlap stays disabled in both modes.
    """
    import torch
    from dsv41_dspark_speculator_probe import native_source
    from hccl_native_attention_pd_dspark_probe import (
        TARGET_GRAPH_CAPTURE_SIZES,
        TARGET_GRAPH_WARMUP_RUNS,
        TARGET_U2_REQUESTS,
        TARGET_U2_STAGES,
        TARGET_U2_TOKENS,
        build_live_prefix_target,
        create_loaded_prefix_consumer,
        initialize_bounded_markov_fixture,
    )
    from vllm.config import (
        CompilationMode,
        CUDAGraphMode,
        get_layers_from_vllm_config,
        set_current_vllm_config,
    )
    from vllm.distributed.kv_transfer import ensure_kv_transfer_initialized
    from vllm.model_executor.layers.attention_layer_base import AttentionLayerBase
    from vllm.model_executor.offloader import get_offloader
    from vllm.utils.torch_utils import set_default_torch_dtype
    from vllm.v1.attention.backends.utils import (
        get_supported_kv_cache_layouts,
        resolve_kv_cache_layout,
    )
    from vllm.v1.worker.gpu.model_states import init_model_state
    from vllm.v1.worker.gpu.sample.prompt_logprob import PromptLogprobsWorker
    from vllm.v1.worker.gpu.sample.sampler import Sampler
    from vllm.v1.worker.gpu.spec_decode.rejection_sampler import RejectionSampler
    from vllm.v1.worker.gpu.structured_outputs import StructuredOutputsWorker
    from vllm.v1.worker.workspace import init_workspace_manager, use_workspace_lane
    from vllm_ascend.models.deepseek_v41.cache_config import (
        get_deepseek_v41_kv_cache_config,
        get_deepseek_v41_pool_bytes_per_block,
        group_cache_specs,
        make_cache_groups,
    )
    from vllm_ascend.worker.v2.model_runner import NPUModelRunner
    from vllm_ascend.worker.v2.spec_decode.dspark.speculator import (
        AscendDSparkSpeculator,
    )
    from vllm_ascend.worker.v2.utils import torch_cuda_wrapper

    from afd_plugin.compat.npu.runtime_config import validate_deepseek_v41_pd
    from afd_plugin.compat.patches.npu.ascend_config import init_ascend_config
    from afd_plugin.config import parse_afd_config
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSettings
    from afd_plugin.connectors.npu.hccl_staged import (
        HcclStagedAFDConnector,
        create_npu_runtime_connector,
    )
    from afd_plugin.connectors.npu.p2p_hccl import P2pHcclAFDConnector
    from afd_plugin.v1.worker.npu.attention_model_runner_v2 import (
        AFDNPUAttentionModelRunnerV2,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_eager_bootstrap import (
        HcclV41EagerBootstrap,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_graph_bootstrap import (
        HcclV41AttentionGraphBootstrap,
    )

    assert type(target_graph) is bool and type(target_u2) is bool
    assert type(graph_compute_overlap) is bool and type(graph_all_axes) is bool
    assert type(eager_stream_overlap) is bool
    assert type(retained_prefixes) is int and retained_prefixes > 0
    if target_u2 and not (target_graph or eager_stream_overlap):
        raise ValueError("target U2 requires explicit Graph or eager streams")
    if eager_stream_overlap and (target_graph or not target_u2):
        raise ValueError("eager stream overlap requires eager native U2")
    if graph_compute_overlap and not (target_graph and target_u2):
        raise ValueError("Graph compute overlap requires consumer target Graph U2")
    if graph_all_axes and not graph_compute_overlap:
        raise ValueError("All Graph axes require Graph compute overlap")
    if graph_exchange_order not in ("stage_serial", "cross_layer_v1"):
        raise ValueError("unsupported component Graph exchange order")
    if graph_exchange_order == "cross_layer_v1" and not (graph_all_axes and target_u2):
        raise ValueError("Cross-layer Graph requires all axes and native U2")
    afd_config = parse_afd_config(config)
    assert (
        afd_config.connector_extra_config.get("graph_exchange_order", "stage_serial")
        == graph_exchange_order
    )
    validate_deepseek_v41_pd(config)
    declared_role = (
        ("kv_producer" if connect_ffn else "kv_consumer")
        if kv_role is None
        else kv_role
    )
    assert declared_role in ("kv_producer", "kv_consumer")
    assert config.kv_transfer_config.kv_role == declared_role
    if eager_stream_overlap:
        assert declared_role == "kv_consumer" and connect_ffn
        assert config.compilation_config.cudagraph_mode == CUDAGraphMode.NONE
    assert config.num_speculative_tokens == 2
    assert config.model_config.enforce_eager is (not target_graph)
    assert config.speculative_config.enforce_eager is True
    assert config.parallel_config.use_ubatching is target_u2
    assert config.engram_config is config.watermark_config is None
    assert not config.compilation_config.static_forward_context
    if target_graph:
        capture_sizes = (TARGET_U2_TOKENS,) if target_u2 else TARGET_GRAPH_CAPTURE_SIZES
        assert declared_role == "kv_consumer" and connect_ffn
        assert (
            config.compilation_config.cudagraph_mode == CUDAGraphMode.FULL_DECODE_ONLY
        )
        assert config.compilation_config.mode == CompilationMode.NONE
        assert not config.compilation_config.use_inductor_graph_partition
        assert config.compilation_config.cudagraph_capture_sizes == list(capture_sizes)
        assert config.compilation_config.max_cudagraph_capture_size == max(
            capture_sizes
        )
        assert (
            config.compilation_config.cudagraph_num_of_warmups
            == TARGET_GRAPH_WARMUP_RUNS
        )
    if target_u2:
        assert config.scheduler_config.max_num_seqs == TARGET_U2_REQUESTS
        assert config.parallel_config.num_ubatches == TARGET_U2_STAGES
        assert config.parallel_config.dbo_decode_token_threshold == TARGET_U2_TOKENS
        assert config.parallel_config.dbo_prefill_token_threshold == TARGET_U2_TOKENS
    init_ascend_config(config)
    detail = report["native_live_owner"] = {
        "native_runner_constructor_executed": False,
        "full_afd_runner_constructor_executed": False,
        "full_worker_constructor_executed": False,
        "model_admission_executed": False,
        "checkpoint_target_loaded": False,
        "controlled_target_arithmetic": True,
        "kv_role": declared_role,
        "target_graph_requested": target_graph,
        "target_u2_requested": target_u2,
        "graph_compute_overlap_requested": graph_compute_overlap,
        "graph_all_axes_requested": graph_all_axes,
        "graph_exchange_order_requested": graph_exchange_order,
        "eager_stream_overlap_requested": eager_stream_overlap,
        "retained_prefixes": retained_prefixes,
        "target_logits_policy": target_logits_policy,
        "target_logits_policy_accepted": False,
        "native_draft_decoder_leaves_replaced": False,
        "production_execute_sample_replaced": False,
        "serving_accepted": False,
        "full_model_accepted": False,
        "npu_component_accepted": False,
    }
    workspace_ubatches = TARGET_U2_STAGES if target_u2 else 1
    init_workspace_manager(
        device, num_ubatches=workspace_ubatches, num_lanes=WORKSPACE_LANES
    )
    detail["workspace"] = {
        "num_ubatches": workspace_ubatches,
        "num_lanes": WORKSPACE_LANES,
    }
    with (
        set_current_vllm_config(config),
        torch.device(device),
        set_default_torch_dtype(torch.bfloat16),
        torch.inference_mode(),
        torch_cuda_wrapper(),
    ):
        owner = AFDNPUAttentionModelRunnerV2.__new__(AFDNPUAttentionModelRunnerV2)
        # Explicit component boundary: this is the original NPU initializer,
        # not an alternative production constructor or a bypass environment.
        NPUModelRunner.__init__(owner, config, device)
        detail["native_runner_constructor_executed"] = True
        assert owner.num_speculative_steps == 2
        assert type(owner.speculator) is AscendDSparkSpeculator
        assert owner.req_states.num_speculative_steps == 2
        assert owner.use_aux_hidden_state_outputs
        owner.afd_config = afd_config
        owner.prof = None
        settings = (
            HcclOverlapSettings(
                eager_u2_stream_overlap=False,
                graph_u2_compute_overlap=graph_compute_overlap,
                graph_u2_hybrid_dag=graph_all_axes,
                graph_u2_attention_three_stream=graph_all_axes,
                graph_u2_ffn_recv_stream=graph_all_axes,
                graph_u2_ffn_cross_layer=graph_all_axes,
                stage_diagnostics=True,
                ffn_compute_sync_diagnostics=False,
            )
            if target_graph
            else HcclOverlapSettings(
                eager_u2_stream_overlap=eager_stream_overlap,
                graph_u2_compute_overlap=False,
                graph_u2_hybrid_dag=False,
                graph_u2_attention_three_stream=False,
                graph_u2_ffn_recv_stream=False,
                graph_u2_ffn_cross_layer=False,
                stage_diagnostics=eager_stream_overlap,
                ffn_compute_sync_diagnostics=False,
            )
            if eager_stream_overlap
            else HcclOverlapSettings(eager_u2_stream_overlap=False)
        )
        owner.connector = create_npu_runtime_connector(
            0,
            device.index,
            config,
            owner.afd_config,
            overlap_settings=settings,
        )
        assert type(owner.connector) is (
            HcclStagedAFDConnector
            if target_graph or eager_stream_overlap
            else P2pHcclAFDConnector
        )
        if target_graph:
            assert (
                owner.connector.transport.capabilities.graph_exchange_order
                == graph_exchange_order
            )
        owner._is_warmup = False
        owner._afd_is_graph_capturing = False
        owner._afd_is_profile = False
        owner._afd_is_graph_replaying = False
        owner._afd_pending_metadata = None
        owner._afd_suppress_metadata_send = False
        owner._afd_transaction_counter = 0
        owner._afd_hccl_execution = None
        owner.hccl_v41_graph_eager = None
        owner.hccl_v41_graph_session = None
        owner.hccl_v41_graph_coordinator = None
        owner.hccl_v41_graph_bootstrap = None
        owner.hccl_v41_eager_bootstrap = None
        owner.hccl_v41_diagnostics = None
        owner._hccl_graph_load_started = False
        owner._hccl_eager_load_started = False
        owner.dspark_pd_consumer = None
        owner._dspark_pd_load_started = True
        owner._dspark_pd_pending_scheduler = None
        owner._afd_shutdown_prepared = False
        owner._afd_staged_stop_completed = False
        owner._hccl_configuration_logged = False
        assert owner.hccl_v41_transport is None
        if target_graph or eager_stream_overlap:
            owner.bind_hccl_v41_transport(owner.connector.transport)
        owner.model, embedding_cpu = build_live_prefix_target(
            config,
            device,
            remote_moe=connect_ffn,
            target_logits_policy=target_logits_policy,
        )
        # Same real loader and workspace lane as native GPU.load_model. The
        # controlled target supplies the true native embedding/head/cache ABI.
        with use_workspace_lane(DRAFT_WORKSPACE_LANE):
            owner.speculator.load_model(owner.model)
        detail["controlled_markov_weights"] = initialize_bounded_markov_fixture(
            owner.speculator
        )
        if target_logits_policy is not None:
            # The original native loader decides sharing. Do not replace its
            # modules, rewrite their weights or modify the draft logits method.
            language = owner.model.language_model
            draft = owner.speculator.model
            assert draft.lm_head is language.lm_head
            assert draft.model.embed_tokens is language.model.embed_tokens
            assert draft.logits_processor is not language.logits_processor
            detail["shared_target_draft_modules"] = {
                "lm_head": True,
                "embedding": True,
                "lm_head_pointer": language.lm_head.weight.data_ptr(),
                "embedding_pointer": language.model.embed_tokens.weight.data_ptr(),
                "target_logits_source": native_source(owner.model.compute_logits),
                "draft_logits_source": native_source(draft.compute_draft_logits),
                "target_processor_source": native_source(
                    language.logits_processor.forward
                ),
                "draft_processor_source": native_source(draft.logits_processor.forward),
            }
        owner.model_state = init_model_state(
            config, owner.model, owner.encoder_cache, device
        )
        owner.decode_query_len = (
            owner.num_speculative_steps
            + owner.model_state.num_new_sampled_tokens_per_step
        )
        assert owner.decode_query_len == 3
        owner.sampler = Sampler(
            max_num_reqs=owner.max_num_reqs,
            vocab_size=owner.vocab_size,
            device=device,
            req_states=owner.req_states,
            logprobs_mode=owner.model_config.logprobs_mode,
            num_speculative_tokens=owner.decode_query_len,
            use_fp64_gumbel=owner.model_config.use_fp64_gumbel,
            enable_trace_replay=owner.model_config.enable_trace_replay,
            reasoning_config=config.reasoning_config,
            return_sampling_mask=owner.model_config.return_sampling_mask,
        )
        assert owner.model_state.custom_sampler(owner.sampler) is None
        owner.rejection_sampler = RejectionSampler(
            owner.sampler, config.speculative_config, device, watermark_key=None
        )
        owner.prompt_logprobs_worker = PromptLogprobsWorker(
            owner.max_num_reqs, logprobs_mode=owner.model_config.logprobs_mode
        )
        owner.structured_outputs_worker = StructuredOutputsWorker(
            max_num_logits=owner.max_num_reqs * owner.decode_query_len,
            vocab_size=owner.vocab_size,
            device=device,
            mask_stride=owner.decode_query_len,
            num_bonus_tokens=owner.model_state.num_new_sampled_tokens_per_step,
        )
        registered = owner.eplb.maybe_register_model(
            owner.model, owner.model_config, True
        )
        owner.eplb.maybe_start_async_loop(registered)
        get_offloader().post_init()
        owner.dspark_pd_consumer = create_loaded_prefix_consumer(
            config,
            owner.model,
            owner.speculator,
            device,
            agree_batch=owner._agree_dspark_pd_batch,
        )
        # Normal A load rendezvous occurs after both model loads. F must use
        # the original N2 target shape before isolating its runtime config.
        if connect_ffn:
            owner.connector.init_afd_connector()
            detail["connector_configuration"] = owner.connector.configuration_record()
        if target_graph:
            assert owner.connector.transport.initialized
            assert (
                owner.connector.transport.negotiated_capabilities.target_query_len
                == (owner.decode_query_len)
            )
            host_records = []
            detail["target_graph"] = {
                "host_records": host_records,
                "native_capture_completed": False,
                "replay_observed": False,
                "device_execution_accepted": False,
                "native_sparse_fa_target_executed": False,
                "native_draft_decoder_leaves_replaced": False,
                "physical_overlap_accepted": False,
                "performance_accepted": False,
            }
            owner._hccl_graph_load_started = True
            owner.hccl_v41_graph_bootstrap = HcclV41AttentionGraphBootstrap(
                owner,
                synchronize=partial(torch.npu.synchronize, device),
                overlap_settings=settings,
                diagnostic_sink=host_records.append,
            )
            owner.hccl_v41_graph_bootstrap.bind_loaded_model()
        elif eager_stream_overlap:
            assert owner.connector.transport.initialized
            assert (
                owner.connector.transport.negotiated_capabilities.graph_execution_version
                == 0
            )
            assert (
                owner.connector.transport.negotiated_capabilities.eager_pipeline_version
                == 1
            )
            host_records = []
            detail["eager_streams"] = {"host_records": host_records}
            owner._hccl_eager_load_started = True
            owner.hccl_v41_eager_bootstrap = HcclV41EagerBootstrap(
                config,
                owner.connector.transport,
                overlap_settings=settings,
                synchronize=partial(torch.npu.synchronize, device),
                diagnostic_sink=host_records.append,
            )
            owner.hccl_v41_eager_bootstrap.prepare(torch.npu.current_stream(device))
            owner.bind_hccl_v41_diagnostics(owner.hccl_v41_eager_bootstrap.diagnostics)
        detail["connect_ffn"] = connect_ffn
        specs = owner.get_kv_cache_spec()
        layers = get_layers_from_vllm_config(config, AttentionLayerBase)
        layouts = get_supported_kv_cache_layouts(
            layer.get_attn_backend() for layer in layers.values()
        )
        layout = resolve_kv_cache_layout(
            config, [[item.name for item in layouts]], specs.values()
        )
        groups = make_cache_groups(group_cache_specs(specs))
        block_budget = NUM_BLOCKS
        if target_u2 or retained_prefixes > 1:
            # One native pool supplies all groups. Reserve the global null
            # block plus every request's complete context and native lookahead
            # in each actual group's logical block units. This conservative
            # component budget is fixed before planning/allocation.
            token_budget = (
                owner.model_config.max_model_len + config.num_speculative_tokens
            )
            group_budgets = []
            for group in groups:
                size = group.kv_cache_spec.block_size
                assert type(size) is int and size > 0
                group_budgets.append(
                    {
                        "layer_names": list(group.layer_names),
                        "block_size": size,
                        "blocks_per_request": (token_budget + size - 1) // size,
                    }
                )
            allocation_requests = max(
                config.scheduler_config.max_num_seqs, retained_prefixes
            )
            block_budget = max(
                NUM_BLOCKS,
                NULL_BLOCK_RESERVE
                + allocation_requests
                * sum(group["blocks_per_request"] for group in group_budgets),
            )
            detail["kv_block_budget"] = {
                "max_model_len": owner.model_config.max_model_len,
                "lookahead_tokens": config.num_speculative_tokens,
                "token_budget": token_budget,
                "max_num_seqs": config.scheduler_config.max_num_seqs,
                "retained_prefixes": retained_prefixes,
                "allocation_requests": allocation_requests,
                "null_block_reserve": NULL_BLOCK_RESERVE,
                "minimum_blocks": NUM_BLOCKS,
                "groups": group_budgets,
                "selected_blocks": block_budget,
            }
        kv_config = get_deepseek_v41_kv_cache_config(
            config,
            groups,
            available_memory=block_budget
            * get_deepseek_v41_pool_bytes_per_block(groups),
        )
        assert kv_config.num_blocks == block_budget
        # Exact native worker ordering. AFD.initialize binds this same original
        # KV config before Ascend deep-copies/plans/allocates it and ActiveKV
        # registers its real physical storage. No toy block assignments.
        ensure_kv_transfer_initialized(config, kv_config)
        owner.initialize_kv_cache(kv_config)
        if kv_config.needs_kv_cache_zeroing:
            owner._init_kv_zero_meta()
        assert owner.speculator.target_input_buffers is owner.input_buffers
        assert owner.speculator.block_tables is owner.block_tables
        assert owner.speculator.model_state is owner.model_state
        assert owner.kv_connector.vllm_config is config
        caches = {name: layers[name].kv_cache[0] for name in specs}
        bindings = NativeLivePrefixOwner(owner, kv_config, caches, embedding_cpu)
        if target_graph:
            _capture_native_target_graph(bindings, detail["target_graph"])
        elif eager_stream_overlap:
            from hccl_native_attention_pd_dspark_eager_probe import (
                eager_session_storage,
            )

            session = owner.hccl_v41_eager_bootstrap.session
            assert owner.ubatch_runner.eager_session is session
            assert owner.ubatch_runner.graph_owner is None
            assert owner.hccl_v41_graph_coordinator is None
            assert session is not None and session.initialized
            detail["eager_streams"]["storage_before"] = eager_session_storage(session)
        torch.npu.synchronize(device)
        detail.update(
            {
                "native_constructor_source": native_source(NPUModelRunner.__init__),
                "kv_initialization_source": native_source(owner.initialize_kv_cache),
                "sampler_source": native_source(Sampler),
                "model_state_class": type(owner.model_state).__qualname__,
                "request_state_class": type(owner.req_states).__qualname__,
                "num_speculative_steps": owner.num_speculative_steps,
                "decode_query_len": owner.decode_query_len,
                "kv_groups": [
                    list(group.layer_names) for group in kv_config.kv_cache_groups
                ],
                "resolved_layout": layout.name,
                "draft_layer_names": list(
                    owner.dspark_pd_consumer.binding.draft_layer_names
                ),
                "native_speculator_load_and_bind_accepted": True,
                "original_buffers_preserved": True,
            }
        )
        return bindings


def _capture_native_target_graph(bindings: NativeLivePrefixOwner, detail: dict) -> None:
    """Capture the actual initialized owner without request or transfer work."""
    import torch
    from dsv41_dspark_speculator_probe import native_source
    from hccl_native_attention_pd_dspark_probe import TARGET_U2_STAGES
    from hccl_native_attention_pd_dspark_run_probe import physical_pages
    from vllm_ascend.distributed.kv_transfer.kv_p2p.mooncake_hybrid_connector import (
        MooncakeConnectorMetadata,
    )
    from vllm_ascend.worker.v2.aclgraph_utils import ModelAclGraphManager

    from afd_plugin.v1.worker.npu.hccl_v41_ubatch_runner import HcclV41UBatchRunner

    owner = bindings.owner
    assert not owner.req_states.req_id_to_index
    assert owner.execute_model_state is None
    assert owner._dspark_pd_pending_scheduler is None
    target_u2 = owner.parallel_config.use_ubatching
    if target_u2:
        assert isinstance(owner.ubatch_runner, HcclV41UBatchRunner)
        assert owner.ubatch_runner.graph_owner is owner.hccl_v41_graph_session
        assert (
            owner.parallel_config.num_ubatches
            == owner.ubatch_runner.num_ubatches
            == TARGET_U2_STAGES
        )
    else:
        assert owner.ubatch_runner is None
    assert isinstance(owner.cudagraph_manager, ModelAclGraphManager)
    bootstrap = owner.hccl_v41_graph_bootstrap
    coordinator = owner.hccl_v41_graph_coordinator
    assert bootstrap is not None and coordinator is bootstrap.coordinator
    assert coordinator is not None
    assert bootstrap.session is owner.hccl_v41_graph_session
    assert coordinator.control.cache is bootstrap.cache
    assert owner.speculator.update_stream is owner.update_stream

    # The native worker constructs empty Mooncake metadata during registration.
    # Clear only that exact initial object through its public API. Capture must
    # never hide a source, cancellation or real in-flight request.
    connector = owner.kv_connector.kv_connector
    assert connector.has_connector_metadata()
    initial_metadata = connector._get_connector_metadata()
    assert type(initial_metadata) is MooncakeConnectorMetadata
    assert not initial_metadata.requests
    assert not initial_metadata.requests_to_send
    assert not initial_metadata.reqs_in_batch
    connector.clear_connector_metadata()
    assert not connector.has_connector_metadata()

    layout, pages = physical_pages(bindings)
    directory = Path(owner.model_config.model).parent
    physical_before = [page.detach().cpu().clone() for page in pages]
    physical_records_before = []
    for index, (page, original) in enumerate(zip(pages, physical_before, strict=True)):
        raw = original.numpy().tobytes()
        path = directory / f"target-graph-capture-before-pool-{index}.bin"
        path.write_bytes(raw)
        physical_records_before.append(
            {
                "path": f"{directory.name}/{path.name}",
                "sha256": hashlib.sha256(raw).hexdigest(),
                "size_bytes": page.numel(),
                "data_ptr": page.data_ptr(),
                "storage_offset_bytes": page.storage_offset(),
                "stride": list(page.stride()),
            }
        )
    detail["capture_physical_layout"] = json.loads(layout.to_json())
    detail["capture_physical_pages_before"] = physical_records_before
    buffers = tuple(owner.kv_caches)
    pointers = [tensor.data_ptr() for tensor in buffers]
    before = [tensor.detach().cpu().view(torch.uint8).clone() for tensor in buffers]
    identities = {
        "model": id(owner.model),
        "model_state": id(owner.model_state),
        "input_buffers": id(owner.input_buffers),
        "block_tables": id(owner.block_tables),
        "manager": id(owner.cudagraph_manager),
        "bootstrap": id(bootstrap),
        "coordinator": id(coordinator),
        "session": id(bootstrap.session),
        "speculator": id(owner.speculator),
    }
    # Normal profiling warms the head before capture locks native workspaces.
    # This controlled target uses the real head too; prepare that real path
    # without a fake sampled output or a dummy execute/proposal transaction.
    head_rows = owner.decode_query_len * owner.scheduler_config.max_num_seqs
    logits = owner.model.compute_logits(
        torch.zeros(
            head_rows,
            owner.model_config.hf_text_config.hidden_size,
            device=owner.device,
            dtype=owner.model_config.dtype,
        )
    )
    assert logits is not None and logits.shape[0] == head_rows
    graph_bytes = owner.capture_model()
    torch.npu.synchronize(owner.device)
    after_layout, after_pages = physical_pages(bindings)
    assert after_layout.to_json() == layout.to_json()
    physical_records_after = []
    for index, (page, original, previous) in enumerate(
        zip(after_pages, physical_before, physical_records_before, strict=True)
    ):
        actual = page.detach().cpu()
        raw = actual.numpy().tobytes()
        path = directory / f"target-graph-capture-after-pool-{index}.bin"
        path.write_bytes(raw)
        entry = {
            "path": f"{directory.name}/{path.name}",
            "sha256": hashlib.sha256(raw).hexdigest(),
            "size_bytes": page.numel(),
            "data_ptr": page.data_ptr(),
            "storage_offset_bytes": page.storage_offset(),
            "stride": list(page.stride()),
        }
        physical_records_after.append(entry)
        assert torch.equal(original, actual)
        for name in (
            "sha256",
            "size_bytes",
            "data_ptr",
            "storage_offset_bytes",
            "stride",
        ):
            assert entry[name] == previous[name]
    detail["capture_physical_pages_after"] = physical_records_after
    after = [tensor.detach().cpu().view(torch.uint8) for tensor in buffers]
    assert all(
        torch.equal(original, actual)
        for original, actual in zip(before, after, strict=True)
    )
    assert len(owner.kv_caches) == len(buffers)
    assert all(
        original is actual
        for original, actual in zip(buffers, owner.kv_caches, strict=True)
    )
    assert [tensor.data_ptr() for tensor in owner.kv_caches] == pointers
    assert not owner.req_states.req_id_to_index
    assert owner.execute_model_state is None
    assert owner._dspark_pd_pending_scheduler is None
    assert not connector.has_connector_metadata()
    assert not owner.dspark_pd_consumer.terminal
    assert not bootstrap.cache.terminal and not bootstrap.cache.closed
    captures = []
    for geometry in coordinator.coverage.geometries:
        descriptor = geometry.descriptor
        key = coordinator.control.key_for(geometry)
        entry = bootstrap.cache.find(key, coordinator.control.generation())
        assert entry is not None
        assert entry.graph is owner.cudagraph_manager.graphs[descriptor]
        resources = entry.resources
        assert resources.manager is owner.cudagraph_manager
        assert resources.model_state is owner.model_state
        assert resources.input_buffers is owner.input_buffers
        assert resources.hidden_states is not None
        bank_stages = []
        for stage_idx, rows in enumerate(resources.bank.stage_rows):
            assert rows > 0
            bank_buffers = resources.bank.buffers(stage_idx)
            bank_stages.append(
                {
                    "stage": stage_idx,
                    "rows": rows,
                    "hidden_states": bank_buffers.hidden_states.data_ptr(),
                    "hidden_states_fp32": bank_buffers.hidden_states_fp32.data_ptr(),
                    "input_ids": bank_buffers.input_ids.data_ptr(),
                    "output": bank_buffers.output.data_ptr(),
                }
            )
        captures.append(
            {
                "mode": descriptor.cg_mode.name,
                "num_tokens": descriptor.num_tokens,
                "num_reqs": descriptor.num_reqs,
                "uniform_token_count": descriptor.uniform_token_count,
                "num_ubatches": descriptor.num_ubatches,
                "key_digest": key.digest,
                "graph_identity": id(entry.graph),
                "bank_identity": id(resources.bank),
                "bank_pointers": {
                    name: bank_stages[0][name]
                    for name in (
                        "hidden_states",
                        "hidden_states_fp32",
                        "input_ids",
                        "output",
                    )
                },
                "bank_stage_pointers": bank_stages,
                "hidden_pointer": resources.hidden_states.data_ptr(),
                "auxiliary_pointers": [item.data_ptr() for item in resources.auxiliary],
            }
        )
    if target_u2:
        assert any(item["num_ubatches"] == TARGET_U2_STAGES for item in captures)
        assert all(
            item["num_tokens"] == head_rows
            and item["num_reqs"] == owner.scheduler_config.max_num_seqs
            and item["uniform_token_count"] == owner.decode_query_len
            and item["num_ubatches"] in (1, TARGET_U2_STAGES)
            for item in captures
        )
    else:
        assert len(captures) == 1
    detail.update(
        native_capture_completed=True,
        capture_source=native_source(owner.capture_model),
        capture_memory_bytes=graph_bytes,
        capture_descriptors=captures,
        owner_identities=identities,
        kv_pointers_before_capture=pointers,
        kv_pointers_after_capture=[tensor.data_ptr() for tensor in owner.kv_caches],
        kv_sha256_before_capture=[
            hashlib.sha256(tensor.numpy().tobytes()).hexdigest() for tensor in before
        ],
        kv_sha256_after_capture=[
            hashlib.sha256(tensor.numpy().tobytes()).hexdigest() for tensor in after
        ],
        initial_empty_pd_metadata_cleared=True,
        capture_completed_without_requests=True,
        capture_completed_without_pd_metadata=True,
        capture_kv_bytes_unchanged=True,
        capture_physical_pages_unchanged=True,
        native_head_warmed_before_capture=True,
    )
