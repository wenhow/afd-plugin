# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the AFD plugin project
"""Bounded native manager/phase/cache component with controlled arithmetic.

Uses the real base CudaGraphManager factory, dispatch and replay plus NPUGraph
HCCL operations. No checkpoint, native model/attention, Engram or full-model
microbatch threads participate.

The optional native FFN service mode uses the real service factory and daemon,
with constructor-free owners and a controlled arithmetic model. It does not
load checkpoint weights or establish full-model Graph admission.
Its optional profiler records the actual daemon's capture/replay lifecycle;
stream inventories do not establish physical parent/side attribution or overlap.
Query3 validates the checkpoint's native DSpark metadata before declaring a
separate two-layer arithmetic configuration; no drafter or auxiliary tensors run.
The optional native Attention owner constructs real native ModelState, inputs,
metadata and capture/replay owners around explicitly controlled NPU leaves.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import signal
import subprocess
import sys
import threading
import time
import traceback
from collections import Counter
from contextlib import nullcontext, suppress
from copy import deepcopy
from dataclasses import dataclass, replace
from datetime import timedelta
from decimal import Decimal
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from afd_plugin.connectors.npu.hccl_graph_pipeline import HcclGraphComputePipeline
    from afd_plugin.connectors.npu.hccl_graph_stage import HcclGraphStageBank
    from afd_plugin.connectors.npu.hccl_overlap import HcclOverlapSelection

HIDDEN_SIZE = 16
CAPACITY = 32
DEFAULT_LAYER_COUNT = 2
CAPTURE_SIZES = (4, 8)
TARGET_REQUEST_BUCKETS = (3, 4)
GROUP_TIMEOUT_SECONDS = 45
TOTAL_TIMEOUT_SECONDS = 300
REAP_TIMEOUT_SECONDS = 10
ROUTER_DELTA = 0.00031
ROUTER_SCALE = 4096
REPLAYS = 3
BASE_TRANSACTION_COUNT = 26
NATIVE_FFN_TRANSACTION_COUNT = BASE_TRANSACTION_COUNT - REPLAYS
NATIVE_ATTENTION_TRANSACTION_COUNT = 21
NATIVE_ATTENTION_LIFECYCLE_TRANSACTION_COUNT = 27
NATIVE_ATTENTION_FAILURE_COMPLETED_COUNT = 25
NATIVE_FFN_PROFILE_ACTIVE_STEPS = NATIVE_FFN_TRANSACTION_COUNT + 1
NATIVE_FFN_PROFILE_SCOPE_PREFIX = "afd_graph_ffn_parent/"
VOCAB_SIZE = 1024
SERVICE_POLL_SECONDS = 0.01
EXPECTED_NATIVE_FFN_EAGER_ERROR = (
    "controlled native FFN service eager failure after successful graph replay"
)
EXPECTED_NATIVE_ATTENTION_EAGER_ERROR = (
    "controlled native Attention replacement prefill failure"
)
GRAPH_AXIS_ARGUMENTS = (
    "graph_compute",
    "graph_hybrid",
    "attention_three",
    "ffn_recv",
    "ffn_cross",
)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--devices", default="0,2", help="FFN then Attention NPU")
    parser.add_argument("--model", required=True, help="configuration only; no weights")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=int, default=TOTAL_TIMEOUT_SECONDS)
    parser.add_argument(
        "--target-query-len",
        type=int,
        choices=(1, 3),
        default=1,
        help="controlled uniform target-query geometry; no native draft model",
    )
    parser.add_argument(
        "--exchange-order",
        choices=("stage_serial", "bulk_v1", "cross_layer_v1"),
        default="stage_serial",
        help="fixed HELLO proposal on both roles; non-serial orders require U2 compute",
    )
    parser.add_argument(
        "--layer-count", type=int, choices=(2, 3), default=DEFAULT_LAYER_COUNT
    )
    parser.add_argument(
        "--stage-bank",
        action="store_true",
        help="reuse the production tensor bank across layers",
    )
    parser.add_argument(
        "--native-ffn-service",
        action="store_true",
        help="use the actual F service factory/daemon with controlled arithmetic",
    )
    parser.add_argument(
        "--native-attention-owner",
        action="store_true",
        help="use actual A ModelState/input preparation/native capture and replay",
    )
    parser.add_argument(
        "--native-attention-lifecycle",
        action="store_true",
        help="also execute/sample, cancel and replace requests through native A",
    )
    parser.add_argument(
        "--fail-native-attention-eager",
        action="store_true",
        help="fail the replacement request's actual native A eager prefill",
    )
    parser.add_argument(
        "--fail-native-ffn-eager",
        action="store_true",
        help="fail the first actual F eager callback after capture/replay",
    )
    parser.add_argument(
        "--profile-native-ffn-service",
        action="store_true",
        help="profile the actual F daemon with output-dependent identity matmul",
    )
    parser.add_argument(
        "--stage-diagnostics",
        action="store_true",
        help="enable actual F host/body logs in the native FFN service component",
    )
    parser.add_argument(
        "--compute-pipeline",
        action="store_true",
        help="fork controlled arithmetic on the production C6 compute pipeline",
    )
    parser.add_argument(
        "--pipeline-hybrid",
        type=int,
        choices=(0, 1),
        help="C6 stage-ready hybrid policy (default 1 with --compute-pipeline)",
    )
    for name in GRAPH_AXIS_ARGUMENTS:
        parser.add_argument(
            "--" + name.replace("_", "-"),
            type=int,
            choices=(0, 1),
            help="fixed session axis; supply all five axes together",
        )
    parser.add_argument("--rank", type=int, choices=(0, 1), help=argparse.SUPPRESS)
    parser.add_argument("--port", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        args.devices = tuple(int(value) for value in args.devices.split(","))
    except ValueError:
        parser.error("--devices requires two distinct NPU indices")
    if len(args.devices) != 2 or len(set(args.devices)) != 2 or min(args.devices) < 0:
        parser.error("--devices requires two distinct nonnegative NPU indices")
    if not 0 < args.timeout <= TOTAL_TIMEOUT_SECONDS:
        parser.error("invalid bounded timeout")
    if args.rank is not None and args.port is None:
        parser.error("worker requires port")
    if args.compute_pipeline and not args.stage_bank:
        parser.error("--compute-pipeline requires --stage-bank")
    if args.pipeline_hybrid is not None and not args.compute_pipeline:
        parser.error("--pipeline-hybrid requires --compute-pipeline")
    if args.compute_pipeline and args.pipeline_hybrid is None:
        args.pipeline_hybrid = 1
    axes = tuple(vars(args)[name] for name in GRAPH_AXIS_ARGUMENTS)
    args.graph_axes = any(value is not None for value in axes)
    if args.graph_axes:
        if any(value is None for value in axes):
            parser.error("the five Graph axes must all be explicitly supplied")
        if (
            not args.stage_bank
            or args.compute_pipeline
            or args.pipeline_hybrid is not None
        ):
            parser.error(
                "Graph axes require --stage-bank and exclude legacy pipeline flags"
            )
        if args.ffn_cross and not args.ffn_recv:
            parser.error("--ffn-cross 1 requires --ffn-recv 1")
    if args.exchange_order != "stage_serial" and not (
        args.stage_bank
        and (args.compute_pipeline or (args.graph_axes and args.graph_compute))
    ):
        parser.error(
            "non-serial order requires --stage-bank and enabled compute pipeline"
        )
    if args.exchange_order == "cross_layer_v1" and (
        (
            args.graph_axes
            and not (args.graph_hybrid and args.ffn_recv and args.ffn_cross)
        )
        or (args.compute_pipeline and not args.pipeline_hybrid)
    ):
        parser.error(
            "cross_layer_v1 requires hybrid and FFN receive/cross dependencies"
        )
    if args.native_ffn_service and (
        not args.stage_bank
        or not args.graph_axes
        or args.exchange_order != "stage_serial"
        or args.layer_count != DEFAULT_LAYER_COUNT
    ):
        parser.error(
            "--native-ffn-service requires --stage-bank, "
            "all five Graph axes, stage_serial and two layers"
        )
    if args.fail_native_ffn_eager and not args.native_ffn_service:
        parser.error("--fail-native-ffn-eager requires --native-ffn-service")
    if args.profile_native_ffn_service and not args.native_ffn_service:
        parser.error("--profile-native-ffn-service requires --native-ffn-service")
    if args.profile_native_ffn_service and args.fail_native_ffn_eager:
        parser.error("profiling and --fail-native-ffn-eager are separate cases")
    if args.target_query_len != 1 and (
        args.profile_native_ffn_service or args.fail_native_ffn_eager
    ):
        parser.error("native FFN profiling/failure cases require target query length1")
    if args.stage_diagnostics and not args.native_ffn_service:
        parser.error("--stage-diagnostics requires --native-ffn-service")
    if args.native_attention_owner and (
        not args.native_ffn_service
        or args.target_query_len != 1
        or any(axes)
        or args.profile_native_ffn_service
        or args.fail_native_ffn_eager
    ):
        parser.error(
            "--native-attention-owner requires native FFN service, Q1, "
            "five zero Graph axes and no profiling/failure injection"
        )
    if args.native_attention_lifecycle and not args.native_attention_owner:
        parser.error("--native-attention-lifecycle requires --native-attention-owner")
    if args.fail_native_attention_eager and not args.native_attention_lifecycle:
        parser.error(
            "--fail-native-attention-eager requires --native-attention-lifecycle"
        )
    return args


def native_ffn_profiler_environment(output_dir):
    """Explicit settings for this isolated F process, not serving defaults."""
    prefix = "AFD_NPU_FFN_PROFILER"
    return {
        f"{prefix}_ENABLE": "1",
        f"{prefix}_WAIT": "0",
        f"{prefix}_WARMUP": "0",
        f"{prefix}_ACTIVE": str(NATIVE_FFN_PROFILE_ACTIVE_STEPS),
        f"{prefix}_REPEAT": "1",
        f"{prefix}_SKIP_FIRST": "0",
        f"{prefix}_WITH_STACK": "0",
        f"{prefix}_RANKS": "0",
        f"{prefix}_DIR": str((output_dir / "traces").resolve()),
    }


def payload(torch, rows, valid, coordinate, iteration, previous=None):
    hidden = (
        torch.arange(rows * HIDDEN_SIZE, dtype=torch.float32).reshape(rows, HIDDEN_SIZE)
        / 8
        + coordinate
        + iteration
    ).bfloat16()
    fp32 = hidden.float() + ROUTER_DELTA * (iteration + 1)
    if previous is not None:
        hidden = (hidden.float() + previous.float()).bfloat16()
        fp32 = fp32 + previous.float()
    ids = torch.arange(rows, dtype=torch.int32) + coordinate * 11 + iteration
    ids[valid:] = 0
    expected = (
        hidden.float() + (fp32 - hidden.float()) * ROUTER_SCALE + ids[:, None].float()
    ).bfloat16()
    expected[valid:] = 0
    return hidden, fp32, ids, expected


@dataclass
class GraphBundle:
    exchanges: tuple
    valid_counts: tuple
    row_indices: tuple
    bank: HcclGraphStageBank | None = None
    observations: tuple = ()
    bank_addresses: tuple = ()
    pipeline: HcclGraphComputePipeline | None = None
    selection: HcclOverlapSelection | None = None
    arithmetic_recurrence: bool = False
    produced: tuple = ()
    continuations: tuple = ()


def run_native_ffn_service(
    torch,
    config,
    connector,
    device,
    report,
    *,
    target_shape,
    fail_eager=False,
    profile_dir=None,
):
    """Run actual factory/daemon/context/graph APIs, without native constructors.

    The only tensor substitute is the final MoE arithmetic. Public transport
    completion/close observers delegate unchanged; failures leave the daemon,
    graph banks and groups to the bounded process supervisor.
    """
    from vllm.config import CUDAGraphMode
    from vllm.forward_context import get_forward_context
    from vllm.platforms import current_platform
    from vllm_ascend.ascend_forward_context import (
        set_mc2_mask,
        set_mc2_tokens_capacity,
    )

    from afd_plugin.v1.worker.npu.ffn_model_runner import AFDNPUFFNModelRunner
    from afd_plugin.v1.worker.npu.ffn_worker import AFDNPUFFNWorker

    transport = connector.transport
    management_thread = threading.get_ident()
    host_calls, lifecycle, retained_addresses = [], [], {}
    retained_entries = []
    injected_error = RuntimeError(EXPECTED_NATIVE_FFN_EAGER_ERROR)
    report["native_ffn_service"] = {
        "runner_constructor_executed": False,
        "worker_constructor_executed": False,
        "native_worker_shutdown_executed": False,
        "checkpoint_weights_loaded": False,
        "native_moe_executed": False,
        "factory_service_and_worker_daemon_executed": False,
        "binding_validation_executed": False,
        "default_graph_api": "torch.npu.NPUGraph/torch.npu.graph",
        "graph_pool_source": "current_platform.get_global_graph_pool",
        "management_thread_id": management_thread,
        "python_model_calls": host_calls,
        "lifecycle": lifecycle,
        "captured_entries": [],
    }
    detail = report["native_ffn_service"]
    assert config.speculative_config is None
    assert config.kv_transfer_config is None and config.engram_config is None
    assert target_shape.target_query_len == transport.capabilities.target_query_len
    detail["retained_target_shape"] = {
        "target_query_len": target_shape.target_query_len,
        "resolved_before_role_isolation": True,
        "isolated_ffn_speculative_config_present": False,
        "isolated_ffn_kv_transfer_config_present": False,
        "isolated_ffn_engram_config_present": False,
    }
    if fail_eager:
        report["expected_failure_observed"] = False
        detail["fault_contract"] = {"injection_observed": False}

    def bank_addresses(bank):
        return tuple(
            tensor.data_ptr()
            for index, rows in enumerate(bank.stage_rows)
            if rows
            for tensor in (
                bank.buffers(index).hidden_states,
                bank.buffers(index).hidden_states_fp32,
                bank.buffers(index).input_ids,
                bank.buffers(index).output,
            )
        )

    class ControlledArithmetic(torch.nn.Module):
        def get_experts_layer_indices(self):
            return transport.negotiated_capabilities.layer_indices

        def compute_ffn_output(
            self,
            hidden_states,
            layer_idx,
            *,
            input_ids,
            hidden_states_fp32,
            already_sequence_parallel,
        ):
            # Host identity/metadata checks are safe while recording. Device
            # values are checked by Attention after actual replay, never read
            # back from this Python capture body.
            plan = transport.plan
            decision = plan.graph_execution
            context = get_forward_context()
            metadata = context.additional_kwargs["afd_metadata"]
            stage = plan.stages[metadata.stage_idx]
            graph_phase = decision.phase in ("warmup", "capture")
            if (
                context.additional_kwargs["model_instance"] is not self
                or metadata.connector is not connector
                or metadata.transaction_id != plan.transaction_id
                or metadata.num_stages != len(plan.stages)
                or metadata.tokens_lens != [hidden_states.shape[0]]
                or metadata.tokens_unpadded_lens
                != [stage.attention_valid_tokens[transport.role_rank]]
                or context.input_ids is not input_ids
                or (context.cudagraph_runtime_mode == CUDAGraphMode.FULL) != graph_phase
                or already_sequence_parallel
                or hidden_states.dtype != torch.bfloat16
                or hidden_states_fp32.dtype != torch.float32
                or threading.get_ident() == management_thread
                or not torch.is_inference_mode_enabled()
                or bool(torch.npu.is_current_stream_capturing())
                != (decision.phase == "capture")
            ):
                raise AssertionError("actual factory FFN context/phase differs")
            host_calls.append(
                {
                    "parent": plan.transaction_id,
                    "phase": decision.phase,
                    "layer": layer_idx,
                    "stage": stage.stage_idx,
                    "native_forward_context_verified": True,
                    "context_raw_ids_identity_verified": True,
                    "serving_thread_id": threading.get_ident(),
                    "native_stream": int(torch.npu.current_stream(device).npu_stream),
                    "native_context_stage_idx": metadata.stage_idx,
                    "input_rows": hidden_states.shape[0],
                    "key_uniform_token_count": (
                        decision.key.uniform_token_count if graph_phase else None
                    ),
                }
            )
            if fail_eager and decision.phase == "eager":
                completed = Counter(item["phase"] for item in report["transactions"])
                graph_count = len(CAPTURE_SIZES) * 2
                assert completed == {
                    "warmup": graph_count,
                    "capture": graph_count,
                    "replay": graph_count * REPLAYS,
                }
                assert len(retained_entries) == graph_count
                assert sum(call["phase"] == "eager" for call in host_calls) == 1
                assert layer_idx == transport.negotiated_capabilities.layer_indices[0]
                assert metadata.stage_idx == 0
                detail["fault_contract"].update(
                    {
                        "injection_observed": True,
                        "parent": plan.transaction_id,
                        "phase": decision.phase,
                        "reason": decision.reason,
                        "key": None,
                        "layer": layer_idx,
                        "stage": metadata.stage_idx,
                        "completed_phases_before_fault": dict(completed),
                        "original_error": {
                            "type": type(injected_error).__name__,
                            "message": str(injected_error),
                        },
                    }
                )
                assert decision.key is None and decision.reason == "cache_miss"
                raise injected_error
            if profile_dir is not None:
                # A fixed identity is allocated before the daemon/capture. This
                # matmul contributes to the checked output, unlike an unused
                # profiling canary, and preserves the independent A oracle.
                return (
                    torch.mm(hidden_states.float(), self.profile_identity)
                    + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                    + input_ids[:, None].float()
                ).bfloat16()
            return (
                hidden_states.float()
                + (hidden_states_fp32 - hidden_states.float()) * ROUTER_SCALE
                + input_ids[:, None].float()
            ).bfloat16()

    runner = AFDNPUFFNModelRunner.__new__(AFDNPUFFNModelRunner)
    runner.vllm_config, runner.model_config = config, config.model_config
    runner.connector, runner.device = connector, device
    runner.target_shape = target_shape
    runner.model = ControlledArithmetic()
    runner.graph_pool = current_platform.get_global_graph_pool()
    runner.prof = None
    if profile_dir is not None:
        from vllm_ascend.ascend_config import get_ascend_config

        from afd_plugin.compat.npu.profiler import create_deferred_afd_npu_profiler

        assert not get_ascend_config().msmonitor_use_daemon
        runner.model.register_buffer(
            "profile_identity",
            torch.eye(HIDDEN_SIZE, dtype=torch.float32, device=device),
        )
        # The daemon selects its own native stream. Publish this immutable
        # management-thread allocation before either owner profiling or capture.
        torch.npu.synchronize(device)
        runner.prof = create_deferred_afd_npu_profiler("ffn", role_rank=0)
        assert runner.prof is not None
        stage_variants = (1, 2)
        warmup_matmuls = (
            len(CAPTURE_SIZES)
            * sum(stage_variants)
            * len(transport.negotiated_capabilities.layer_indices)
        )
        expected_matmuls = {
            "warmup": warmup_matmuls,
            "capture": 0,
            "replay": warmup_matmuls * REPLAYS,
            "eager": DEFAULT_LAYER_COUNT * max(stage_variants) * REPLAYS,
        }
        detail["profiler"] = {
            "environment": native_ffn_profiler_environment(profile_dir.parent),
            "management_thread_id": management_thread,
            "management_native_thread_id": threading.get_native_id(),
            "pid": os.getpid(),
            "status_before_daemon_start": runner.prof.status(),
            "identity_shape": list(runner.model.profile_identity.shape),
            "identity_bytes": runner.model.profile_identity.numel()
            * runner.model.profile_identity.element_size(),
            "identity_address": runner.model.profile_identity.data_ptr(),
            "matmul_contributes_to_checked_output": True,
            "execution_scopes": [],
            "expected_device_matmul_count": sum(expected_matmuls.values()),
            "expected_device_matmul_by_phase": expected_matmuls,
            "expectations_are_not_device_evidence": True,
            "physical_parent_vs_compute_stream_attribution_verified": False,
            "overlap_measured": False,
            "performance_accepted": False,
        }
        actual_execute = runner.execute_hccl_v41_step

        def observe_execute(staged):
            # This CPU scope opens before receive/capture and closes only after
            # the real public step returns. It never wraps a profiler operation
            # inside NPUGraph capture and does not replace the worker loop.
            status = runner.prof.status()
            slot = len(report["transactions"])
            scope = f"{NATIVE_FFN_PROFILE_SCOPE_PREFIX}{slot}"
            assert status["steps"] == slot and status["applied"]
            assert status["owner_thread_id"] == threading.get_ident()
            with torch.autograd.profiler.record_function(scope):
                continued = actual_execute(staged)
            detail["profiler"]["execution_scopes"].append(
                {
                    "name": scope,
                    "continued": continued,
                    "owner_steps_before_step": status["steps"],
                    "owner_thread_id": threading.get_ident(),
                    "owner_native_thread_id": threading.get_native_id(),
                }
            )
            if not continued:
                # The active schedule exceeds the completed-parent count: this
                # trace must be exported by the real owner.finish after STOP.
                before_finish = list(profile_dir.rglob("trace_view.json"))
                detail["profiler"]["stop_returned"] = {
                    "host_monotonic_ns": time.monotonic_ns(),
                    "status": runner.prof.status(),
                    "trace_views_before_owner_finish": [str(p) for p in before_finish],
                }
                assert not before_finish
            return continued

        runner.execute_hccl_v41_step = observe_execute
    runner.hccl_v41_graph_service = runner.hccl_v41_eager_session = None
    runner.hccl_v41_diagnostics = runner.hccl_v41_eager_bootstrap = None
    set_mc2_tokens_capacity(
        config, config.scheduler_config.max_num_seqs, target_shape.target_query_len
    )
    set_mc2_mask(config, device)
    detail["native_mc2_capacity_and_mask_initialized"] = True

    worker = AFDNPUFFNWorker.__new__(AFDNPUFFNWorker)
    worker.vllm_config, worker.model_runner, worker.device = config, runner, device
    worker.local_rank, worker.rank, worker.profiler_config = device.index, 0, None
    worker.target_shape = runner.target_shape
    worker._ffn_thread = worker._ffn_shutdown_event = worker._ffn_loop_error = None
    worker._hccl_stop_received = worker._hccl_configuration_logged = False
    worker._hccl_v41_transport = None
    worker._cpu_binding_attempted = False
    worker.bind_hccl_v41_transport(transport)
    detail["binding_validation_executed"] = True

    actual_finish, actual_close = transport.finish_forward, transport.close

    def observe_finish():
        plan = transport.plan
        decision = plan.graph_execution
        actual_finish()
        service = runner.hccl_v41_graph_service
        if decision.phase in ("capture", "replay"):
            assert decision.key.uniform_token_count == target_shape.target_query_len
            assert decision.key.max_query_len == target_shape.target_query_len
            entry = service.cache.find(decision.key, service.generation())
            assert entry is not None and isinstance(entry.graph, torch.npu.NPUGraph)
            bank = entry.resources.bank
            assert bank.capabilities.target_query_len == target_shape.target_query_len
            assert bank.stage_rows == decision.key.padded_tokens
            addresses = bank_addresses(bank)
            if decision.phase == "capture":
                retained_addresses[decision.key.digest] = addresses
                if fail_eager:
                    # Explicit probe references permit post-error address
                    # inspection; cache.is_empty separately checks cache state.
                    retained_entries.append(entry)
                detail["captured_entries"].append(
                    {
                        "key": decision.key.digest,
                        "uniform_token_count": decision.key.uniform_token_count,
                        "max_query_len": decision.key.max_query_len,
                        "num_reqs": decision.key.num_reqs,
                        "num_tokens": decision.key.num_tokens,
                        "stage_layouts": [
                            [
                                stage.request_start,
                                stage.request_stop,
                                stage.token_start,
                                stage.token_stop,
                            ]
                            for stage in decision.key.stage_layouts
                        ],
                        "stage_rows": bank.stage_rows,
                        "bank_target_query_len": bank.capabilities.target_query_len,
                        "graph_type": type(entry.graph).__qualname__,
                        "native_contexts": len(entry.resources.contexts),
                        "native_context_input_rows": [
                            context.input_ids.shape[0]
                            if context.input_ids is not None
                            else 0
                            for context in entry.resources.contexts
                        ],
                        "pipeline_allocated": entry.resources.pipeline is not None,
                        "bank_addresses": addresses,
                    }
                )
            else:
                assert retained_addresses[decision.key.digest] == addresses
        transaction = {
            "id": plan.transaction_id,
            "phase": decision.phase,
            "reason": decision.reason,
            "key": decision.key.digest if decision.key is not None else None,
            "target_query_len": target_shape.target_query_len,
            "key_uniform_token_count": (
                decision.key.uniform_token_count if decision.key is not None else None
            ),
            "key_max_query_len": (
                decision.key.max_query_len if decision.key is not None else None
            ),
            "padded_tokens_by_stage": tuple(
                stage.attention_padded_tokens[0] for stage in plan.stages
            ),
            "valid_tokens_by_stage": tuple(
                stage.attention_valid_tokens[0] for stage in plan.stages
            ),
            "python_body_executed": any(
                call["parent"] == plan.transaction_id for call in host_calls
            ),
        }
        if profile_dir is not None:
            status = runner.prof.status()
            slot = len(report["transactions"])
            assert status["steps"] == slot and status["applied"]
            transaction["profiler"] = {
                "scope": f"{NATIVE_FFN_PROFILE_SCOPE_PREFIX}{slot}",
                "owner_steps_before_step": status["steps"],
                "expected_device_matmul_count": (
                    0
                    if decision.phase == "capture"
                    else len(plan.layer_indices)
                    * sum(rows > 0 for rows in decision.padded_tokens)
                ),
            }
        report["transactions"].append(transaction)

    def observe_close():
        service = runner.hccl_v41_graph_service
        assert service.acknowledged_stop and service.cache.closed
        lifecycle.append("graph-cache-closed-before-groups")
        actual_close()
        lifecycle.append("groups-closed")

    # Observation of public host boundaries only, with the same real methods
    # owning synchronization/COMPLETE/group destruction and original errors.
    transport.finish_forward, transport.close = observe_finish, observe_close
    try:
        worker.start_ffn_server_loop()
        service = runner.hccl_v41_graph_service
        assert service is not None and service.graph_factory is torch.npu.NPUGraph
        assert service.overlap_settings == connector.overlap_settings
        assert transport.initialized
        assert (
            transport.negotiated_capabilities.target_query_len
            == target_shape.target_query_len
        )
        report["target_shape_binding"].update(
            {
                "initialized_at_observation": transport.initialized,
                "negotiated_query_len": (
                    transport.negotiated_capabilities.target_query_len
                ),
                "actual_worker_binding_validated": True,
            }
        )
        detail["factory_service_and_worker_daemon_executed"] = True
        detail["default_npugraph_factory_verified"] = True
        lifecycle.append("factory-service-bound-and-daemon-started")
        while worker.poll_hccl_ffn_service():
            time.sleep(SERVICE_POLL_SECONDS)
        if profile_dir is not None:
            status = runner.prof.status()
            detail["profiler"]["status_when_poll_stopped"] = status
            detail["profiler"]["poll_stopped_host_monotonic_ns"] = time.monotonic_ns()
            assert status["closed"] and not status["failed"]
            assert not status["applied"] and not status["pending"]
            assert status["steps"] == NATIVE_FFN_TRANSACTION_COUNT
            assert status["owner_thread_id"] != management_thread
            assert status["owner_thread_id"] == host_calls[0]["serving_thread_id"]
            assert len(detail["profiler"]["execution_scopes"]) == (
                NATIVE_FFN_TRANSACTION_COUNT + 1
            )
            lifecycle.append("profiler-owner-finished-before-management-stop")
        lifecycle.append("peer-stop-acknowledged")
        worker.stop_ffn_server_loop()
        lifecycle.append("daemon-joined-and-service-closed")
        assert worker.poll_hccl_ffn_service() is False
        assert service.cache.closed and service.cache.is_empty and transport.closed
        assert len(detail["captured_entries"]) == len(CAPTURE_SIZES) * 2
        assert all(call["phase"] != "replay" for call in host_calls)
        assert {call["serving_thread_id"] for call in host_calls} != {management_thread}
        detail["acknowledged_stop"] = True
        detail["cache_closed"] = True
    except RuntimeError as error:
        if not fail_eager or error.__cause__ is not injected_error:
            raise
        contract = detail["fault_contract"]
        assert contract["injection_observed"]
        contract["public_errors"] = {
            "first_poll": {
                "type": type(error).__name__,
                "message": str(error),
                "cause_is_original_error": True,
            }
        }
        for name, operation in (
            ("repeated_poll", worker.poll_hccl_ffn_service),
            ("stop", worker.stop_ffn_server_loop),
        ):
            try:
                operation()
            except RuntimeError as repeated:
                assert repeated.__cause__ is injected_error
                contract["public_errors"][name] = {
                    "type": type(repeated).__name__,
                    "message": str(repeated),
                    "cause_is_original_error": True,
                }
            else:
                raise AssertionError(f"failed FFN service accepted {name}")
        try:
            service.close()
        except RuntimeError as close_error:
            assert "acknowledged idle STOP" in str(close_error)
            contract["service_close_error"] = str(close_error)
        else:
            raise AssertionError("failed FFN service closed retained graph cache")
        assert not service.acknowledged_stop
        assert service.cache.terminal and not service.cache.closed
        assert not service.cache.is_empty
        assert transport.terminal and not transport.closed
        assert lifecycle == ["factory-service-bound-and-daemon-started"]
        assert worker._ffn_thread is not None and not worker._ffn_thread.is_alive()
        retained_banks = [
            {
                "key": entry.key.digest,
                "bank_addresses": bank_addresses(entry.resources.bank),
            }
            for entry in retained_entries
        ]
        assert len(retained_banks) == len(CAPTURE_SIZES) * 2
        assert all(
            item["bank_addresses"] == retained_addresses[item["key"]]
            for item in retained_banks
        )
        contract.update(
            {
                "acknowledged_stop": service.acknowledged_stop,
                "cache_terminal": service.cache.terminal,
                "cache_closed": service.cache.closed,
                "cache_nonempty": not service.cache.is_empty,
                "transport_terminal": transport.terminal,
                "transport_closed": transport.closed,
                "serving_thread_exited": True,
                "retained_banks": retained_banks,
                "bank_addresses_match_capture": True,
                "retained_entry_reference_owner": "probe capture observer",
                "group_close_observed": False,
                "native_worker_shutdown_executed": False,
            }
        )
        report["expected_failure_observed"] = True
        # Preserve the actual compute exception, failed worker exit and blocked
        # peer for the process supervisor. No STOP/abort or group teardown here.
        raise injected_error from None
    finally:
        service = runner.hccl_v41_graph_service
        detail["transport_closed"] = transport.closed
        detail["transport_terminal"] = transport.terminal
        detail["serving_thread_alive"] = (
            worker._ffn_thread is not None and worker._ffn_thread.is_alive()
        )
        if service is not None:
            detail["cache_closed"] = service.cache.closed
            detail["cache_terminal"] = service.cache.terminal
        if profile_dir is not None:
            detail["profiler"]["final_owner_status"] = runner.prof.status()


def dspark_metadata_record(config, shape):
    """Describe normalized metadata, without constructing either model."""
    speculative = config.speculative_config
    target = config.model_config.hf_text_config
    draft = speculative.draft_model_config
    text = draft.hf_text_config
    return {
        "speculative_config_type": type(speculative).__qualname__,
        "target_checkpoint": config.model_config.model,
        "draft_checkpoint": draft.model,
        "method": speculative.method,
        "num_speculative_tokens": speculative.num_speculative_tokens,
        "target_query_len": shape.target_query_len,
        "draft_enforce_eager": speculative.enforce_eager,
        "adaptive_verification": speculative.enable_adaptive_verification,
        "target_num_hidden_layers": target.num_hidden_layers,
        "target_hidden_size": target.hidden_size,
        "target_vocab_size": target.vocab_size,
        "target_aux_layer_ids": list(target.dspark_target_layer_ids),
        "target_dspark_block_size": target.dspark_block_size,
        "target_num_nextn_predict_layers": target.num_nextn_predict_layers,
        "draft_architectures": list(draft.architectures),
        "draft_aux_layer_ids": list(text.dspark_target_layer_ids),
        "draft_n_mtp_layers": text.n_mtp_layers,
        "draft_n_routed_experts": text.n_routed_experts,
        "draft_num_experts_per_tok": text.num_experts_per_tok,
    }


def prepare_native_ffn_target(config, *, target_query_len, layer_count):
    """Validate checkpoint metadata, then declare the smaller arithmetic fixture.

    Only Q3 constructs the actual native DSpark configuration. The independent
    component copies keep the checkpoint's normalized draft metadata auditable;
    their explicit two-layer/aux override is not checkpoint execution evidence.
    """
    from afd_plugin.compat.npu.runtime_config import (
        resolve_deepseek_v41_target_shape,
        validate_deepseek_v41_graph_speculation,
    )

    original = None
    original_shape = None
    if target_query_len != 1:
        from vllm.config import SpeculativeConfig

        config.speculative_config = SpeculativeConfig(
            method="dspark",
            num_speculative_tokens=target_query_len - 1,
            target_model_config=config.model_config,
            target_parallel_config=config.parallel_config,
            enforce_eager=True,
            enable_adaptive_verification=False,
        )
        original_shape = validate_deepseek_v41_graph_speculation(config)
        assert original_shape.target_query_len == target_query_len
        original = dspark_metadata_record(config, original_shape)
        # The arithmetic fixture must not mutate the original checkpoint or
        # normalized draft metadata retained by this native configuration.
        config.model_config = deepcopy(config.model_config)
        config.speculative_config = deepcopy(config.speculative_config)
        config.speculative_config.target_model_config = config.model_config
        config.speculative_config.target_parallel_config = config.parallel_config

    text = config.model_config.hf_text_config
    text.hidden_size = HIDDEN_SIZE
    text.vocab_size = VOCAB_SIZE
    text.num_hidden_layers = layer_count
    if original is not None:
        component_aux_ids = list(range(1, layer_count + 1))
        text.dspark_target_layer_ids = component_aux_ids
        draft_text = config.speculative_config.draft_model_config.hf_text_config
        draft_text.hidden_size = HIDDEN_SIZE
        draft_text.vocab_size = VOCAB_SIZE
        draft_text.num_hidden_layers = layer_count
        draft_text.dspark_target_layer_ids = list(component_aux_ids)
        shape = validate_deepseek_v41_graph_speculation(config)
        assert shape == original_shape
        return original_shape, {
            "original_checkpoint": original,
            "controlled_component": dspark_metadata_record(config, shape),
            "metadata_only": True,
            "target_or_draft_model_constructed": False,
            "auxiliary_tensors_produced_or_consumed": False,
            "native_dspark_proposal_executed": False,
            "dspark_execution_accepted": False,
        }
    return resolve_deepseek_v41_target_shape(config), None


def run_worker(args):
    # Runtime imports are confined to isolated workers.
    if args.profile_native_ffn_service and args.rank == 0:
        os.environ.update(native_ffn_profiler_environment(args.output_dir))
    import numpy as np
    import torch
    import torch.distributed as dist
    import vllm_ascend.ops  # noqa: F401
    from vllm.config import CUDAGraphMode, set_current_vllm_config
    from vllm.distributed import (
        destroy_distributed_environment,
        destroy_model_parallel,
        get_tp_group,
        init_distributed_environment,
        initialize_model_parallel,
    )
    from vllm.platforms import current_platform
    from vllm.plugins import load_general_plugins
    from vllm.v1.kv_cache_interface import KVCacheConfig
    from vllm.v1.worker.gpu.cudagraph_utils import CudaGraphManager
    from vllm.v1.worker.gpu.input_batch import InputBatch, InputBuffers
    from vllm.v1.worker.gpu.model_runner import BatchReqState
    from vllm.v1.worker.gpu.ubatch_utils import create_ubatch_slices
    from vllm_ascend.ascend_config import init_ascend_config
    from vllm_ascend.utils import adapt_patch
    from vllm_ascend.worker.v2.utils import communicator_switch, torch_cuda_wrapper

    from afd_plugin.compat.patches.npu.mrv2_ubatching import use_npu_ubatch_sm_control
    from afd_plugin.connectors.npu.hccl_graph import (
        HcclGraphBuffers,
        HcclGraphEndpoint,
        HcclGraphExchange,
    )
    from afd_plugin.connectors.npu.hccl_graph_cache import HcclGraphCache
    from afd_plugin.connectors.npu.hccl_overlap import (
        HcclOverlapSelection,
        HcclOverlapSettings,
    )
    from afd_plugin.connectors.npu.hccl_staged_transport import HcclStagedTransport
    from afd_plugin.distributed.hccl_graph import HcclGraphReport
    from afd_plugin.distributed.hccl_plan import HcclLocalForward, HcclPlanCapabilities
    from afd_plugin.v1.worker.npu.hccl_v41_graph import (
        HcclV41GraphGeometry,
        HcclV41StageGeometry,
        preview_hccl_v41_geometry,
    )
    from afd_plugin.v1.worker.npu.hccl_v41_graph_control import HcclV41GraphControl
    from afd_plugin.v1.worker.npu.ubatch_runner import NPUUBatchRunner
    from tests.npu.hccl_staged_probe import build_config

    layers = tuple(range(args.layer_count))
    target_query_len = args.target_query_len
    capture_sizes = (
        CAPTURE_SIZES
        if target_query_len == 1
        else tuple(target_query_len * rows for rows in TARGET_REQUEST_BUCKETS)
    )
    device = torch.device("npu", args.devices[args.rank])
    role = "ffn" if args.rank == 0 else "attention"
    settings = (
        HcclOverlapSettings(
            eager_u2_stream_overlap=False,
            graph_u2_compute_overlap=bool(args.graph_compute),
            graph_u2_hybrid_dag=bool(args.graph_hybrid),
            graph_u2_attention_three_stream=bool(args.attention_three),
            graph_u2_ffn_recv_stream=bool(args.ffn_recv),
            graph_u2_ffn_cross_layer=bool(args.ffn_cross),
            stage_diagnostics=args.stage_diagnostics,
            ffn_compute_sync_diagnostics=False,
        )
        if args.graph_axes
        else None
    )
    report = {
        "rank": args.rank,
        "role": role,
        "device": str(device),
        "scope": "native base manager and HCCL phase/cache component",
        "checkpoint_weights_loaded": False,
        "engram_or_native_attention_executed": False,
        "transactions": [],
        "stage_bank": args.stage_bank,
        "compute_pipeline": args.compute_pipeline,
        "pipeline_hybrid": args.pipeline_hybrid,
        "exchange_order": args.exchange_order,
        "layer_count": args.layer_count,
        "target_query_len": target_query_len,
        "native_ffn_service_mode": args.native_ffn_service,
        "native_attention_owner_mode": args.native_attention_owner,
        "native_attention_lifecycle_mode": args.native_attention_lifecycle,
        "fail_native_attention_eager": args.fail_native_attention_eager,
        "fail_native_ffn_eager": args.fail_native_ffn_eager,
        "stage_diagnostics": args.stage_diagnostics,
        "capture_sizes": capture_sizes,
        "expected_transactions": (
            NATIVE_ATTENTION_FAILURE_COMPLETED_COUNT
            if args.fail_native_attention_eager
            else NATIVE_ATTENTION_LIFECYCLE_TRANSACTION_COUNT
            if args.native_attention_lifecycle
            else NATIVE_ATTENTION_TRANSACTION_COUNT
            if args.native_attention_owner
            else NATIVE_FFN_TRANSACTION_COUNT + int(target_query_len == 3)
            if args.native_ffn_service
            else BASE_TRANSACTION_COUNT + int(target_query_len == 3)
        ),
        "graph_axes": (
            {name: vars(args)[name] for name in GRAPH_AXIS_ARGUMENTS}
            if args.graph_axes
            else None
        ),
        "overlap_settings": settings.effective_settings()
        if settings is not None
        else None,
        "graph_selections": [],
        "bank_storage": [],
        "pipeline_storage": [],
    }
    transport = cache = connector = None
    manager = None
    input_buffers = None
    active = None
    counter = 0
    generation = 0
    captured_geometries = {}
    target_shape = None

    def native_check():
        value = torch.ones(1, device=device)
        dist.all_reduce(value, group=get_tp_group().device_group)
        assert value.item() == 1
        return value.cpu().tolist()

    def prepare_geometry(descriptor, real_tokens):
        # Actually construct the native input batch and call its native slice
        # helper after reservation. These controlled uniform dummy tensors exercise
        # geometry only; no runner/ModelState/history/attention is prepared.
        assert real_tokens % target_query_len == 0
        batch = InputBatch.make_dummy(
            real_tokens // target_query_len,
            real_tokens,
            input_buffers,
            max_query_len=target_query_len,
        )
        batch = replace(
            batch,
            num_reqs_after_padding=descriptor.num_reqs,
            num_tokens_after_padding=descriptor.num_tokens,
            input_ids=input_buffers.input_ids[: descriptor.num_tokens],
            positions=input_buffers.positions[: descriptor.num_tokens],
            is_padding=input_buffers.is_padding[: descriptor.num_tokens],
        )
        if descriptor.num_ubatches == 1:
            stages = (
                HcclV41StageGeometry(0, descriptor.num_reqs, 0, descriptor.num_tokens),
            )
        else:
            stages = tuple(
                HcclV41StageGeometry(
                    stage.request_slice.start,
                    stage.request_slice.stop,
                    stage.token_slice.start,
                    stage.token_slice.stop,
                )
                for stage in create_ubatch_slices(batch, descriptor.num_ubatches)
            )
        return HcclV41GraphGeometry(descriptor, stages)

    def make_batch_state(real_tokens):
        assert real_tokens % target_query_len == 0
        real_requests = real_tokens // target_query_len
        return BatchReqState(
            req_ids=[str(index) for index in range(real_requests)],
            num_tokens=real_tokens,
            num_scheduled_tokens=np.full(
                real_requests, target_query_len, dtype=np.int32
            ),
            idx_mapping_np=np.arange(real_requests, dtype=np.int32),
            prefill_len_np=np.zeros(real_requests, dtype=np.int32),
            num_computed_prefill_tokens_np=np.zeros(real_requests, dtype=np.int32),
            is_prefilling_np=np.zeros(real_requests, dtype=np.bool_),
            has_prefill=False,
        )

    def resolve(candidate):
        if candidate.key is None:
            return HcclGraphReport("unsupported")
        entry = cache.find(candidate.key, generation)
        return HcclGraphReport("ready" if entry is not None else "missing")

    def allocate(key, phase):
        if args.stage_bank:
            from afd_plugin.connectors.npu.hccl_graph_stage import HcclGraphStageBank

            bank = HcclGraphStageBank.allocate(transport, key, device=device)
            exchanges = tuple(exchange for _ in layers for exchange in bank.exchanges)
            # Only the bank is production exchange storage. These separate
            # probe buffers retain each layer's oracle inputs/outputs, so a
            # later layer cannot hide an earlier bad exchange by overwriting it.
            observations = tuple(
                HcclGraphBuffers.allocate(rows, HIDDEN_SIZE, device) if rows else None
                for _ in layers
                for rows in bank.stage_rows
            )
            pipeline, selection, produced, continuations = None, None, (), ()
            arithmetic_recurrence = args.compute_pipeline or args.graph_axes
            if arithmetic_recurrence:
                from afd_plugin.connectors.npu.hccl_graph_pipeline import (
                    HcclGraphComputePipeline,
                    HcclGraphPipelinePolicy,
                )

                if settings is not None:
                    selection = HcclOverlapSelection(
                        settings,
                        role,
                        "graph_warmup" if phase == "warmup" else "graph_capture",
                        len(bank.stage_rows),
                    )
                    policy = HcclGraphPipelinePolicy.from_selection(selection)
                    if policy is not None:
                        pipeline = HcclGraphComputePipeline.allocate(
                            bank, selection=selection
                        )
                    assert (pipeline is not None) == (
                        len(bank.stage_rows) > 1 and bool(args.graph_compute)
                    )
                    report["graph_selections"].append(
                        {
                            "key": key.digest,
                            "phase": phase,
                            "pipeline_allocated": pipeline is not None,
                            "selection": selection.diagnostic_record(),
                        }
                    )
                else:
                    pipeline = HcclGraphComputePipeline.allocate(
                        bank, hybrid=bool(args.pipeline_hybrid)
                    )
                if role == "attention":
                    produced = tuple(
                        HcclGraphBuffers.allocate(rows, HIDDEN_SIZE, device)
                        if rows
                        else None
                        for _ in layers
                        for rows in bank.stage_rows
                    )
                    continuations = tuple(
                        torch.empty_like(bank.buffers(stage).output) if rows else None
                        for stage, rows in enumerate(bank.stage_rows)
                    )
            if pipeline is not None:
                report["pipeline_storage"].append(
                    {
                        "key": key.digest,
                        "phase": phase,
                        "hybrid": pipeline.hybrid,
                        "attention_three_stream": (
                            pipeline.policy.attention_three_stream
                        ),
                        "ffn_recv_stream": pipeline.policy.ffn_recv_stream,
                        "ffn_cross_layer": pipeline.policy.ffn_cross_layer,
                        "compute_stream": int(pipeline.compute_stream.npu_stream),
                        "positive_steps": len(pipeline.step_events),
                        "tail_event_pairs": len(pipeline.tail_events),
                        "exchange_order": bank.exchange_order,
                        "static_wire_actions": [
                            [action.kind, action.layer_idx, action.stage_idx]
                            for action in pipeline.schedule.actions
                        ]
                        if pipeline.schedule is not None
                        else [],
                    }
                )
            tensors = bank_tensors(bank)
            storage_bytes = sum(
                tensor.numel() * tensor.element_size() for tensor in tensors
            )
            assert (
                storage_bytes
                == (8 * HIDDEN_SIZE + 9) * key.num_tokens + 4 * key.num_ubatches
            )
            report["bank_storage"].append({"key": key.digest, "bytes": storage_bytes})
            return GraphBundle(
                exchanges=exchanges,
                valid_counts=(),
                row_indices=(),
                bank=bank,
                observations=observations,
                bank_addresses=tuple(tensor.data_ptr() for tensor in tensors),
                pipeline=pipeline,
                selection=selection,
                arithmetic_recurrence=arithmetic_recurrence,
                produced=produced,
                continuations=continuations,
            )
        exchanges, valid_counts, row_indices = [], [], []
        for _layer in layers:
            for stage, rows in enumerate(key.padded_tokens):
                endpoint = HcclGraphEndpoint.from_process_group(
                    transport.data_groups[stage], 1 - args.rank
                )
                exchanges.append(
                    HcclGraphExchange(
                        endpoint,
                        HcclGraphBuffers.allocate(rows, HIDDEN_SIZE, device),
                        role=role,
                    )
                    if rows
                    else None
                )
                valid_counts.append(torch.zeros(1, dtype=torch.int32, device=device))
                row_indices.append(torch.arange(rows, device=device))
        return GraphBundle(tuple(exchanges), tuple(valid_counts), tuple(row_indices))

    def bank_tensors(bank):
        payloads = tuple(
            tensor
            for index, rows in enumerate(bank.stage_rows)
            if rows
            for tensor in (
                bank.buffers(index).hidden_states,
                bank.buffers(index).hidden_states_fp32,
                bank.buffers(index).input_ids,
                bank.buffers(index).output,
            )
        )
        return (*payloads, *bank.valid_counts, *bank.row_indices, *bank.padding_masks)

    def refill(bundle, plan, iteration):
        if bundle.bank is not None:
            bundle.bank.update_counts(plan)
        for index, exchange in enumerate(bundle.exchanges):
            if exchange is None:
                continue
            stage = plan.stages[index % len(plan.stages)]
            rows, valid = (
                stage.attention_padded_tokens[0],
                stage.attention_valid_tokens[0],
            )
            if bundle.bank is None:
                bundle.valid_counts[index].fill_(valid)
            if role == "attention":
                values = payload(torch, rows, valid, index, iteration)
                if bundle.bank is None:
                    exchange.update_inputs(
                        *(tensor.to(device) for tensor in values[:3])
                    )
                else:
                    observed = bundle.observations[index]
                    for target, value in zip(
                        (
                            observed.hidden_states,
                            observed.hidden_states_fp32,
                            observed.input_ids,
                        ),
                        values[:3],
                        strict=True,
                    ):
                        target.copy_(value.to(device))
                    # Deliberately dirty padded IDs; the captured bank body,
                    # rather than the external producer, must sanitize them.
                    observed.input_ids[valid:] = 127

    def body(bundle):
        # Tensor-only callback; no JSON, host cursor, COMPLETE or device readback.
        if bundle.arithmetic_recurrence:
            pipeline_body(bundle)
            return
        for index, exchange in enumerate(bundle.exchanges):
            if exchange is None:
                continue
            if bundle.bank is not None:
                bank, observed = bundle.bank, bundle.observations[index]
                stage_index = index % len(bank.stage_rows)
                if role == "attention":
                    output = bank.attention_exchange(
                        stage_index,
                        observed.hidden_states,
                        observed.hidden_states_fp32,
                        observed.input_ids,
                    )
                    observed.output.copy_(output)
                else:
                    inputs = bank.receive_inputs(stage_index)
                    output = (
                        inputs.hidden_states.float()
                        + (inputs.hidden_states_fp32 - inputs.hidden_states.float())
                        * ROUTER_SCALE
                        + inputs.input_ids[:, None].float()
                    ).bfloat16()
                    bank.send_output(stage_index, output)
                for target, source in zip(
                    (
                        observed.hidden_states,
                        observed.hidden_states_fp32,
                        observed.input_ids,
                    ),
                    (
                        exchange.buffers.hidden_states,
                        exchange.buffers.hidden_states_fp32,
                        exchange.buffers.input_ids,
                    ),
                    strict=True,
                ):
                    target.copy_(source)
                if role == "ffn":
                    observed.output.copy_(exchange.buffers.output)
                continue
            if role == "attention":
                exchange.send_inputs()
                exchange.receive_output()
            else:
                exchange.receive_inputs()
                buffers = exchange.buffers
                output = (
                    buffers.hidden_states.float()
                    + (buffers.hidden_states_fp32 - buffers.hidden_states.float())
                    * ROUTER_SCALE
                    + buffers.input_ids[:, None].float()
                ).bfloat16()
                buffers.output.copy_(
                    output.masked_fill(
                        bundle.row_indices[index][:, None]
                        >= bundle.valid_counts[index],
                        0,
                    )
                )
                exchange.send_output()

    def pipeline_body(bundle):
        bank, pipeline = bundle.bank, bundle.pipeline
        if bank.exchange_order == "cross_layer_v1":
            wavefront_body(bundle)
            return
        bulk = bank.exchange_order == "bulk_v1"
        if bulk:
            assert pipeline is not None
        positive = tuple(stage for stage, rows in enumerate(bank.stage_rows) if rows)
        with pipeline.run() if pipeline is not None else nullcontext():
            for layer_index, layer in enumerate(layers):
                if role == "attention":
                    for stage in positive:
                        index = layer_index * len(bank.stage_rows) + stage
                        observed = bundle.observations[index]
                        produced = bundle.produced[index]
                        previous = bank.buffers(stage).output if layer_index else None
                        dependencies = (
                            observed.hidden_states,
                            observed.hidden_states_fp32,
                            observed.input_ids,
                        ) + ((previous,) if previous is not None else ())
                        with (
                            pipeline.compute(layer, stage, inputs=dependencies)
                            if pipeline is not None
                            else nullcontext()
                        ):
                            if previous is None:
                                produced.hidden_states.copy_(observed.hidden_states)
                                produced.hidden_states_fp32.copy_(
                                    observed.hidden_states_fp32
                                )
                            else:
                                produced.hidden_states.copy_(
                                    observed.hidden_states.float() + previous.float()
                                )
                                produced.hidden_states_fp32.copy_(
                                    observed.hidden_states_fp32 + previous.float()
                                )
                            produced.input_ids.copy_(observed.input_ids)
                    for stage in positive:
                        index = layer_index * len(bank.stage_rows) + stage
                        produced = bundle.produced[index]
                        with (
                            (
                                pipeline.attention_send
                                if bulk
                                else pipeline.attention_exchange
                            )(
                                layer,
                                stage,
                                tensors=(
                                    produced.hidden_states,
                                    produced.hidden_states_fp32,
                                    produced.input_ids,
                                ),
                            )
                            if pipeline is not None
                            else nullcontext()
                        ):
                            if bulk:
                                bank.attention_send(
                                    stage,
                                    produced.hidden_states,
                                    produced.hidden_states_fp32,
                                    produced.input_ids,
                                )
                            else:
                                bank.attention_exchange(
                                    stage,
                                    produced.hidden_states,
                                    produced.hidden_states_fp32,
                                    produced.input_ids,
                                )
                                observe_bank(bundle, index, stage)
                    if bulk:
                        for stage in positive:
                            index = layer_index * len(bank.stage_rows) + stage
                            with pipeline.attention_receive(layer, stage):
                                bank.attention_receive(stage)
                                observe_bank(bundle, index, stage)
                else:
                    pending_outputs = []
                    for stage in positive:
                        index = layer_index * len(bank.stage_rows) + stage
                        with (
                            pipeline.ffn_receive(layer, stage)
                            if pipeline is not None
                            else nullcontext()
                        ):
                            inputs = bank.receive_inputs(stage)
                        with (
                            pipeline.compute(
                                layer,
                                stage,
                                inputs=(
                                    inputs.hidden_states,
                                    inputs.hidden_states_fp32,
                                    inputs.input_ids,
                                ),
                            )
                            if pipeline is not None
                            else nullcontext()
                        ):
                            output = (
                                inputs.hidden_states.float()
                                + (
                                    inputs.hidden_states_fp32
                                    - inputs.hidden_states.float()
                                )
                                * ROUTER_SCALE
                                + inputs.input_ids[:, None].float()
                            ).bfloat16()
                            if bulk:
                                output.record_stream(pipeline.compute_stream)
                                output = bank.prepare_output(stage, output)
                        if bulk:
                            pipeline.retain_compute_outputs(
                                layer, stage, tensors=(output,)
                            )
                            pending_outputs.append((stage, index, output))
                        else:
                            with (
                                pipeline.ffn_send(layer, stage, tensors=(output,))
                                if pipeline is not None
                                else nullcontext()
                            ):
                                bank.send_output(stage, output)
                                observe_bank(bundle, index, stage)
                    for stage, index, output in pending_outputs:
                        with pipeline.ffn_send(layer, stage, tensors=(output,)):
                            bank.send_output(stage, output)
                            observe_bank(bundle, index, stage)
                    if pipeline is not None and not pipeline.policy.ffn_cross_layer:
                        pipeline.join_layer(layer)
            join_pipeline(bundle, positive)

    def wavefront_body(bundle):
        bank, pipeline = bundle.bank, bundle.pipeline
        assert pipeline is not None and pipeline.schedule is not None
        positive = tuple(stage for stage, rows in enumerate(bank.stage_rows) if rows)
        pending = {}

        def prepare_attention(layer, stage):
            index = layers.index(layer) * len(bank.stage_rows) + stage
            observed, produced = bundle.observations[index], bundle.produced[index]
            previous = bank.buffers(stage).output if layer != layers[0] else None
            dependencies = (
                observed.hidden_states,
                observed.hidden_states_fp32,
                observed.input_ids,
            ) + ((previous,) if previous is not None else ())
            with pipeline.compute(layer, stage, inputs=dependencies):
                if previous is None:
                    produced.hidden_states.copy_(observed.hidden_states)
                    produced.hidden_states_fp32.copy_(observed.hidden_states_fp32)
                else:
                    produced.hidden_states.copy_(
                        observed.hidden_states.float() + previous.float()
                    )
                    produced.hidden_states_fp32.copy_(
                        observed.hidden_states_fp32 + previous.float()
                    )
                produced.input_ids.copy_(observed.input_ids)
            pipeline.retain_compute_outputs(
                layer,
                stage,
                tensors=(
                    produced.hidden_states,
                    produced.hidden_states_fp32,
                    produced.input_ids,
                ),
            )

        with pipeline.run():
            if role == "attention":
                for stage in positive:
                    prepare_attention(layers[0], stage)
            for action in pipeline.schedule.actions:
                layer, stage = action.layer_idx, action.stage_idx
                index = layers.index(layer) * len(bank.stage_rows) + stage
                if action.kind == "input":
                    if role == "attention":
                        if layer != layers[0]:
                            prepare_attention(layer, stage)
                        produced = bundle.produced[index]
                        with pipeline.attention_send(
                            layer,
                            stage,
                            tensors=(
                                produced.hidden_states,
                                produced.hidden_states_fp32,
                                produced.input_ids,
                            ),
                        ):
                            bank.attention_send(
                                stage,
                                produced.hidden_states,
                                produced.hidden_states_fp32,
                                produced.input_ids,
                            )
                    else:
                        with pipeline.ffn_receive(layer, stage):
                            inputs = bank.receive_inputs(stage)
                        with pipeline.compute(
                            layer,
                            stage,
                            inputs=(
                                inputs.hidden_states,
                                inputs.hidden_states_fp32,
                                inputs.input_ids,
                            ),
                        ):
                            output = (
                                inputs.hidden_states.float()
                                + (
                                    inputs.hidden_states_fp32
                                    - inputs.hidden_states.float()
                                )
                                * ROUTER_SCALE
                                + inputs.input_ids[:, None].float()
                            ).bfloat16()
                            output.record_stream(pipeline.compute_stream)
                            output = bank.prepare_output(stage, output)
                        pipeline.retain_compute_outputs(layer, stage, tensors=(output,))
                        pending[stage] = output
                elif role == "attention":
                    with pipeline.attention_receive(layer, stage):
                        bank.attention_receive(stage)
                        observe_bank(bundle, index, stage)
                else:
                    output = pending.pop(stage)
                    with pipeline.ffn_send(layer, stage, tensors=(output,)):
                        bank.send_output(stage, output)
                        observe_bank(bundle, index, stage)
            join_pipeline(bundle, positive)

    def join_pipeline(bundle, positive):
        bank, pipeline = bundle.bank, bundle.pipeline
        if role == "attention":
            for stage in positive:
                index = (len(layers) - 1) * len(bank.stage_rows) + stage
                previous = bank.buffers(stage).output
                produced = bundle.produced[index].hidden_states
                continuation = bundle.continuations[stage]
                with (
                    pipeline.final_compute(stage, inputs=(previous, produced))
                    if pipeline is not None
                    else nullcontext()
                ):
                    torch.add(previous, produced, out=continuation)
                    continuation.masked_fill_(bank.padding_masks[stage].unsqueeze(1), 0)
            if pipeline is not None:
                pipeline.join(
                    outputs=tuple(bundle.continuations[stage] for stage in positive)
                )
        elif pipeline is not None:
            pipeline.join(
                outputs=tuple(
                    observed.output
                    for observed in bundle.observations
                    if observed is not None
                )
            )

    def observe_bank(bundle, index, stage):
        observed, buffers = bundle.observations[index], bundle.bank.buffers(stage)
        for target, source in zip(
            (
                observed.hidden_states,
                observed.hidden_states_fp32,
                observed.input_ids,
                observed.output,
            ),
            (
                buffers.hidden_states,
                buffers.hidden_states_fp32,
                buffers.input_ids,
                buffers.output,
            ),
            strict=True,
        ):
            target.copy_(source)

    def verify(bundle, plan, iteration):
        if bundle.bank is not None:
            assert (
                tuple(tensor.data_ptr() for tensor in bank_tensors(bundle.bank))
                == bundle.bank_addresses
            )
        previous = {}
        last_inputs = {}
        for index, exchange in enumerate(bundle.exchanges):
            if exchange is None:
                continue
            stage = plan.stages[index % len(plan.stages)]
            values = payload(
                torch,
                stage.attention_padded_tokens[0],
                stage.attention_valid_tokens[0],
                index,
                iteration,
                previous.get(stage.stage_idx) if bundle.arithmetic_recurrence else None,
            )
            previous[stage.stage_idx] = values[3]
            last_inputs[stage.stage_idx] = values[0]
            buffers = (
                exchange.buffers if bundle.bank is None else bundle.observations[index]
            )
            for actual, expected in zip(
                (
                    buffers.hidden_states,
                    buffers.hidden_states_fp32,
                    buffers.input_ids,
                    buffers.output,
                ),
                values,
                strict=True,
            ):
                torch.testing.assert_close(actual.cpu(), expected, rtol=0, atol=0)
        if bundle.arithmetic_recurrence and role == "attention":
            for stage, output in enumerate(bundle.continuations):
                if output is None:
                    continue
                expected = previous[stage] + last_inputs[stage]
                expected[plan.stages[stage].attention_valid_tokens[0] :] = 0
                torch.testing.assert_close(output.cpu(), expected, rtol=0, atol=0)

    def complete_active():
        nonlocal active
        if active is None:
            return
        desc, decision, bundle, plan = active
        torch.npu.synchronize(device)
        if decision.phase == "warmup":
            verify(bundle, plan, 0)
        if decision.phase == "capture":
            # Native manager has inserted the completed graph by this boundary.
            # Its factory/active tuple retained every dependency until handoff.
            cache.reserve_capture(
                decision.key, generation, manager.graphs[desc], bundle
            )
            cache.publish_capture(decision.key, generation)
        transport.complete_graph_forward(decision.key)
        report["transactions"].append(
            {
                "id": plan.transaction_id,
                "phase": decision.phase,
                "key": decision.key.digest,
            }
        )
        active = None

    def eager(plan, iteration):
        for layer_index, layer in enumerate(layers):
            for stage in plan.stages:
                rows = stage.attention_padded_tokens[0]
                if not rows:
                    continue
                coordinate = layer_index * len(plan.stages) + stage.stage_idx
                values = payload(
                    torch, rows, stage.attention_valid_tokens[0], coordinate, iteration
                )
                if role == "attention":
                    transport.send_layer_inputs(
                        layer,
                        stage.stage_idx,
                        *(tensor.to(device) for tensor in values[:3]),
                    )
                    output = transport.receive_layer_output(layer, stage.stage_idx)
                else:
                    inputs = transport.receive_layer(layer, stage.stage_idx)
                    for actual, expected in zip(
                        (
                            inputs.hidden_states,
                            inputs.hidden_states_fp32,
                            inputs.input_ids,
                        ),
                        values[:3],
                        strict=True,
                    ):
                        torch.testing.assert_close(
                            actual.cpu(), expected, rtol=0, atol=0
                        )
                    output = values[3].to(device)
                    transport.send_layer_output(layer, stage.stage_idx, output)
                torch.testing.assert_close(output.cpu(), values[3], rtol=0, atol=0)
        transport.finish_forward()

    try:
        current_platform.pre_register_and_update()
        load_general_plugins()
        torch.npu.set_device(device)
        adapt_patch()
        config = build_config(1, args.model)
        config.parallel_config.ubatch_size = 2
        config.parallel_config.dbo_decode_token_threshold = 1
        config.compilation_config.cudagraph_capture_sizes = list(capture_sizes)
        config.compilation_config.max_cudagraph_capture_size = max(capture_sizes)
        if args.native_ffn_service:
            from afd_plugin.compat.npu.runtime_config import get_npu_ffn_config
            from afd_plugin.compat.patches.npu.ascend_config import (
                init_ascend_config as init_afd_ascend_config,
            )

            # Deliberately controlled component dimensions. The actual HF config
            # file supplies native configuration types, not checkpoint/model
            # execution evidence for this two-layer arithmetic fixture.
            config.model_config.enforce_eager = False
            config.scheduler_config.max_num_batched_tokens = CAPACITY
            config.scheduler_config.max_num_seqs = CAPACITY
            config.compilation_config.cudagraph_mode = CUDAGraphMode.FULL_DECODE_ONLY
            config.additional_config = {
                "afd": {
                    "connector": "P2pHcclAFDConnector",
                    "role": role,
                    "num_attention_ranks": 1,
                    "num_ffn_ranks": 1,
                    "port": args.port,
                    "afd_process_group_timeout_s": GROUP_TIMEOUT_SECONDS,
                    "connector_extra_config": {"max_tokens": CAPACITY},
                }
            }
            target_shape, dspark_metadata = prepare_native_ffn_target(
                config, target_query_len=target_query_len, layer_count=len(layers)
            )
            if args.native_attention_owner:
                from hccl_native_attention_probe import configure_native_attention

                configure_native_attention(config)
            assert target_shape.target_query_len == target_query_len
            if dspark_metadata is not None:
                report["dspark_target_metadata"] = dspark_metadata
            if role == "ffn":
                config = get_npu_ffn_config(config)
            init_afd_ascend_config(config)
            report["component_configuration"] = {
                "hidden_size": HIDDEN_SIZE,
                "vocab_size": VOCAB_SIZE,
                "layer_count": len(layers),
                "engram_config_present": config.engram_config is not None,
                "speculative_config_present": config.speculative_config is not None,
                "kv_transfer_config_present": config.kv_transfer_config is not None,
                "use_v2_model_runner": config.use_v2_model_runner,
                "model_enforce_eager": config.model_config.enforce_eager,
                "cudagraph_mode": config.compilation_config.cudagraph_mode.name,
                "checkpoint_model_constructed": False,
                "production_model_admission_executed": False,
                "target_query_len_resolved_before_role_isolation": (
                    target_shape.target_query_len
                ),
            }
        else:
            init_ascend_config(config)
        with (
            set_current_vllm_config(config),
            torch_cuda_wrapper(),
            torch.inference_mode(),
        ):
            init_distributed_environment(
                world_size=1,
                rank=0,
                local_rank=device.index,
                distributed_init_method=f"tcp://127.0.0.1:{args.port + 1 + args.rank}",
                backend="hccl",
                timeout=timedelta(seconds=GROUP_TIMEOUT_SECONDS),
            )
            initialize_model_parallel(tensor_model_parallel_size=1, backend="hccl")
            report["native_tp_before"] = native_check()
            if args.native_ffn_service:
                from afd_plugin.config import parse_afd_config
                from afd_plugin.connectors.npu.hccl_staged import (
                    create_npu_runtime_connector,
                )

                connector = create_npu_runtime_connector(
                    0,
                    device.index,
                    config,
                    parse_afd_config(config),
                    target_shape=target_shape,
                    overlap_settings=settings,
                )
                transport = connector.transport
            else:
                transport = HcclStagedTransport(
                    role,
                    0,
                    HcclPlanCapabilities(
                        HIDDEN_SIZE,
                        VOCAB_SIZE,
                        CAPACITY,
                        layers,
                        1,
                        1,
                        local_counts_version=1,
                        graph_execution_version=1,
                        graph_exchange_order=args.exchange_order,
                        target_query_len=target_query_len,
                    ),
                    init_method=f"tcp://127.0.0.1:{args.port}",
                    local_device=device.index,
                    timeout_seconds=GROUP_TIMEOUT_SECONDS,
                )
            if not (args.native_ffn_service and role == "ffn"):
                transport.initialize()
            assert (
                transport.negotiated_capabilities.graph_exchange_order
                == args.exchange_order
            )
            assert (
                transport.negotiated_capabilities.target_query_len == target_query_len
            )
            if args.native_ffn_service:
                assert transport.capabilities.target_query_len == target_query_len
                report["target_shape_binding"] = {
                    "initialized_at_observation": transport.initialized,
                    "original_resolved_query_len": target_shape.target_query_len,
                    "local_hello_query_len": transport.capabilities.target_query_len,
                    "negotiated_query_len": (
                        transport.negotiated_capabilities.target_query_len
                    ),
                    "negotiated_graph_execution_version": (
                        transport.negotiated_capabilities.graph_execution_version
                    ),
                    "negotiated_layers": (
                        transport.negotiated_capabilities.layer_indices
                    ),
                }
            cache = (
                None
                if args.native_ffn_service and role == "ffn"
                else HcclGraphCache(lambda: torch.npu.synchronize(device))
            )
            if role == "attention" and args.native_attention_owner:
                from hccl_native_attention_probe import run_native_attention

                manager, cache = run_native_attention(
                    config,
                    connector,
                    device,
                    report,
                    lifecycle=args.native_attention_lifecycle,
                    fail_eager=args.fail_native_attention_eager,
                )
            elif role == "attention":
                # Real runner construction supplies native capture streams and
                # candidate U2 twins. No model-state methods or handoff threads
                # are used by this controlled callback (model_state is unused).
                with use_npu_ubatch_sm_control():
                    ubatches = NPUUBatchRunner(
                        config,
                        device,
                        None,
                        [],
                        KVCacheConfig(1, [], []),
                        16,
                        kernel_block_sizes=[],
                        timeout_s=GROUP_TIMEOUT_SECONDS,
                    )
                manager = CudaGraphManager(
                    config,
                    device,
                    CUDAGraphMode.FULL_DECODE_ONLY,
                    target_query_len,
                    ubatch_runner=ubatches,
                )
                input_buffers = InputBuffers(CAPACITY, CAPACITY, device)
                control = HcclV41GraphControl(
                    transport, manager, cache, lambda: generation
                )

                def factory(desc, warmup):
                    nonlocal counter, active
                    complete_active()
                    counter += 1
                    reservation = control.reserve_capture(
                        desc,
                        warmup=warmup,
                        transaction_id=f"capture-{counter}",
                    )
                    assert reservation is not None
                    decision = reservation.decision
                    key = decision.key
                    prepared = prepare_geometry(desc, desc.num_tokens)
                    captured_geometries[desc] = prepared
                    if target_query_len == 3 and desc.num_tokens == 9:
                        assert desc.num_reqs == 3
                        if desc.num_ubatches == 2:
                            assert prepared.stages == (
                                HcclV41StageGeometry(0, 2, 0, 4),
                                HcclV41StageGeometry(1, 3, 4, 9),
                            )
                    control.verify_prepared(reservation, prepared)
                    plan = transport.submit_forward(
                        HcclLocalForward(
                            "warmup", (0,) * len(key.stage_layouts), key.padded_tokens
                        ),
                        transaction_id=decision.transaction_id,
                    )
                    bundle = allocate(key, decision.phase)
                    refill(bundle, plan, 0)
                    active = desc, decision, bundle, plan
                    return lambda cg_mode: body(bundle)

                with communicator_switch():
                    manager.capture(factory, progress_bar_desc="AFD paired component")
                complete_active()
                captured = tuple(manager.graphs)
                assert len(captured) == len(capture_sizes) * 2
                assert {desc.num_ubatches for desc in captured} == {1, 2}
                # Full exact geometry replays, then an A same-bucket/different
                # request-layout miss selects eager. The legacy component also
                # simulates an F generation miss; the factory service keeps its
                # genuine immutable storage generation and excludes that case.
                cases = [(desc, desc.num_tokens, "captured") for desc in captured]
                if not args.native_ffn_service:
                    cases.extend(
                        [(captured[-1], captured[-1].num_tokens, "ffn-generation-miss")]
                    )
                cases.append(
                    (
                        next(
                            desc
                            for desc in captured
                            if desc.num_tokens == min(capture_sizes)
                            and desc.num_ubatches == 2
                        ),
                        2 if target_query_len == 1 else target_query_len,
                        "request-layout-miss",
                    )
                )
                if target_query_len == 3:
                    cases.append(
                        (
                            next(
                                desc
                                for desc in captured
                                if desc.num_tokens == 9 and desc.num_ubatches == 2
                            ),
                            2 * target_query_len,
                            "short-same-key",
                        )
                    )
                for case_index, (wanted, real_tokens, kind) in enumerate(cases):
                    force_ffn_miss = kind == "ffn-generation-miss"
                    geometry_miss = kind == "request-layout-miss"
                    short_replay = kind == "short-same-key"
                    config.parallel_config.dbo_decode_token_threshold = (
                        1 if wanted.num_ubatches == 2 else CAPACITY
                    )
                    state = make_batch_state(real_tokens)
                    if target_query_len == 3 and geometry_miss:
                        # Actual R1/T3 is padded to the captured R3/T9 bucket,
                        # but native clamping moves child 1's request start.
                        preview = preview_hccl_v41_geometry(
                            state, wanted, target_query_len=target_query_len
                        )
                        assert preview.stages == (
                            HcclV41StageGeometry(0, 2, 0, 4),
                            HcclV41StageGeometry(0, 3, 4, 9),
                        )
                        assert control.key_for(preview) != control.key_for(
                            captured_geometries[wanted]
                        )
                    fixed_replay_key = None
                    for iteration in range(1 if short_replay else REPLAYS):
                        if short_replay:
                            # R2/T6 retains the actual captured request slices;
                            # unlike R1/T3 it must replay the same bank/key.
                            preview = preview_hccl_v41_geometry(
                                state,
                                wanted,
                                target_query_len=target_query_len,
                            )
                            assert control.key_for(preview) == control.key_for(
                                captured_geometries[wanted]
                            )
                        transaction = f"replay-{case_index}-{iteration}"
                        # This flag is an explicit probe schedule communicated
                        # as iteration identity; production has no bypass knob.
                        if force_ffn_miss:
                            transaction += "-ffn-generation-miss"
                        reservation = control.reserve_batch(
                            state,
                            parallel_config=config.parallel_config,
                            allow_ubatching=wanted.num_ubatches == 2,
                            max_query_len=target_query_len,
                            transaction_id=transaction,
                        )
                        assert reservation is not None
                        decision, geometry = reservation.decision, reservation.geometry
                        key = decision.key
                        prepared = prepare_geometry(geometry.descriptor, real_tokens)
                        control.verify_prepared(reservation, prepared)
                        controlled_valid = real_tokens
                        if (
                            (args.compute_pipeline or args.graph_axes)
                            and not force_ffn_miss
                            and not geometry_miss
                            and not short_replay
                        ):
                            # Keep the native dummy's physical request/token
                            # geometry fixed. Only this controlled component's
                            # device-valid scalars and oracle payloads vary.
                            controlled_valid = (
                                real_tokens,
                                1,
                                real_tokens - 1,
                            )[iteration]
                            assert decision.phase == "replay"
                            assert geometry.descriptor == wanted
                            if fixed_replay_key is None:
                                fixed_replay_key = key
                            assert key == fixed_replay_key
                        valid = tuple(
                            max(
                                0,
                                min(stage.token_stop, controlled_valid)
                                - stage.token_start,
                            )
                            for stage in geometry.stages
                        )
                        plan = transport.submit_forward(
                            HcclLocalForward("target", valid, decision.padded_tokens),
                            transaction_id=transaction,
                        )
                        assert (
                            tuple(
                                stage.attention_valid_tokens[0] for stage in plan.stages
                            )
                            == valid
                        )
                        assert sum(valid) == controlled_valid
                        if short_replay:
                            assert controlled_valid == 6
                            assert valid == (4, 2)
                            assert decision.padded_tokens == (4, 5)
                        if force_ffn_miss or geometry_miss:
                            assert decision.phase == "eager"
                        else:
                            assert decision.phase == "replay"
                        if decision.phase == "eager":
                            eager(plan, iteration)
                        else:
                            entry = cache.find(key, generation)
                            assert entry is not None
                            refill(entry.resources, plan, iteration)
                            manager.run_fullgraph(geometry.descriptor)
                            torch.npu.synchronize(device)
                            verify(entry.resources, plan, iteration)
                            transport.complete_graph_forward(key)
                        report["transactions"].append(
                            {
                                "id": transaction,
                                "phase": decision.phase,
                                "reason": decision.reason,
                                "native_input_batch_geometry_verified": True,
                                "key": key.digest if key is not None else None,
                                "controlled_valid_tokens": controlled_valid,
                                "valid_tokens_by_stage": valid,
                                "padded_tokens_by_stage": decision.padded_tokens,
                                "native_num_requests": len(state.req_ids),
                                "native_num_tokens": real_tokens,
                                "target_query_len": target_query_len,
                                "short_batch_same_key": short_replay,
                                "case": kind,
                                "native_stage_geometry": [
                                    [
                                        stage.request_start,
                                        stage.request_stop,
                                        stage.token_start,
                                        stage.token_stop,
                                    ]
                                    for stage in prepared.stages
                                ],
                            }
                        )
                transport.stop_attention()
            elif args.native_ffn_service:
                run_native_ffn_service(
                    torch,
                    config,
                    connector,
                    device,
                    report,
                    target_shape=target_shape,
                    fail_eager=args.fail_native_ffn_eager,
                    profile_dir=(args.output_dir / "traces")
                    if args.profile_native_ffn_service
                    else None,
                )
            else:
                while True:
                    # Transaction IDs are intentionally not visible to the
                    # resolver. Alternate the local generation only through a
                    # known component schedule after the captured replays.
                    target_count = sum(
                        r["id"].startswith("replay-") for r in report["transactions"]
                    )
                    miss_start = len(capture_sizes) * 2 * REPLAYS
                    generation = int(miss_start <= target_count < miss_start + REPLAYS)
                    decision = transport.receive_graph_reservation(resolve)
                    if decision is None:
                        break
                    plan = transport.receive_forward()
                    assert plan is not None
                    iteration = (
                        int(decision.transaction_id.split("-")[2])
                        if decision.transaction_id.startswith("replay-")
                        else 0
                    )
                    if decision.phase == "eager":
                        eager(plan, iteration)
                    elif decision.phase == "replay":
                        entry = cache.find(decision.key, generation)
                        assert entry is not None
                        refill(entry.resources, plan, iteration)
                        entry.graph.replay()
                        torch.npu.synchronize(device)
                        verify(entry.resources, plan, iteration)
                        transport.complete_graph_forward(decision.key)
                    else:
                        bundle = allocate(decision.key, decision.phase)
                        refill(bundle, plan, 0)
                        if decision.phase == "warmup":
                            body(bundle)
                        else:
                            graph = torch.npu.NPUGraph()
                            cache.reserve_capture(
                                decision.key, generation, graph, bundle
                            )
                            with torch.npu.graph(graph):
                                body(bundle)
                            cache.publish_capture(decision.key, generation)
                        torch.npu.synchronize(device)
                        if decision.phase == "warmup":
                            verify(bundle, plan, 0)
                        transport.complete_graph_forward(decision.key)
                    report["transactions"].append(
                        {
                            "id": decision.transaction_id,
                            "phase": decision.phase,
                            "reason": decision.reason,
                            "key": decision.key.digest
                            if decision.key is not None
                            else None,
                            "controlled_valid_tokens": sum(
                                stage.attention_valid_tokens[0] for stage in plan.stages
                            ),
                            "valid_tokens_by_stage": tuple(
                                stage.attention_valid_tokens[0] for stage in plan.stages
                            ),
                            "padded_tokens_by_stage": decision.padded_tokens,
                        }
                    )
            if cache is not None:
                cache.close()
            if manager is not None:
                manager.graphs.clear()
            if not (args.native_ffn_service and role == "ffn"):
                transport.close()
            report["native_tp_after_close"] = native_check()
            assert len(report["transactions"]) == report["expected_transactions"]
            report["status"] = "passed"
    except BaseException as exc:
        if cache is not None:
            cache.fail()
        if transport is not None:
            transport.terminal = True
        report["status"] = "failed"
        report["error"] = {"type": type(exc).__name__, "message": str(exc)}
        traceback.print_exc()
        raise
    finally:
        (args.output_dir / f"rank-{args.rank}.json").write_text(
            json.dumps(report, indent=2) + "\n"
        )
        # Failure cleanup is left to this probe's bounded supervisor; a device
        # exception does not make a graph/group destruct sequence safe to retry.
        if report.get("status") == "passed":
            destroy_model_parallel()
            destroy_distributed_environment()


def inspect_native_ffn_profile(output_dir, device):
    # Optional supervisor-only parsing reuses the independently reviewed device
    # MatMul/CSV checks without importing torch in this process.
    import afd_profiler_probe as profiler_helpers

    trace_root = output_dir / "traces"
    traces = sorted(trace_root.rglob("trace_view.json"))
    assert len(traces) == 1, "expected exactly one owner-exported F trace"
    trace_path = traces[0]
    csv_path = trace_path.with_name("kernel_details.csv")
    report = json.loads((output_dir / "rank-0.json").read_text(encoding="utf-8"))
    detail = report["native_ffn_service"]["profiler"]
    transactions = report["transactions"]
    assert report["status"] == "passed"
    assert len(transactions) == NATIVE_FFN_TRANSACTION_COUNT
    assert len({parent["id"] for parent in transactions}) == len(transactions)
    parsed = profiler_helpers.inspect_trace(trace_path, csv_path, device)
    assert "parse_error" not in parsed, parsed
    assert parsed["csv_matches_trace"], "device MatMul CSV and trace differ"
    assert parsed["npu_matmul_kernel_events"] == detail["expected_device_matmul_count"]
    content = json.loads(trace_path.read_text(encoding="utf-8"))
    events = content["traceEvents"] if isinstance(content, dict) else content
    hardware_ids = set(parsed["hardware_process_ids"])
    matmuls = [
        event
        for event in events
        if event.get("pid") in hardware_ids
        and event.get("ph") == "X"
        and event.get("args", {}).get("Task Type") == "AI_CORE"
        and "matmul" in event.get("name", "").casefold()
    ]
    communication = [
        event
        for event in events
        if event.get("pid") in hardware_ids
        and event.get("ph") == "X"
        and event.get("args", {}).get("Task Type") == "AI_CPU"
        and event.get("name") in ("receiveAicpuKernel", "sendAicpuKernel")
    ]
    with csv_path.open(encoding="utf-8-sig", newline="") as handle:
        csv_rows = list(csv.DictReader(handle))
    csv_matmuls = parsed["csv_kernel_rows"]
    csv_communication = [
        row
        for row in csv_rows
        if row["Device_id"] == str(device)
        and row["Accelerator Core"] == "AI_CPU"
        and row["Name"] in ("receiveAicpuKernel", "sendAicpuKernel")
    ]

    def trace_tasks(selected):
        return Counter(
            (
                event["name"],
                int(event["args"]["Model Id"]),
                int(event["args"]["Task Id"]),
                int(event["tid"]),
                Decimal(str(event["ts"])),
                Decimal(str(event["dur"])),
            )
            for event in selected
        )

    def csv_tasks(selected):
        return Counter(
            (
                row["Name"],
                int(row["Model ID"]),
                int(row["Task ID"]),
                int(row["Stream ID"]),
                Decimal(row["Start Time(us)"].strip()),
                Decimal(row["Duration(us)"].strip()),
            )
            for row in selected
        )

    assert trace_tasks(matmuls) == csv_tasks(csv_matmuls)
    assert communication and trace_tasks(communication) == csv_tasks(csv_communication)
    scopes = detail["execution_scopes"]
    owner_native_ids = {scope["owner_native_thread_id"] for scope in scopes}
    owner_ids = {scope["owner_thread_id"] for scope in scopes}
    assert len(owner_native_ids) == len(owner_ids) == 1
    assert owner_native_ids != {detail["management_native_thread_id"]}
    assert owner_ids == {detail["final_owner_status"]["owner_thread_id"]}
    assert scopes[-1]["continued"] is False
    assert scopes[-1]["owner_steps_before_step"] == len(transactions)
    assert not detail["stop_returned"]["trace_views_before_owner_finish"]
    assert detail["final_owner_status"]["closed"]
    assert not detail["final_owner_status"]["failed"]
    assert detail["final_owner_status"]["steps"] == len(transactions)
    cpu_events = [
        event
        for event in events
        if event.get("ph") == "X"
        and event.get("pid") == detail["pid"]
        and event.get("tid") in owner_native_ids
    ]
    profiler_steps = [
        event
        for event in cpu_events
        if event.get("name", "").startswith("ProfilerStep#")
    ]

    def within(event, scope):
        start = Decimal(str(scope["ts"]))
        end = start + Decimal(str(scope["dur"]))
        event_start = Decimal(str(event["ts"]))
        return start <= event_start and event_start + Decimal(str(event["dur"])) <= end

    observed, phase_counts, assigned, step_offsets = [], Counter(), 0, set()
    for index, parent in enumerate(transactions):
        mapping = parent["profiler"]
        assert mapping["owner_steps_before_step"] == index
        scope_name = mapping["scope"]
        assert scope_name == scopes[index]["name"]
        assert scopes[index]["continued"] is True
        matching = [event for event in cpu_events if event.get("name") == scope_name]
        assert len(matching) == 1, f"missing/duplicate actual CPU scope {scope_name}"
        scope = matching[0]
        matching_steps = [step for step in profiler_steps if within(scope, step)]
        assert len(matching_steps) == 1, f"ambiguous profiler step for {parent['id']}"
        step = matching_steps[0]
        step_id = int(step["name"].removeprefix("ProfilerStep#"))
        step_offsets.add(step_id - mapping["owner_steps_before_step"])
        kernels = [event for event in matmuls if within(event, scope)]
        communication_tasks = [event for event in communication if within(event, scope)]
        # Graph tasks can retain their recording-step ID across replay. Match
        # the actual task interval and identity; keep CSV Step Id as metadata.
        kernel_rows = [
            row
            for row in csv_matmuls
            if within({"ts": row["Start Time(us)"], "dur": row["Duration(us)"]}, scope)
        ]
        assert len(kernels) == mapping["expected_device_matmul_count"], parent
        assert trace_tasks(kernels) == csv_tasks(kernel_rows), parent
        cpu_mm = [
            event
            for event in cpu_events
            if event.get("name") == "aten::mm" and within(event, scope)
        ]
        if parent["phase"] == "replay":
            assert not parent["python_body_executed"] and not cpu_mm
            assert kernels, "replay must execute actual device MatMul kernels"
        if kernels:
            assert {event["name"] for event in communication_tasks} == {
                "receiveAicpuKernel",
                "sendAicpuKernel",
            }, f"missing device HCCL payload tasks for {parent['id']}"
        phase_counts[parent["phase"]] += len(kernels)
        assigned += len(kernels)
        observed.append(
            {
                "transaction_id": parent["id"],
                "phase": parent["phase"],
                "key": parent["key"],
                "cpu_scope": scope_name,
                "profiler_step": step["name"],
                "csv_step_ids": sorted({row["Step Id"] for row in kernel_rows}),
                "owner_steps_before_step": mapping["owner_steps_before_step"],
                "device_matmul_count": len(kernels),
                "device_matmul_stream_ids": sorted({int(e["tid"]) for e in kernels}),
                "device_matmul_model_ids": sorted(
                    {int(e["args"]["Model Id"]) for e in kernels}
                ),
                "device_hccl_payload_task_count": len(communication_tasks),
                "device_hccl_payload_stream_ids": sorted(
                    {int(e["tid"]) for e in communication_tasks}
                ),
                "python_matmul_count": len(cpu_mm),
                "csv_matches_trace": True,
            }
        )
    assert len(step_offsets) == 1, "owner steps and actual ProfilerStep diverged"
    assert assigned == len(matmuls), "unassigned device MatMul outside parent scopes"
    assert dict(phase_counts) == detail["expected_device_matmul_by_phase"]
    source_root = Path(__file__).resolve().parents[2]
    return {
        "status": "passed",
        "scope": "actual F daemon owner / controlled Graph-HCCL-MatMul timeline",
        "source_sha256": {
            str(path.relative_to(source_root)): profiler_helpers.file_sha256(path)
            for path in (
                Path(__file__).resolve(),
                Path(profiler_helpers.__file__).resolve(),
                source_root / "afd_plugin/compat/npu/profiler.py",
            )
        },
        "trace_file_sha256": {
            str(path.relative_to(trace_root)): profiler_helpers.file_sha256(path)
            for path in sorted(trace_root.rglob("*"))
            if path.is_file()
        },
        "parsed_trace": parsed,
        "parents": observed,
        "actual_matmul_by_phase": dict(phase_counts),
        "actual_owner_step_offset": next(iter(step_offsets)),
        "csv_step_id_used_as_parent_identity": False,
        "actual_device_hccl_payload_csv_matches_trace": True,
        "physical_parent_vs_compute_stream_attribution_verified": False,
        "overlap_measured": False,
        "performance_accepted": False,
        "full_model_executed": False,
        "limits": [
            "Graph CSV Step Id can retain recording IDs during later replay.",
            "Communication device streams can differ from their parent launch stream.",
            "Native stream handles are not equated to profiler device Stream IDs.",
            "Stream inventories and replay do not establish overlap or speedup.",
            "Attention uses the existing arithmetic oracle and is not profiled.",
        ],
    }


def run_supervisor(args):
    from tests.npu.hccl_staged_probe import select_port_block

    args.output_dir.mkdir(parents=True, exist_ok=True)
    port = select_port_block(3)
    processes, handles = [], []
    started = time.monotonic()
    summary = {
        "scope": __doc__,
        "exit_codes": [],
        "supervisor_cleanup": [],
        "stage_bank": args.stage_bank,
        "compute_pipeline": args.compute_pipeline,
        "pipeline_hybrid": args.pipeline_hybrid,
        "exchange_order": args.exchange_order,
        "layer_count": args.layer_count,
        "target_query_len": args.target_query_len,
        "native_ffn_service_mode": args.native_ffn_service,
        "native_attention_owner_mode": args.native_attention_owner,
        "native_attention_lifecycle_mode": args.native_attention_lifecycle,
        "fail_native_attention_eager": args.fail_native_attention_eager,
        "fail_native_ffn_eager": args.fail_native_ffn_eager,
        "stage_diagnostics": args.stage_diagnostics,
        "expected_transactions_per_rank": (
            NATIVE_ATTENTION_FAILURE_COMPLETED_COUNT
            if args.fail_native_attention_eager
            else NATIVE_ATTENTION_LIFECYCLE_TRANSACTION_COUNT
            if args.native_attention_lifecycle
            else NATIVE_ATTENTION_TRANSACTION_COUNT
            if args.native_attention_owner
            else NATIVE_FFN_TRANSACTION_COUNT + int(args.target_query_len == 3)
            if args.native_ffn_service
            else BASE_TRANSACTION_COUNT + int(args.target_query_len == 3)
        ),
        "graph_axes": (
            {name: vars(args)[name] for name in GRAPH_AXIS_ARGUMENTS}
            if args.graph_axes
            else None
        ),
    }
    if args.profile_native_ffn_service:
        summary["profile_native_ffn_service"] = True
        summary["profiler_environment"] = native_ffn_profiler_environment(
            args.output_dir
        )
    try:
        for rank in range(2):
            handle = (args.output_dir / f"rank-{rank}.log").open("wb")
            handles.append(handle)
            command = [
                sys.executable,
                str(Path(__file__).resolve()),
                "--devices",
                ",".join(map(str, args.devices)),
                "--model",
                args.model,
                "--output-dir",
                str(args.output_dir),
                "--rank",
                str(rank),
                "--port",
                str(port),
                "--exchange-order",
                args.exchange_order,
                "--layer-count",
                str(args.layer_count),
                "--target-query-len",
                str(args.target_query_len),
            ]
            if args.stage_bank:
                command.append("--stage-bank")
            if args.native_ffn_service:
                command.append("--native-ffn-service")
            if args.native_attention_owner:
                command.append("--native-attention-owner")
            if args.native_attention_lifecycle:
                command.append("--native-attention-lifecycle")
            if args.fail_native_attention_eager:
                command.append("--fail-native-attention-eager")
            if args.fail_native_ffn_eager:
                command.append("--fail-native-ffn-eager")
            if args.profile_native_ffn_service:
                command.append("--profile-native-ffn-service")
            if args.stage_diagnostics:
                command.append("--stage-diagnostics")
            if args.compute_pipeline:
                command.extend(
                    [
                        "--compute-pipeline",
                        "--pipeline-hybrid",
                        str(args.pipeline_hybrid),
                    ]
                )
            if args.graph_axes:
                for name in GRAPH_AXIS_ARGUMENTS:
                    command.extend(
                        ["--" + name.replace("_", "-"), str(vars(args)[name])]
                    )
            processes.append(
                subprocess.Popen(
                    command,
                    stdout=handle,
                    stderr=subprocess.STDOUT,
                    start_new_session=True,
                )
            )
        while any(process.poll() is None for process in processes):
            failed = any(process.poll() not in (None, 0) for process in processes)
            if failed or time.monotonic() - started > args.timeout:
                summary["failure"] = "worker failure" if failed else "bounded timeout"
                break
            time.sleep(0.1)
    finally:
        for process in processes:
            if process.poll() is None:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGTERM)
                    summary["supervisor_cleanup"].append(
                        {"pid": process.pid, "signal": "SIGTERM"}
                    )
        for process in processes:
            try:
                process.wait(timeout=REAP_TIMEOUT_SECONDS)
            except subprocess.TimeoutExpired:
                with suppress(ProcessLookupError):
                    os.killpg(process.pid, signal.SIGKILL)
                    summary["supervisor_cleanup"].append(
                        {"pid": process.pid, "signal": "SIGKILL"}
                    )
                process.wait(timeout=REAP_TIMEOUT_SECONDS)
        for handle in handles:
            handle.close()
        summary["exit_codes"] = [process.returncode for process in processes]
        summary["elapsed_seconds"] = time.monotonic() - started
        summary["status"] = (
            "passed"
            if summary["exit_codes"] == [0, 0] and "failure" not in summary
            else "failed"
        )
        if args.fail_native_attention_eager:
            # Preserve raw failure/exit/supervision evidence. The separate
            # contract classifies only the deliberately observed A failure;
            # F supervision is never relabeled as clean STOP or recovery.
            contract = {
                "status": "failed",
                "native_attention_error_expected": (
                    EXPECTED_NATIVE_ATTENTION_EAGER_ERROR
                ),
                "clean_stop_verified": False,
                "fresh_process_recovery_verified": False,
                "worker_shutdown_executed": False,
            }
            try:
                attention = json.loads(
                    (args.output_dir / "rank-1.json").read_text(encoding="utf-8")
                )
                assert attention["status"] == "failed"
                assert attention["error"] == {
                    "type": "RuntimeError",
                    "message": EXPECTED_NATIVE_ATTENTION_EAGER_ERROR,
                }
                assert summary["exit_codes"][1] == 1
                assert len(attention["transactions"]) == (
                    NATIVE_ATTENTION_FAILURE_COMPLETED_COUNT
                )
                fault = attention["native_attention_owner"]["fault_contract"]
                assert fault["status"] == "passed"
                assert fault["original_error_identity_preserved"]
                assert fault["owner_resources_retained"]
                assert fault["stop_absent"] and fault["failed_parent_complete_absent"]
                contract["status"] = "passed"
                contract["attention_exit_code"] = summary["exit_codes"][1]
                contract["peer_exit_code"] = summary["exit_codes"][0]
                contract["peer_supervision"] = summary["supervisor_cleanup"]
            except (AssertionError, OSError, ValueError, KeyError) as error:
                contract["error"] = {
                    "type": type(error).__name__,
                    "message": str(error),
                }
            summary["expected_failure_contract"] = contract
        if args.profile_native_ffn_service and summary["status"] == "passed":
            try:
                summary["native_ffn_profile"] = inspect_native_ffn_profile(
                    args.output_dir, args.devices[0]
                )
            except Exception as error:
                summary["status"] = "failed"
                summary["native_ffn_profile"] = {
                    "status": "failed",
                    "error": {"type": type(error).__name__, "message": str(error)},
                }
                traceback.print_exc()
        (args.output_dir / "summary.json").write_text(
            json.dumps(summary, indent=2) + "\n"
        )
    return 0 if summary["status"] == "passed" else 1


if __name__ == "__main__":
    options = parse_args()
    if options.rank is None:
        raise SystemExit(run_supervisor(options))
    run_worker(options)
